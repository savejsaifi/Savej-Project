package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.adapter.PackageAdapter;
import com.avaskm.api.Api;
import com.avaskm.model.HistoryModel;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OrderDetailsActivity extends AppCompatActivity {

    SharedPreferences sharedOrderDetails;
    SharedPreferences sharedPreferences;
    TextView tv_cart_event_title, tv_cart_event_date, tv_cart_event_end_date,tvaddres, tv_cart_event_package, tv_pass_cart_event,
            tv_cart_event_total_price, edt_cart_event_name, edt_cart_event_email, edt_cart_event_mobile,
            tv_cart_event_ratio, tv_cart_event_taxprice,tv_subtotal_price;
    ImageView img_cart_event;
    String qrCode, token;
    Button buttonmark;

    private Dialog mDialogConfirmPopUp;
    Button btn_ok_pop_down_out_line;
    TextView txtMessage;
    ArrayList<HistoryModel> listOrderPackages;
    RecyclerView rv_pakage;
    PackageAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_order_details );

        sharedPreferences = getSharedPreferences( "LoginData", MODE_PRIVATE );
        token = sharedPreferences.getString( "token", "" );
        sharedOrderDetails = getSharedPreferences( "OrderDetails", MODE_PRIVATE );
        tv_cart_event_title = findViewById( R.id.tv_cart_event_title );
        tv_cart_event_date = findViewById( R.id.tv_cart_event_date );
        tv_cart_event_end_date = findViewById( R.id.tv_cart_event_end_date );
        tvaddres = findViewById( R.id.tvaddres );
       // tv_cart_event_package = findViewById( R.id.tv_cart_event_package );
        tv_pass_cart_event = findViewById( R.id.tv_pass_cart_event );
        tv_cart_event_total_price = findViewById( R.id.tv_cart_event_total_price );
        edt_cart_event_name = findViewById( R.id.edt_cart_event_name );
        edt_cart_event_email = findViewById( R.id.edt_cart_event_email );
        edt_cart_event_mobile = findViewById( R.id.edt_cart_event_mobile );
        tv_cart_event_ratio = findViewById( R.id.tv_cart_event_ratio );
        tv_cart_event_taxprice = findViewById( R.id.tv_cart_event_taxprice );
        tv_subtotal_price = findViewById( R.id.tv_subtotal_price );
        img_cart_event = findViewById( R.id.img_cart_event );
        buttonmark = findViewById( R.id.buttonmark );
        rv_pakage = findViewById( R.id.rv_pakage );

        listOrderPackages = getIntent().getParcelableArrayListExtra( "listOrderPackages" );
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager( getApplicationContext(),1 );
        rv_pakage.setLayoutManager( layoutManager );
        rv_pakage.setHasFixedSize( true );
        adapter= new PackageAdapter( listOrderPackages,getApplicationContext() );
        rv_pakage.setAdapter( adapter );
        Log.d( "asqweaax", String.valueOf( listOrderPackages ) );

        String date = sharedOrderDetails.getString( "date", "" );
        String[] divide = date.split( "-" );
        String startDate = divide[0];
        String endDate = divide[1];

        Log.d( "asdoqw",date );
        qrCode = sharedOrderDetails.getString( "qrCode", "" );

        String image = sharedOrderDetails.getString( "image", "" );
        Uri uri = Uri.parse( image );
        Picasso.get().load( uri ).placeholder( R.drawable.loginimage ).into( img_cart_event );

        tv_cart_event_title.setText( sharedOrderDetails.getString( "title", "" ) );
      //  tv_cart_event_package.setText( sharedOrderDetails.getString( "packages", "" ) );
        tv_pass_cart_event.setText( "Total Pass " + sharedOrderDetails.getString( "totalpass", "" ) );
        tv_cart_event_total_price.setText( "\u20B9 " + sharedOrderDetails.getString( "amount", "" ) );
        tvaddres.setText( sharedOrderDetails.getString( "address", "" ) );
        edt_cart_event_name.setText( sharedOrderDetails.getString( "name", "" ) );
        edt_cart_event_email.setText( sharedOrderDetails.getString( "email", "" ) );
        edt_cart_event_mobile.setText( sharedOrderDetails.getString( "mobile", "" ) );
        tv_cart_event_ratio.setText( sharedOrderDetails.getString( "ratio", "" ) );
        tv_cart_event_taxprice.setText( sharedOrderDetails.getString( "taxes", "" ) );
        tv_subtotal_price.setText( "\u20B9 " + sharedOrderDetails.getString( "subtotal", "" ) );
        tv_cart_event_date.setText( startDate );
        tv_cart_event_end_date.setText( endDate );

        buttonmark.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d( "sdazawsa","asdwsidoa" );
                hitApi();
            }
        } );
    }

    private void hitApi() {
        {

            RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
            StringRequest request = new StringRequest( Request.Method.GET, Api.Mark + qrCode, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d( "iiopszaq", response );
                    try {
                        JSONObject jsonObject = new JSONObject( response );

                        String msg = jsonObject.getString( "message" );
                        String status = jsonObject.getString( "status" );
                        if (status.equalsIgnoreCase( "success" )) {
                            dialogOpen( msg );
                          //  Toast.makeText( OrderDetailsActivity.this, msg, Toast.LENGTH_SHORT ).show();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
                }
            } ) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    //   params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put( "Authorization", "Bearer " + token );
                    Log.d( "asddaqqw", String.valueOf( params ) );
                    return params;
                }

            };

            requestQueue.add( request );

        }
    }

    private void dialogOpen(String msg) {
        LayoutInflater inflater = LayoutInflater.from(OrderDetailsActivity.this);
        mDialogConfirmPopUp = new Dialog(OrderDetailsActivity.this,
                android.R.style.Theme_Translucent_NoTitleBar);
        mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
        mDialogConfirmPopUp.getWindow().setLayout( LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        mDialogConfirmPopUp.getWindow().setGravity( Gravity.CENTER);
        final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
        lp.dimAmount = 0.75f;
        mDialogConfirmPopUp.getWindow()
                .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        mDialogConfirmPopUp.requestWindowFeature( Window.FEATURE_NO_TITLE);
        mDialogConfirmPopUp.getWindow();

        View dialoglayout = inflater.inflate(R.layout.row_dialog, null);
        mDialogConfirmPopUp.setContentView(dialoglayout);

        btn_ok_pop_down_out_line = (Button) mDialogConfirmPopUp.findViewById(R.id.btn_ok_pop_down_out_line);
        txtMessage = (TextView) mDialogConfirmPopUp.findViewById(R.id.txtMessage);
        txtMessage.setText( msg );
        btn_ok_pop_down_out_line.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialogConfirmPopUp.dismiss();
            }
        });
        mDialogConfirmPopUp.show();
    }
}
