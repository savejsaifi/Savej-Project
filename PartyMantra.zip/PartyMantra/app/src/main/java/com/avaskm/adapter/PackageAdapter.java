package com.avaskm.adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.model.HistoryModel;
import com.avaskm.partymantra.OrderDetailsActivity;
import com.avaskm.partymantra.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class PackageAdapter extends RecyclerView.Adapter<PackageAdapter.PackageHolder>{

    ArrayList<HistoryModel> listHistory;
    Context context;


    public PackageAdapter(ArrayList<HistoryModel> listHistory, Context context) {
        this.listHistory = listHistory;
        this.context = context;
    }

    @NonNull
    @Override
    public PackageAdapter.PackageHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate( R.layout.row_packages_details,parent,false);
        return new PackageAdapter.PackageHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull PackageAdapter.PackageHolder holder, int position) {
        HistoryModel model = listHistory.get(position);

        Log.d("aqwaauz", String.valueOf(listHistory.size()));
        // holder.titleNotification.setText(model.getTitle());
        holder.tv_cart_package_name.setText(model.getPackages());
        holder.tv_cart_pass.setText(model.getPass());
        holder.tv_cart_price.setText(model.getPrice());
    }


    @Override
    public int getItemCount() {
        return listHistory.size();
    }

    public class PackageHolder extends RecyclerView.ViewHolder{
        TextView tv_cart_package_name,tv_cart_pass,tv_cart_price;
        Button btnHistory;
        public PackageHolder(@NonNull View itemView) {
            super(itemView);
            tv_cart_package_name = itemView.findViewById( R.id.tv_cart_package_name );
            tv_cart_pass = itemView.findViewById( R.id.tv_cart_pass );
            tv_cart_price = itemView.findViewById( R.id.tv_cart_price );



        }
    }



}

