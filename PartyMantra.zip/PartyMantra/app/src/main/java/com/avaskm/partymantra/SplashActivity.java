package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;

public class SplashActivity extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    private static int SPLASH_SCREEN_TIME_OUT=2000;
    String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_splash );
        sharedPreferences = getSharedPreferences( "LoginData",MODE_PRIVATE );
        token = sharedPreferences.getString( "token","" );

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        new Handler().postDelayed( new Runnable() {
            @Override
            public void run() {
                if(token.length()>0){
                    startActivity( new Intent( getApplicationContext(),Profile.class ) );
                    //invoke the SecondActivity.

                    finish();
                    //the current activity will get finished.
                }else {
                    startActivity( new Intent( getApplicationContext(),LoginRegisterActivity.class ) );
                    //invoke the SecondActivity.

                    finish();
                }

            }

        }, SPLASH_SCREEN_TIME_OUT);
    }
}
