package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.api.Api;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ScannerQRActivity extends AppCompatActivity implements View.OnClickListener {

    //View Objects
    private Button buttonScan;
    private TextView textViewName;
    TextView tvNameQr,tvcontactQr;
    //qr code scanner object
    private IntentIntegrator qrScan;
  SharedPreferences sharedPreferences;
  SharedPreferences sharedPreferencesProfile;
  String token;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner_qr);
        sharedPreferences = getSharedPreferences( "LoginData",MODE_PRIVATE );
        token = sharedPreferences.getString( "token","" );
        Log.d( "iiqoaps", token );
        //View objects
        buttonScan = (Button) findViewById(R.id.buttonScan2);
        textViewName = (TextView) findViewById(R.id.textViewName);


        //intializing scan object
        qrScan = new IntentIntegrator(this);

        //attaching onclick listener
        buttonScan.setOnClickListener(this);
    }

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                String qrUrl = "http://sarkarinaukriinfo.in/api/partner-order-details/"+result.getContents();
                textViewName.setText(result.getContents());
                hitApiSubmitQrCode(qrUrl);
                Log.d( "iiqops", qrUrl );
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void hitApiSubmitQrCode(String qrUrl) {

            RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
            StringRequest request = new StringRequest( Request.Method.GET, qrUrl, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d( "iiopszaq", response );
                    try {
                        JSONObject jsonObject = new JSONObject( response );
                        String status = jsonObject.getString( "status" );
                        String msg = jsonObject.getString( "status" );


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
                }
            } ) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                 //   params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization","Bearer "+token);
                    Log.d( "asddqw", String.valueOf( params ) );
                    return params;
                }

            };

            requestQueue.add( request );

    }

    @Override
    public void onClick(View view) {
        //initiating the qr code scan
        qrScan.initiateScan();
    }
}