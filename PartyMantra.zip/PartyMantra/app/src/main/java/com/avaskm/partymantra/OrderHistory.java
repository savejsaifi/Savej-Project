package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.adapter.HistoryAdapter;
import com.avaskm.api.Api;
import com.avaskm.model.HistoryModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OrderHistory extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    String token;
    RecyclerView rvOrderHistory;
    HistoryAdapter adapter;
    ArrayList<HistoryModel> listHistory = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_order_history );
        sharedPreferences = getSharedPreferences( "LoginData", MODE_PRIVATE );
        token = sharedPreferences.getString( "token", "" );
        rvOrderHistory = findViewById( R.id.rvOrderHistory );
        Log.d( "adqwa", token );
        hitHistoryApi();
    }

    private void hitHistoryApi() {

        listHistory.clear();
        RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
        StringRequest request = new StringRequest( Request.Method.GET, Api.orderHistory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d( "iiopszaaq", response );

                try {
                    JSONObject jsonObject = new JSONObject( response );
                    JSONArray jsonArray = jsonObject.getJSONArray( "data" );
                    for (int i = 0; i < jsonArray.length(); i++) {
                        HistoryModel model = new HistoryModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject( i );
                        model.setId( jsonObject1.getString( "id" ) );
                        model.setRefId( jsonObject1.getString( "refid" ) );
                        model.setTotal( jsonObject1.getString( "total" ) );
                        model.setStatus( jsonObject1.getString( "status" ) );

                        listHistory.add( model );
                        Log.d( "dwqaasa", String.valueOf( listHistory ) );
                    }
                    rvOrderHistory.setHasFixedSize( true );
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager( getApplicationContext(), 1 );
                    rvOrderHistory.setLayoutManager( layoutManager );
                    adapter = new HistoryAdapter( listHistory, getApplicationContext() );
                    rvOrderHistory.setAdapter( adapter );
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
            }
        } ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                //   params.put("Content-Type", "application/json; charset=UTF-8");
                params.put( "Authorization", "Bearer " + token );
                Log.d( "asddqw", String.valueOf( params ) );
                return params;
            }

        };

        requestQueue.add( request );

    }

}
