package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.api.Api;
import com.avaskm.model.HistoryModel;
import com.google.android.material.snackbar.Snackbar;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Profile extends AppCompatActivity implements View.OnClickListener{

    TextView tvName,tvcontact,tvaddres;
    Button btnScan,buttonlog,buttonHistory;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    String token;
    private IntentIntegrator qrScan;
    String qrCode;
    ImageView profileImage;
    LinearLayout profileLayout;
    String packages,pass,price;
    ArrayList<HistoryModel> listOrderDetail = new ArrayList<>(  );
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_profile );
        sharedPreferences = getSharedPreferences( "LoginData",MODE_PRIVATE );
        editor = sharedPreferences.edit();
        token = sharedPreferences.getString( "token","" );
        tvName = findViewById( R.id.tvName );
        tvcontact = findViewById( R.id.tvcontact );
        tvaddres = findViewById( R.id.tvaddres );
        profileImage = findViewById( R.id.profileImage );
        btnScan = findViewById( R.id.buttonScan );
        buttonlog = findViewById( R.id.buttonlog );
        buttonHistory = findViewById( R.id.buttonHistory );
        profileLayout = findViewById( R.id.profileLayout );
        qrScan = new IntentIntegrator(this);


        hitProfileApi();
        btnScan.setOnClickListener(this);
        buttonlog.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.clear();
                editor.commit();
                Toast.makeText( Profile.this, "Logout succesfully", Toast.LENGTH_SHORT ).show();
                startActivity( new Intent( getApplicationContext(),LoginRegisterActivity.class ).
                        addFlags( Intent.FLAG_ACTIVITY_CLEAR_TASK ).addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ));
            }
        } );

        buttonHistory.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent( getApplicationContext(),OrderHistory.class ) );
            }
        } );
    }

    private void hitProfileApi() {


            RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
            StringRequest request = new StringRequest( Request.Method.GET, Api.Profile, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d( "iiopszawq", response );
                    try {
                        JSONObject jsonObject = new JSONObject( response );
                        String status = jsonObject.getString( "status" );

                        JSONObject jsonObject1 = jsonObject.getJSONObject( "partner" );
                        String name = jsonObject1.getString( "name" );
                        String image = jsonObject1.getString( "header_image" );
                        String address = jsonObject1.getString( "address" );
                        String contact = jsonObject1.getString( "contact_no" );

                        tvName.setText( name );
                        tvcontact.setText( contact );
                        tvaddres.setText( address );
                        Picasso.get().load( image ).into( profileImage );
                        Log.d( "adsqwzx",name +" "+address+" "+contact );

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
                }
            } ) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    //   params.put("Content-Type", "application/json; charset=UTF-8");
                    params.put("Authorization","Bearer "+token);
                    Log.d( "asdaqadqw", String.valueOf( params ) );
                    return params;
                }

            };

            requestQueue.add( request );

        }

    //Getting the scan results
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            //if qrcode has nothing in it
            if (result.getContents() == null) {
                Toast.makeText(this, "Result Not Found", Toast.LENGTH_LONG).show();
            } else {
                //if qr contains data
                qrCode = result.getContents();
                String qrUrl = Api.partnerOrderDetail+result.getContents();
                hitApiSubmitQrCode(qrUrl);
                Log.d( "iiqops", qrUrl );
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void hitApiSubmitQrCode(String qrUrl) {

        RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
        StringRequest request = new StringRequest( Request.Method.GET, qrUrl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d( "iiopszaq", response );
                listOrderDetail.clear();
                try {
                    JSONObject jsonObject = new JSONObject( response );

                    String msg = jsonObject.getString( "status" );

                    JSONObject jsonObject1 = jsonObject.getJSONObject( "data" );
                     String orderId = jsonObject1.getString( "orderid" );
                     String title = jsonObject1.getString( "title" );
                     String address = jsonObject1.getString( "address" );
                 //    String packages = jsonObject1.getString( "package" );
                     String image = jsonObject1.getString( "image" );
                     String date = jsonObject1.getString( "date" );
                     String totalpass = jsonObject1.getString( "totalpass" );
                     String name = jsonObject1.getString( "name" );
                     String mobile = jsonObject1.getString( "mobile" );
                     String email = jsonObject1.getString( "email" );
                     String ratio = jsonObject1.getString( "ratio" );
                     String amount = jsonObject1.getString( "amount" );
                     String subtotal = jsonObject1.getString( "subtotal" );
                     String taxes = jsonObject1.getString( "taxes" );

                    JSONArray jsonArray = jsonObject1.getJSONArray( "packages" );
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject2 = jsonArray.getJSONObject( i );
                        HistoryModel model = new HistoryModel();
                        packages = jsonObject2.getString( "package" );
                        pass = jsonObject2.getString( "pass" );
                        price = jsonObject2.getString( "price" );
                        model.setPackages( packages );
                        model.setPass( pass );
                        model.setPrice( price );
                        listOrderDetail.add( model );
                    }


                    Log.d( "qwezsasqf",amount );
                     if(msg.equalsIgnoreCase( "success" )){
                         Log.d( "qwezsasf","podjew" );
                         SharedPreferences sharedOrderDetails = getSharedPreferences( "OrderDetails",MODE_PRIVATE );
                         sharedOrderDetails.edit().putString( "orderId",orderId ).apply();
                         sharedOrderDetails.edit().putString( "title",title ).apply();
                         sharedOrderDetails.edit().putString( "address",address ).apply();
//                         sharedOrderDetails.edit().putString( "packages",packages ).apply();
//                         sharedOrderDetails.edit().putString( "pass",pass ).apply();
//                         sharedOrderDetails.edit().putString( "price",price ).apply();
                         sharedOrderDetails.edit().putString( "date",date ).apply();
                         sharedOrderDetails.edit().putString( "totalpass",totalpass ).apply();
                         sharedOrderDetails.edit().putString( "name",name ).apply();
                         sharedOrderDetails.edit().putString( "mobile",mobile ).apply();
                         sharedOrderDetails.edit().putString( "email",email ).apply();
                         sharedOrderDetails.edit().putString( "ratio",ratio ).apply();
                         sharedOrderDetails.edit().putString( "amount",amount ).apply();
                         sharedOrderDetails.edit().putString( "subtotal",subtotal ).apply();
                         sharedOrderDetails.edit().putString( "taxes",taxes ).apply();
                         sharedOrderDetails.edit().putString( "image",image ).apply();
                         sharedOrderDetails.edit().putString( "qrCode",qrCode ).apply();



                         startActivity( new Intent( getApplicationContext(),OrderDetailsActivity.class )
                         .putParcelableArrayListExtra( "listOrderPackages",listOrderDetail ));
                     }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
            }
        } ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                //   params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization","Bearer "+token);
                Log.d( "asddqw", String.valueOf( params ) );
                return params;
            }

        };

        requestQueue.add( request );

    }

    @Override
    public void onClick(View view) {
        //initiating the qr code scan
        qrScan.setOrientationLocked(false);

        //qrScan.setBeepEnabled( true );
       // qrScan.setCaptureActivity(Profile.class);
        qrScan.initiateScan();


    }

    long back_pressed=0;

    @Override
    public void onBackPressed()
    {

        if (back_pressed + 2000 > System.currentTimeMillis())
            super.onBackPressed();
        else
        {
            Snackbar snackbar=Snackbar.make(profileLayout, "Double Tap to Exit!", Snackbar.LENGTH_SHORT);
            View view=snackbar.getView();
            view.setBackgroundColor(getResources().getColor(R.color.blackColor));
            snackbar.show();
            back_pressed = System.currentTimeMillis();
        }

    }
}
