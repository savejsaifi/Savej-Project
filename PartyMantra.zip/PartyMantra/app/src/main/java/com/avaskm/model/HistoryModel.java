package com.avaskm.model;

import android.os.Parcel;
import android.os.Parcelable;

public class HistoryModel implements Parcelable {
    String id;
    String total;
    String status;
    String refId;
    String packages;
    String price;
    String pass;

    public HistoryModel(){

    }

    public HistoryModel(Parcel in) {
        id = in.readString();
        total = in.readString();
        status = in.readString();
        refId = in.readString();
        packages = in.readString();
        price = in.readString();
        pass = in.readString();
    }

    public static final Creator<HistoryModel> CREATOR = new Creator<HistoryModel>() {
        @Override
        public HistoryModel createFromParcel(Parcel in) {
            return new HistoryModel( in );
        }

        @Override
        public HistoryModel[] newArray(int size) {
            return new HistoryModel[size];
        }
    };

    public String getPackages() {
        return packages;
    }

    public void setPackages(String packages) {
        this.packages = packages;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }


    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString( id );
        parcel.writeString( total );
        parcel.writeString( status );
        parcel.writeString( refId );
        parcel.writeString( packages );
        parcel.writeString( price );
        parcel.writeString( pass );
    }
}
