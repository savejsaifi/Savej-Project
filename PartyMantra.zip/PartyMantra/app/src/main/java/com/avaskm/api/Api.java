package com.avaskm.api;

public class Api {
    public  static final  String Baseurl = "http://partymantra.appoffice.xyz/api/";
    public static final String Login = Baseurl+"login";
    public static final String Otp = Baseurl+"verify-otp";
    public static final String Profile = Baseurl+"partner-profile";
    public static final String Mark = Baseurl+"mark-entry/";
    public static final String orderHistory = Baseurl+"my-orders";
    public static final String partnerOrderDetail = Baseurl+"partner-order-details/";
}
