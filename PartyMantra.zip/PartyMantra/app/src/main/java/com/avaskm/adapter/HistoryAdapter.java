package com.avaskm.adapter;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.api.Api;
import com.avaskm.model.HistoryModel;
import com.avaskm.partymantra.OrderDetailsActivity;
import com.avaskm.partymantra.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryHolder>{

    ArrayList<HistoryModel> listHistory;
    Context context;
    SharedPreferences sharedPreferences;
    String token;
    String packages,price,pass;
    ArrayList<HistoryModel> listPackageDetails = new ArrayList<>(  );

    public HistoryAdapter(ArrayList<HistoryModel> listHistory, Context context) {
        this.listHistory = listHistory;
        this.context = context;
    }

    @NonNull
    @Override
    public HistoryHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate( R.layout.row_history,parent,false);
        return new HistoryHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull HistoryHolder holder, int position) {
        HistoryModel model = listHistory.get(position);

        Log.d("aqwaauz", String.valueOf(listHistory.size()));
        // holder.titleNotification.setText(model.getTitle());
        holder.refId.setText(model.getRefId());
        holder.total.setText(model.getTotal());
        holder.status.setText(model.getStatus());
    }


    @Override
    public int getItemCount() {
        return listHistory.size();
    }

    public class HistoryHolder extends RecyclerView.ViewHolder{
        TextView refId,total,status;
        Button btnHistory;
        public HistoryHolder(@NonNull View itemView) {
            super(itemView);
            refId = itemView.findViewById( R.id.refId );
            total = itemView.findViewById( R.id.total );
            status = itemView.findViewById( R.id.status );
            btnHistory = itemView.findViewById( R.id.btnHistory );

            btnHistory.setOnClickListener( new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //Toast.makeText( context, "adssd", Toast.LENGTH_SHORT ).show();

                  //context.startActivity( new Intent( context,OrderDetailsActivity.class ).addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ) );
                    HistoryModel historyModel = listHistory.get( getAdapterPosition() );
                    String refid = historyModel.getRefId();
                    String data = Api.partnerOrderDetail +refid;
                    hitwithRefIdApi(data,refid);
                    Log.d( "adsdadaa",refid );

                }
            } );
        }
    }

    private void hitwithRefIdApi(String data, final String refid) {

        sharedPreferences = context.getSharedPreferences( "LoginData",MODE_PRIVATE );
        token = sharedPreferences.getString( "token","" );

        RequestQueue requestQueue = Volley.newRequestQueue( context );
        StringRequest request = new StringRequest( Request.Method.GET, data, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d( "iiopszaq", response );
                listPackageDetails.clear();
                try {
                    JSONObject jsonObject = new JSONObject( response );
                    String msg = jsonObject.getString( "status" );
                    JSONObject jsonObject1 = jsonObject.getJSONObject( "data" );
                    String orderId = jsonObject1.getString( "orderid" );
                    String title = jsonObject1.getString( "title" );
                    String address = jsonObject1.getString( "address" );
                   // String packages = jsonObject1.getString( "package" );
                    String image = jsonObject1.getString( "image" );
                    String date = jsonObject1.getString( "date" );
                    String totalpass = jsonObject1.getString( "totalpass" );
                    String name = jsonObject1.getString( "name" );
                    String mobile = jsonObject1.getString( "mobile" );
                    String email = jsonObject1.getString( "email" );
                    String ratio = jsonObject1.getString( "ratio" );
                    String amount = jsonObject1.getString( "amount" );
                    String subtotal = jsonObject1.getString( "subtotal" );
                    String taxes = jsonObject1.getString( "taxes" );


                    JSONArray jsonArray = jsonObject1.getJSONArray( "packages" );
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject2 = jsonArray.getJSONObject( i );
                        HistoryModel model = new HistoryModel();
                        packages = jsonObject2.getString( "package" );
                        pass = jsonObject2.getString( "pass" );
                        price = jsonObject2.getString( "price" );
                        model.setPackages( packages );
                        model.setPass( pass );
                        model.setPrice("₹ "+ price );
                        listPackageDetails.add( model );
                    }

                    Log.d( "qwezsasqf",amount );
                    if(msg.equalsIgnoreCase( "success" )){
                        Log.d( "qwezsasf","podjew" );
                        SharedPreferences sharedOrderDetails = context.getSharedPreferences( "OrderDetails",MODE_PRIVATE );
                        sharedOrderDetails.edit().putString( "orderId",orderId ).apply();
                        sharedOrderDetails.edit().putString( "title",title ).apply();
                        sharedOrderDetails.edit().putString( "address",address ).apply();
                      //  sharedOrderDetails.edit().putString( "packages",packages ).apply();
                        sharedOrderDetails.edit().putString( "date",date ).apply();
                        sharedOrderDetails.edit().putString( "totalpass",totalpass ).apply();
                        sharedOrderDetails.edit().putString( "name",name ).apply();
                        sharedOrderDetails.edit().putString( "mobile",mobile ).apply();
                        sharedOrderDetails.edit().putString( "email",email ).apply();
                        sharedOrderDetails.edit().putString( "ratio",ratio ).apply();
                        sharedOrderDetails.edit().putString( "amount",amount ).apply();
                        sharedOrderDetails.edit().putString( "subtotal",subtotal ).apply();
                        sharedOrderDetails.edit().putString( "taxes",taxes ).apply();
                        sharedOrderDetails.edit().putString( "image",image ).apply();
                        sharedOrderDetails.edit().putString( "qrCode",refid ).apply();


                        context.startActivity( new Intent( context,OrderDetailsActivity.class )
                                .putParcelableArrayListExtra( "listOrderPackages",listPackageDetails )
                                .addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ) );
                    }
                    else {
                        Toast.makeText( context, ""+msg, Toast.LENGTH_SHORT ).show();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
//                    Log.d( "iiopas", error.getMessage() );
            }
        } ) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                //   params.put("Content-Type", "application/json; charset=UTF-8");
                params.put("Authorization","Bearer "+token);
                Log.d( "asddqw", String.valueOf( params ) );
                return params;
            }

        };

        requestQueue.add( request );

    }

}
