package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.api.Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OtpActivity extends AppCompatActivity {

//    EditText edtOtp;
    PinEntryEditText edtOtp;
    Button otpSubmit;
    String mobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_otp );
        edtOtp = findViewById( R.id.edtOtp );
        otpSubmit = findViewById( R.id.otpSubmit );
        mobile = getIntent().getStringExtra( "mobile" );
        otpSubmit.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtOtp.getText().toString().equals( "" )){
                    edtOtp.setError( "Please enter Otp" );
                    edtOtp.requestFocus();
                }

//                else if(!edtOtp.getText().toString().equals( "111111" )){
//                    edtOtp.setError( "Please enter valid Otp" );
//                    edtOtp.requestFocus();
//                }
                else {
                    hitOtpApi();
                }
            }
        } );
    }

    private void hitOtpApi() {
        {

            final ProgressDialog dialog = ProgressDialog.show(OtpActivity.this, "", "Wait....", false);
            RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
            StringRequest request = new StringRequest( Request.Method.POST, Api.Otp, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d( "iiopsresponse", response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject( response );
                        String msg = jsonObject.getString( "message" );
                        String token = jsonObject.getString( "token" );
                        Log.d( "saddasd",msg + " "+token);
                        if(msg.equalsIgnoreCase( "Login Successfull" )){
                            SharedPreferences sharedPreferences = getSharedPreferences( "LoginData",MODE_PRIVATE );
                            sharedPreferences.edit().putString( "mobile",mobile ).apply();
                            sharedPreferences.edit().putString( "token",token ).apply();
                            Toast.makeText( OtpActivity.this, "Enjoy.... You have Successfull Login", Toast.LENGTH_SHORT ).show();
                            startActivity( new Intent( getApplicationContext(),Profile.class ).
                                    addFlags( Intent.FLAG_ACTIVITY_CLEAR_TASK).
                                    addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ));
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                   // Log.d( "iiopas", error.getMessage());
                    Toast.makeText( OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT ).show();
                    dialog.dismiss();
                }
            } ){
                protected Map<String,String> getParams(){
                    HashMap<String,String> hashMap = new HashMap<>(  );
                    hashMap.put( "otp",edtOtp.getText().toString() );
                    hashMap.put( "mobile",mobile );

                    Log.d( "iiopqs", String.valueOf( hashMap ) );
                    return hashMap;

                }
            };
            requestQueue.add( request );
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event)
    {
        if ((keyCode == KeyEvent.KEYCODE_BACK))
        {
            finish();
        }
        return super.onKeyDown(keyCode, event);
    }
}
