package com.avaskm.partymantra;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.api.Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class LoginRegisterActivity extends AppCompatActivity {

    Button btnLogin;
    EditText edtMobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login_register );
        btnLogin = findViewById( R.id.btnLogin );
        edtMobile = findViewById( R.id.edtMobile );

        btnLogin.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtMobile.getText().toString().equals( "" )){
                    edtMobile.setError( "Please enter Mobile No." );
                    edtMobile.requestFocus();
                }
                else {
                    hitSubmitApi();
                   //startActivity( new Intent( getApplicationContext(),OtpActivity.class ) );
                }
            }
        } );
    }

    private void hitSubmitApi() {
        Log.d( "iidops", "dqw");
        final ProgressDialog dialog = ProgressDialog.show(LoginRegisterActivity.this, "", "Wait....", false);
        RequestQueue requestQueue = Volley.newRequestQueue( getApplicationContext() );
        StringRequest request = new StringRequest( Request.Method.POST, Api.Login, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d( "iiops", response);

                try {
                    JSONObject jsonObject = new JSONObject( response );
                    String msg = jsonObject.getString( "message" );
                    if(msg.equalsIgnoreCase( "Please verify OTP to continue" )){
                        startActivity( new Intent( getApplicationContext(),OtpActivity.class ).
                                putExtra( "mobile" ,edtMobile.getText().toString()) );
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
//                Log.d( "iiopas", error.getMessage());
            }
        } ){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>(  );
                hashMap.put( "mobile",edtMobile.getText().toString() );

                Log.d( "iiopqs", String.valueOf( hashMap ) );
                return hashMap;

            }
        };
        requestQueue.add( request );
    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();

    }
}
