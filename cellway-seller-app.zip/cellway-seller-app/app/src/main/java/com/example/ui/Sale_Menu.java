package com.example.ui;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import io.reactivex.annotations.Nullable;


public class Sale_Menu extends AppCompatActivity {

    ImageView backActivity;


    Button btn_Register;
    EditText edt_brand_Sale, edt_model_sale, edt_gb_sale, edt_sale_amount, edt_customer_name, edt_mobile, edt_remrk;
    EditText edtImei;
    String id, sale_category;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_sale__menu);

          //hideSoftKeyboard();

        Bundle bundle1 = getIntent().getExtras();
        final String imeiId = bundle1.getString("imei_id");
        final String imeino = bundle1.getString("imei_no");
        final String imeiBrand = bundle1.getString("imei_brand");
        final String imeimodel = bundle1.getString("imei_model");
        final String imeiGb = bundle1.getString("imei_gb");

        SharedPreferences sharedPreferences = getSharedPreferences("savej", Context.MODE_PRIVATE);
        id = sharedPreferences.getString("userid", "");

        Bundle bundle = getIntent().getExtras();
        sale_category = bundle.getString("sel_category");

        Log.d("dasjkl",sale_category);
        Log.d("weklui", imeino + imeiId + imeiBrand + imeimodel + imeiGb);


        edtImei = findViewById(R.id.edtImei);
        edt_brand_Sale = findViewById(R.id.edt_brand_Sale);
        edt_model_sale = findViewById(R.id.edt_model_sale);
        edt_gb_sale = findViewById(R.id.edt_gb_sale);
        edt_sale_amount = findViewById(R.id.edt_sale_amount);
        edt_customer_name = findViewById(R.id.edt_name);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_remrk = findViewById(R.id.edt_remrk);
        btn_Register = findViewById(R.id.btn_Register);

        edtImei.setText(imeino);
        edt_brand_Sale.setText(imeiBrand);
        edt_model_sale.setText(imeimodel);
        edt_gb_sale.setText(imeiGb);


//        sale_category = getArguments().getString("category_sale");


        backActivity = findViewById(R.id.backActivity);


        click();

    }



    private void click() {

        backActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImeiFragment frag = new ImeiFragment();
//                Bundle bundle = new Bundle();
//                bundle.putString("sel_category",sale_category);
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame, frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();

                Intent intent = new Intent(Sale_Menu.this,ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category",sale_category);
                intent.putExtras(bundle);
                startActivity(intent);
//                getActivity().finish();
            }
        });

        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edt_sale_amount.getText().toString().isEmpty()){
                    edt_sale_amount.setError("Please enter the amount");
                }

                else  if(edt_customer_name.getText().toString().isEmpty()){
                    edt_customer_name.setError("Please enter the customer name");
                }

                else {

                    hitsaleMenuApi();
                }
            }
        });


    }


    private void hitsaleMenuApi() {
        final ProgressDialog progressDialog = new ProgressDialog(Sale_Menu.this,R.style.MyTheme);
        progressDialog.setMessage("Please wait......");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest request = new StringRequest(Request.Method.POST, Api.saleMenu, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    progressDialog.dismiss();
                    Log.d("jkeli",response);
                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    Log.d("jedhk",msg);
                    if (code.equals("200")) {

//                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
//                        Select frag = new Select();
//                        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                        fragmentTransaction.addToBackStack(null);
//                        fragmentTransaction.replace(R.id.frame, frag);
//                        fragmentTransaction.commit();

                        startActivity(new Intent(getApplicationContext(),Select.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                        Toast.makeText(Sale_Menu.this, msg, Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                 progressDialog.dismiss();
                Toast.makeText(Sale_Menu.this, " "+error, Toast.LENGTH_SHORT).show();
                Log.d("sdajksld", String.valueOf(error));
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("userid", id);
                params.put("sel_category", sale_category);
                params.put("imei_no", edtImei.getText().toString());
                params.put("brand", edt_brand_Sale.getText().toString());
                params.put("model", edt_model_sale.getText().toString());
                params.put("gb", edt_gb_sale.getText().toString());
                params.put("sale_amount", edt_sale_amount.getText().toString());
                params.put("customer_name", edt_customer_name.getText().toString());
                params.put("customer_mobile", edt_mobile.getText().toString());
                params.put("remark", edt_remrk.getText().toString());

                Log.d("sfdhik", String.valueOf(params));
                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }


    public void hideSoftKeyboard() {
        if(getCurrentFocus()==null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

}
