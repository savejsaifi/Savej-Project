package com.example.ui;


import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.adapter.ModelAdapter;
import com.example.ui.adapter.StateAdapter;
import com.example.ui.model.Model_Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import io.reactivex.annotations.Nullable;

public class Sale_Menu extends AppCompatActivity {

    ImageView backActivity;

  String otp,mesage;
    Button btn_Register;
    EditText edt_brand_Sale, edt_model_sale, edt_gb_sale, edt_sale_amount, edt_customer_name, edt_mobile, edt_remrk,
            edt_email;
    EditText edtImei;
    String id, sale_category;
    String cash="",card="",Bank="",pending="",total;
    int cashI=0,cardI=0,BankI=0,pendingI=0,totalI=0;
    EditText edt_cash,edt_card,edt_bank,edt_pending;
    Button btn_total_amount;
    EditText edt_OTP;
    Button otpSubmit;

    AutoCompleteTextView state_autocompleteTv;
    ArrayList<Model_Model> state_list= new ArrayList<>();
    StateAdapter stateAdapter;
    String state="",message;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_sale__menu);

          //hideSoftKeyboard();

        Bundle bundle1 = getIntent().getExtras();
        final String imeiId = bundle1.getString("imei_id");
        final String imeino = bundle1.getString("imei_no");
        final String imeiBrand = bundle1.getString("imei_brand");
        final String imeimodel = bundle1.getString("imei_model");
        final String imeiGb = bundle1.getString("imei_gb");

        SharedPreferences sharedPreferences = getSharedPreferences("savej", Context.MODE_PRIVATE);
        id = sharedPreferences.getString("userid", "");

        Bundle bundle = getIntent().getExtras();
        sale_category = bundle.getString("sel_category");

        Log.d("dasjkl",sale_category);
        Log.d("weklui", imeino + imeiId + imeiBrand + imeimodel + imeiGb);


        edtImei = findViewById(R.id.edtImei);
        edt_brand_Sale = findViewById(R.id.edt_brand_Sale);
        edt_model_sale = findViewById(R.id.edt_model_sale);
        edt_gb_sale = findViewById(R.id.edt_gb_sale);
        edt_sale_amount = findViewById(R.id.edt_sale_amount);
        edt_customer_name = findViewById(R.id.edt_name);
        state_autocompleteTv = findViewById(R.id.state_autocompleteTv);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_remrk = findViewById(R.id.edt_remrk);
        edt_email = findViewById(R.id.edt_email);
        btn_Register = findViewById(R.id.btn_Register);

        edtImei.setText(imeino);
        edt_brand_Sale.setText(imeiBrand);
        edt_model_sale.setText(imeimodel);
        edt_gb_sale.setText(imeiGb);

        backActivity = findViewById(R.id.backActivity);

        hitStateApi();
        click();

    }

    private void hitStateApi() {
        final ProgressDialog progressDialog = new ProgressDialog(Sale_Menu.this,R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        RequestQueue queue = Volley.newRequestQueue(Sale_Menu.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.getState, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                  Log.d("ajdkqwcvd",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1= jsonArray.getJSONObject(i);
                        Model_Model model = new Model_Model();
                        model.setState_id(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        state_list.add(model);
                    }
                    stateAdapter = new StateAdapter(getApplicationContext(), R.layout.fragment_sale__menu,
                            R.id.lbl_name, state_list);
                    state_autocompleteTv.setAdapter(stateAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap();
                hashMap.put("key",Api.key);
                return hashMap;
            }
        };
        queue.add(request);
    }


    private void click() {

        backActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(Sale_Menu.this,ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category",sale_category);
                intent.putExtras(bundle);
                startActivity(intent);
//                getActivity().finish();
            }
        });

        state_autocompleteTv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                state = ((Model_Model)parent.getItemAtPosition(position)).getStateName();
               String  ids  = ((Model_Model)parent.getItemAtPosition(position)).getState_id();

               Log.d("asdjklplom",state+" "+ids);
            }
        });

        edt_sale_amount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              final Dialog dialog= new Dialog(Sale_Menu.this);
                dialog.setContentView(R.layout.sale_menu_amount_dialog);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(false);
                edt_cash = dialog.findViewById(R.id.edt_cash);
                edt_card = dialog.findViewById(R.id.edt_card);
                edt_bank = dialog.findViewById(R.id.edt_bank);
                edt_pending = dialog.findViewById(R.id.edt_pending);
                btn_total_amount = dialog.findViewById(R.id.btn_total_amount);
                dialog.show();


                btn_total_amount.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        cashI=0;
                        cardI=0;
                        BankI=0;
                        pendingI=0;

                        cash = edt_cash.getText().toString();
                        if(!(cash.isEmpty())){
                            cashI = Integer.parseInt(cash);
                        }

                        card = edt_card.getText().toString();
                        if(!(card.isEmpty())){
                            cardI = Integer.parseInt(card);
                        }

                        Bank = edt_bank.getText().toString();
                        if(!(Bank.isEmpty())){
                            BankI = Integer.parseInt(Bank);
                        }
                        pending = edt_pending.getText().toString();
                        if(!(pending.isEmpty())){
                            pendingI = Integer.parseInt(pending);
                        }

                        totalI = cashI+cardI+BankI+pendingI;
                        total = String.valueOf(totalI);

                        edt_sale_amount.setText(total);
                        Log.d("adksaldsk",cash+" "+card+"  "+Bank);
                        dialog.dismiss();
                    }
                });
            }
        });


        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edt_sale_amount.getText().toString().isEmpty()){
                    edt_sale_amount.setError("Please enter the amount");
                }

                else  if(edt_customer_name.getText().toString().isEmpty()){
                    edt_customer_name.setError("Please enter the customer name");
                }
              else  if(edt_email.getText().toString().isEmpty()){
                    edt_email.setError("Please enter the customer Email");
                }
              else if(state.equalsIgnoreCase("")||state.equalsIgnoreCase("Select State")){
                    Toast.makeText(Sale_Menu.this, "Please Select state", Toast.LENGTH_SHORT).show();
                }

                else {
                     showOtpDialog();
                  //  hitsaleMenuApi();
                }
            }
        });


    }

    private void showOtpDialog() {
        Dialog dialog = new Dialog(Sale_Menu.this);
        dialog.setContentView(R.layout.sale_menu_otp);
        edt_OTP = dialog.findViewById(R.id.edt_OTP);
        otpSubmit = dialog.findViewById(R.id.otpSubmit);
        dialog.show();
        hitUrlForOtp();

        otpSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edt_OTP.getText().toString().isEmpty()) {
                    edt_OTP.setError("Please enter Otp");
                    edt_OTP.requestFocus();
                } else if (!(edt_OTP.getText().toString().equals(otp))) {
                    //  startActivity(new Intent(Otp.this, Login.class));
                    edt_OTP.getText().clear();
                    edt_OTP.requestFocus();
                    Toast.makeText(Sale_Menu.this, "Please enter Valid Otp", Toast.LENGTH_SHORT).show();

                } else {
                    hitsaleMenuApi();
                }
            }
        });
    }


    private void hitsaleMenuApi() {
        final ProgressDialog progressDialog = new ProgressDialog(Sale_Menu.this,R.style.MyTheme);
        progressDialog.setMessage("Please wait......");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest request = new StringRequest(Request.Method.POST, Api.saleMenu, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    progressDialog.dismiss();
                    Log.d("jkeli",response);
                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    Log.d("jedhk",msg);
                    if (code.equals("200")) {

                        message = "Dear ("+edt_customer_name.getText().toString()+") \n" +
                                "We are very glad to help you find " +edt_brand_Sale.getText().toString()+ "("+edt_model_sale.getText().toString()+")"+ " for ("+edt_sale_amount.getText().toString()+"/-) and we wanted to reach out and say thank you!\n" +
                                "\n" +
                                "Regards \n" +
                                "Cellway\n" +
                                "9788022224";

                        hitUrlFormessage();
                       // startActivity(new Intent(getApplicationContext(),Select.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
                      //  Toast.makeText(Sale_Menu.this, msg, Toast.LENGTH_SHORT).show();

                    } else {
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                 progressDialog.dismiss();
                Toast.makeText(Sale_Menu.this, " "+error, Toast.LENGTH_SHORT).show();
                Log.d("sdajksld", String.valueOf(error));
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("userid", id);
                params.put("sel_category", sale_category);
                params.put("imei_no", edtImei.getText().toString());
                params.put("brand", edt_brand_Sale.getText().toString());
                params.put("model", edt_model_sale.getText().toString());
                params.put("gb", edt_gb_sale.getText().toString());
                params.put("sale_amount", edt_sale_amount.getText().toString());
                params.put("customer_name", edt_customer_name.getText().toString());
                params.put("customer_mobile", edt_mobile.getText().toString());
                params.put("remark", edt_remrk.getText().toString());
                params.put("email", edt_email.getText().toString());
                params.put("cash", String.valueOf(cashI));
                params.put("card", String.valueOf(cardI));
                params.put("bank", String.valueOf(BankI));
                params.put("pending", String.valueOf(pendingI));
                params.put("state", state);

                Log.d("sfdhik", String.valueOf(params));
                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }


    private void hitUrlFormessage(){

        final ProgressDialog progressDialog = new ProgressDialog(Sale_Menu.this,R.style.MyTheme);
        progressDialog.setMessage("Please wait......");
        progressDialog.setCancelable(false);
        progressDialog.show();
        Log.d("msg",message);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.SENDOTP, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                progressDialog.dismiss();
                Log.d("chekclohin", response);

                Toast.makeText(getApplicationContext(), "message sent", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(),Select.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("authkey","290873ACnsgu9J5d5fd88f");
                hashMap.put("message",message);
                hashMap.put("country", "91");
                hashMap.put("route", "106");
                hashMap.put("sender","Celway");
                hashMap.put("mobiles",edt_mobile.getText().toString());
                Log.d("checkparams",hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void hitUrlForOtp(){
        otp = String.valueOf(randomOtp());
        mesage = "Your verification code is :"+otp;
        Log.d("msg",mesage);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.SENDOTP, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Log.d("chekclohin", response);

                Toast.makeText(getApplicationContext(), "OTP sent your mobile number", Toast.LENGTH_SHORT).show();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("authkey","290873ACnsgu9J5d5fd88f");
                hashMap.put("message",mesage);
                hashMap.put("country", "91");
                hashMap.put("route", "106");
                hashMap.put("sender","MSGOTP");
                hashMap.put("mobiles",edt_mobile.getText().toString());
                Log.d("checkparams",hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private int randomOtp(){
        Random rnd = new Random();
        int n = 1000 + rnd.nextInt(9000);
        return n;
    }

    public void hideSoftKeyboard() {
        if(getCurrentFocus()==null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

}
