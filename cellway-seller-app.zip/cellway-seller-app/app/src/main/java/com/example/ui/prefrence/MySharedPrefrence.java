package com.example.ui.prefrence;

public class MySharedPrefrence {

}
