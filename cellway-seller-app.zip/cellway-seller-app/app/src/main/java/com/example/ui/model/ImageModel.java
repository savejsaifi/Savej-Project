package com.example.ui.model;

import android.graphics.Bitmap;

public class ImageModel {

    public Bitmap imageMobile;
    public Bitmap getImageMobile() {
        return imageMobile;
    }

    public void setImageMobile(Bitmap imageMobile) {
        this.imageMobile = imageMobile;
    }

    public Bitmap imageCustomerId;

    public Bitmap getImageCustomerId() {
        return imageCustomerId;
    }

    public void setImageCustomerId(Bitmap imageCustomerId) {
        this.imageCustomerId = imageCustomerId;
    }




}
