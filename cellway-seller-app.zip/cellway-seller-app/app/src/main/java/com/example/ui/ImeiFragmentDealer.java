
package com.example.ui;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.model.ImeiModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class ImeiFragmentDealer extends AppCompatActivity implements SearchView.OnQueryTextListener {


    SearchView ImeiSearch;
    RecyclerView imeirecyclerview;
    ArrayList<ImeiModel> ImeiList = new ArrayList<ImeiModel>();
    // ArrayList<ImeiModel> ImeiListWithAmount = new ArrayList<ImeiModel>();
    ArrayList<String> ImeiListWithAmount = new ArrayList<>();
    ArrayList<String> ImeiListId = new ArrayList<>();
    ArrayList<String> ImeiListAmount = new ArrayList<>();

    Button btn_ImeiDealerSubmit;
    ImeiAdapter imeiAdapter;
    JSONArray jsonArray;
    ImageView backToSale;
    String sel_category, dealer_name, dealerId;

    EditText edt_amount;
    Button btn_amount_dealer;
    ImeiWithAmountAdapter adapeterAmount;
    RecyclerView rvImeiSelected;
    SwipeRefreshLayout swipeToRefresh;

    String cash, card, Bank, pending, total,remark;
    int cashI = 0, cardI = 0, BankI = 0, pendingI = 0, totalI = 0;
    EditText edt_cash, edt_card, edt_bank, edt_pending,edt_remark;
    Button btn_total_amount;
    TextView txtDealer;
    String userid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imei_fragment_dealer);
        hideSoftKeyboard();

        SharedPreferences sharedPreferences = getSharedPreferences("savej", Context.MODE_PRIVATE);
        userid = sharedPreferences.getString("userid", "");

        imeirecyclerview = findViewById(R.id.imeirecyclerviewdealer);
        imeirecyclerview.setVisibility(View.GONE);
        ImeiSearch = findViewById(R.id.ImeiSearchDealer);
        rvImeiSelected = findViewById(R.id.rvImeiSelected);
        swipeToRefresh = findViewById(R.id.swipeToRefresh);
        backToSale = findViewById(R.id.backToSaleFromDealer);
        btn_ImeiDealerSubmit = findViewById(R.id.btn_ImeiDealerSubmit);
        txtDealer = findViewById(R.id.txtDealer);

        swipeToRefresh.setColorSchemeResources(R.color.yellow);

        hitImeiApi();
        ImeiSearch.setOnQueryTextListener(this);
        ImeiSearch.setQueryHint(Html.fromHtml("<font color = #ffffff>" +
                getResources().getString(R.string.imeihint) + "</font>"));

        Bundle bundle = getIntent().getExtras();
        sel_category = bundle.getString("sel_category");
        dealer_name = bundle.getString("dealer");
        dealerId = bundle.getString("dealerId");
        txtDealer.setText(dealer_name);
        Log.d("sakls", sel_category);
//        sale_category = getArguments().getString("category_sale");

        click();
    }

    private void click() {
        backToSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ImeiFragmentDealer.this, Select.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });


        btn_ImeiDealerSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Object[] objects = ImeiListAmount.toArray();
//
//                // Printing array of objects
//                for (Object obj : objects)
//                   // System.out.print(obj + " ");
//                    Log.d("jkkkkgg", String.valueOf(objects));

                final Dialog dialog = new Dialog(ImeiFragmentDealer.this);
                dialog.setContentView(R.layout.dealer_menu_amount_final_dialog);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(false);
                dialog.show();

                edt_cash = dialog.findViewById(R.id.edt_cashDealer);
                edt_card = dialog.findViewById(R.id.edt_cardDealer);
                edt_bank = dialog.findViewById(R.id.edt_bankDealer);
                edt_pending = dialog.findViewById(R.id.edt_pendingDealer);
                edt_remark = dialog.findViewById(R.id.edt_remarkdialog);
                btn_total_amount = dialog.findViewById(R.id.btn_total_amountDealer);
                btn_total_amount.setText("Final Submit");

                btn_total_amount.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        remark = edt_remark.getText().toString();
                        cash = edt_cash.getText().toString();
                        card = edt_card.getText().toString();
                        Bank = edt_bank.getText().toString();
                        pending = edt_pending.getText().toString();
                        cashI = 0;
                        cardI = 0;
                        BankI = 0;
                        pendingI = 0;

                        if (cash.isEmpty() && card.isEmpty() && Bank.isEmpty() && pending.isEmpty()) {
                            Toast.makeText(ImeiFragmentDealer.this, "Please fill amount", Toast.LENGTH_SHORT).show();
                        }
                        else if (remark.isEmpty()) {
                           edt_remark.setError("can't be empty");
                           edt_remark.requestFocus();
                        }
                        else {
                            if (!(cash.isEmpty())) {
                                cashI = Integer.parseInt(cash);
                            }

                            if (!(card.isEmpty())) {
                                cardI = Integer.parseInt(card);
                            }

                            if (!(Bank.isEmpty())) {
                                BankI = Integer.parseInt(Bank);
                            }

                            if (!(pending.isEmpty())) {
                                pendingI = Integer.parseInt(pending);
                            }

                            totalI = cashI + cardI + BankI + pendingI;
                            total = String.valueOf(totalI);


                            Log.d("adksaldshk", cash + " " + card + "  " + Bank + " " + pending + "  " + total);

                            hitSaleDealerApi();

                        }

                    }
                });
            }
        });
    }

    private void hitSaleDealerApi() {
        final ProgressDialog progressDialog = new ProgressDialog(ImeiFragmentDealer.this, R.style.MyTheme);
        progressDialog.setMessage("Please wait......");
        progressDialog.setCancelable(false);
        progressDialog.show();
        StringRequest request = new StringRequest(Request.Method.POST, Api.dealerSale, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    progressDialog.dismiss();

                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    Log.d("jedhk", msg);
                    if (code.equals("200")) {

                        Toast.makeText(ImeiFragmentDealer.this, msg, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ImeiFragmentDealer.this, Select.class)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));

                    } else {
                        Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(ImeiFragmentDealer.this, " " + error, Toast.LENGTH_SHORT).show();
                Log.d("sdajksld", String.valueOf(error));
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("dealer_id", dealerId);
                params.put("userid", userid);
                params.put("sel_category", "Dealer");
                params.put("sale_amount", String.valueOf(ImeiListAmount));
                params.put("imei_id", String.valueOf(ImeiListId));
                params.put("cash", String.valueOf(cashI));
                params.put("card", String.valueOf(cardI));
                params.put("bank", String.valueOf(BankI));
                params.put("pending", String.valueOf(pendingI));
                params.put("total_price", String.valueOf(totalI));
                params.put("total_qty", String.valueOf(ImeiListId.size()));
                params.put("remark",remark);

                Log.d("psram", String.valueOf(params));
                return params;

            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        if (ImeiList.contains(query)) {
            imeiAdapter.getFilter().filter(query);
        } else {
            Toast.makeText(getApplicationContext(), "No Imei no. is Exist", Toast.LENGTH_SHORT).show();
        }

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        imeiAdapter.getFilter().filter(newText);
        if (newText.length() >= 1) {
            imeirecyclerview.setVisibility(View.VISIBLE);
        }
        if (newText.length() < 1) {
            imeirecyclerview.setVisibility(View.GONE);
        }
        return false;
    }

    private void hitImeiApi() {

        final ProgressDialog progressDialog = new ProgressDialog(ImeiFragmentDealer.this, R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        RequestQueue requestQueueMobile = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.saleImei, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();
                ImeiList.clear();
                //  ImeiListWithAmount.clear();
                ImeiListWithAmount.clear();
                ImeiListId.clear();
                ImeiListAmount.clear();
                //allList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    jsonArray = jsonObject.getJSONArray("data");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        ImeiModel imeiModel = new ImeiModel();
                        imeiModel.setImei_no(jsonObject1.getString("imei_no"));
                        imeiModel.setBrand(jsonObject1.getString("brand"));
                        imeiModel.setModel(jsonObject1.getString("model"));
                        imeiModel.setGb(jsonObject1.getString("gb"));
                        imeiModel.setId(jsonObject1.getString("id"));

                        Log.d("ijkad", jsonObject1.getString("imei_no"));
                        ImeiList.add(imeiModel);
                        Log.d("gfdfsdsd", String.valueOf(ImeiList.size()));

                    }

                    imeirecyclerview.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 1);
                    imeirecyclerview.setLayoutManager(layoutManager);
                    imeiAdapter = new ImeiAdapter(getApplicationContext(), ImeiList);
                    imeirecyclerview.setAdapter(imeiAdapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getApplicationContext(), "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;

            }

        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }

    public class ImeiAdapter extends RecyclerView.Adapter<ImeiAdapter.LatestViewHolder> implements Filterable {


        Context context;

        private List<ImeiModel> nameList;
        private List<ImeiModel> filteredNameList;


        public ImeiAdapter(Context context, ArrayList<ImeiModel> nameList) {
            super();
            this.context = context;
            this.nameList = nameList;
            this.filteredNameList = nameList;
        }


        @NonNull
        @Override
        public ImeiAdapter.LatestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;

            LayoutInflater layoutInflater = LayoutInflater.from(context);
            view = layoutInflater.inflate(R.layout.row_imei, parent, false);

            return new ImeiAdapter.LatestViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull ImeiAdapter.LatestViewHolder holder, int position) {

            holder.tv_imei.setText(filteredNameList.get(position).getImei_no());


        }


        @Override
        public int getItemCount() {
            return filteredNameList.size();
        }

        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String charSequenceString = constraint.toString();
                    if (charSequenceString.isEmpty()) {
                        filteredNameList = nameList;
                    } else {
                        List<ImeiModel> filteredList = new ArrayList<>();
                        for (ImeiModel name : nameList) {
                            if (name.getImei_no().toLowerCase().contains(charSequenceString.toLowerCase())) {
                                filteredList.add(name);
                            }
                            filteredNameList = filteredList;
                        }

                    }
                    FilterResults results = new FilterResults();
                    results.values = filteredNameList;
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    filteredNameList = (List<ImeiModel>) results.values;
                    notifyDataSetChanged();
                }
            };
        }

        public class LatestViewHolder extends RecyclerView.ViewHolder {

            String imeiNo = "";
            String imeiId = "";
            TextView tv_imei;

            public LatestViewHolder(@NonNull final View itemView) {
                super(itemView);
                tv_imei = itemView.findViewById(R.id.tv_imei);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        int pos = getAdapterPosition();

                        // check if item still exists
                        if (pos != RecyclerView.NO_POSITION) {
                            hideSoftKeyboard();
                            ImeiModel clickedDataItem = filteredNameList.get(pos);

                            imeiNo = clickedDataItem.getImei_no();
                            imeiId = clickedDataItem.getId();
                            Log.d("askjlfafs", imeiNo + "  " + imeiId);


                            final Dialog dialog = new Dialog(ImeiFragmentDealer.this);
                            dialog.setContentView(R.layout.dealer_menu_amount_dialog);
                            dialog.setCanceledOnTouchOutside(false);
                            dialog.setCancelable(false);
                            edt_amount = dialog.findViewById(R.id.edt_amount);
                            btn_amount_dealer = dialog.findViewById(R.id.btn_amount_dealer);
                            dialog.show();

                            btn_amount_dealer.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (edt_amount.getText().toString().isEmpty()) {
                                        edt_amount.setError("can't be blank");
                                        edt_amount.requestFocus();
                                    } else {
                                        ImeiSearch.clearFocus();
                                        ImeiSearch.setQuery("", false);
                                        hideSoftKeyboard();

                                        ImeiListId.add(imeiId);
                                        ImeiListAmount.add(edt_amount.getText().toString());

                                        ImeiListWithAmount.add(imeiNo + " - " + edt_amount.getText().toString());

                                        rvImeiSelected.setHasFixedSize(true);
                                        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 1);
                                        rvImeiSelected.setLayoutManager(layoutManager);
                                        adapeterAmount = new ImeiWithAmountAdapter(ImeiFragmentDealer.this, ImeiListWithAmount);
                                        rvImeiSelected.setAdapter(adapeterAmount);
                                        adapeterAmount.notifyDataSetChanged();

                                        Log.d("saafksjasf", imeiNo + " , " + edt_amount.getText().toString());
//                                        Log.d("asdpolimu",a[0]+" "+a[1]+" "+a[2]);
                                        Log.d("asdpolimu", String.valueOf(ImeiListWithAmount.size()));
                                        Log.d("asdsxpolimu", String.valueOf(ImeiListId.size()));
                                        Log.d("asdsxpolximu", String.valueOf(ImeiListAmount));
                                     //   Toast.makeText(ImeiFragmentDealer.this, "" + String.valueOf(ImeiListId.size()), Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                    }
                                }
                            });

                        }
                    }
                });

            }
        }

    }

    /////////////////////////////////////////
    public class ImeiWithAmountAdapter extends RecyclerView.Adapter<ImeiWithAmountAdapter.LatestViewHolder> {

        Context context;
        private ArrayList<String> ImeiList;

        public ImeiWithAmountAdapter(Context context, ArrayList<String> ImeiList) {
            super();
            this.context = context;
            this.ImeiList = ImeiList;
        }


        @NonNull
        @Override
        public ImeiWithAmountAdapter.LatestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;

            LayoutInflater layoutInflater = LayoutInflater.from(context);
            view = layoutInflater.inflate(R.layout.row_imei, parent, false);

            return new ImeiWithAmountAdapter.LatestViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull ImeiWithAmountAdapter.LatestViewHolder holder, int position) {
            holder.tv_imei.setText(ImeiList.get(position));
        }


        @Override
        public int getItemCount() {
            return ImeiList.size();
        }


        public class LatestViewHolder extends RecyclerView.ViewHolder {
            TextView tv_imei;

            public LatestViewHolder(@NonNull final View itemView) {
                super(itemView);
                tv_imei = itemView.findViewById(R.id.tv_imei);
            }
        }
    }


    public void hideSoftKeyboard() {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
