package com.example.ui;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.model.ImeiModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ImeiFragment extends AppCompatActivity implements SearchView.OnQueryTextListener {


    SearchView ImeiSearch;
    RecyclerView imeirecyclerview;
    ArrayList<ImeiModel> ImeiList ;
    ImeiAdapter imeiAdapter;
    JSONArray jsonArray;
    ImageView backToSale;
    String sel_category;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate the layout for this fragment
        setContentView(R.layout.fragment_imei);
        hideSoftKeyboard();

        imeirecyclerview = findViewById(R.id.imeirecyclerview);
        imeirecyclerview.setVisibility(View.GONE);
        ImeiSearch = findViewById(R.id.ImeiSearch);

        backToSale = findViewById(R.id.backToSale);
        ImeiSearch.setOnQueryTextListener(this);
        ImeiSearch.setQueryHint(Html.fromHtml("<font color = #ffffff>" +
                getResources().getString(R.string.imeihint) + "</font>"));
        ImeiList=new ArrayList<ImeiModel>();

//        if(){
//            imeirecyclerview.setVisibility(View.VISIBLE);
//        }

        Bundle bundle = getIntent().getExtras();
        sel_category = bundle.getString("sel_category");
        Log.d("sakls",sel_category);
//        sale_category = getArguments().getString("category_sale");

        click();
        hitImeiApi();



    }

    private void click() {
        backToSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Select frag = new Select();
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame, frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();
                startActivity(new Intent(ImeiFragment.this,Select.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK));
            }
        });
    }

    private void hitImeiApi() {

        {
//            ProgressDialog progressDialog = new ProgressDialog(getApplicationContext());
//            progressDialog.setCanceledOnTouchOutside(false);
//            progressDialog.show();
            RequestQueue requestQueueMobile = Volley.newRequestQueue(getApplicationContext());
            StringRequest request = new StringRequest(Request.Method.POST, Api.saleImei, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("Loginresponse", response);
//                    progressDialog.dismiss();
                    ImeiList.clear();
                    //allList.clear();
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {

                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            ImeiModel imeiModel = new ImeiModel();
                            imeiModel.setImei_no(jsonObject1.getString("imei_no"));
                            imeiModel.setBrand(jsonObject1.getString("brand"));
                            imeiModel.setModel(jsonObject1.getString("model"));
                            imeiModel.setGb(jsonObject1.getString("gb"));
                            imeiModel.setId(jsonObject1.getString("id"));

                            Log.d("ijkad",jsonObject1.getString("imei_no"));
                            ImeiList.add(imeiModel);
                            Log.d("gfdfsdsd", String.valueOf(ImeiList.size()));

                        }

                        imeirecyclerview.setHasFixedSize(true);
                        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getApplicationContext(),1);
                        imeirecyclerview.setLayoutManager(layoutManager);
                        imeiAdapter=new ImeiAdapter(getApplicationContext(),ImeiList);
                        imeirecyclerview.setAdapter(imeiAdapter);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
//                    progressDialog.dismiss();
                    Toast.makeText(getApplicationContext(), "Something Wrong", Toast.LENGTH_SHORT).show();
                    Log.d("errodfr", error.getMessage() + "errorr");

                }
            })
            {
                protected Map<String, String> getParams() {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("key", Api.key);
                    return hashMap;

                }

            };
            requestQueueMobile.getCache().clear();
            requestQueueMobile.add(request);
        }

    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        if(ImeiList.contains(query)){
            imeiAdapter.getFilter().filter(query);
        }

        else {
            Toast.makeText(getApplicationContext(), "No Imei no. is Exist", Toast.LENGTH_SHORT).show();
        }

        return false;
    }


    @Override
    public boolean onQueryTextChange(String newText) {
        imeiAdapter.getFilter().filter(newText);
        if(newText.length()>=1){
            imeirecyclerview.setVisibility(View.VISIBLE);
        }
        if(newText.length()<1){
            imeirecyclerview.setVisibility(View.GONE);
        }
        return false;
    }

    public class ImeiAdapter extends RecyclerView.Adapter<ImeiAdapter.LatestViewHolder> implements Filterable {


        Context context;

        private List<ImeiModel> nameList;
        private List<ImeiModel> filteredNameList;


        public ImeiAdapter(Context context, ArrayList<ImeiModel> nameList) {
            super();
            this.context = context;
            this.nameList = nameList;
            this.filteredNameList = nameList;
        }


        @NonNull
        @Override
        public LatestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;

            LayoutInflater layoutInflater = LayoutInflater.from(context);
            view = layoutInflater.inflate(R.layout.row_imei,parent,false);

            return new LatestViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull LatestViewHolder holder, int position) {
//        ImeiModel all = mData.get(position);
//        holder.tv_imei.setText(((ImeiModel) all).getImei_no());
            holder.tv_imei.setText(filteredNameList.get(position).getImei_no());


        }


        @Override
        public int getItemCount() {
            return filteredNameList.size();
        }

        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String charSequenceString = constraint.toString();
                    if (charSequenceString.isEmpty()) {
                        filteredNameList = nameList;
                    } else {
                        List<ImeiModel> filteredList = new ArrayList<>();
                        for (ImeiModel name : nameList) {
                            if (name.getImei_no().toLowerCase().contains(charSequenceString.toLowerCase())) {
                                filteredList.add(name);
                            }
                            filteredNameList = filteredList;
                        }

                    }
                    FilterResults results = new FilterResults();
                    results.values = filteredNameList;
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    filteredNameList = (List<ImeiModel>) results.values;
                    notifyDataSetChanged();
                }
            };
        }

        public class LatestViewHolder extends RecyclerView.ViewHolder{

//            FragmentManager fragmentManager = getSupportFragmentManager();
            TextView tv_imei;
            public LatestViewHolder(@NonNull final View itemView) {
                super(itemView);
                tv_imei = itemView.findViewById(R.id.tv_imei);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        int pos = getAdapterPosition();

                        // check if item still exists
                        if(pos != RecyclerView.NO_POSITION){
                            ImeiModel clickedDataItem = filteredNameList.get(pos);
                            String id = clickedDataItem.getId();
                            String imeiNo = clickedDataItem.getImei_no();
                            String brand = clickedDataItem.getBrand();
                            String model = clickedDataItem.getModel();
                            String gb = clickedDataItem.getGb();

                            Intent intent = new Intent(getApplicationContext(),Sale_Menu.class);

//                            Sale_Menu frag = new Sale_Menu();
                            Bundle bundle = new Bundle();
                            bundle.putString("imei_id", id);
                            bundle.putString("imei_no", imeiNo);
                            bundle.putString("imei_brand", brand);
                            bundle.putString("imei_model", model);
                            bundle.putString("imei_gb", gb);
                            bundle.putString("sel_category",sel_category);
                            intent.putExtras(bundle);
                            startActivity(intent);

//                            frag.setArguments(bundle);
//                            fragmentManager.beginTransaction().replace(R.id.frame,
//                                    frag, frag.getTag())
//                                    .addToBackStack(null)
//                                    .commit();


//                        Toast.makeText(v.getContext(), "You clicked " + clickedDataItem.getImei_no()+" "+clickedDataItem.getId()+" "+clickedDataItem.getBrand()+" "+clickedDataItem.getModel()+" "+clickedDataItem.getGb(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        }

    }


    public void hideSoftKeyboard() {
        if(getCurrentFocus()!=null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }

}
