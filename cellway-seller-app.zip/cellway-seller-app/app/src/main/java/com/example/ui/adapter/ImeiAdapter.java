//package com.example.ui.adapter;
//
//import android.content.Context;
//import android.os.Bundle;
//import android.support.annotation.NonNull;
//import android.support.v4.app.FragmentManager;
//import android.support.v7.widget.RecyclerView;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Filter;
//import android.widget.Filterable;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.example.ui.ImeiFragment;
//import com.example.ui.MainActivity;
//import com.example.ui.R;
//import com.example.ui.Sale_Menu;
//import com.example.ui.model.ImeiModel;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ImeiAdapter extends RecyclerView.Adapter<ImeiAdapter.LatestViewHolder> implements Filterable {
//
//
//    Context context;
//
//    private List<ImeiModel> nameList;
//    private List<ImeiModel> filteredNameList;
//
//
//    public ImeiAdapter(Context context, ArrayList<ImeiModel> nameList) {
//        super();
//        this.context = context;
//        this.nameList = nameList;
//        this.filteredNameList = nameList;
//    }
//
//
//    @NonNull
//    @Override
//    public LatestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view;
//
//        LayoutInflater layoutInflater = LayoutInflater.from(context);
//        view = layoutInflater.inflate(R.layout.row_imei,parent,false);
//
//        return new LatestViewHolder(view);
//    }
//
//
//    @Override
//    public void onBindViewHolder(@NonNull LatestViewHolder holder, int position) {
////        ImeiModel all = mData.get(position);
////        holder.tv_imei.setText(((ImeiModel) all).getImei_no());
//        holder.tv_imei.setText(filteredNameList.get(position).getImei_no());
//
//
//    }
//
//
//    @Override
//    public int getItemCount() {
//        return filteredNameList.size();
//    }
//
//    public Filter getFilter() {
//        return new Filter() {
//            @Override
//            protected FilterResults performFiltering(CharSequence constraint) {
//                String charSequenceString = constraint.toString();
//                if (charSequenceString.isEmpty()) {
//                    filteredNameList = nameList;
//                } else {
//                    List<ImeiModel> filteredList = new ArrayList<>();
//                    for (ImeiModel name : nameList) {
//                        if (name.getImei_no().toLowerCase().contains(charSequenceString.toLowerCase())) {
//                            filteredList.add(name);
//                        }
//                        filteredNameList = filteredList;
//                    }
//
//                }
//                FilterResults results = new FilterResults();
//                results.values = filteredNameList;
//                return results;
//            }
//
//            @Override
//            protected void publishResults(CharSequence constraint, FilterResults results) {
//                filteredNameList = (List<ImeiModel>) results.values;
//                notifyDataSetChanged();
//            }
//        };
//    }
//
//    public class LatestViewHolder extends RecyclerView.ViewHolder{
//
//        FragmentManager fragmentManager = ((MainActivity) context).getSupportFragmentManager();
//        TextView tv_imei;
//        public LatestViewHolder(@NonNull final View itemView) {
//            super(itemView);
//            tv_imei = itemView.findViewById(R.id.tv_imei);
//            itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                    int pos = getAdapterPosition();
//
//                    // check if item still exists
//                    if(pos != RecyclerView.NO_POSITION){
//                        ImeiModel clickedDataItem = filteredNameList.get(pos);
//                        String id = clickedDataItem.getId();
//                        String imeiNo = clickedDataItem.getImei_no();
//                        String brand = clickedDataItem.getBrand();
//                        String model = clickedDataItem.getModel();
//                        String gb = clickedDataItem.getGb();
//
//                        Sale_Menu frag = new Sale_Menu();
//                        Bundle bundle = new Bundle();
//                        bundle.putString("imei_id", id);
//                        bundle.putString("imei_no", imeiNo);
//                        bundle.putString("imei_brand", brand);
//                        bundle.putString("imei_model", model);
//                        bundle.putString("imei_gb", gb);
//                        frag.setArguments(bundle);
//                        fragmentManager.beginTransaction().replace(R.id.frame,
//                                frag, frag.getTag())
//                                .addToBackStack(null)
//                                .commit();
//
//
////                        Toast.makeText(v.getContext(), "You clicked " + clickedDataItem.getImei_no()+" "+clickedDataItem.getId()+" "+clickedDataItem.getBrand()+" "+clickedDataItem.getModel()+" "+clickedDataItem.getGb(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }
//    }
//
//}
