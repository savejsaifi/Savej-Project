package com.example.ui;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK;


public class Select extends AppCompatActivity{


Button btn_shop_purchase,btn_dealerPurchase,btn_fieldPurchase,btn_shopSale,btn_dealer_sale,btn_remark;
TextView logOut;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate the layout for this fragment

        setContentView(R.layout.fragment_select);
        btn_shop_purchase = findViewById(R.id.btn_shop_purchase);
        btn_dealerPurchase = findViewById(R.id.btn_dealerPurchase);
        btn_fieldPurchase = findViewById(R.id.btn_fieldPurchase);
        btn_shopSale = findViewById(R.id.btn_shopSale);
        btn_dealer_sale = findViewById(R.id.btn_dealer_sale);
        btn_remark = findViewById(R.id.btn_remark);
        logOut = findViewById(R.id.logOut);
        click();

    }

   /* private void backPressd() {
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    getActivity().getSupportFragmentManager().popBackStackImmediate();
                    return true;
                }
                return false;
            }
        });
    }
*/
    private void click() {
        btn_shop_purchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Purchase_Menu frag = new Purchase_Menu();
//                Bundle bundle = new Bundle();
//                bundle.putString("category","Shop Purchase");
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();

                  Intent intent = new Intent(Select.this,Purchase_Menu.class);
                  Bundle bundle = new Bundle();
                  bundle.putString("category","Shop Purchase");
                  intent.putExtras(bundle);
                  startActivity(intent);
//                 purCategory.remove("productId");

//                startActivity(new Intent(getApplicationContext(),Purchase_Menu.class));

            }
        });
        btn_dealerPurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Purchase_Menu frag = new Purchase_Menu();
//                Bundle bundle = new Bundle();
//                bundle.putString("category","Dealer Purchase");
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();
                Intent intent = new Intent(getApplicationContext(),Purchase_Menu.class);
                Bundle bundle = new Bundle();
                bundle.putString("category","Dealer Purchase");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        btn_fieldPurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Purchase_Menu frag = new Purchase_Menu();
//                Bundle bundle = new Bundle();
//                bundle.putString("category","Field Purchase");
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();
                Intent intent = new Intent(getApplicationContext(),Purchase_Menu.class);
                Bundle bundle = new Bundle();
                bundle.putString("category","Field Purchase");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });


        btn_shopSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImeiFragment frag = new ImeiFragment();
//                Bundle bundle = new Bundle();
//                bundle.putString("sel_category","Shop sale");
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.container,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();

                Intent intent = new Intent(getApplicationContext(),ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category","Shop sale");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        btn_dealer_sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImeiFragment frag = new ImeiFragment();
////                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sel_category", MODE_PRIVATE);
////                sharedPreferences.edit().putString("sel_cat","Dealer sale").apply();
//
//                Bundle bundle = new Bundle();
//                bundle.putString("sel_category","Dealer sale");
//                frag.setArguments(bundle);
//                FragmentManager fragmentManager = getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.container,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();

                Intent intent = new Intent(getApplicationContext(),ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category","Dealer sale");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        btn_remark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImeiFragment frag = new ImeiFragment();
//
////                SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sel_category", MODE_PRIVATE);
////                sharedPreferences.edit().putString("sel_cat","Field sale").apply();
//
//                Bundle bundle = new Bundle();
//                bundle.putString("sel_category","Field sale");
//                frag.setArguments(bundle);
//
//                FragmentManager fragmentManager = getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.container,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();

                Intent intent = new Intent(getApplicationContext(),ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category","Field sale");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences sharedPreferences = getSharedPreferences("savej",MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(Select.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Select.this,MainActivity.class).addFlags(FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

//                LOGIN frag = new LOGIN();
//                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
//                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
//                fragmentTransaction.replace(R.id.frame,frag);
//                fragmentTransaction.addToBackStack(null);
//                fragmentTransaction.commit();
            }
        });
    }

}
