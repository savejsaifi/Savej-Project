package com.example.ui;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.adapter.DealerAdapter;
import com.example.ui.adapter.StateAdapter;
import com.example.ui.model.Model_Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK;


public class Select extends AppCompatActivity{


Button btn_shop_purchase,btn_dealerPurchase,btn_fieldPurchase,btn_shopSale,btn_dealer_sale,btn_remark;
Button btn_receipt;
TextView logOut,txtUser;
    SharedPreferences sharedPreferences;

    AutoCompleteTextView dealer_autocompleteTv;
    Button btn_deler;
    ArrayList<Model_Model> dealer_list= new ArrayList<>();
    DealerAdapter dealerAdapter;
    String dealerName,dealerId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inflate the layout for this fragment

        setContentView(R.layout.fragment_select);
         sharedPreferences = getSharedPreferences("savej",MODE_PRIVATE);

        btn_shop_purchase = findViewById(R.id.btn_shop_purchase);
        btn_dealerPurchase = findViewById(R.id.btn_dealerPurchase);
        btn_fieldPurchase = findViewById(R.id.btn_fieldPurchase);
        btn_shopSale = findViewById(R.id.btn_shopSale);
        btn_dealer_sale = findViewById(R.id.btn_dealer_sale);
        btn_remark = findViewById(R.id.btn_remark);
        btn_receipt = findViewById(R.id.btn_receipt);
        logOut = findViewById(R.id.logOut);
        txtUser = findViewById(R.id.txtUser);
        txtUser.setText(sharedPreferences.getString("name",""));
        click();


    }


    private void click() {
        btn_shop_purchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                  Intent intent = new Intent(Select.this,Purchase_Menu.class);
                  Bundle bundle = new Bundle();
                  bundle.putString("category","Shop Purchase");
                  intent.putExtras(bundle);
                  startActivity(intent);
//                 purCategory.remove("productId");

//                startActivity(new Intent(getApplicationContext(),Purchase_Menu.class));

            }
        });
        btn_dealerPurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),Purchase_Menu.class);
                Bundle bundle = new Bundle();
                bundle.putString("category","Dealer Purchase");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        btn_fieldPurchase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),Purchase_Menu.class);
                Bundle bundle = new Bundle();
                bundle.putString("category","Field Purchase");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });


        btn_shopSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent = new Intent(getApplicationContext(),ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category","Shop Sale");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        btn_dealer_sale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // startActivity(new Intent(getApplicationContext(),Dealer_Select.class));

                final Dialog dialog= new Dialog(Select.this);
                dialog.setContentView(R.layout.dealer_dialog);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setCancelable(false);
                btn_deler = dialog.findViewById(R.id.btn_deler);
                dealer_autocompleteTv = dialog.findViewById(R.id.dealer_autocompleteTv);
                dialog.show();

                hitDealerApi();

                dealer_autocompleteTv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        dealerName = ((Model_Model)parent.getItemAtPosition(position)).getDealerName();
                        dealerId = ((Model_Model)parent.getItemAtPosition(position)).getDealer_id();
                        Log.d("afskpasfkdsf",dealerId);

                    }
                });
                btn_deler.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialog.dismiss();
                        Intent intent = new Intent(getApplicationContext(),ImeiFragmentDealer.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("sel_category","Dealer Sale");
                        bundle.putString("dealer",dealerName);
                        bundle.putString("dealerId",dealerId);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                });
            }
        });
        btn_remark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ImeiFragment.class);
                Bundle bundle = new Bundle();
                bundle.putString("sel_category","Courier Sale");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.clear();
                editor.commit();
                Toast.makeText(Select.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(Select.this,MainActivity.class).addFlags(FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));


            }
        });


        btn_receipt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),ReceiptActivity.class));
            }
        });
    }

    private void hitDealerApi() {
        dealer_list.clear();
        final ProgressDialog progressDialog = new ProgressDialog(Select.this,R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        RequestQueue queue = Volley.newRequestQueue(Select.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.getDealer, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                Log.d("ajdkqwcvd",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i=0;i<jsonArray.length();i++){
                        JSONObject jsonObject1= jsonArray.getJSONObject(i);
                        Model_Model model = new Model_Model();
                          model.setDealer_id(jsonObject1.getString("id"));
                         model.setDealerName(jsonObject1.getString("dealer_name")+" - "+jsonObject1.getString("tread_name"));
                        dealer_list.add(model);
                    }
                    dealerAdapter = new DealerAdapter(getApplicationContext(), R.layout.dealer_dialog,
                            R.id.lbl_name, dealer_list);
                    dealer_autocompleteTv.setAdapter(dealerAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap();
                hashMap.put("key",Api.key);
                return hashMap;
            }
        };
        queue.add(request);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
