package com.example.ui;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.media.MediaRecorder.VideoSource.CAMERA;


public class LOGIN extends Fragment {

    View view;
    Button btn_Login;
    EditText edt_user, edt_password;

    public LOGIN() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_login, container, false);
        btn_Login = view.findViewById(R.id.btn_Login);
        edt_user = view.findViewById(R.id.edt_user);
        edt_password = view.findViewById(R.id.edt_password);

        btn_Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(SignIn()){

                }
            }
        });


        return view;
    }



    private boolean setUsername(){
        if((edt_user.getText().toString().length()>0)){
            return true;

        }else {
            edt_user.setError("Please enter mobile no");
            return false;
        }
    }

    private boolean setPassword(){
        if(edt_password.getText().toString().length()>0){
            return true;

        }else {
            edt_password.setError("Please enter password");
            return false;
        }
    }

    private boolean  SignIn(){
        if(!setUsername()){
            return false;
        }else if(!setPassword()){
            return false;
        }

        loginApi();
        return true;
    }





    private void loginApi() {
        final ProgressDialog progressDialog = new ProgressDialog(getActivity(),R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        StringRequest request = new StringRequest(Request.Method.POST, Api.login_url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String userid = jsonObject.getString("userid");
                    SharedPreferences sharedPreferences = getActivity().getSharedPreferences("savej", Context.MODE_PRIVATE);
                    sharedPreferences.edit().putString("userid",userid).apply();
                    String code = jsonObject.getString("code");
                    if (code.equals("200")) {
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getActivity(),Select.class));

                    } else if (code.equals("401")) {
                        edt_user.setText("");
                        edt_password.setText("");
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr",error.getMessage()+"errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("mobile", edt_user.getText().toString());
                hashMap.put("password", edt_password.getText().toString());

                Log.d("oyeResponse", String.valueOf(hashMap));
                return hashMap;

            }


        };

        requestQueue.add(request);
    }

    public boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = ((ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE));
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

}
