package com.example.ui;


import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.IntDef;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.adapter.ModelAdapter;
import com.example.ui.model.BrandSpinner;
import com.example.ui.model.ImageModel;
import com.example.ui.model.Model_Model;
import com.example.ui.model.SeriesModel;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Condition;

import id.zelory.compressor.Compressor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.media.MediaRecorder.VideoSource.CAMERA;


public class Purchase_Menu extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener,ScanResultReceiver{


    RecyclerView rv_mobile,rv_customerId;
    AlertDialog.Builder builder;
    Button btn_Submit;
    Bitmap bitmap1,bitmap2;
    private String photoPathMobile,photoPathCustomer;
    ArrayList<ImageModel> Mobilelist;
    ArrayList<ImageModel> customerlist;
    String imageEncodedMobile,imageEncodeCustomer;
    public MobileImageAdapter mIMGAdapter;
    public CustomerImageAdapter cImgAdapter;
    Button btn_mblImg,customer_button;
    int PICK_IMAGE_MULTIPLE = 1;
    ArrayList<String> imagePathListMobile, imagePathListCustomer;
    File photoMobileFile = null;
    File photoCustomerFile = null;
    String mCurrentPhotoPath,cCurrentPhotoPath;
    Uri photoUriCustomer,photoUriMobile;

    int count;
    CheckBox chkIn, chkOut,chkMobile, chkTablet, chkAccesories, chkOther,chkOk, chkPrexo, chkRepairing;
    String condition[] = {"**", "A+", "A", "B", "C"};
    String conditon_Mobile;
    String brandstore,seriesstore,modelstore,warrenty_month,warranty;
    String Warranty_data[] = {
            "0 - 1 month old",
            "1 - 3 month old",
            "3 - 6 month old",
            "6 - 9 month old",
            "9 - 12 month old",
    };

    ArrayList<BrandSpinner> brand_list = new ArrayList<>();
    //ArrayList<String> brandid = new ArrayList<>();
    final ArrayList<String> brand_list_datamobile = new ArrayList();

    ArrayList<SeriesModel> series_list = new ArrayList<>();
    final ArrayList<String> series_list_dataSeries = new ArrayList();

    LinearLayout layoutAccesother, layoutMobTab;
    String productCategory;
    String statusok="", statusPrexo="", statusRepairing="";
    Spinner condition_spinner, spinnerBrandMobile, Warranty_spinner,spinnerSeries;
    String brand_id,series_id;

    AutoCompleteTextView model_autocompleteTv;
    ArrayList<Model_Model> model_list= new ArrayList<>();
    ModelAdapter modelAdapter;
    Model_Model modelObject;

  //  ArrayList<String> model_list_dataModel= new ArrayList<>();


    EditText edt_brand,edt_model,edt_gb,edt_imei,edt_purchase_amount,edt_customer_name,edt_customer_mobile,edt_remark;
    ImageView scanNow,backToSelect;
    String catgory,phone_id;
    SharedPreferences useridprefrence;
    String userId;
    String idmodel;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.fragment_purchase__menu);
        //hideSoftKeyboard();



        askForPermissioncamera(Manifest.permission.CAMERA,CAMERA);

        Bundle bundle= getIntent().getExtras();
        catgory = bundle.getString("category");
        //catgory = bundle.getString("category");
        Log.d("category",catgory);
        init();

        Mobilelist = new ArrayList<>();
        customerlist = new ArrayList<>();
        imagePathListMobile = new ArrayList<>();
        imagePathListCustomer = new ArrayList<>();


        btn_mblImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 1;

                PopupMenu popupMenu = new PopupMenu(getApplicationContext(),btn_mblImg);
                popupMenu.getMenuInflater().inflate(R.menu.camera_image,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId())
                        {
                            case R.id.Camera:
                                try {
                                    //purmissionforgallery();
                                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                        ActivityCompat.requestPermissions(Purchase_Menu.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                                    }
                                    else{
                                        takeMobileCameraImg();
                                    }

                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                break;
                             case R.id.Gallery:
                                try {
                                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                        ActivityCompat.requestPermissions(Purchase_Menu.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                                    } else{
                                        Intent intent = new Intent();
                                        intent.setType("image/*");
                                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                                        intent.setAction(Intent.ACTION_GET_CONTENT);
                                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);

                                    }



                                } catch (Exception e) {
                                    e.printStackTrace();
                                }

                                break;

                        }

                        return false;
                    }
                });

                popupMenu.show();



            }
        });


        customer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 2;
                PopupMenu popupMenu = new PopupMenu(getApplicationContext(),customer_button);
                popupMenu.getMenuInflater().inflate(R.menu.camera_image,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.Gallery:
                                try {
                                    if (ActivityCompat.checkSelfPermission(Purchase_Menu.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                                        ActivityCompat.requestPermissions(Purchase_Menu.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);
                                    } else {

                                        Intent intent = new Intent();
                                        intent.setType("image/*");
                                        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                                        intent.setAction(Intent.ACTION_GET_CONTENT);
                                        startActivityForResult(Intent.createChooser(intent, "Select Picture"), 1);

                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                break;

                            case R.id.Camera:
                                try {
                                    takeCustomerIdImage();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                                break;

                        }


                        return false;
                    }
                });
               popupMenu.show();

            }
        });


        click();


    }

    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(Purchase_Menu.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(Purchase_Menu.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(Purchase_Menu.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }



    private void init() {


        useridprefrence = getSharedPreferences("savej",MODE_PRIVATE);
        userId = useridprefrence.getString("userid","");
        builder = new AlertDialog.Builder(this);
//        bundle = getApplicationContext().getIntent().getBundleExtra();


        chkMobile = findViewById(R.id.chkMobile);
        chkTablet = findViewById(R.id.chkTablet);
        chkAccesories = findViewById(R.id.chkAccesories);
        chkOther = findViewById(R.id.chkOther);
        chkOk = findViewById(R.id.chkOk);
        chkPrexo = findViewById(R.id.chkPrexo);
        chkRepairing = findViewById(R.id.chkRepairing);
        chkIn = findViewById(R.id.chkIn);
        chkOut = findViewById(R.id.chkOut);
        Warranty_spinner = findViewById(R.id.Warranty_spinner);
        edt_brand = findViewById(R.id.edt_brand);
        edt_model = findViewById(R.id.edt_model);
        edt_remark = findViewById(R.id.edt_remark);
        edt_gb = findViewById(R.id.edt_gb);
        edt_imei = findViewById(R.id.edt_imei);
        edt_purchase_amount =findViewById(R.id.edt_purchase_amount);
        edt_customer_name = findViewById(R.id.edt_customer_name);
        edt_customer_mobile = findViewById(R.id.edt_customer_mobile);
        condition_spinner =findViewById(R.id.condition_spinner);
        scanNow = findViewById(R.id.scanNow);
        backToSelect = findViewById(R.id.backToSelect);
        scanClick();



        checkboxClick();
        layoutAccesother = findViewById(R.id.layoutAccesother);
        layoutMobTab = findViewById(R.id.layoutMobTab);

        btn_Submit = findViewById(R.id.btn_Submit);

    ///for upload image
        btn_mblImg = findViewById(R.id.btn_mblImg);
        customer_button = findViewById(R.id.customer_button);
        rv_mobile = findViewById(R.id.rv_mobile);
        rv_customerId = findViewById(R.id.rv_customerId);

        spinnerBrandMobile = findViewById(R.id.spinnerBrandMobile);
        spinnerSeries = findViewById(R.id.spinnerSeries);
        model_autocompleteTv = findViewById(R.id.model_autocompleteTv);
     //   modelstore = model_autocompleteTv.getText().toString();
        model_autocompleteTv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

             //   modelMobTab = (String) parent.getItemAtPosition(position);

                modelObject = (Model_Model)parent.getItemAtPosition(position);
                modelstore = modelObject.getModelName();
                idmodel =modelObject.getModel_id();

           //     Log.d("dfkls",modelstore + " " +idmodel);



//                Toast.makeText(
//                        parent.getContext(),
//                        "Selected Value: " + modelMobTab,
//                        Toast.LENGTH_LONG).show();

            }
        });

        spinnerBrandMobile.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                //int position = adapterView.getSelectedItemPosition();
                brand_id = String.valueOf(brand_list.get(i).getBrandId());
                brandstore = brand_list.get(i).getBrand_name();

                Log.d("fsdklj",brand_id+brandstore);

                hitSpinnerSeries(brand_id);

            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        spinnerSeries.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                int position = adapterView.getSelectedItemPosition();
                series_id = String.valueOf(series_list.get(position).getSeries_id());
                seriesstore = series_list.get(i).getSeries_name();
                hitModelApi(series_id);
              Log.d("sepo",seriesstore + " "+series_id);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });


        ArrayAdapter cndnAdapter = new ArrayAdapter(Purchase_Menu.this, android.R.layout.simple_spinner_dropdown_item, condition);
        condition_spinner.setAdapter(cndnAdapter);
        condition_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                if(position==0){
                     conditon_Mobile= "**";
                    Log.d("wsir",conditon_Mobile);
                }
                else if(position==1){
                     conditon_Mobile= "A+";
                    Log.d("optre",conditon_Mobile);
                }
                else if(position==2){
                     conditon_Mobile= "A";
                }
                else if(position==3){
                     conditon_Mobile= "B";
                }
                else if(position==4){
                     conditon_Mobile= "C";
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void scanClick() {
        scanNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                ScanFragment scanFragment = new ScanFragment();
                fragmentTransaction.add(R.id.scan_fragment,scanFragment);
                fragmentTransaction.commit();
            }
        });
    }

    private void checkboxClick() {

        chkMobile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (chkMobile.isChecked()) {
                    brand_list.clear();
                    productCategory = "Mobile";
                    chkTablet.setChecked(false);
                    chkAccesories.setChecked(false);
                    chkOther.setChecked(false);
                    layoutMobTab.setVisibility(View.VISIBLE);
                    layoutAccesother.setVisibility(View.GONE);
                    hitSpinnerBrandMobile();

                    Log.d("aks", productCategory);
                }
            }
        });
        chkTablet.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (chkTablet.isChecked()) {
                    productCategory = "Tablet";
                    chkMobile.setChecked(false);
                    chkAccesories.setChecked(false);
                    chkOther.setChecked(false);
                    layoutMobTab.setVisibility(View.VISIBLE);
                    layoutAccesother.setVisibility(View.GONE);
                    hitSpinnerBrandTablet();

                    Log.d("akfds", productCategory);
                }
            }
        });

        chkAccesories.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (chkAccesories.isChecked()) {
                    productCategory = "Accessories";
                    chkTablet.setChecked(false);
                    chkMobile.setChecked(false);
                    chkOther.setChecked(false);
                    layoutMobTab.setVisibility(View.GONE);
                    layoutAccesother.setVisibility(View.VISIBLE);
                    Log.d("aerqks", productCategory);
                }
            }
        });

        chkOther.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (chkOther.isChecked()) {
                    productCategory = "Other";
                    chkTablet.setChecked(false);
                    chkAccesories.setChecked(false);
                    chkMobile.setChecked(false);
                    layoutMobTab.setVisibility(View.GONE);
                    layoutAccesother.setVisibility(View.VISIBLE);
                    Log.d("addks", productCategory);
                }
            }
        });

        chkIn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(chkIn.isChecked()){
                    chkOut.setChecked(false);
                    Warranty_spinner.setVisibility(View.VISIBLE);
                    ArrayAdapter ab = new ArrayAdapter(Purchase_Menu.this, android.R.layout.simple_spinner_dropdown_item, Warranty_data);
                    Warranty_spinner.setAdapter(ab);
                    Warranty_spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        public void onItemSelected(AdapterView<?> parent, View view,
                                                   int position, long id) {

                                if(position==0){
                                    warrenty_month = "0-1 month old";
                                    Log.d("weir",warrenty_month);
                                }
                                else if(position==1){
                                    warrenty_month= "1-3 month old";
                                    Log.d("wseir",warrenty_month);
                                }
                                else if(position==2){
                                    warrenty_month= "3-6 month old";
                                    Log.d("weiar",warrenty_month);
                                }
                                else if(position==3){
                                    warrenty_month= "6-9 month old";
                                }else if(position==4){
                                    warrenty_month= "9-12 month old";
                                }

                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });

                }
            }
        });
        chkOut.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(chkOut.isChecked()){
                    chkIn.setChecked(false);
                    Warranty_spinner.setVisibility(View.GONE);
                }

            }
        });

    }

    private void click() {

        btn_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!(chkOk.isChecked() || chkPrexo.isChecked() || chkRepairing.isChecked())) {
                      Toast.makeText(Purchase_Menu.this, "Please choose Prexo, OK or Repairing ", Toast.LENGTH_SHORT).show();
                  }
                else if (!(chkMobile.isChecked() || chkTablet.isChecked() || chkAccesories.isChecked() || chkOther.isChecked())) {
                    Toast.makeText(Purchase_Menu.this, "Please choose any one category in product", Toast.LENGTH_SHORT).show();
                }
                else if((chkAccesories.isChecked() || chkOther.isChecked()) && (edt_brand.getText().toString().isEmpty() || edt_model.getText().toString().isEmpty())){
                    Toast.makeText(Purchase_Menu.this, "Please enter brand and model", Toast.LENGTH_SHORT).show();
                }
                else if(edt_gb.getText().toString().isEmpty()){
                    edt_gb.setError("Please enter gb");

                }
                else if(edt_imei.getText().toString().isEmpty()){
                    edt_imei.setError("Please enter Imei No.");
                }
                else if(edt_purchase_amount.getText().toString().isEmpty()){
                    edt_purchase_amount.setError("Please enter Purchase Amount.");
                }
                else if(edt_customer_name.getText().toString().isEmpty()){
                    edt_customer_name.setError("Please enter Customer Name.");
                }

                else{
                      finalSubmitApi();
                  }

            }
        });

    }

    ///////////////////////////////////////// Brand Spinner /////////////////////////////////////////////////////////////

    private void hitSpinnerBrandMobile() {
        final ProgressDialog progressDialog = new ProgressDialog(Purchase_Menu.this,R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        RequestQueue requestQueueMobile = Volley.newRequestQueue(Purchase_Menu.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.getBrand, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();

                brand_list.clear();
                brand_list_datamobile.clear();
                try {

                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.getString("code").equals("200")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            BrandSpinner brandSpinner = new BrandSpinner();
                            brandSpinner.setBrandId(jsonObject1.getInt("id"));
                            brandSpinner.setBrand_name(jsonObject1.getString("brand_name"));
                            brand_list.add(brandSpinner);
                            brand_list_datamobile.add(brand_list.get(i).getBrand_name());
                        }

                        Log.d("jhkljk", brand_list_datamobile.toString());

                        ArrayAdapter brandAdapter = new ArrayAdapter(Purchase_Menu.this, android.R.layout.simple_spinner_dropdown_item, brand_list_datamobile);
                        spinnerBrandMobile.setAdapter(brandAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Purchase_Menu.this, "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("type", "Mobile");

                return hashMap;

            }


        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }

    ///////////////////////////////////////Series Spinner///////////////////////////////////////////////////////////////

    private void hitSpinnerSeries(final String brand) {

            final ProgressDialog progressDialog = new ProgressDialog(Purchase_Menu.this,R.style.MyTheme);
            progressDialog.setCanceledOnTouchOutside(false);
            progressDialog.show();
            series_list_dataSeries.clear();
            series_list.clear();

            RequestQueue requestQueueMobile = Volley.newRequestQueue(Purchase_Menu.this);
            StringRequest request = new StringRequest(Request.Method.POST, Api.getseries, new com.android.volley.Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("Logdfgonse", response);
                    progressDialog.dismiss();

                    try {

                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.getString("code").equals("200")) {
                            JSONArray jsonArray = jsonObject.getJSONArray("data");

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                SeriesModel seriesModel = new SeriesModel();
                                seriesModel.setSeries_id(jsonObject1.getString("id"));
                                seriesModel.setSeries_name(jsonObject1.getString("series_name"));
                                series_list.add(seriesModel);
                                series_list_dataSeries.add(series_list.get(i).getSeries_name());
                            }

                            Log.d("jhkljasdk", series_list_dataSeries.toString());

                            ArrayAdapter brandAdapter = new ArrayAdapter(Purchase_Menu.this, android.R.layout.simple_spinner_dropdown_item, series_list_dataSeries);
                            spinnerSeries.setAdapter(brandAdapter);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new com.android.volley.Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    progressDialog.dismiss();
                    Toast.makeText(Purchase_Menu.this, "Something Wrong", Toast.LENGTH_SHORT).show();
                    Log.d("errodfr", error.getMessage() + "errorr");

                }
            }) {
                protected Map<String, String> getParams() {
                    HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("key", Api.key);
                    hashMap.put("brand_id", brand);
                    Log.d("brandidd",brand_id);

                    return hashMap;

                }

            };
            requestQueueMobile.getCache().clear();
            requestQueueMobile.add(request);
        }

    //////////////////////////////////////Model Autocomplete ////////////////////////////////////////////////////////////

    void hitModelApi(final String series) {

        RequestQueue requestQueue = Volley.newRequestQueue(Purchase_Menu.this);

        StringRequest request = new StringRequest(Request.Method.POST, Api.getModel, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("response_model",response);

                try {
                    JSONObject jsonObject= new JSONObject(response);

                    if (jsonObject.getString("code").equals("200")){
                        JSONArray jsonArray=jsonObject.getJSONArray("data");
                       // model_list_dataModel.clear();
                        model_list.clear();
                        for (int i=0;i<jsonArray.length();i++){

                            JSONObject jsonObject1= jsonArray.getJSONObject(i);
                            Model_Model model = new Model_Model();
                            model.setModel_id(jsonObject1.getString("id"));
                            model.setModelName(jsonObject1.getString("model_name"));
                            model_list.add(model);
                       //     model_list_dataModel.add(model_list.get(i).getModelName());

                          //  model_list_dataModel.add(jsonObject1.getString("model_name"));

                        }

                        modelAdapter = new ModelAdapter(getApplicationContext(), R.layout.fragment_purchase__menu,
                                R.id.lbl_name, model_list);
                        model_autocompleteTv.setAdapter(modelAdapter);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("series_id",series);
                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(request);


    }

   /////////////////////////////////// Brand Tablet Spinner /////////////////////////////////////////////////////////

    private void hitSpinnerBrandTablet() {
        final ProgressDialog progressDialog = new ProgressDialog(Purchase_Menu.this,R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();

        RequestQueue requestQueueMobile = Volley.newRequestQueue(Purchase_Menu.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.getBrand, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();
                brand_list_datamobile.clear();
                brand_list.clear();
                try {

                    JSONObject jsonObject = new JSONObject(response);

                    if (jsonObject.getString("code").equals("200")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("data");

                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            BrandSpinner brandSpinner = new BrandSpinner();
                            brandSpinner.setBrandId(jsonObject1.getInt("id"));
                            brandSpinner.setBrand_name(jsonObject1.getString("brand_name"));
                            brand_list.add(brandSpinner);
                            brand_list_datamobile.add(brand_list.get(i).getBrand_name());
                        }

                        Log.d("jhkljk", brand_list_datamobile.toString());

                        ArrayAdapter brandAdapter = new ArrayAdapter(Purchase_Menu.this, android.R.layout.simple_spinner_dropdown_item, brand_list_datamobile);
                        spinnerBrandMobile.setAdapter(brandAdapter);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(Purchase_Menu.this, "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("type", "Tablet");

                return hashMap;

            }


        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }


    //////////////////////////////////////// final submit Api ////////////////////////////////////////////////////////

    public void finalSubmitApi() {

        final ProgressDialog progressDialog = new ProgressDialog(Purchase_Menu.this,R.style.MyTheme);
        progressDialog.setMessage("Please wait while uploading image.");
        progressDialog.setCancelable(false);
        progressDialog.show();
        if(chkOk.isChecked()){
            statusok="Ok";
        }
        if(chkPrexo.isChecked()){
            statusPrexo="Prexo";
        }
        if(chkRepairing.isChecked()){
            statusRepairing="Repairing";
        }

        Log.d("statoscheck",statusok+statusPrexo+statusRepairing);
        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("purchase_cat_name", ApiFactory.getRequestBodyFromString(catgory));
        partMap.put("product_category", ApiFactory.getRequestBodyFromString(productCategory));

        if(chkMobile.isChecked() || chkTablet.isChecked()){
            partMap.put("brand", ApiFactory.getRequestBodyFromString(brand_id));
            partMap.put("model", ApiFactory.getRequestBodyFromString(idmodel));
            partMap.put("series_name", ApiFactory.getRequestBodyFromString(seriesstore));

            Log.d("dsaa",idmodel);
            Log.d("wqopw",brandstore+modelstore+seriesstore);
        }
        else if(chkAccesories.isChecked() || chkOther.isChecked()){
            partMap.put("brand", ApiFactory.getRequestBodyFromString(edt_brand.getText().toString()));
            partMap.put("model", ApiFactory.getRequestBodyFromString(edt_model.getText().toString()));

            Log.d("sadjkl",edt_brand.getText().toString()+" "+edt_model.getText().toString());
        }

        if(chkIn.isChecked()){
            warranty = "In";
            partMap.put("warrenty", ApiFactory.getRequestBodyFromString(warranty));
            partMap.put("warrenty_month", ApiFactory.getRequestBodyFromString(warrenty_month));
            Log.d("warntdy",warranty);
            Log.d("warnty",warrenty_month);
        }
        else if(chkOut.isChecked()){
            warranty = "out";
            partMap.put("warrenty",ApiFactory.getRequestBodyFromString(warranty));
            Log.d("warntdy",warranty);
        }

        partMap.put("gb", ApiFactory.getRequestBodyFromString(edt_gb.getText().toString()));
        partMap.put("imei_no", ApiFactory.getRequestBodyFromString(edt_imei.getText().toString()));
        partMap.put("product_condotion", ApiFactory.getRequestBodyFromString(conditon_Mobile));

        Log.d("codtn",conditon_Mobile);
        partMap.put("purchase_amount", ApiFactory.getRequestBodyFromString(edt_purchase_amount.getText().toString()));
        partMap.put("customer_name", ApiFactory.getRequestBodyFromString(edt_customer_name.getText().toString()));
        partMap.put("customer_mobile", ApiFactory.getRequestBodyFromString(edt_customer_mobile.getText().toString()));
        partMap.put("remark", ApiFactory.getRequestBodyFromString(edt_remark.getText().toString()));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("status_ok", ApiFactory.getRequestBodyFromString(statusok));
        partMap.put("status_prexo", ApiFactory.getRequestBodyFromString(statusPrexo));
        partMap.put("status_reparing", ApiFactory.getRequestBodyFromString(statusRepairing));

        Log.d("saidyt", String.valueOf(partMap));
        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListMobile.size()];
        MultipartBody.Part[] imageArray2 = new MultipartBody.Part[imagePathListCustomer.size()];

        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListMobile.get(i));
            try {
                File compressedfile = new Compressor(Purchase_Menu.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("image[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray2[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        for (int i = 0; i < imageArray2.length; i++) {
            File file = new File(imagePathListCustomer.get(i));
            try {
                File compressedfile = new Compressor(Purchase_Menu.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray2[i] = MultipartBody.Part.createFormData("image1[]", compressedfile.getName(), requestBodyArray);
            } catch (Exception e) {
                e.printStackTrace();
            }
            Log.d("assawe", String.valueOf(imageArray2[i]));

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.base_url).create(IApiServices.class);
        iApiServices.claimAPi(imageArray1,imageArray2, partMap)
                .enqueue(new Callback<JsonArray>() {
                    @Override
                    public void onResponse(Call<JsonArray> call, Response<JsonArray> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        Log.d("resposed_data",response.toString());
                        try {
                            JsonArray responseData = response.body();
                            final JsonObject jsonObject = responseData.get(0).getAsJsonObject();
                            phone_id = jsonObject.get("phone_id").getAsString();
                            if (jsonObject.get("code").getAsString().equals("200")) {

                                builder.setTitle("Your phone submission no.");
                                builder.setMessage(phone_id)
                                        .setCancelable(false)
                                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                finish();
                                                startActivity(new Intent(getApplicationContext(),Select.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                                                Toast.makeText(Purchase_Menu.this, jsonObject.get("msg").getAsString(), Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                AlertDialog alert = builder.create();
                                alert.show();

                            }
                        } catch (Exception e) {

                            Log.d("error_message",e.getMessage());
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonArray> call, Throwable t) {

                        Toast.makeText(Purchase_Menu.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        Log.d("data_error",t.getMessage());

                    }
                });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == 1 && count==1) {
                selectFromGalleryMobile(data);
                // setClaimGaller();
            }
            if (requestCode == 2 && count==1) {
                rotateImageMobile();
                // setClaimGaller();
            }
            if(requestCode==1 && count==2){
                selectFromGalleryCustomer(data);
            } if(requestCode==3 && count==2){
                rotateImageCustomer();
            }
        } catch (Exception e) {
        }
    }

    private File createImageFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        // Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

   private File createImageFile2() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        // Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
       cCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }


    private void takeMobileCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoMobileFile = createImageFile();
                // Log.d("checkexcesdp", String.valueOf(photoFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                //   Log.d("checkexcep", ex.getMessage());
            }

            photoMobileFile = createImageFile();
            //lk changes here
            photoUriMobile = FileProvider.getUriForFile(Purchase_Menu.this, getPackageName() + ".provider", photoMobileFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriMobile);
            startActivityForResult(takePictureIntent, 2);
        }

    }
      private void takeCustomerIdImage() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoCustomerFile = createImageFile2();
                // Log.d("checkexcesdp", String.valueOf(photoFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                //   Log.d("checkexcep", ex.getMessage());
            }

            photoCustomerFile = createImageFile2();
            //lk changes here
            photoUriCustomer = FileProvider.getUriForFile(Purchase_Menu.this, getPackageName() + ".provider", photoCustomerFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriCustomer);
            startActivityForResult(takePictureIntent, 3);
        }

    }


    public void rotateImageMobile() throws IOException {

        try {
            String photoPath= photoMobileFile.getAbsolutePath();
            imagePathListMobile.add(photoPath);
            bitmap1 = MediaStore.Images.Media.getBitmap(Purchase_Menu.this.getContentResolver(), photoUriMobile);
            bitmap1 = Bitmap.createScaledBitmap(bitmap1, 800, 800, false);
            ImageModel imageModel = new ImageModel();
            imageModel.setImageMobile(bitmap1);
            if (Mobilelist.size() < 5) {
                Mobilelist.add(imageModel);
            }


            if (Mobilelist.size() > 5) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_mobile.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
            mIMGAdapter = new MobileImageAdapter(Mobilelist, Purchase_Menu.this);
            rv_mobile.setAdapter(mIMGAdapter);

        } catch (Exception e) {
            e.printStackTrace();

        }
    }

 public void rotateImageCustomer() throws IOException {

        try {
            String photoPath= photoCustomerFile.getAbsolutePath();
            imagePathListCustomer.add(photoPath);
            bitmap2 = MediaStore.Images.Media.getBitmap(Purchase_Menu.this.getContentResolver(), photoUriCustomer);
            bitmap2 = Bitmap.createScaledBitmap(bitmap2, 800, 800, false);
            ImageModel imageModel = new ImageModel();
            imageModel.setImageCustomerId(bitmap2);
            if (customerlist.size() < 4) {
                customerlist.add(imageModel);
            }


            if (customerlist.size() > 4) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_customerId.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
            cImgAdapter = new CustomerImageAdapter(customerlist, Purchase_Menu.this);
            rv_customerId.setAdapter(cImgAdapter);

        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    private void selectFromGalleryMobile(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};


                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathMobile = Helper.pathFromUri(Purchase_Menu.this, mImageUri);
                        imagePathListMobile.add(photoPathMobile);

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedMobile = cursor1.getString(columnIndex1);
                        bitmap1 = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        ImageModel imageModel = new ImageModel();
                        imageModel.setImageMobile(bitmap1);

                        if (Mobilelist.size() < 5) {
                            Mobilelist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathMobile = Helper.pathFromUri(Purchase_Menu.this, mImageUri);
                    imagePathListMobile.add(photoPathMobile);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedMobile = cursor1.getString(columnIndex1);
                    bitmap1 = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                    cursor1.close();
                    ImageModel imageModel = new ImageModel();
                    imageModel.setImageMobile(bitmap1);
                    if (Mobilelist.size() < 5) {
                        Mobilelist.add(imageModel);
                    }
                }

                if (Mobilelist.size() > 5) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }

                rv_mobile.setLayoutManager(new LinearLayoutManager(Purchase_Menu.this, LinearLayoutManager.HORIZONTAL, false));
                mIMGAdapter = new MobileImageAdapter(Mobilelist, Purchase_Menu.this);
                rv_mobile.setAdapter(mIMGAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void selectFromGalleryCustomer(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};


                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathCustomer = Helper.pathFromUri(Purchase_Menu.this, mImageUri);
                        imagePathListCustomer.add(photoPathCustomer);

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodeCustomer = cursor1.getString(columnIndex1);
                        bitmap2 = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                        Log.d("asdads", String.valueOf(bitmap2));
                        cursor1.close();
                        ImageModel imageModel = new ImageModel();
                        imageModel.setImageCustomerId(bitmap2);
                        if (customerlist.size() < 4) {
                            customerlist.add(imageModel);
                        }

                    }
                } else {


                    Uri mImageUri = data.getData();
                    photoPathCustomer = Helper.pathFromUri(Purchase_Menu.this, mImageUri);
                    imagePathListCustomer.add(photoPathCustomer);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodeCustomer = cursor1.getString(columnIndex1);
                    bitmap2 = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                    cursor1.close();
                    ImageModel imageModel = new ImageModel();
                    imageModel.setImageMobile(bitmap2);
                    if (customerlist.size() < 4) {
                        customerlist.add(imageModel);
                    }
                }

                if (customerlist.size() > 4) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }

                rv_customerId.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false));
                cImgAdapter = new CustomerImageAdapter(customerlist, getApplicationContext());
                rv_customerId.setAdapter(cImgAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    /**
     * function to receive scanresult
     *
     * @param codeFormat  format of the barcode scanned
     * @param codeContent data of the barcode scanned
     */
    @Override
    public void scanResultData(String codeFormat, String codeContent) {
         edt_imei.setText(codeContent);
    }

    @Override
    public void scanResultData(NoScanResultException noScanData) {

    }

    public class MobileImageAdapter extends RecyclerView.Adapter<MobileImageAdapter.ListViewHolder> {
        ArrayList<ImageModel> list;
        Context context;

        public MobileImageAdapter(ArrayList<ImageModel> list, Context context) {
            this.context = context;
            this.list = list;
        }

        @Override
        public MobileImageAdapter.ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.row_image, null);

            return new MobileImageAdapter.ListViewHolder(view);
        }

        @Override
        public void onBindViewHolder(MobileImageAdapter.ListViewHolder holder, final int position) {
            final ImageModel imageModel = list.get(position);
            holder.image.setImageBitmap(imageModel.getImageMobile());
            holder.close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    removeAt(position);
                }
            });
        }

        public void removeAt(int position) {
            list.remove(position);
            notifyItemRemoved(position);
            notifyItemChanged(position);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ListViewHolder extends RecyclerView.ViewHolder {

            ImageView image;
            TextView close;

            public ListViewHolder(View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.ivGallery);
                close = itemView.findViewById(R.id.badge_view);
            }

        }
    }

    public class CustomerImageAdapter extends RecyclerView.Adapter<CustomerImageAdapter.ListViewHolder> {
        ArrayList<ImageModel> list;
        Context context;

        public CustomerImageAdapter(ArrayList<ImageModel> list, Context context) {
            this.context = context;
            this.list = list;
        }

        @Override
        public CustomerImageAdapter.ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.row_image, null);

            return new CustomerImageAdapter.ListViewHolder(view);
        }

        @Override
        public void onBindViewHolder(CustomerImageAdapter.ListViewHolder holder, final int position) {
            final ImageModel imageModel = list.get(position);
            holder.image.setImageBitmap(imageModel.getImageCustomerId());


            holder.close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    removeAt(position);
                }
            });
        }

        public void removeAt(int position) {
            list.remove(position);
            notifyItemRemoved(position);
            notifyItemChanged(position);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ListViewHolder extends RecyclerView.ViewHolder {

            ImageView image;
            TextView close;

            public ListViewHolder(View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.ivGallery);
                close = itemView.findViewById(R.id.badge_view);
            }

        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public void hideSoftKeyboard() {
        if(getCurrentFocus()==null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}