package com.example.ui;

public class Api {

    public static  final String key = "5642vcb546gfnbvb7r6ewc211365vhh34";
    public static  final String booking_url = "http://cellway.in/mobileappold/index.php/purchase_booking";
    public static  final String base_url = "https://cellway.in/mobileappold/index.php/";
    public static  final String login_url = "https://cellway.in/mobileappold/index.php/purchase_login";
    public static  final String saleMenu = "https://cellway.in/mobileappold/index.php/salebooking";
    public static  final String saleMenuCourier = "https://cellway.in/mobileappold/index.php/courierbooking";
    public static  final String dealerSale = "https://cellway.in/mobileappold/index.php/dealer_sale";
    public static  final String saleImei = "https://cellway.in/mobileappold/index.php/get_search_imeino";
    public static  final String getBrand = "https://cellway.in/mobileappold/index.php/getbrand";
    public static  final String getseries = "https://cellway.in/mobileappold/index.php/getseries";
    public static  final String getModel = "https://cellway.in/mobileappold/index.php/getmodel";
    public static  final String getState = base_url+"getstate";
    public static  final String getDealer = base_url+"getdealer";
    public static  final String getPaymentReceiptSearch = base_url+"getrecipt_paymentuser_search";
    public static  final String addReceipt = base_url+"add_recipt_payment";

    public static final String SENDOTP = "http://api.msg91.com/api/sendhttp.php";

}
