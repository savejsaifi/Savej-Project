package com.example.ui;

public class Api {

    public static  final String key = "5642vcb546gfnbvb7r6ewc211365vhh34";
    public static  final String booking_url = "http://cellway.in/mobileapp/index.php/purchase_booking";
    public static  final String base_url = "https://cellway.in/mobileapp/index.php/";
    public static  final String login_url = "https://cellway.in/mobileapp/index.php/purchase_login";
    public static  final String saleMenu = "https://cellway.in/mobileapp/index.php/salebooking";
    public static  final String saleImei = "https://cellway.in/mobileapp/index.php/get_search_imeino";
    public static  final String getBrand = "https://cellway.in/mobileapp/index.php/getbrand";
    public static  final String getseries = "https://cellway.in/mobileapp/index.php/getseries";
    public static  final String getModel = "https://cellway.in/mobileapp/index.php/getmodel";

}
