package com.example.ui.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.ui.Api;
import com.example.ui.R;
import com.example.ui.model.ReceiptPaymentGetModel;
import com.example.ui.model.ReceiptPaymentModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class PaymentAccountFragment extends Fragment implements SearchView.OnQueryTextListener {

    public PaymentAccountFragment() {
        // Required empty public constructor
    }

    RadioGroup ReciptGroup;
    LinearLayout linearAccountingReceipt;
    EditText edtName_OtherReceipt, edtCash_OtherReceipt, edtCard_OtherReceipt, edtBank_OtherReceipt, edtNaration_OtherReceipt;
  //  TextView txtTodayBank, txtTodayCard, txtTodayCash;
    Button btn_receiptOther_Submit;
    SearchView ReceiptSearchName;
    RecyclerView rv_Search_receipt, rvReceiptSelected;
    ArrayList<ReceiptPaymentModel> listReceipt = new ArrayList<>();
    ArrayList<ReceiptPaymentGetModel> listReceiptGet = new ArrayList<>();
    ImeiAdapter adapter;
    String dealerid = "";
    String dealerName = "";
    SharedPreferences sharedPreferences;
    String userid;
    Receipt_Adapter receiptAdapter;

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_payment_account, container, false);
        sharedPreferences = getActivity().getSharedPreferences("savej", MODE_PRIVATE);
        userid = sharedPreferences.getString("userid", "");

        ReciptGroup = (RadioGroup) view.findViewById(R.id.ReciptGroupPayment);
        linearAccountingReceipt = (LinearLayout) view.findViewById(R.id.linearAccountingPayment);
        edtName_OtherReceipt = (EditText) view.findViewById(R.id.edtName_OtherPayment);
        edtCash_OtherReceipt = (EditText) view.findViewById(R.id.edtCash_OtherPayment);
        edtCard_OtherReceipt = (EditText) view.findViewById(R.id.edtCard_OtherPayment);
        edtBank_OtherReceipt = (EditText) view.findViewById(R.id.edtBank_OtherPayment);
        edtNaration_OtherReceipt = (EditText) view.findViewById(R.id.edtNaration_OtherPayment);
//        txtTodayCash = (TextView) view.findViewById(R.id.txtTodayCashPay);
//        txtTodayCard = (TextView) view.findViewById(R.id.txtTodayCardPay);
//        txtTodayBank = (TextView) view.findViewById(R.id.txtTodayBankPay);
        btn_receiptOther_Submit = (Button) view.findViewById(R.id.btn_paymentOther_Submit);
        ReceiptSearchName = view.findViewById(R.id.PaymentSearchName);
        rv_Search_receipt = view.findViewById(R.id.rv_Search_payment);
        rvReceiptSelected = view.findViewById(R.id.rvPaymentSelected);
        rv_Search_receipt.setVisibility(View.GONE);

        hitSearchApi();
        hitgetDetailApiWithouParams();
        ReceiptSearchName.setOnQueryTextListener(this);
        ReceiptSearchName.setQueryHint(Html.fromHtml("<font color = #ffffff>" +
                getResources().getString(R.string.dealerhint) + "</font>"));


        ReciptGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton checkedRadioButton = group.findViewById(checkedId);
                boolean isChecked = checkedRadioButton.isChecked();
                if (isChecked) {
                    if (checkedRadioButton.getText().equals("Payment Accounting")) {
                        linearAccountingReceipt.setVisibility(View.VISIBLE);
                        edtName_OtherReceipt.setVisibility(View.GONE);
                    }
                    if (checkedRadioButton.getText().equals("Payment Other")) {
                        dealerid = "0";
                        edtName_OtherReceipt.setVisibility(View.VISIBLE);
                        linearAccountingReceipt.setVisibility(View.GONE);
                    }
                }
            }
        });

        btn_receiptOther_Submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dealerid.equals("0")) {
                    dealerName = edtName_OtherReceipt.getText().toString();
                }
                if (edtCash_OtherReceipt.getText().toString().isEmpty() && edtCard_OtherReceipt.getText().toString().isEmpty()
                        && edtBank_OtherReceipt.getText().toString().isEmpty()) {
                    Toast.makeText(getActivity(), "enter cash,card or bank details", Toast.LENGTH_SHORT).show();
                }
                else {
                    hitgetDetailApi();
                }
            }
        });
        return view;
    }

    private void hitgetDetailApiWithouParams() {
        listReceiptGet.clear();
        final ProgressDialog progressDialog = new ProgressDialog(getActivity(), R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        RequestQueue requestQueueMobile = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.addReceipt, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
//                    txtTodayBank.setText(jsonObject.getString("today_bank") + "/-");
//                    txtTodayCash.setText(jsonObject.getString("today_cash") + "/-");
//                    txtTodayCard.setText(jsonObject.getString("today_card") + "/-");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        ReceiptPaymentGetModel model = new ReceiptPaymentGetModel();
                        model.setBank(jsonObject1.getString("bank_r")+"/-");
                        model.setCard(jsonObject1.getString("card_r")+"/-");
                        model.setCash(jsonObject1.getString("cash_r")+"/-");
                        model.setName(jsonObject1.getString("name_receive_pay"));
                        model.setNarration(jsonObject1.getString("narration"));
                        model.setTotalPrice(jsonObject1.getString("total_price_r")+"/-");
                        model.setPaymentType(jsonObject1.getString("payment_type"));

                        listReceiptGet.add(model);
                    }

                    rvReceiptSelected.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
                    rvReceiptSelected.setLayoutManager(layoutManager);
                    receiptAdapter = new Receipt_Adapter(getActivity(), listReceiptGet);
                    rvReceiptSelected.setAdapter(receiptAdapter);
                    receiptAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;

            }

        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }

    private void hitgetDetailApi() {
        listReceiptGet.clear();
        final ProgressDialog progressDialog = new ProgressDialog(getActivity(), R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        RequestQueue requestQueueMobile = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.addReceipt, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Loginresponse", response);
                progressDialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
//                    txtTodayBank.setText(jsonObject.getString("today_bank") + "/-");
//                    txtTodayCash.setText(jsonObject.getString("today_cash") + "/-");
//                    txtTodayCard.setText(jsonObject.getString("today_card") + "/-");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        ReceiptPaymentGetModel model = new ReceiptPaymentGetModel();
                        model.setBank(jsonObject1.getString("bank_r")+"/-");
                        model.setCard(jsonObject1.getString("card_r")+"/-");
                        model.setCash(jsonObject1.getString("cash_r")+"/-");
                        model.setName(jsonObject1.getString("name_receive_pay"));
                        model.setNarration(jsonObject1.getString("narration"));
                        model.setTotalPrice(jsonObject1.getString("total_price_r")+"/-");
                        model.setPaymentType(jsonObject1.getString("payment_type"));

                        listReceiptGet.add(model);


                    }

                    rvReceiptSelected.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
                    rvReceiptSelected.setLayoutManager(layoutManager);
                    receiptAdapter = new Receipt_Adapter(getActivity(), listReceiptGet);
                    rvReceiptSelected.setAdapter(receiptAdapter);
                    receiptAdapter.notifyDataSetChanged();

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("userid", userid);
                hashMap.put("dealer_id", dealerid);
                hashMap.put("pay_username", dealerName);
                hashMap.put("payment_type", "debit");

                if (edtNaration_OtherReceipt.getText().toString().isEmpty()) {
                    hashMap.put("narration", "");
                } else {
                    hashMap.put("narration", edtNaration_OtherReceipt.getText().toString());
                }
                if (edtCash_OtherReceipt.getText().toString().isEmpty()) {
                    hashMap.put("cash", "0");
                } else {
                    hashMap.put("cash", edtCash_OtherReceipt.getText().toString());
                }
                if (edtCard_OtherReceipt.getText().toString().isEmpty()) {
                    hashMap.put("card", "0");
                } else {
                    hashMap.put("card", edtCard_OtherReceipt.getText().toString());
                }
                if (edtBank_OtherReceipt.getText().toString().isEmpty()) {
                    hashMap.put("bank", "0");
                } else {
                    hashMap.put("bank", edtBank_OtherReceipt.getText().toString());
                }
                return hashMap;

            }

        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        if (listReceipt.contains(query)) {
            adapter.getFilter().filter(query);
        } else {
            // Toast.makeText(getActivity(), "No Dealer is available", Toast.LENGTH_SHORT).show();
        }

        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {

        adapter.getFilter().filter(newText);
        if (newText.length() >= 1) {
            rv_Search_receipt.setVisibility(View.VISIBLE);
        }
        if (newText.length() < 1) {
            rv_Search_receipt.setVisibility(View.GONE);
        }
        return false;
    }


    public class Receipt_Adapter extends RecyclerView.Adapter<Receipt_Adapter.ReceiptViewHolder> {

        Context context;
        ArrayList<ReceiptPaymentGetModel> lstArvl;

        public Receipt_Adapter(Context context, ArrayList<ReceiptPaymentGetModel> lstArvl) {
            this.context = context;
            this.lstArvl = lstArvl;
        }


        @NonNull
        @Override
        public Receipt_Adapter.ReceiptViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            view = layoutInflater.inflate(R.layout.row_receipt_account,parent,false);
            return new Receipt_Adapter.ReceiptViewHolder(view);
        }


        @Override
        public void onBindViewHolder(Receipt_Adapter.ReceiptViewHolder holder, int position) {
            ReceiptPaymentGetModel model = lstArvl.get(position);

            holder.txtName.setText(model.getName());
            holder.txtNarration.setText(model.getNarration());
            holder.txtTotal.setText(model.getTotalPrice());
            holder.txtcash.setText(model.getCash());
            holder.txtCard.setText(model.getCard());
            holder.txtBank.setText(model.getBank());

        }


        @Override
        public int getItemCount() {
            return lstArvl.size();
        }

        public class ReceiptViewHolder extends RecyclerView.ViewHolder{

            TextView txtName,txtNarration,txtTotal,txtcash,txtCard,txtBank;
            public ReceiptViewHolder(@NonNull View itemView) {
                super(itemView);
                txtName = itemView.findViewById(R.id.txtName);
                txtNarration = itemView.findViewById(R.id.txtNarration);
                txtTotal = itemView.findViewById(R.id.txtTotal);
                txtcash = itemView.findViewById(R.id.txtcash);
                txtCard = itemView.findViewById(R.id.txtCard);
                txtBank = itemView.findViewById(R.id.txtBank);

            }
        }

    }

    ///////////////////////////////////////////// search api with adapter ////////////////////////////////////
    private void hitSearchApi() {

        final ProgressDialog progressDialog = new ProgressDialog(getActivity(),R.style.MyTheme);
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();
        RequestQueue requestQueueMobile = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.getPaymentReceiptSearch, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("mlkon", response);
                progressDialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        ReceiptPaymentModel model = new ReceiptPaymentModel();
                        model.setId(jsonObject1.getString("id"));
                        model.setDealerName(jsonObject1.getString("dealer_name"));

                        listReceipt.add(model);


                    }

                    rv_Search_receipt.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getActivity(),1);
                    rv_Search_receipt.setLayoutManager(layoutManager);
                    adapter=new ImeiAdapter(getActivity(),listReceipt);
                    rv_Search_receipt.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(getActivity(), "Something Wrong", Toast.LENGTH_SHORT).show();
                Log.d("errodfr", error.getMessage() + "errorr");

            }
        })
        {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;

            }

        };
        requestQueueMobile.getCache().clear();
        requestQueueMobile.add(request);
    }
    public class ImeiAdapter extends RecyclerView.Adapter<ImeiAdapter.LatestViewHolder> implements Filterable {


        Context context;

        private List<ReceiptPaymentModel> nameList;
        private List<ReceiptPaymentModel> filteredNameList;


        public ImeiAdapter(Context context, ArrayList<ReceiptPaymentModel> nameList) {
            super();
            this.context = context;
            this.nameList = nameList;
            this.filteredNameList = nameList;
        }


        @NonNull
        @Override
        public ImeiAdapter.LatestViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;

            LayoutInflater layoutInflater = LayoutInflater.from(context);
            view = layoutInflater.inflate(R.layout.row_imei,parent,false);

            return new ImeiAdapter.LatestViewHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull ImeiAdapter.LatestViewHolder holder, int position) {

            holder.tv_imei.setText(filteredNameList.get(position).getDealerName());


        }


        @Override
        public int getItemCount() {
            return filteredNameList.size();
        }

        public Filter getFilter() {
            return new Filter() {
                @Override
                protected FilterResults performFiltering(CharSequence constraint) {
                    String charSequenceString = constraint.toString();
                    if (charSequenceString.isEmpty()) {
                        filteredNameList = nameList;
                    } else {
                        List<ReceiptPaymentModel> filteredList = new ArrayList<>();
                        for (ReceiptPaymentModel name : nameList) {
                            if (name.getDealerName().toLowerCase().contains(charSequenceString.toLowerCase())) {
                                filteredList.add(name);
                            }
                            filteredNameList = filteredList;
                        }

                    }
                    FilterResults results = new FilterResults();
                    results.values = filteredNameList;
                    return results;
                }

                @Override
                protected void publishResults(CharSequence constraint, FilterResults results) {
                    filteredNameList = (List<ReceiptPaymentModel>) results.values;
                    notifyDataSetChanged();
                }
            };
        }

        public class LatestViewHolder extends RecyclerView.ViewHolder{

            //            FragmentManager fragmentManager = getSupportFragmentManager();
            TextView tv_imei;
            public LatestViewHolder(@NonNull final View itemView) {
                super(itemView);
                tv_imei = itemView.findViewById(R.id.tv_imei);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        int pos = getAdapterPosition();

                        // check if item still exists
                        if(pos != RecyclerView.NO_POSITION){
                            ReceiptPaymentModel clickedDataItem = filteredNameList.get(pos);
                            dealerid = clickedDataItem.getId();
                            dealerName = clickedDataItem.getDealerName();
                            ReceiptSearchName.setQuery(dealerName,true);

                            rv_Search_receipt.setVisibility(View.GONE);
                            Log.d("assaflmnj",dealerid+" "+dealerName);
                        }
                    }
                });
            }
        }

    }


}
