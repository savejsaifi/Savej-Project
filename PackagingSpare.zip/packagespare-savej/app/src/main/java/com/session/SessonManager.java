package com.session;

import android.content.Context;
import android.content.SharedPreferences;

public class SessonManager {

    private static SessonManager pref;
    private SharedPreferences sharedPreference;
    private SharedPreferences.Editor editor;
    public static final String NAME = "MY_PREFERENCES";
    public static final String Key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9hcHBwbGFjZS54eXpcL2FwaVwvdmVyaWZ5LW90cCIsImlhdCI6MTU3NzA4MDMwNSwiZXhwIjoxNTc3MDgzOTA1LCJuYmYiOjE1NzcwODAzMDUsImp0aSI6Im01aU9BNVBscEoyMDZXMXIiLCJzdWIiOjEyLCJwcnYiOiI4N2UwYWYxZWY5ZmQxNTgxMmZkZWM5NzE1M2ExNGUwYjA0NzU0NmFhIn0.sv0no1EOPYMiRdB9dOQL0Xdu8xBUtK4dpf0_4xZl2jQ";


    public SessonManager(Context ctx) {
        sharedPreference = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        editor = sharedPreference.edit();
    }
    public static SessonManager getInstance(Context ctx) {
        if (pref == null) {
            pref = new SessonManager(ctx);
        }
        return pref;
    }

    public void setUserId(String userId){
        editor.putString(Key,userId);
        editor.commit();
    }

    public  void deleteAllSharePrefs(){
        sharedPreference.edit().clear().commit();
    }


    public String getUserid(){
        return sharedPreference.getString(Key,"");
}


}
