package com.avaskm.model;

public class Categorymodel {
    private String item;
    private String image;
    private String id;

    public Categorymodel() {
    }

    public Categorymodel(String item, String image, String id) {
        this.item = item;
        this.image = image;
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
