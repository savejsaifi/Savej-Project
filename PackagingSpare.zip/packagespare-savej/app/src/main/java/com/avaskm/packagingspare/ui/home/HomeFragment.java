package com.avaskm.packagingspare.ui.home;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.activity.CategoryActivity;
import com.avaskm.activity.OtpActivity;
import com.avaskm.activity.SearchProduct;
import com.avaskm.adapter.SliderAdapter;
import com.avaskm.model.BannerModel;
import com.avaskm.model.Pakagingmodel;
import com.avaskm.packagingspare.LoginActivity;
import com.avaskm.packagingspare.R;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.avaskm.Api.Api.LOGIN_URL;
import static com.avaskm.Api.Api.category;
import static com.avaskm.Api.Api.home;

public class HomeFragment extends Fragment {
    RecyclerView rvrecyclerview;
    List<Pakagingmodel> pakagingmodelList;
    Packagingspareadapter adapter;
    Integer[] images={R.drawable.categoryfirst,R.drawable.categorysecond,R.drawable.categorythirdd,R.drawable.categoryfour};
    TabLayout tabLayout;
    ViewPager mViewPager;
    EditText searchHome;
    ArrayList<BannerModel>arListBanner;
    private static int currentpage;
    int[] pic = {R.drawable.categoryfirst,
            R.drawable.categoryfirst,
            R.drawable.categoryfirst,
            R.drawable.categoryfirst,
            R.drawable.categoryfirst,
            R.drawable.categoryfirst};
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate( R.layout.fragment_home, container, false );
        rvrecyclerview=root.findViewById( R.id.recyclerview);

        searchHome= root.findViewById( R.id.searchHome);
        pakagingmodelList=new ArrayList<>();
        arListBanner=new ArrayList<>();
        //setpackaging();
        rvrecyclerview.setFocusable(false);
        mViewPager = (ViewPager) root.findViewById(R.id.viewPage);
        SliderAdapter adapterView = new SliderAdapter(getActivity(), arListBanner);
        mViewPager.setAdapter(adapterView);

        tabLayout = root.findViewById(R.id.tab_dots);
        tabLayout.setupWithViewPager(mViewPager,true);
        init();
        gethomecategoryAPI();

        rvrecyclerview.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getContext(),2);
        rvrecyclerview.setLayoutManager(layoutManager);
        pakagingmodelList.clear();



        searchHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), SearchProduct.class));
            }
        });



        return root;
    }

    private void init() {

//        tabLayout.setupWithViewPager(mViewPager, true);

        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (currentpage == pic.length) {
                    currentpage = 0;
                }
                mViewPager.setCurrentItem(currentpage++, true);
            }
        };
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 2000, 2000);
    }

    public class Packagingspareadapter extends RecyclerView.Adapter<Packagingspareadapter.ViewHolder>{
        private Context context;
        private ArrayList<Pakagingmodel>mData;

        public Packagingspareadapter(Context context, ArrayList<Pakagingmodel> mData) {
            this.context = context;
            this.mData = mData;
        }
        @NonNull
        @Override
        public Packagingspareadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_pakaging,viewGroup,false);
            Packagingspareadapter.ViewHolder viewHolder=new Packagingspareadapter.ViewHolder(view);
            return viewHolder;
        }
        @Override
        public void onBindViewHolder(@NonNull Packagingspareadapter.ViewHolder holder, final int i) {
           // Picasso.get().load(mData.get(i).getImage()).into(holder.imageView);
            //Picasso.with(context).load(arList.get(position).getImage()).into(holder.IvIMageCateFirst);
            Picasso.get().load( mData.get(i).getImage()).into( holder.imageView );
            holder.txtcategory.setText( mData.get( i ).getItem());
            holder.cardviewitem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   // final Intent intent;


                    Intent intent=new Intent(getContext(), CategoryActivity.class);

                    intent.putExtra("id",mData.get(i).getId() );

                    Log.d("ids===",mData.get(i).getId());


                    startActivity(intent);

                }
            });

        }


        @Override
        public int getItemCount() {
            return mData.size();
        }
        public class ViewHolder extends RecyclerView.ViewHolder{
            ImageView imageView;
            CardView cardviewitem;
            TextView txtcategory;

            public ViewHolder(@NonNull View itemView) {
                super( itemView );
                imageView=itemView.findViewById( R.id.iv_pacaging_image );
                cardviewitem=itemView.findViewById( R.id.cardviewitem );
                txtcategory=itemView.findViewById( R.id.txtcategory);
            }
        }
    }

    public void gethomecategoryAPI(){
        final ProgressDialog dialog = ProgressDialog.show( getContext(), "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest( Request.Method.GET, home, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responsesee",response);
                dialog.dismiss();
                try {
                   JSONObject jsonObject=new JSONObject( response );
                   JSONArray jsonArray=jsonObject.getJSONArray( "banner" );
                   for (int i=0;i<jsonArray.length();i++) {
                       JSONObject jsonObject1 = jsonArray.getJSONObject( i );
                       BannerModel model=new BannerModel();
                       model.setImage(jsonObject1.getString( "doc_path" ));
                       arListBanner.add( model );
                       Log.d("banner", String.valueOf(arListBanner.size()));

                   }
                    SliderAdapter adapterView = new SliderAdapter(getActivity(), arListBanner);
                    mViewPager.setAdapter(adapterView);
                    tabLayout.setupWithViewPager(mViewPager);
                    JSONArray maincategory=jsonObject.getJSONArray("maincategories");

                    for (int j=0;j<maincategory.length();j++){
                       JSONObject jsonmain=maincategory.getJSONObject(j);
                        Pakagingmodel bussiness=new Pakagingmodel();
                        String title=jsonmain.getString( "title" );
                        String image=jsonmain.getString( "image" );
                        bussiness.setId( jsonmain.getString( "id" ));
                        bussiness.setItem(jsonmain.getString("title"));
                        bussiness.setImage( jsonmain.getString( "image" ) );
                        Log.d( "image",image );
                        pakagingmodelList.add( bussiness );
                    }
                    adapter=new Packagingspareadapter( getContext(), (ArrayList<Pakagingmodel>) pakagingmodelList );
                    rvrecyclerview.setAdapter( adapter );

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        });
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}