package com.avaskm.model;

public class Ordermodel {
    private String product;
    private String size;
    private String orderid;
    private String date;
    private String totalpaidamount;
    private String pricetotal;
    private String unitcost;
    private String status;
    private String image;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private String id;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }



    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    private String qty;

    public Ordermodel() {
    }

    public Ordermodel(String product, String size, String orderid, String date, String totalpaidamount, String pricetotal, String unitcost, String image) {
        this.product = product;
        this.size = size;
        this.orderid = orderid;
        this.date = date;
        this.totalpaidamount = totalpaidamount;
        this.pricetotal = pricetotal;
        this.unitcost = unitcost;
        this.image = image;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getOrderid() {
        return orderid;
    }

    public void setOrderid(String orderid) {
        this.orderid = orderid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotalpaidamount() {
        return totalpaidamount;
    }

    public void setTotalpaidamount(String totalpaidamount) {
        this.totalpaidamount = totalpaidamount;
    }

    public String getPricetotal() {
        return pricetotal;
    }

    public void setPricetotal(String pricetotal) {
        this.pricetotal = pricetotal;
    }

    public String getUnitcost() {
        return unitcost;
    }

    public void setUnitcost(String unitcost) {
        this.unitcost = unitcost;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
