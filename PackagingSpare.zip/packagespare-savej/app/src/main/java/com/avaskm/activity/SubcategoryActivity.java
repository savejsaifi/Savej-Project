package com.avaskm.activity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.CustomBottomSheetFragment;
import com.avaskm.SessonManager;
import com.avaskm.fragment.FilterFragment;
import com.avaskm.model.Categorymodel;
import com.avaskm.model.Subcategory;
import com.avaskm.packagingspare.CustomBottomSheetDialogFragment;
import com.avaskm.packagingspare.R;
import com.avaskm.packagingspare.ui.home.HomeFragment;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import static com.avaskm.Api.Api.category;


public class SubcategoryActivity extends AppCompatActivity {
    RecyclerView recyclerviewsubcategory;
    List<Subcategory> subcategories;
    Subcategoryadapter subcategoryadapter;

    LinearLayout  mainactivity;
    private Context mContext;
    TextView txtproduct;
    private static FragmentManager fragmentManager;
    RelativeLayout relative_cart;
    TextView TvCartQty;

    EditText searchClick;
    SessonManager sessonManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subcategory);
        sessonManager = new SessonManager(SubcategoryActivity.this);

        mainactivity = (LinearLayout) findViewById(R.id.mainactivity);
        fragmentManager = getSupportFragmentManager();
        recyclerviewsubcategory = findViewById(R.id.recyclerviewsubcategory);
        searchClick = findViewById(R.id.searchClick);
        txtproduct = findViewById(R.id.txtproduct);
        subcategories = new ArrayList<>();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Product");
        //setpackaging();
        String id = getIntent().getStringExtra("id");
        Log.d("subcategory", id);

        mContext = getApplicationContext();
        recyclerviewsubcategory.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(SubcategoryActivity.this, 2);
        recyclerviewsubcategory.setLayoutManager(layoutManager);
        subcategories.clear();

        SharedPreferences myPrefs;
        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String StoredValue = myPrefs.getString("token", "");
        //Log.d("categorysubkey", StoredValue);

        getcategoryId(id);
        searchClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SearchProduct.class));
            }
        });


    }

    @Override
    protected void onRestart() {
        super.onRestart();
        TvCartQty.setText(sessonManager.getQty());
        // Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart,menu);
        MenuItem item = menu.findItem(R.id.action_viewcart);
        MenuItemCompat.setActionView(item,R.layout.badge_menu);


        RelativeLayout notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        relative_cart = (RelativeLayout) notifCount.findViewById(R.id.relative_cart);

        TvCartQty = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);
        TvCartQty.setText(sessonManager.getQty());

        TvCartQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });


        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    public class Subcategoryadapter extends RecyclerView.Adapter<Subcategoryadapter.ViewHolder> {
        private Context context;
        private ArrayList<Subcategory> mData;

        public Subcategoryadapter(Context context, ArrayList<Subcategory> mData) {
            this.context = context;
            this.mData = mData;
        }

        @NonNull
        @Override
        public Subcategoryadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_subcategory, parent, false);
            Subcategoryadapter.ViewHolder viewHolder = new Subcategoryadapter.ViewHolder(view);
            return viewHolder;
        }


        @Override
        public void onBindViewHolder(@NonNull Subcategoryadapter.ViewHolder holder, final int position) {
            Picasso.get().load(mData.get(position).getImage()).into(holder.img_categoryimage);
            holder.txtfirst.setText(mData.get(position).getFirt());
            holder.txtsecprodcutprice.setText(mData.get(position).getSecond());
            holder.txtPercent.setText(mData.get(position).getPercent());

            //btncutprice.setPaintFlags(btncutprice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG );
            holder.txtsecprodcutprice.setPaintFlags(holder.txtsecprodcutprice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.txtproduct.setText(mData.get(position).getThird());
            holder.cardviewsubcategory.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Intent intent;

                    Intent intentone = new Intent(SubcategoryActivity.this, CategorydetailActivity.class);

                    intentone.putExtra("id", mData.get(position).getId());

                    Log.d("ids===", mData.get(position).getId());


                    startActivity(intentone);
                    // mContext.startActivity(intent);

                }
            });
        }


        @Override
        public int getItemCount() {
            return mData.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            ImageView img_categoryimage;
            TextView txtfirst, txtproduct, txtsecprodcutprice,txtPercent;
            CardView cardviewsubcategory;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                img_categoryimage = itemView.findViewById(R.id.img_categoryimage);
                txtfirst = itemView.findViewById(R.id.txtsubcat);
                txtproduct = itemView.findViewById(R.id.txtproduct);
                txtsecprodcutprice = itemView.findViewById(R.id.txtsecprodcutprice);
                cardviewsubcategory = itemView.findViewById(R.id.cardviewsubcategory);
                txtPercent = itemView.findViewById(R.id.txtPercent);

            }
        }
    }



    private void getcategoryId(String id) {
        final ProgressDialog dialog = ProgressDialog.show(SubcategoryActivity.this, "", "Loading....", false);
        String urll = category + "/" + id + "/product";
        /*http://appplace.xyz/api/category/2/product*/
        RequestQueue requestQueue = Volley.newRequestQueue(SubcategoryActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urll, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("subcategoryres", response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray = new JSONArray(response);

                    for (int j = 0; j < jsonArray.length(); j++) {
                        JSONObject jsonmain = jsonArray.getJSONObject(j);
                        Subcategory bussiness = new Subcategory();
//                        String titlee = jsonmain.getString("cut_price");
                      //  String image = jsonmain.getString("image");

                        bussiness.setFirt(jsonmain.getString("name"));
                        bussiness.setPercent(jsonmain.getString("percent"));
                    //    bussiness.setThird(jsonmain.getString("price"));
                     //   bussiness.setSecond(jsonmain.getString("cut_price"));
                    //    Log.d("cutprice", titlee);
                        bussiness.setImage(jsonmain.getString("image"));
                        bussiness.setId(jsonmain.getString("id"));
                        bussiness.setSecond(jsonmain.getString("cut_price"));
                        bussiness.setThird(jsonmain.getString("price"));


                       // Log.d("imagee", image);
                        subcategories.add(bussiness);
                    }
                    subcategoryadapter = new Subcategoryadapter(SubcategoryActivity.this, (ArrayList<Subcategory>) subcategories);
                    recyclerviewsubcategory.setAdapter(subcategoryadapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}