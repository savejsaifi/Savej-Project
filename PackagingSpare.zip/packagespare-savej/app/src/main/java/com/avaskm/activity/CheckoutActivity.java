package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.model.Cartymodel;
import com.avaskm.packagingspare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.avaskm.Api.Api.cartdetail;
import static com.avaskm.Api.Api.makeorder;

public class CheckoutActivity extends AppCompatActivity {
    Button btncontinue;
    SharedPreferences sharedPreferencesAddress,myPrefs,amountSharedPref;
    String shippingAddress,shippingPin,shippingCity;
    TextView txtAddress,txtCity,txtPin;
    ImageView addressEdt;
    String token,Id;
    TextView txtMRP,txtDELIVERY,txtPAYBLE;
    int mrp,delivery,total;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_checkout );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Packaging Spare");

        sharedPreferencesAddress = getSharedPreferences("shippingAddress",MODE_PRIVATE);
        shippingAddress = sharedPreferencesAddress.getString("shippingAddress","");
        shippingCity = sharedPreferencesAddress.getString("shippingCity","");
        shippingPin = sharedPreferencesAddress.getString("shippingPin","");

        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        token=myPrefs.getString("token", "");
        Log.d( "categorysubkey",token );

        amountSharedPref = getSharedPreferences("finalAmount",MODE_PRIVATE);
        Id = amountSharedPref.getString("id","");
//        mrp = amountSharedPref.getInt("mrp",0);
//        delivery = amountSharedPref.getInt("delivery",0);
//        total = amountSharedPref.getInt("paybleAmount",0);

        Log.d( "catesgorysubkey", String.valueOf(mrp));

        btncontinue=findViewById( R.id.btncontinue );
        txtAddress=findViewById( R.id.txtAddress );
        txtCity=findViewById( R.id.txtCity );
        txtPin=findViewById( R.id.txtPin );

        addressEdt=findViewById( R.id.addressEdt );
        txtMRP=findViewById( R.id.txtMRP );
        txtDELIVERY=findViewById( R.id.txtDELIVERY );
        txtPAYBLE=findViewById( R.id.txtPAYBLE );

        txtAddress.setText(shippingAddress);
        txtCity.setText(shippingCity);
        txtPin.setText(shippingPin);

        getTotalDetail();


        imgClickListner();


        btncontinue.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    payNow();


            }
        } );
    }

    private void getTotalDetail() {
//                final ProgressDialog dialog = ProgressDialog.show(CartActivity.this, "", "Loading....", false);
        //  String urll= http://appplace.xyz/api/product/;

        RequestQueue requestQueue = Volley.newRequestQueue(CheckoutActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, cartdetail, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("cartcaard", response);
//                        dialog.dismiss();
                try {
                    JSONObject jsonObjectFirst = new JSONObject(response);

//                    totalPrice.setText("\u20B9"+jsonObjectFirst.getString("total"));
//                    totalQuantityCart.setText("Qty "+jsonObjectFirst.getString("quantity")+",");

                    txtMRP.setText("₹"+jsonObjectFirst.getString("price_total")+"/-");
                    txtDELIVERY.setText("₹"+jsonObjectFirst.getString("delivery_total")+"/-");
                    txtPAYBLE.setText("₹"+jsonObjectFirst.getString("total")+"/-");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
//                        dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + token);
                Log.d("chejklf", String.valueOf(token));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                Log.d("chejklf", String.valueOf(hashMap));

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }



    private void imgClickListner() {
        addressEdt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(CheckoutActivity.this, "edit your shipping address details", Toast.LENGTH_LONG).show();
                startActivity(new Intent(getApplicationContext(),AddressActivity.class));
            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    private void payNow() {
        final ProgressDialog dialog = ProgressDialog.show( CheckoutActivity.this, "", "Loading....", false );
        //  String urll= http://appplace.xyz/api/product/;

        RequestQueue requestQueue = Volley.newRequestQueue( CheckoutActivity.this );
        StringRequest stringRequest = new StringRequest( Request.Method.GET, Api.payNow+"/"+Id, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d( "checkout", response );
                dialog.dismiss();
                try {
                    JSONObject jsonObject=new JSONObject( response );

                    String orderid=jsonObject.getString( "order_id" );
                    String total=jsonObject.getString( "total" );
                    String id=jsonObject.getString( "id" );
                    amountSharedPref.edit().putString("id",id).apply();
                    amountSharedPref.edit().putString("order_id",orderid).apply();
                    amountSharedPref.edit().putString("paybleAmount",total).apply();

                    Intent intent=new Intent(CheckoutActivity.this,PaymentModeActivity.class);
                    startActivity(intent);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + token);
                Log.d("chejklf", String.valueOf(token));
                return headerMap;
            }

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }
}
