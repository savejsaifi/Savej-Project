package com.avaskm.packagingspare.ui.order;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.activity.MyorderActivity;
import com.avaskm.model.Ordermodel;
import com.avaskm.model.Pakagingmodel;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;
import com.avaskm.packagingspare.ui.home.HomeFragment;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.avaskm.Api.Api.addcart;
import static com.avaskm.Api.Api.makeorder;
import static com.avaskm.Api.Api.orderdetail;
import static com.avaskm.Api.Api.orderhistory;
import static com.avaskm.Api.Api.productdetail;

public class MyorderFragment extends Fragment {
    RecyclerView rvrecyclervieworder, secrecyclervieworder;
    ArrayList<Ordermodel> oredermoderlist;
    // ArrayList<Ordermodel> orderListId;
    Orderadapter adapter;
    Button btndel, btnid;



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_order, container, false);
        rvrecyclervieworder = root.findViewById(R.id.recyclervieworder);

      //  btnid = root.findViewById(R.id.btnid);
        btndel = root.findViewById(R.id.btndel);
        btndel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                oredermoderlist.clear();
                adapter.notifyDataSetChanged();
            }
        });
        //  secrecyclervieworder=root.findViewById( R.id.secrecyclervieworder );
        oredermoderlist = new ArrayList<>();

        enableSwipe();




        SharedPreferences myPrefs;
        myPrefs = getActivity().getSharedPreferences("myPrefs", MODE_PRIVATE);
        String StoredValue = myPrefs.getString("token", "");
        Log.d("myorder", StoredValue);
        gethomecategoryAPI(StoredValue);
        return root;
    }

    private void enableSwipe() {

    }



    public class Orderadapter extends RecyclerView.Adapter<Orderadapter.ViewHolderItem> {
        private Context context;
        private ArrayList<Ordermodel> mData;
        //  private ArrayList<Ordermodel>IdData;


        public Orderadapter(Context context, ArrayList<Ordermodel> mData) {
            this.context = context;
            this.mData = mData;
            // this.IdData = IdData;
        }

        @NonNull
        @Override
        public ViewHolderItem onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

            View view;
            view = LayoutInflater.from(context).inflate(R.layout.list_oredering, viewGroup, false);

            return new ViewHolderItem(view);


        }


        @Override
        public void onBindViewHolder(@NonNull ViewHolderItem holder, final int position) {


            ( holder).orderID.setText("order id" + " " + mData.get(position).getOrderid());
            ( holder).date.setText(mData.get(position).getDate());
            ( holder).total.setText(mData.get(position).getTotalpaidamount());
            ( holder).status.setText(mData.get(position).getStatus());



        }

        @Override
        public int getItemCount() {

            Log.d("size==", String.valueOf(mData.size()));
            return mData.size();
        }


        public class ViewHolderItem extends RecyclerView.ViewHolder {

            CardView cardDetail;
            TextView orderID, date, status, total;

            public ViewHolderItem(@NonNull View itemView) {
                super(itemView);
                orderID = itemView.findViewById(R.id.orderID);
                date = itemView.findViewById(R.id.date);
                status = itemView.findViewById(R.id.status);
                total = itemView.findViewById(R.id.total);
                cardDetail = itemView.findViewById(R.id.cardDetail);
                cardDetail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Ordermodel model = mData.get(getAdapterPosition());
                        String id = model.getOrderid();
                       Log.d("dfssdfa",id);



                        OrderDetailFragment  fragment= new OrderDetailFragment();
                        FragmentManager fragmentManager = getFragmentManager();
                        Bundle bundle = new Bundle();
                        bundle.putString("id",id);
                        fragment.setArguments(bundle);
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.replace(R.id.frame, fragment);
                        fragmentTransaction.commit();


                    }
                });

            }
        }


    }

    public void gethomecategoryAPI(final String StoredValue) {
        final ProgressDialog dialog = ProgressDialog.show(getContext(), "", "Loading....", false);

        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, orderhistory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("orderhistory", response);
                oredermoderlist.clear();
                dialog.dismiss();
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        Ordermodel model1 = new Ordermodel();
                        model1.setOrderid(jsonObject.getString("id"));
                        model1.setDate(jsonObject.getString("updated_at"));
                        model1.setTotalpaidamount(jsonObject.getString("total_paid"));
                        String status = jsonObject.getString("ispaid");


                        if (status.equalsIgnoreCase("0")) {
                            model1.setStatus("Pending");
                        } else {
                            model1.setStatus("Delivered");
                        }


                        oredermoderlist.add(model1);

                        Log.d("asqwspoaa", String.valueOf(oredermoderlist));
                        Log.d("sadwqesa",status);
                        // oredermoderlist.add(model2);
                    }
                    rvrecyclervieworder.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getContext(),1);
                    rvrecyclervieworder.setLayoutManager(layoutManager);
                    adapter = new Orderadapter(getContext(), oredermoderlist);
                    rvrecyclervieworder.setAdapter(adapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();

                headers.put("Authorization", "Bearer " + StoredValue);
                Log.d("keyAuthorization", String.valueOf(headers));
                return headers;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}