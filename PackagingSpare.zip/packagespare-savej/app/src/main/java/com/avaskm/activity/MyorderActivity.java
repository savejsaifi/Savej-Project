package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.model.Categorymodel;
import com.avaskm.packagingspare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.avaskm.Api.Api.category;
import static com.avaskm.Api.Api.makeorder;

public class MyorderActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_myorder );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("My Order");

        SharedPreferences myPrefs;
        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String StoredValue=myPrefs.getString("token", "");
        Log.d( "categorymyorder",StoredValue );
        gethomecategoryAPI();

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
    public void gethomecategoryAPI(){
        final ProgressDialog dialog = ProgressDialog.show( MyorderActivity.this, "", "Loading....", false);
        /*  public static String category=SITE_URL+"/category";*/
        /* http://appplace.xyz/api/category/{id}/subcategory*/
        RequestQueue requestQueue = Volley.newRequestQueue(MyorderActivity.this);
        StringRequest stringRequest = new StringRequest( Request.Method.GET, makeorder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("makeorder",response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray=new JSONArray( response );



                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }
}
