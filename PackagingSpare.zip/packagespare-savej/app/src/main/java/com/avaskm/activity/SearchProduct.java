package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.SessonManager;
import com.avaskm.adapter.SearchAdapter;
import com.avaskm.model.Subcategory;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SearchProduct extends AppCompatActivity  {


    EditText edtsearch;
    RecyclerView productRecyclerview;
    SharedPreferences sharedPreferences;
    String token;
    ArrayList<Subcategory> listProduct = new ArrayList<>();
    SearchAdapter adapter;
    ImageView imgSearch;
    RelativeLayout relative_cart;
    TextView TvCartQty;
    SessonManager sessonManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_product);
        getSupportActionBar().setTitle("Search Your Product");
        sharedPreferences = getSharedPreferences("myPrefs", MODE_PRIVATE);
        token = sharedPreferences.getString("token", "");
        sessonManager = new SessonManager(SearchProduct.this);

        edtsearch = findViewById(R.id.edtsearch);
        imgSearch = findViewById(R.id.imgSearch);
        productRecyclerview = findViewById(R.id.productRecyclerview);
//        productSearch.setQueryHint(Html.fromHtml("<font color = #ADAAAA>" +
//                getResources().getString(R.string.hintSearch) + "</font>"));


        imgSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (view != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
                }

                hitSearchApi();
            }
        });

    }

    @Override
    protected void onRestart() {
        super.onRestart();
        TvCartQty.setText(sessonManager.getQty());
        // Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart,menu);
        MenuItem item = menu.findItem(R.id.action_viewcart);
        MenuItemCompat.setActionView(item,R.layout.badge_menu);



        RelativeLayout notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        relative_cart = (RelativeLayout) notifCount.findViewById(R.id.relative_cart);

        TvCartQty = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);
        TvCartQty.setText(sessonManager.getQty());

        TvCartQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });


        return super.onCreateOptionsMenu(menu);
    }


    private void hitSearchApi() {
        listProduct.clear();

        final ProgressDialog progressDialog = new ProgressDialog(SearchProduct.this);
        progressDialog.setTitle("Loading....");
        progressDialog.setCancelable(false);
        progressDialog.show();

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.GET, Api.searchProduct+"?search="+edtsearch.getText().toString()
                , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("respodssa", response);
                progressDialog.cancel();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("products");
                    for(int i=0;i<jsonArray.length();i++){

                        JSONObject productObject = jsonArray.getJSONObject(i);
                        Subcategory model = new Subcategory();
                        model.setId(productObject.getString("id"));
                        model.setFirt(productObject.getString("name"));
                        model.setImage(productObject.getString("image"));
                        model.setSecond(productObject.getString("cut_price"));
                        Log.d("hhh",productObject.getString("cut_price"));
                        model.setThird(productObject.getString("price"));
                        model.setPercent(productObject.getString("percent"));
                        Log.d("ffprice",productObject.getString("price"));

                       /* JSONArray sizeArray = productObject.getJSONArray("sizeprice");
                        for(int j=0;j<sizeArray.length();j++){
                            JSONObject sizeObject = sizeArray.getJSONObject(j);
                            model.setSecond(sizeObject.getString("cut_price"));
                            Log.d("hhh",sizeObject.getString("cut_price"));
                            model.setThird(sizeObject.getString("price"));
                            Log.d("ffprice",sizeObject.getString("price"));
                        }*/

                        listProduct.add(model);
                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),2);
                    productRecyclerview.setLayoutManager(layoutManager);
                    adapter = new SearchAdapter(getApplicationContext(),listProduct);
                    productRecyclerview.setAdapter(adapter);

                } catch (JSONException e) {

                    Toast.makeText(SearchProduct.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
               Map<String,String> header = new HashMap<>();
                header.put("Authorization", "Bearer " + token);
                Log.d("keyAuthorization", String.valueOf(token));
               return header;
            }

        };
        requestQueue.add(request);
    }


}
