package com.avaskm.model;

public class Pakagingmodel {
    private String id;
    private String item;
    private String image;

    public Pakagingmodel() {
    }

    public Pakagingmodel(String id, String item, String image) {
        this.id = id;
        this.item = item;
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
