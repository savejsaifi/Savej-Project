package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import com.avaskm.packagingspare.LoginActivity;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;

public class Splashactivity extends AppCompatActivity {
    SharedPreferences myPrefs;
    String token;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashactivity);
        //getActivity().getActionbar().hide();
        myPrefs = getSharedPreferences("myPrefs", Context.MODE_PRIVATE);
        token = myPrefs.getString("token","");

        new Handler().postDelayed(new Runnable() {


            @Override
            public void run() {
                // This method w

                if(token.isEmpty()){
                    Intent i = new Intent(getBaseContext(), LoginActivity.class);
                    startActivity(i);
                }
                else {
                    startActivity(new Intent(getApplicationContext(), MainPackagingSpare.class));
                }
                finish();
            }

        }, 5000);
    }
}