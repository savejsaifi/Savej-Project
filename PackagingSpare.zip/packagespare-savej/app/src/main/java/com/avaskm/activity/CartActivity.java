package com.avaskm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.SessonManager;
import com.avaskm.model.Cartymodel;
import com.avaskm.model.Categorymodel;
import com.avaskm.packagingspare.R;
import com.avaskm.packagingspare.ui.MyArrayList;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.avaskm.Api.Api.addcart;
import static com.avaskm.Api.Api.cartdetail;
import static com.avaskm.Api.Api.category;

public class CartActivity extends AppCompatActivity {
    RecyclerView cartrecyclerview;
    List<Cartymodel> cartmodelList;
    Cartadapter adapter;
    int quantity;
            float totalprc;
    int final_Mrp,finalDelivery=0;
    int finalQuantity;
    TextView btncheck, totalQuantityCart, totalPrice;
    String StoredValue;
    SessonManager sessonManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        cartrecyclerview = findViewById(R.id.recyclerviewcart);
        btncheck = findViewById(R.id.btncheck);
        totalQuantityCart = findViewById(R.id.totalQuantityCart);
        totalPrice = findViewById(R.id.totalPrice);
        cartmodelList = new ArrayList<>();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Cart");

        SharedPreferences myPrefs;
        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        StoredValue = myPrefs.getString("token", "");
        Log.d("categorydetail", StoredValue);
        //  setpackaging();

        sessonManager = new SessonManager(CartActivity.this);

        cartrecyclerview.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, 1);
        cartrecyclerview.setLayoutManager(layoutManager);
        cartmodelList.clear();

        getcardDetail(StoredValue);
        btncheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            if(totalPrice.getText().toString().equalsIgnoreCase("₹0")){
                Toast.makeText(CartActivity.this, "Cart is Empty", Toast.LENGTH_SHORT).show();
            }else{
                hitMakeOrder();
            }

            }
        });


    }

    private void hitMakeOrder() {
        final ProgressDialog dialog = ProgressDialog.show(CartActivity.this, "", "Loading....", false);
        RequestQueue queue = Volley.newRequestQueue(CartActivity.this);
        StringRequest request = new StringRequest(Request.Method.GET, Api.makeorder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                 dialog.dismiss();

                String value = totalQuantityCart.getText().toString();
                String Split[] = value.split(" ");
                String part1 = Split[0];
                String part2 = Split[1];
                String Split2[] = part2.split(",");
                String qty = Split2[0];
//                String comma = Split2[1];
                sessonManager.setQty(qty);


                 String id=null;
                 String  orderid = null;
                Log.d("sdasdaweqdas", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    id = dataObject.getString("id");
                    orderid = dataObject.getString("orderid");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

               // final_Mrp = totalprc-finalDelivery;

                SharedPreferences sharedPreferences = getSharedPreferences("finalAmount",MODE_PRIVATE);
//                sharedPreferences.edit().putInt("delivery",finalDelivery).apply();
//                sharedPreferences.edit().putInt("mrp",final_Mrp).apply();
//                sharedPreferences.edit().putFloat("paybleAmount",totalprc).apply();
                sharedPreferences.edit().putString("id",id).apply();
                sharedPreferences.edit().putString("orderid",orderid).apply();

                Log.d("sdajiohjas",finalDelivery+"  "+final_Mrp+"  "+totalprc);
                Intent intent = new Intent(CartActivity.this, AddressActivity.class);
//                intent.putExtra("id",id);
                startActivity(intent);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> hashmap = new HashMap<>();
                hashmap.put("Authorization","Bearer "+StoredValue);
                Log.d("sdasdaweqdsadas", String.valueOf(hashmap));
                return hashmap;
            }
        };

        queue.add(request);
    }

    private void getcardDetail(final String StoredValue) {
        final ProgressDialog dialog = ProgressDialog.show(CartActivity.this, "", "Loading....", false);
        //  String urll= http://appplace.xyz/api/product/;

        RequestQueue requestQueue = Volley.newRequestQueue(CartActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, cartdetail, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("cartcaard", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObjectFirst = new JSONObject(response);
                    String total = jsonObjectFirst.getString("total");

                    JSONArray jsonArray = jsonObjectFirst.getJSONArray("cartitems");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        Cartymodel model = new Cartymodel();

                        model.setTotal(total);

                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        int qty = Integer.parseInt(jsonObject.getString("quantity"));
                        model.setQuanityrs(String.valueOf(qty));
                        model.setId(jsonObject.getString("product_id"));
                     //   model.setSizeid(jsonObject.getString("size_id"));
//                        totalQuantityCart.setText(jsonObject.getString( "quantity" ));

                        JSONObject jsonObject1 = jsonObject.getJSONObject("product");
                        model.setProduct(jsonObject1.getString("name"));
                        model.setImage(jsonObject1.getString("image"));
                        model.setMinimumQuantity(jsonObject1.getString("minimum_quantity"));
                        Log.d("product", String.valueOf(jsonObject1));

                        float price = Integer.parseInt(jsonObject1.getString("price"));
                       // int gst =  Integer.parseInt(jsonObject1.getString("gst"));
                        float deliverys = Integer.parseInt(jsonObject1.getString("delivery_per_kg_price"))
                                  *Float.parseFloat(jsonObject1.getString("product_weight"));
                        float total1 = price ;

                        model.setPrize(""+total1);
                        model.setTxtcutprize(jsonObject1.getString("cut_price"));
                        model.setDelivery(String.valueOf(deliverys));

                        cartmodelList.add(model);

                        quantity = quantity + Integer.parseInt(cartmodelList.get(i).getQuanityrs());

                        totalprc = Float.parseFloat(cartmodelList.get(i).getTotal());
                        totalPrice.setText("₹"+(int)totalprc);
                        totalQuantityCart.setText(String.valueOf("Qty " + quantity+","));

                    }


                    adapter = new Cartadapter(CartActivity.this, (ArrayList<Cartymodel>) cartmodelList);
                    cartrecyclerview.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + StoredValue);
                Log.d("chejklf", String.valueOf(StoredValue));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                Log.d("chejklf", String.valueOf(hashMap));

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {

            String value = totalQuantityCart.getText().toString();
            String Split[] = value.split(" ");
            String part1 = Split[0];
            String part2 = Split[1];
            String Split2[] = part2.split(",");
            String qty = Split2[0];
//                String comma = Split2[1];
            sessonManager.setQty(qty);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }

    public class Cartadapter extends RecyclerView.Adapter<Cartadapter.ViewHolder> {
        private Context context;
        private ArrayList<Cartymodel> mData;
        int minintgr;
        float mrp = 0;
        float delvry;
        int cutPrice;
        public Cartadapter(Context context, ArrayList<Cartymodel> mData) {
            this.context = context;
            this.mData = mData;
        }

        @NonNull
        @Override
        public Cartadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_cart, parent, false);
            Cartadapter.ViewHolder viewHolder = new Cartadapter.ViewHolder(view);
            return viewHolder;
        }


        @Override
        public void onBindViewHolder(@NonNull Cartadapter.ViewHolder holder, int position) {
            Picasso.get().load(mData.get(position).getImage()).into(holder.imageView);
            holder.txtpro_title.setText(mData.get(position).getProduct());
            mrp = Float.parseFloat(mData.get(position).getPrize())*Integer.parseInt(mData.get(position).getQuanityrs());
            delvry= Float.parseFloat(mData.get(position).getDelivery())*Integer.parseInt(mData.get(position).getQuanityrs());
            cutPrice = Integer.parseInt(mData.get(position).getTxtcutprize())*Integer.parseInt(mData.get(position).getQuanityrs());
            holder.txtprize.setText(String.valueOf(mrp));
            holder.quanityrs.setText(mData.get(position).getQuanityrs());
            holder.txtcutprize.setText(String.valueOf(cutPrice));
            holder.dlvry.setText("₹"+delvry);
            holder.txtcutprize.setPaintFlags(holder.txtcutprize.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

            //  minintgr = Integer.parseInt( mData.get( position ).getQuanityrs());
            holder.integerNum.setText(mData.get(position).getQuanityrs());
           // holder.txtMinimum.setText(mData.get(position).getMinimumQuantity());
        }

        @Override
        public int getItemCount() {
            return mData.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            ImageView imageView;
            CardView cardviewitem;
            TextView dlvry, integerNum;
            TextView txtpro_title, txtprize, txtcutprize, quanityrs;
            RelativeLayout incremetLayout, decrementLayout, relativequantity_layout;
            float total,deliveryInt,cutInt;
            public ViewHolder(@NonNull final View itemView) {

                super(itemView);
                imageView = itemView.findViewById(R.id.imagecart);
                txtcutprize = itemView.findViewById(R.id.txtcutprize);
                quanityrs = itemView.findViewById(R.id.quanityrs);
                txtpro_title = itemView.findViewById(R.id.txtpro_title);
                txtprize = itemView.findViewById(R.id.txtprize);
                incremetLayout = itemView.findViewById(R.id.increse);
                decrementLayout = itemView.findViewById(R.id.decrese);
                integerNum = itemView.findViewById(R.id.integerNum);
                dlvry = itemView.findViewById(R.id.dlvry);


                relativequantity_layout = itemView.findViewById(R.id.quantity_layout);


                incremetLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Cartymodel cartymodel = mData.get(getAdapterPosition());
                        String productId = cartymodel.getId();
                        String delivery = cartymodel.getDelivery();
                        String price = cartymodel.getPrize();
                        String cutprice = cartymodel.getTxtcutprize();
                        String minimumQuantity = cartymodel.getMinimumQuantity();

                        int ctprc = Integer.parseInt(cutprice);
                        float dlry = (Float.parseFloat(delivery));
                        float pric = (Float.parseFloat(price));
                        int minQTY = (Integer.parseInt(minimumQuantity));

                        String minimum = cartymodel.getQuanityrs();
                        minintgr = Integer.parseInt(minimum);


                        int position = getAdapterPosition();

                        Log.d("asqwszaaa", delivery+" "+" "+price);
                        minintgr = minintgr + 1;

                        cutInt = ctprc*minintgr;

                        cartymodel.setQuanityrs(String.valueOf(minintgr));
                        quantity = quantity + 1;
                       // totalQuantityCart.setText(String.valueOf("Qty " + quantity+","));

                        totalprc =  (totalprc + dlry +pric);
                      //  totalPrice.setText("\u20B9"+totalprc);

                        deliveryInt = (int)(minintgr*dlry);

//                        final_Mrp = final_Mrp+pric;
//                        finalDelivery = (float) (finalDelivery+dlry);

                        total = minintgr*pric;
                        display(minintgr,position,total,minQTY);
                        getcardId(StoredValue, productId);



                        Log.d("asqwszaa",  " "+minimum+"  "+totalprc);
                    }
                });
                decrementLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Cartymodel cartymodel = mData.get(getAdapterPosition());
                        String productId = cartymodel.getId();
                        String minimum = cartymodel.getQuanityrs();
                        String delivery = cartymodel.getDelivery();
                        String price = cartymodel.getPrize();
                        String cutprice = cartymodel.getTxtcutprize();
                        String minimumQuantity = cartymodel.getMinimumQuantity();

                        int ctprc = Integer.parseInt(cutprice);

                        float dlry = (Float.parseFloat(delivery));
                        float pric = (Float.parseFloat(price));
                        int minQty = (Integer.parseInt(minimumQuantity));

                        minintgr = Integer.parseInt(minimum);

                        int position = getAdapterPosition();


                        if (minintgr <=minQty) {

                            minintgr = minintgr -minQty;
                            quantity = quantity-minQty;
                         //   totalQuantityCart.setText(String.valueOf("Qty " + quantity+","));
                            cartymodel.setQuanityrs(String.valueOf(minintgr));
//                            integerNum.setText("0");
                            totalprc = totalprc  - pric*minQty -((float)(dlry))*minQty;

                            //totalprc = totalprc -dlry -pric;
                          //  totalPrice.setText("\u20B9"+totalprc);

                            total = total - pric*minQty -((float) (dlry)*minQty);

                            deliveryInt = (float) (minintgr*dlry);

                            cutInt = ctprc*minintgr;

//                            final_Mrp = final_Mrp-(pric +(float) (dlry)*minQty);
//                            finalDelivery = (float) (finalDelivery-dlry);

                            Log.d("sadasddsaqq", String.valueOf(totalprc)+" "+minintgr+" "+minQty+" "+total);
                            getcardId(StoredValue, productId);
                        } else {
                            minintgr = minintgr -1;
                            quantity = quantity - 1;
                            cartymodel.setQuanityrs(String.valueOf(minintgr));
                           // totalQuantityCart.setText(String.valueOf("Qty " + quantity+","));

                            cutInt = ctprc*minintgr;
                            totalprc = (float) (totalprc -pric-dlry);

                            totalprc = totalprc -dlry -pric;
                        //    totalPrice.setText("₹"+totalprc);
                            total = minintgr*pric;

                            deliveryInt = (float) (minintgr*dlry);

//                            final_Mrp = final_Mrp-pric;
//                            finalDelivery = (float) (finalDelivery-dlry);

                            getcardId(StoredValue, productId);
                        }

                        display(minintgr,position,total,minQty);

                        Log.d("sadasddsaq", String.valueOf(totalprc)+"   "+minintgr+" "+minimumQuantity);
                    }
                });



            }

            public void removeAt(int position) {
                mData.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, mData.size());
            }

            private void display(int number,int position,float price,int min) {
//                integerNum=itemView.findViewById(R.id.integerNum);

                if(number>=min){
                    integerNum.setText("" + number);
                }
                else {
                    integerNum.setText("" + number);
                    removeAt(position);
                }
                quanityrs.setText(""+minintgr);
                txtprize.setText(""+price);
                dlvry.setText("₹"+deliveryInt);
                txtcutprize.setText(""+cutInt);

                Log.d("asdwqaklhj", String.valueOf(final_Mrp)+" "+finalDelivery);
            }


            private void getcardId(final String StoredValue, final String productid) {
                final ProgressDialog dialog = ProgressDialog.show(context, "", "Loading....", false);
                //  String urll= http://appplace.xyz/api/product/;

                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest stringRequest = new StringRequest(Request.Method.POST, addcart, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("addcazrd", response);
                        dialog.dismiss();
                        getTotalDetail();

                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        dialog.dismiss();
                        Log.e("onErrorResponse", error.toString());
                    }
                }) {
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> headerMap = new HashMap<String, String>();
                        headerMap.put("Authorization", "Bearer " + StoredValue);
                        Log.d("tokenvalue", String.valueOf(StoredValue));
                        return headerMap;
                    }

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> hashMap = new HashMap<>();
                        hashMap.put("quantity", integerNum.getText().toString());
                        Log.d("kkk", integerNum.getText().toString());
                        hashMap.put("product_id", productid);
                        Log.d("chejklf", String.valueOf(hashMap));
                        return hashMap;
                    }
                };
                requestQueue.getCache().clear();
                requestQueue.add(stringRequest);
            }


            private void getTotalDetail() {
//                final ProgressDialog dialog = ProgressDialog.show(CartActivity.this, "", "Loading....", false);
                //  String urll= http://appplace.xyz/api/product/;

                RequestQueue requestQueue = Volley.newRequestQueue(CartActivity.this);
                StringRequest stringRequest = new StringRequest(Request.Method.GET, cartdetail, new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("cartcaard", response);
//                        dialog.dismiss();
                        try {
                            JSONObject jsonObjectFirst = new JSONObject(response);
                          //  final_Mrp = Integer.parseInt();
                          //  finalDelivery = Integer.parseInt(jsonObjectFirst.getString("delivery_total"));
                           // finalQuantity = Integer.parseInt();
                          //  totalprc = Integer.parseInt(jsonObjectFirst.getString("price_total"));
                            totalPrice.setText("\u20B9"+jsonObjectFirst.getString("total"));
                            totalQuantityCart.setText("Qty "+jsonObjectFirst.getString("quantity")+",");



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
//                        dialog.dismiss();
                        Log.e("onErrorResponse", error.toString());
                    }
                }) {

                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> headerMap = new HashMap<String, String>();
                        headerMap.put("Authorization", "Bearer " + StoredValue);
                        Log.d("chejklf", String.valueOf(StoredValue));
                        return headerMap;
                    }

                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        HashMap<String, String> hashMap = new HashMap<>();

                        Log.d("chejklf", String.valueOf(hashMap));

                        return hashMap;
                    }
                };
                requestQueue.getCache().clear();
                requestQueue.add(stringRequest);
            }


        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        String value = totalQuantityCart.getText().toString();
        String Split[] = value.split(" ");
        String part1 = Split[0];
        String part2 = Split[1];

        String Split2[] = part2.split(",");
        String qty = Split2[0];
       // String comma = Split2[1];

        sessonManager.setQty(qty);
    }
}


