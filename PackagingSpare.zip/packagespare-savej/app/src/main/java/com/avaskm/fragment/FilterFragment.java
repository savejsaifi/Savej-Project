package com.avaskm.fragment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.avaskm.packagingspare.R;

public class FilterFragment extends Fragment {



    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate( R.layout.fragment_filter, container, false );
        //TextView text = (TextView) root.findViewById(R.id.newtextView);
       // String getArgument = getArguments().getString("data");
      //  text.setText(getArgument);

        return root;


   /* public static FilterFragment newInstance(int someInt, String someTitle) {
        FilterFragment fragmentDemo = new FilterFragment();
        Bundle args = new Bundle();
        args.putInt("someInt", someInt);
        args.putString("someTitle", someTitle);
        fragmentDemo.setArguments(args);
        return fragmentDemo;*/
}}
//}
