package com.avaskm.model;

public class Subcategory {
    private String firt;
    private String second;
    private String third;
    private String image;
    private String id;

    public String getPercent() {
        return percent;
    }

    public void setPercent(String percent) {
        this.percent = percent;
    }

    private String percent;

    public Subcategory() {
    }

    public Subcategory(String firt, String second, String third, String image, String id) {
        this.firt = firt;
        this.second = second;
        this.third = third;
        this.image = image;
        this.id = id;
    }

    public String getFirt() {
        return firt;
    }

    public void setFirt(String firt) {
        this.firt = firt;
    }

    public String getSecond() {
        return second;
    }

    public void setSecond(String second) {
        this.second = second;
    }

    public String getThird() {
        return third;
    }

    public void setThird(String third) {
        this.third = third;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
