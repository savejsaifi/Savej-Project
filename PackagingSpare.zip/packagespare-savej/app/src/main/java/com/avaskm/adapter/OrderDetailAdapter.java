package com.avaskm.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.model.Ordermodel;
import com.avaskm.packagingspare.R;
import com.avaskm.packagingspare.ui.order.MyorderFragment;
import com.avaskm.packagingspare.ui.order.OrderDetailFragment;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class OrderDetailAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private Context context;
    private ArrayList<Ordermodel> mData;

    String token;

    //  private ArrayList<Ordermodel>IdData;


    public OrderDetailAdapter(Context context, ArrayList<Ordermodel> mData, String token) {
        this.context = context;
        this.mData = mData;
        this.token = token;
        // this.IdData = IdData;
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        View view;
        view = LayoutInflater.from(context).inflate(R.layout.list_ordering_id, viewGroup, false);

        return new OrderDetailAdapter.ViewHolderItem(view);


    }


    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {


//        ((MyorderFragment.Orderadapter.ViewHolderItem) holder).orderID.setText("order id" + " " + mData.get(position).getOrderid());
//        ((MyorderFragment.Orderadapter.ViewHolderItem) holder).date.setText(mData.get(position).getDate());
//        ((MyorderFragment.Orderadapter.ViewHolderItem) holder).total.setText(mData.get(position).getTotalpaidamount());
//        ((MyorderFragment.Orderadapter.ViewHolderItem) holder).status.setText(mData.get(position).getStatus());

        Picasso.get().load(mData.get(position).getImage()).into(((ViewHolderItem) holder).imageorder);
        ((ViewHolderItem) holder).txtQuantity.setText(mData.get(position).getQty());

        ((ViewHolderItem) holder).txtpro_title.setText(mData.get(position).getProduct());
        //   ((ViewHolderItem) holder).txt_size.setText(mData.get(position).getSize());
        ((ViewHolderItem) holder).txtprice.setText("\u20B9" + mData.get(position).getPricetotal());
        // ((ViewHolderItem) holder).textCost.setText(mData.get(position).getUnitcost());
        ((ViewHolderItem) holder).txtdate.setText(mData.get(position).getDate());
        ((ViewHolderItem) holder).txttotalprice.setText(mData.get(position).getTotalpaidamount());
        ((ViewHolderItem) holder).textCost.setText(mData.get(position).getUnitcost());
        ((ViewHolderItem) holder).txt_size.setText(mData.get(position).getSize());
        String status = mData.get(position).getStatus();

        Log.d("asdadsqw",status);
        if (status.equalsIgnoreCase("pending") || (status.equalsIgnoreCase("paid"))) {
            ((ViewHolderItem) holder).cancel.setVisibility(View.VISIBLE);
            ((ViewHolderItem) holder).returns.setVisibility(View.GONE);
            ((ViewHolderItem) holder).status.setVisibility(View.GONE);
        } else if(status.equalsIgnoreCase("delivered")){
            ((ViewHolderItem) holder).returns.setVisibility(View.VISIBLE);
            ((ViewHolderItem) holder).cancel.setVisibility(View.GONE);
            ((ViewHolderItem) holder).status.setVisibility(View.GONE);
        }else{
            ((ViewHolderItem) holder).cancel.setVisibility(View.GONE);
            ((ViewHolderItem) holder).returns.setVisibility(View.GONE);
            ((ViewHolderItem) holder).status.setVisibility(View.VISIBLE);
            ((ViewHolderItem) holder).status.setText(status);
        }


    }

    @Override
    public int getItemCount() {

        Log.d("size==", String.valueOf(mData.size()));
        return mData.size();
    }


    public class ViewHolderItem extends RecyclerView.ViewHolder {

        TextView txtpro_title, txt_size, textCost, txtQuantity, txtprice, txtdate, txttotalprice, status;
        ImageView imageorder;
        Button returns, cancel;

        public ViewHolderItem(@NonNull View itemView) {
            super(itemView);
            txtpro_title = itemView.findViewById(R.id.txtpro_title);
            txt_size = itemView.findViewById(R.id.txt_size);
            txtQuantity = itemView.findViewById(R.id.txtQuantity);
            txtprice = itemView.findViewById(R.id.txtprice);
            txtdate = itemView.findViewById(R.id.txtdate);
            txttotalprice = itemView.findViewById(R.id.txttotalprice);
            textCost = itemView.findViewById(R.id.textCost);
            imageorder = itemView.findViewById(R.id.imageorder);
            returns = itemView.findViewById(R.id.returns);
            cancel = itemView.findViewById(R.id.cancel);
            status = itemView.findViewById(R.id.status);

            returns.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Ordermodel ordermodel = mData.get(getAdapterPosition());
                    String statusId = ordermodel.getId();
                    Log.d("sdadaswq", statusId);
                    hitApiReturn(statusId);
                }
            });
            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    Ordermodel ordermodel = mData.get(getAdapterPosition());
                    String statusId = ordermodel.getId();

                    Log.d("sdadaswq", statusId);
                    hitApiCancel(statusId);

                }
            });

        }

        public void hitApiCancel(String statusid) {

            RequestQueue queue = Volley.newRequestQueue(context);
            StringRequest request = new StringRequest(Request.Method.GET, Api.canelOrder + statusid, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsew", response);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String message = jsonObject.getString("message");
                        String statuss = jsonObject.getString("status");
                        if (statuss.equalsIgnoreCase("success")) {
                            cancel.setVisibility(View.GONE);
                            returns.setVisibility(View.GONE);
                            status.setVisibility(View.VISIBLE);
                            status.setText("Canceled");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    // Basic Authentication
                    //String auth = "Basic " + Base64.encodeToString(CONSUMER_KEY_AND_SECRET.getBytes(), Base64.NO_WRAP);

                    headers.put("Authorization", "Bearer " + token);
                    Log.d("keyAuthorizationa", String.valueOf(headers));
                    return headers;
                }
            };
            queue.add(request);
        }
        public void hitApiReturn(String statusid) {

            RequestQueue queue = Volley.newRequestQueue(context);
            StringRequest request = new StringRequest(Request.Method.GET, Api.returnOrder + statusid, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsew", response);
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String message = jsonObject.getString("message");
                        String statuss = jsonObject.getString("status");
                        if (statuss.equalsIgnoreCase("success")) {
                            cancel.setVisibility(View.GONE);
                            returns.setVisibility(View.GONE);
                            status.setVisibility(View.VISIBLE);
                            status.setText("Return Requested");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    // Basic Authentication
                    //String auth = "Basic " + Base64.encodeToString(CONSUMER_KEY_AND_SECRET.getBytes(), Base64.NO_WRAP);

                    headers.put("Authorization", "Bearer " + token);
                    Log.d("keyAuthorizationa", String.valueOf(headers));
                    return headers;
                }
            };
            queue.add(request);
        }

    }


}
