package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.packagingspare.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddressActivity extends AppCompatActivity {

    EditText edt_name,edt_Compny_name,edt_gstNo,edt_mobile_no,edt_compnyAddress,
            edt_city,edt_Pin,edt_shipingAddress,edt_shipingCity,edt_shipingPin,edt_servecName;
    Button btn_address;
    CheckBox chkShiping;
    SharedPreferences myPrefs;
   String token;
    String AddressId;

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        myPrefs = getSharedPreferences("myPrefs", Context.MODE_PRIVATE);
        sharedPreferences = getSharedPreferences("finalAmount",MODE_PRIVATE);
        token = myPrefs.getString("token","");
        AddressId = sharedPreferences.getString("id","");
        Log.d("sdaasdwqsa",AddressId);
        Log.d("sdawqsalk",token);
        edt_name = findViewById(R.id.edt_name);
        edt_Compny_name = findViewById(R.id.edt_Compny_name);
        edt_gstNo = findViewById(R.id.edt_gstNo);
        edt_mobile_no = findViewById(R.id.edt_mobile_no);
        edt_compnyAddress = findViewById(R.id.edt_compnyAddress);
        edt_servecName = findViewById(R.id.edt_servecName);
        edt_city = findViewById(R.id.edt_city);
        edt_Pin = findViewById(R.id.edt_Pin);
        edt_shipingAddress = findViewById(R.id.edt_shipingAddress);
        edt_shipingCity = findViewById(R.id.edt_shipingCity);
        edt_shipingPin = findViewById(R.id.edt_shipingPin);
        btn_address = findViewById(R.id.btn_address);
        chkShiping = findViewById(R.id.chkShiping);


        getAddressApi();

        chkShiping.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(chkShiping.isChecked()){
                    edt_shipingAddress.setText(edt_compnyAddress.getText().toString());
                    edt_shipingCity.setText(edt_city.getText().toString());
                    edt_shipingPin.setText(edt_Pin.getText().toString());
                }
                if(!chkShiping.isChecked()){
                    edt_shipingAddress.setText("");
                    edt_shipingCity.setText("");
                    edt_shipingPin.setText("");

                    edt_shipingAddress.setHint("Shipping Address");
                    edt_shipingCity.setHint("Shipping City.");
                    edt_shipingPin.setHint("Pin No.");
                }
            }
        });
        btn_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edt_name.getText().toString().isEmpty()){
                    edt_name.setError("Please enter Name");
                    edt_name.requestFocus();
                }else if(edt_Compny_name.getText().toString().isEmpty()){
                    edt_Compny_name.setError("Please enter Company Name");
                    edt_Compny_name.requestFocus();
                } else if (edt_gstNo.getText().toString().isEmpty()) {
                    edt_gstNo.setError("Please enter Gst no.");
                    edt_gstNo.requestFocus();
                }else if (edt_mobile_no.getText().toString().isEmpty()) {
                    edt_mobile_no.setError("Please enter Mobile No.");
                    edt_mobile_no.requestFocus();
                }
                else if (edt_mobile_no.getText().toString().length()!=10) {
                    edt_mobile_no.setError("Mobile No. should be 10 digit");
                    edt_mobile_no.requestFocus();
                }
                else if (edt_compnyAddress.getText().toString().isEmpty()) {
                    edt_compnyAddress.setError("PLease enter Company Address");
                    edt_compnyAddress.requestFocus();
                }
                else if (edt_city.getText().toString().isEmpty()) {
                    edt_city.setError("PLease enter city");
                    edt_city.requestFocus();
                }
                else if (edt_Pin.getText().toString().isEmpty()) {
                    edt_Pin.setError("PLease enter pin");
                    edt_Pin.requestFocus();
                }
                else if (edt_shipingAddress.getText().toString().isEmpty()) {
                    edt_shipingAddress.setError("PLease enter Shipping Address");
                    edt_shipingAddress.requestFocus();
                }
                else if (edt_shipingCity.getText().toString().isEmpty()) {
                    edt_shipingCity.setError("PLease enter city");
                    edt_shipingCity.requestFocus();
                }
                else if (edt_shipingPin.getText().toString().isEmpty()) {
                    edt_shipingPin.setError("PLease enter pin");
                    edt_shipingPin.requestFocus();
                }
                else{
//                    startActivity(new Intent(getApplicationContext(),CheckoutActivity.class));
                    hitSubmitAddressApi(AddressId);
                    
                }
            }
        });

    }

    private void hitSubmitAddressApi(String addressId) {
        final ProgressDialog dialog = ProgressDialog.show(AddressActivity.this, "", "Loading....", false);
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.setAdress+"/"+addressId, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                    Log.d("polkjuy",response);
                dialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if(jsonObject.getString("status").equalsIgnoreCase("success")){
                        SharedPreferences sharedPreferences = getSharedPreferences("shippingAddress",MODE_PRIVATE);
                        sharedPreferences.edit().putString("shippingAddress",edt_shipingAddress.getText().toString()).apply();
                        sharedPreferences.edit().putString("shippingCity",edt_shipingCity.getText().toString()).apply();
                        sharedPreferences.edit().putString("shippingPin",edt_shipingPin.getText().toString()).apply();
                        startActivity(new Intent(getApplicationContext(),CheckoutActivity.class));
                    }else{
                        Toast.makeText(AddressActivity.this, jsonObject.getString("status"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> hashmap = new HashMap<>();
                hashmap.put("name",edt_name.getText().toString());
                hashmap.put("mobile",edt_mobile_no.getText().toString());
                hashmap.put("gst_no",edt_gstNo.getText().toString());
                hashmap.put("company_name",edt_Compny_name.getText().toString());
                hashmap.put("company_address",edt_compnyAddress.getText().toString());
                hashmap.put("company_pincode",edt_Pin.getText().toString());
                hashmap.put("company_city",edt_city.getText().toString());
                hashmap.put("shipping_address",edt_shipingAddress.getText().toString());
                hashmap.put("shipping_pincode",edt_shipingPin.getText().toString());
                hashmap.put("shipping_city",edt_shipingCity.getText().toString());
                hashmap.put("courier_service",edt_servecName.getText().toString());
                Log.d("daswqsalk", String.valueOf(hashmap));
                return hashmap;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> hashMap = new HashMap<>();
                hashMap.put("Authorization","Bearer "+token);
                return hashMap;
            }
        };
        queue.add(request);
    }

    private void getAddressApi() {
        final ProgressDialog dialog = ProgressDialog.show(AddressActivity.this, "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.GET, Api.getAdress, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("sadfaaswe",response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject objectAddress = jsonObject.getJSONObject("address");
                    edt_name.setText(objectAddress.getString("name"));
                    edt_mobile_no.setText(objectAddress.getString("mobile"));
                    edt_gstNo.setText(objectAddress.getString("gst_no"));
                    edt_Compny_name.setText(objectAddress.getString("company_name"));
                    edt_compnyAddress.setText(objectAddress.getString("company_address"));
                    edt_Pin.setText(objectAddress.getString("company_pincode"));
                    edt_city.setText(objectAddress.getString("company_city"));
                    edt_shipingAddress.setText(objectAddress.getString("shipping_address"));
                    edt_shipingPin.setText(objectAddress.getString("shipping_pincode"));
                    edt_shipingCity.setText(objectAddress.getString("shipping_city"));
                    edt_servecName.setText(objectAddress.getString("courier_service"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Toast.makeText(AddressActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> hashMap = new HashMap<>();
                 hashMap.put("Authorization","Bearer "+token);

                 Log.d("sadwdqw", String.valueOf(hashMap));
                return hashMap;
            }
        };
        requestQueue.add(request);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
}
