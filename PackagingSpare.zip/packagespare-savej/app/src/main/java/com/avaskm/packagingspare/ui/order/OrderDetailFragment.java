package com.avaskm.packagingspare.ui.order;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.adapter.OrderDetailAdapter;
import com.avaskm.model.Ordermodel;
import com.avaskm.packagingspare.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;
import static com.avaskm.Api.Api.orderdetail;
import static com.avaskm.Api.Api.orderhistory;


public class OrderDetailFragment extends Fragment {

View view;

RecyclerView rvDetailOrder;
Button btnidDETail;

    OrderDetailAdapter adapter;
    public OrderDetailFragment() {
        // Required empty public constructor
    }


   String id;
    String StoredValue;
    ArrayList<Ordermodel> orderlist=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_order_detail, container, false);
        Bundle bundle = this.getArguments();
        if (bundle != null) {
            id = bundle.getString("id");
        }


        rvDetailOrder = view.findViewById(R.id.rvDetailOrder);
        btnidDETail = view.findViewById(R.id.btnidDETail);

        btnidDETail.setText("order Id - "+id);
        SharedPreferences myPrefs;
        myPrefs = getActivity().getSharedPreferences("myPrefs", MODE_PRIVATE);
        StoredValue = myPrefs.getString("token", "");
        Log.d("myorder", StoredValue);
        gethomecategoryAPI(StoredValue);
        return view;
    }


    private void gethomecategoryAPI(final String StoredValue) {
        final ProgressDialog dialog = ProgressDialog.show(getContext(), "", "Loading....", false);
        /*  public static String category=SITE_URL+"/category";*/
        /* http://appplace.xyz/api/category/{id}/subcategory*/
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest stringRequest = new StringRequest(Request.Method.GET, orderdetail+id, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("orderhistoray", response);
                orderlist.clear();
                dialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);


                    JSONArray itemArray = jsonObject.getJSONArray("items");

                    for(int j=0;j<itemArray.length();j++){
                        Ordermodel model = new Ordermodel();

                        model.setDate(jsonObject.getString("date"));
                        model.setTotalpaidamount(jsonObject.getString("total"));

                        JSONObject detailObject = itemArray.getJSONObject(j);
                        model.setId(detailObject.getString("id"));
                        model.setQty(detailObject.getString("quantity"));
                        model.setProduct(detailObject.getString("name"));
                        model.setUnitcost(detailObject.getString("unitprice"));
                        model.setImage(detailObject.getString("image"));
                        model.setStatus(detailObject.getString("order_status"));

                        JSONObject sizeObject = detailObject.getJSONObject("sizeprice");
                        model.setSize(sizeObject.getString("size"));
                        model.setPricetotal(sizeObject.getString("price"));

                        orderlist.add(model);
                        Log.d("sdawea", String.valueOf(orderlist));
                    }


                    rvDetailOrder.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getContext(),1);
                    rvDetailOrder.setLayoutManager(layoutManager);
                    adapter = new OrderDetailAdapter(getContext(), orderlist,StoredValue);
                    rvDetailOrder.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


                    }


        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                // Basic Authentication
                //String auth = "Basic " + Base64.encodeToString(CONSUMER_KEY_AND_SECRET.getBytes(), Base64.NO_WRAP);

                headers.put("Authorization", "Bearer " + StoredValue);
                Log.d("keyAuthorization", String.valueOf(headers));
                return headers;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }




}
