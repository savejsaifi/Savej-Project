package com.avaskm.packagingspare.ui.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.activity.AddressActivity;
import com.avaskm.activity.CheckoutActivity;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileFragment extends Fragment {

    View view;
    EditText edt_nameProfile,edt_Compny_name_profile,edt_gstNo_profile,
            edt_mobile_no_profile,edt_compnyAddress_profile,
            edt_city_profile,edt_Pin_profile,edt_shipingAddress_profile,
            edt_shipingCity_profile,edt_shipingPin_profile;
    Button btn_address_profile;
    CheckBox chkShiping_profile;
    String token;
    SharedPreferences myPrefs;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate( R.layout.fragment_profile, container, false );
        edt_nameProfile = view.findViewById( R.id.edt_nameProfile );
        edt_Compny_name_profile = view.findViewById( R.id.edt_Compny_name_profile );
        edt_gstNo_profile = view.findViewById( R.id.edt_gstNo_profile );
        edt_mobile_no_profile = view.findViewById( R.id.edt_mobile_no_profile );
        edt_compnyAddress_profile = view.findViewById( R.id.edt_compnyAddress_profile );
        edt_city_profile = view.findViewById( R.id.edt_city_profile );
        edt_Pin_profile = view.findViewById( R.id.edt_Pin_profile );
        edt_shipingAddress_profile = view.findViewById( R.id.edt_shipingAddress_profile );
        edt_shipingCity_profile = view.findViewById( R.id.edt_shipingCity_profile );
        edt_shipingPin_profile = view.findViewById( R.id.edt_shipingPin_profile );
        btn_address_profile = view.findViewById( R.id.btn_address_profile );
        chkShiping_profile = view.findViewById( R.id.chkShiping_profile );

        myPrefs = getActivity().getSharedPreferences("myPrefs", Context.MODE_PRIVATE);
        token = myPrefs.getString("token","");

        getAddressApi();

        chkShiping_profile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if(chkShiping_profile.isChecked()){
                    edt_shipingAddress_profile.setText(edt_compnyAddress_profile.getText().toString());
                    edt_shipingCity_profile.setText(edt_city_profile.getText().toString());
                    edt_shipingPin_profile.setText(edt_Pin_profile.getText().toString());
                }
                if(!chkShiping_profile.isChecked()){
                    edt_shipingAddress_profile.setText("");
                    edt_shipingCity_profile.setText("");
                    edt_shipingPin_profile.setText("");

                    edt_shipingAddress_profile.setHint("Shipping Address");
                    edt_shipingCity_profile.setHint("Shipping City.");
                    edt_shipingPin_profile.setHint("Pin No.");
                }
            }
        });

        btn_address_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edt_nameProfile.getText().toString().isEmpty()){
                    edt_nameProfile.setError("Please enter Name");
                    edt_nameProfile.requestFocus();
                }else if(edt_Compny_name_profile.getText().toString().isEmpty()){
                    edt_Compny_name_profile.setError("Please enter Company Name");
                    edt_Compny_name_profile.requestFocus();
                } else if (edt_gstNo_profile.getText().toString().isEmpty()) {
                    edt_gstNo_profile.setError("Please enter Gst no.");
                    edt_gstNo_profile.requestFocus();
                }else if (edt_mobile_no_profile.getText().toString().isEmpty()) {
                    edt_mobile_no_profile.setError("Please enter Mobile No.");
                    edt_mobile_no_profile.requestFocus();
                }
                else if (edt_mobile_no_profile.getText().toString().length()!=10) {
                    edt_mobile_no_profile.setError("Mobile No. should be 10 digit");
                    edt_mobile_no_profile.requestFocus();
                }
                else if (edt_compnyAddress_profile.getText().toString().isEmpty()) {
                    edt_compnyAddress_profile.setError("PLease enter Company Address");
                    edt_compnyAddress_profile.requestFocus();
                }
                else if (edt_city_profile.getText().toString().isEmpty()) {
                    edt_city_profile.setError("PLease enter city");
                    edt_city_profile.requestFocus();
                }
                else if (edt_Pin_profile.getText().toString().isEmpty()) {
                    edt_Pin_profile.setError("PLease enter pin");
                    edt_Pin_profile.requestFocus();
                }
                else if (edt_shipingAddress_profile.getText().toString().isEmpty()) {
                    edt_shipingAddress_profile.setError("PLease enter Shipping Address");
                    edt_shipingAddress_profile.requestFocus();
                }
                else if (edt_shipingCity_profile.getText().toString().isEmpty()) {
                    edt_shipingCity_profile.setError("PLease enter city");
                    edt_shipingCity_profile.requestFocus();
                }
                else if (edt_shipingPin_profile.getText().toString().isEmpty()) {
                    edt_shipingPin_profile.setError("PLease enter pin");
                    edt_shipingPin_profile.requestFocus();
                }
                else{
//                    startActivity(new Intent(getApplicationContext(),CheckoutActivity.class));
                    hitSubmitProfile();

                }
            }
        });

        return view;
    }

    private void getAddressApi() {
        final ProgressDialog dialog = ProgressDialog.show( getContext(), "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest( Request.Method.GET, Api.getProfile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("sadfaaswe",response);
                dialog.dismiss();
                try {
                    JSONObject objectAddress = new JSONObject(response);
                    edt_nameProfile.setText(objectAddress.getString("name"));
                    edt_mobile_no_profile.setText(objectAddress.getString("mobile"));
                    edt_gstNo_profile.setText(objectAddress.getString("gst_no"));
                    edt_Compny_name_profile.setText(objectAddress.getString("company_name"));
                    edt_compnyAddress_profile.setText(objectAddress.getString("company_address"));
                    edt_Pin_profile.setText(objectAddress.getString("company_pincode"));
                    edt_city_profile.setText(objectAddress.getString("company_city"));
                    edt_shipingAddress_profile.setText(objectAddress.getString("shipping_address"));
                    edt_shipingPin_profile.setText(objectAddress.getString("shipping_pincode"));
                    edt_shipingCity_profile.setText(objectAddress.getString("shipping_city"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> hashMap = new HashMap<>();
                hashMap.put("Authorization","Bearer "+token);
                Log.d("sadwdqw", String.valueOf(hashMap));
                return hashMap;
            }
        };
        requestQueue.add(request);
    }

    private void hitSubmitProfile() {
        final ProgressDialog dialog = ProgressDialog.show(getContext(), "", "Loading....", false);
        RequestQueue queue = Volley.newRequestQueue(getContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.updateProfile, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("polkjuy",response);
                dialog.dismiss();

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    if(jsonObject.getString("status").equalsIgnoreCase("success")){

                        Toast.makeText(getActivity(), jsonObject.getString("status"), Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(getActivity(), MainPackagingSpare.class)
                        .addFlags( Intent.FLAG_ACTIVITY_CLEAR_TASK ).addFlags( Intent.FLAG_ACTIVITY_NEW_TASK ));
                    }else{
                        Toast.makeText(getActivity(), jsonObject.getString("status"), Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> hashmap = new HashMap<>();
                hashmap.put("name",edt_nameProfile.getText().toString());
                hashmap.put("mobile",edt_mobile_no_profile.getText().toString());
                hashmap.put("gst_no",edt_gstNo_profile.getText().toString());
                hashmap.put("company_name",edt_Compny_name_profile.getText().toString());
                hashmap.put("company_address",edt_compnyAddress_profile.getText().toString());
                hashmap.put("company_pincode",edt_Pin_profile.getText().toString());
                hashmap.put("company_city",edt_city_profile.getText().toString());
                hashmap.put("shipping_address",edt_shipingAddress_profile.getText().toString());
                hashmap.put("shipping_pincode",edt_shipingPin_profile.getText().toString());
                hashmap.put("shipping_city",edt_shipingCity_profile.getText().toString());
                Log.d("daswqsalk", String.valueOf(hashmap));
                return hashmap;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> hashMap = new HashMap<>();
                hashMap.put("Authorization","Bearer "+token);
                return hashMap;
            }
        };
        queue.add(request);
    }
}