package com.avaskm.activity;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.packagingspare.LoginActivity;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;
import com.session.SessonManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import static com.avaskm.Api.Api.LOGIN_URL;
import static com.avaskm.Api.Api.otpurl;

public class OtpActivity extends AppCompatActivity {
    Button btn_submit_otp;
    String mobile,msg;
    TextView textnumber,resend;
    String otpVerification;
    String msgfrgt,pincode;
    PinEntryEditText pinEntryEditText;

    public static final String MyPREFERENCES = "MyPrefs" ;
    SharedPreferences sharedpreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_otp );
        btn_submit_otp=findViewById( R.id.btn_submit_otp);
        textnumber=findViewById( R.id.textnumber );
        pinEntryEditText=findViewById( R.id.txt_pin_entry1 );

        mobile=getIntent().getStringExtra( "mobile" );
        Log.d("jyoti+++",mobile);
        textnumber.setText(mobile);
        sharedpreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        //VerifyOtp( mobile,otpVerification);

        btn_submit_otp.setOnClickListener( new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                pincode=pinEntryEditText.getText().toString();
              if (pinEntryEditText.getText().toString().equals( "" )){
                    Toast.makeText( OtpActivity.this, "enter  oto", Toast.LENGTH_SHORT ).show();
                }
                else if (pincode.length()!=6){
                    Toast.makeText( OtpActivity.this, "enter valid otp", Toast.LENGTH_SHORT ).show();
                }

              else {

                  VerifyOtp( mobile,pinEntryEditText.getText().toString());
                  //  Loginapi();
                }
            }
        } );
    }

    public void VerifyOtp(final String mobileno, final String otp){
     //   otpVerification=String.valueOf(randomOtp());
        final ProgressDialog dialog = ProgressDialog.show(OtpActivity.this, "", "Loading...", false);
        RequestQueue requestQueue = Volley.newRequestQueue(OtpActivity.this);
        StringRequest   stringRequest = new StringRequest( Request.Method.POST, otpurl, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responsesee",response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject=new JSONObject( response );
                    String msg=jsonObject.getString("message");
                    String token=jsonObject.getString("token");
                    Log.d("mobileffff",msg);
                    Log.d("mobiasleffff",token);
                    if(msg.equals("Login Successfull")) {
                        Intent intent = new Intent( OtpActivity.this, MainPackagingSpare.class )
                                .addFlags( Intent.FLAG_ACTIVITY_CLEAR_TASK ).addFlags( Intent.FLAG_ACTIVITY_NEW_TASK );

                        SharedPreferences myPrefs = getSharedPreferences("myPrefs", Context.MODE_PRIVATE);

                        myPrefs.edit().putString( "token",token ).apply();
                        startActivity(intent);

                    }
                  //  intent.putExtra("mobile",mobileno);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }){
            @Override protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String> params=new HashMap<>();
                params.put("mobile",mobileno);
                params.put("otp",otp);
                Log.d("dasaqwaouyt", String.valueOf(params));
                return params;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);


    }


    public void Loginapi(){
        final ProgressDialog dialog = ProgressDialog.show(OtpActivity.this, "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(OtpActivity.this);
        StringRequest   stringRequest = new StringRequest( Request.Method.POST, LOGIN_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responsesee",response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject=new JSONObject( response );
                    String code=jsonObject.getString("message");
                    Log.d("mobileffff",code);
                    Intent intent=new Intent(OtpActivity.this, MainPackagingSpare.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                   intent.putExtra("mobile",mobile);
                    startActivity(intent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }){
            @Override protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String> params=new HashMap<>();
                params.put("mobile",mobile);
                return params;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);


    }

}
