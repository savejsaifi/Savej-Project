package com.avaskm.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.SessonManager;
import com.avaskm.model.BannerModel;
import com.avaskm.model.Cartymodel;
import com.avaskm.model.CategoriesModel;
import com.avaskm.packagingspare.R;
import com.google.android.material.tabs.TabLayout;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static com.avaskm.Api.Api.addcart;
import static com.avaskm.Api.Api.cartdetail;
import static com.avaskm.Api.Api.productdetail;

public class CategorydetailActivity extends AppCompatActivity {
    //    Button btnprize,btnGst,btnMrp;
    TextView txtPrice, txtcutPrice, txtPercentOff, txtMinimum;
    Spinner spinner;
    String spinneritem;
    TextView txtdescription, txtproductone;
    LinearLayout linearlayout, add_layout;
    List<String> list = new ArrayList<String>();
    int minintgr;
    //    String productid;
    TextView integerNum;
    ImageView mainImage;
    RelativeLayout incremetLayout, decrementLayout, relativepricelayout, relativequantity_layout;
    RecyclerView rvCategoryImage;
    CategorynewAdapter categorynewAdapter;
    ArrayList<CategoriesModel> categoryImagelist = new ArrayList<>();
    int positionOfImage = 0;
    TabLayout tabLayout;
    ViewPager mViewPager;
    ArrayList<Cartymodel> listPrice = new ArrayList<>();
    ArrayList<BannerModel> arListBanner;
    TextView txtDeliverycharge;
    float delivery = 0;

    int total = 0;
    RelativeLayout relative_cart, quantity_layout;
    TextView TvCartQty;
    SessonManager sessonManager;
    SharedPreferences myPrefs;
    String StoredValue;
    String id;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorydetail);
        mainImage = findViewById(R.id.viewPagerProduct);
        arListBanner = new ArrayList<>();
        categoryImagelist = new ArrayList<>();
        rvCategoryImage = findViewById(R.id.rvcategoryImage);
        txtproductone = findViewById(R.id.txtproductone);
        linearlayout = findViewById(R.id.linearlayout);
        add_layout = findViewById(R.id.add_layout);
        quantity_layout = findViewById(R.id.quantity_layout);
        txtdescription = findViewById(R.id.txtdescription);
        txtDeliverycharge = findViewById(R.id.txtDeliverycharge);
//        totalQuantityCart = findViewById( R.id.totalQuantityCart );
        sessonManager = new SessonManager(CategorydetailActivity.this);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        txtPrice = findViewById(R.id.txtPrice);
        txtcutPrice = findViewById(R.id.txtcutPrice);
        txtPercentOff = findViewById(R.id.txtPercentOff);
        txtMinimum = findViewById(R.id.txtMinimum);
        incremetLayout = findViewById(R.id.increse);
        decrementLayout = findViewById(R.id.decrese);
        //relativepricelayout = findViewById( R.id.add_layout );
        relativequantity_layout = findViewById(R.id.quantity_layout);
        integerNum = findViewById(R.id.value1);

        rvCategoryImage.setHasFixedSize(true);
        rvCategoryImage.setLayoutManager(new LinearLayoutManager(CategorydetailActivity.this, RecyclerView.HORIZONTAL, false));


        categoryImagelist.clear();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        id = getIntent().getStringExtra("id");
        Log.d("categoryid", id);


        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        StoredValue = myPrefs.getString("token", "");
        Log.d("categorydetail", StoredValue);
        getcategoryId(id, StoredValue);

        //   getCartDetails(StoredValue);

        rvCategoryImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mViewPager.setCurrentItem(2);

            }
        });
        linearlayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //getcardId(StoredValue,id);

            }
        });
        mainImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent ListIntent = new Intent(CategorydetailActivity.this, Categorieszoom.class);
                Bundle loadInfo = new Bundle();
                loadInfo.putInt("positionImage", positionOfImage);
                loadInfo.putSerializable("fullImage", categoryImagelist);
                ListIntent.putExtras(loadInfo);

                Log.d("fawfqwfas", String.valueOf(positionOfImage));
                startActivity(ListIntent);
            }
        });

        add_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add_layout.setVisibility(View.GONE);
                quantity_layout.setVisibility(View.VISIBLE);
                if (total == 0) {
                    total = minintgr;
                    TvCartQty.setText(String.valueOf(total));
                    integerNum.setText("" + total);
                    getcardId(StoredValue, id);
                } else {
                    int minimum = Integer.parseInt(txtMinimum.getText().toString());
                    total = total + minimum;
                    TvCartQty.setText(String.valueOf(total));
                    integerNum.setText("" + minimum);
                    getcardId(StoredValue, id);
                }
            }
        });

        incremetLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                increaseInteger();
            }

            private void increaseInteger() {
                minintgr = minintgr + 1;


                Log.d("sadasaxd", String.valueOf(total));
                total = total + 1;
                TvCartQty.setText(String.valueOf(total));
                Log.d("sadasxd", String.valueOf(total));

                txtDeliverycharge.setText(String.valueOf(minintgr * delivery));

                display(minintgr);
                getcardId(StoredValue, id);

            }
        });
        decrementLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int minimum = Integer.parseInt(txtMinimum.getText().toString());
                Log.d("sfafaasqwer", "" + minimum + "  " + minintgr);

                if (minintgr <= minimum) {
                    //  minintgr=0;
                    // integerNum.setText("0");
                    add_layout.setVisibility(View.VISIBLE);
                    quantity_layout.setVisibility(View.GONE);

                    total = total - minimum;
                    TvCartQty.setText(String.valueOf(total));

                    integerNum.setText("" + 0);
                    getcardId(StoredValue, id);
                } else {
                    decreaseInteger();
                    getcardId(StoredValue, id);
                }

            }

        });

    }



    @Override
    protected void onRestart() {
        super.onRestart();
        TvCartQty.setText(sessonManager.getQty());
        getcategoryId(id, StoredValue);
        positionOfImage = 0;
        delivery=0;
    }

    private void decreaseInteger() {
        minintgr = minintgr - 1;
        total = total - 1;
        TvCartQty.setText(String.valueOf(total));
        display(minintgr);


        txtDeliverycharge.setText(String.valueOf(minintgr * delivery));
    }


    private void display(int number) {


        integerNum.setText("" + number);
        //  totalQuantityCart.setText("Qty "+ String.valueOf(quantity));

        Log.d("displaynum=", String.valueOf(number));

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        // Handle your other action bar items...
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
//        int id = item.getItemId();
//        if (id == R.id.action_search) {
//
//            Intent intent = new Intent(CategorydetailActivity.this, SearchProduct.class);
//            startActivity(intent);
//        }
//        else if (id == R.id.action_viewcart) {
//
//            Intent intent = new Intent( CategorydetailActivity.this, CartActivity.class );
//            startActivity( intent );
//        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart, menu);
        MenuItem item = menu.findItem(R.id.action_viewcart);
        MenuItemCompat.setActionView(item, R.layout.badge_menu);
        RelativeLayout notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        relative_cart = (RelativeLayout) notifCount.findViewById(R.id.relative_cart);

        TvCartQty = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);


        TvCartQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessonManager.setQty(TvCartQty.getText().toString());
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });

        return super.onCreateOptionsMenu(menu);
    }


    public class CategorynewAdapter extends RecyclerView.Adapter<CategorynewAdapter.BookHolder> {

        ArrayList<CategoriesModel> listModel;
        Context context;

        public CategorynewAdapter(ArrayList<CategoriesModel> listModel, Context context) {
            this.listModel = listModel;
            this.context = context;
        }


        @NonNull
        @Override
        public BookHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater inflater = LayoutInflater.from(context);
            view = inflater.inflate(R.layout.category_image, parent, false);
            return new BookHolder(view);
        }


        @Override
        public void onBindViewHolder(@NonNull BookHolder holder, int position) {

            Log.d("bindholder", listModel.get(position).getBookMobileImage());


            Picasso.get().load(listModel.get(position).getBookMobileImage()).into(holder.row_ImgBook);
            //  holder.row_ImgBook.setImageResource(listModel.get(position).getBookMobileImage());


            // Log.d("aserewd", listModel.get(position).getBookMobileImage());
        }

        @Override
        public int getItemCount() {
            return listModel.size();
        }

        public class BookHolder extends RecyclerView.ViewHolder {
            ImageView row_ImgBook;

            public BookHolder(@NonNull View itemView) {
                super(itemView);
                row_ImgBook = itemView.findViewById(R.id.row_ImgBook);
                itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int i = getAdapterPosition();
                        positionOfImage = Integer.parseInt(String.valueOf(i));
                        CategoriesModel object = categoryImagelist.get(getAdapterPosition());
                        String img = object.getBookMobileImage();


                        Picasso.get().load(img).into(mainImage);

                        //positionOfImage = mobileImagelist.indexOf(object);
                        Log.d("dsdsa", String.valueOf(positionOfImage));

                    }
                });
            }
        }
    }

    private void getcategoryId(final String id, final String StoredValue) {
        final ProgressDialog dialog = ProgressDialog.show(CategorydetailActivity.this, "", "Loading....", false);
        //  String urll= http://appplace.xyz/api/product/;
        String urll = productdetail + "/" + id;

        listPrice.clear();
        categoryImagelist.clear();

        RequestQueue requestQueue = Volley.newRequestQueue(CategorydetailActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, urll, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("categorydetail", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    Cartymodel cartymodel = new Cartymodel();
//                    String image = jsonObject.getString( "image" );
                    String description = jsonObject.getString("description");
                    String txtproduct = jsonObject.getString("name");
                    String totalCartItem = jsonObject.getString("total");
                    total = Integer.parseInt(totalCartItem);
                    TvCartQty.setText(totalCartItem);
                    getSupportActionBar().setTitle(txtproduct);


                    String quantity = jsonObject.getString("quantity");
                    String Minquantity = jsonObject.getString("minimum_quantity");

                    txtMinimum.setText(Minquantity);

                    if ((Integer.parseInt(quantity) >= Integer.parseInt(Minquantity))) {
                        add_layout.setVisibility(View.GONE);
                        quantity_layout.setVisibility(View.VISIBLE);
                        minintgr = Integer.parseInt(quantity);
                        integerNum.setText(quantity);

                    } else {
                        add_layout.setVisibility(View.VISIBLE);
                        quantity_layout.setVisibility(View.GONE);
                        minintgr = Integer.parseInt(Minquantity);
                        integerNum.setText(Minquantity);
                    }

                    txtproductone.setText(txtproduct);
                    txtdescription.setText(description);
                    // Picasso.get().load( image ).into( mainImage );
                    txtPrice.setText(jsonObject.getString("price"));
                    txtcutPrice.setText(jsonObject.getString("cut_price"));
                    txtPercentOff.setText(jsonObject.getString("percent"));
                    txtcutPrice.setPaintFlags(txtcutPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);


                    String product_weight = jsonObject.getString("product_weight");
                    String product_per_kg = jsonObject.getString("delivery_per_kg_price");
                    delivery = delivery + Float.parseFloat(product_per_kg) * Float.parseFloat(product_weight);
                    txtDeliverycharge.setText(String.valueOf(delivery * minintgr));

//                    JSONArray jsonArray = jsonObject.getJSONArray( "sizeprice" );
//                  //  JSONArray gallery=jsonObject.getJSONArray( "gallery" );
//                    for (int k = 0; k < jsonArray.length(); k++) {
//                        JSONObject jsonObjectone = jsonArray.getJSONObject( k );
//
//
//
//                         cartymodel.setDelivery(jsonObjectone.getString( "deliverycharge" ));
//
//                        list.add( jsonObjectone.getString( "size" ) );
//
//
//                        cartymodel.setPrize(jsonObjectone.getString( "price" ));
//                        cartymodel.setId(jsonObjectone.getString( "id" ));
//                        cartymodel.setSize(jsonObjectone.getString( "size" ));
//                        cartymodel.setGst(jsonObjectone.getString( "gst" ));
//                        listPrice.add(cartymodel);
//
//                       // listid.add( jsonObjectone.getString( "product_id" ) );
//                        Log.d( "checkname", String.valueOf( list.size() ) );
//                        Log.d( "checaqkname", String.valueOf( jsonObjectone.getString( "id" ) ) );
//
//                        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>( CategorydetailActivity.this,
//                                android.R.layout.simple_spinner_item, list );
//                        dataAdapter.setDropDownViewResource( android.R.layout.simple_spinner_dropdown_item );
//                        //   spinner.setOnItemSelectedListener(new TancardActivity.CustomOnItemSelectedListener());
//                        spinner.setAdapter( dataAdapter );
//
//                        delivery = delivery+Integer.parseInt(listPrice.get(k).getDelivery());
//                    }
//                    txtDeliverycharge.setText(String.valueOf(delivery*minintgr));


                    JSONArray gallery = jsonObject.getJSONArray("gallery");

                    Log.d("gallerylenght", String.valueOf(gallery.length()));
                    for (int l = 0; l < gallery.length(); l++) {
                        JSONObject jsongallery = gallery.getJSONObject(l);
                        String doc_path = jsongallery.getString("doc_path");
                        Log.d("docpath", jsongallery.getString("doc_path"));
                        CategoriesModel model = new CategoriesModel();
                        model.setBookMobileImage(jsongallery.getString("doc_path"));
                        // bussiness.setImage( jsonmain.getString( "image" ) );
                        categoryImagelist.add(model);
                    }
                    Log.d("gallerylenght1", String.valueOf(gallery.length()));
                    categorynewAdapter = new CategorynewAdapter(categoryImagelist, CategorydetailActivity.this);
                    rvCategoryImage.setAdapter(categorynewAdapter);

                    if (categoryImagelist.size() == 0) {
                        Picasso.get().load(R.drawable.active_dots).into(mainImage);
                    } else {
                        CategoriesModel object = categoryImagelist.get(0);
                        String img = object.getBookMobileImage();
                        Picasso.get().load(img).into(mainImage);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + StoredValue);
                Log.d("chejklf", String.valueOf(StoredValue));
                return headerMap;
            }

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    private void getcardId(final String StoredValue, final String id) {
        final ProgressDialog dialog = ProgressDialog.show(CategorydetailActivity.this, "", "Loading....", false);
        //  String urll= http://appplace.xyz/api/product/;

        RequestQueue requestQueue = Volley.newRequestQueue(CategorydetailActivity.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, addcart, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("addcazrd", response);
                dialog.dismiss();

                sessonManager.setQty(TvCartQty.getText().toString());
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
                Log.e("onErrorResponse", error.toString());
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + StoredValue);
                Log.d("tokenvalue", String.valueOf(StoredValue));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("quantity", integerNum.getText().toString());
                hashMap.put("product_id", id);

                Log.d("chejklf", String.valueOf(hashMap));
                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {
        sessonManager.setQty(TvCartQty.getText().toString());
        // Toast.makeText(this, "sdaowe", Toast.LENGTH_SHORT).show();
        super.onBackPressed();

    }
}
