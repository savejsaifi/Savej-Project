package com.avaskm.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.SessonManager;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;
import com.google.android.material.snackbar.Snackbar;
import com.razorpay.Checkout;
import com.razorpay.PaymentData;
import com.razorpay.PaymentResultListener;
import com.razorpay.PaymentResultWithDataListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PaymentModeActivity extends Activity implements PaymentResultWithDataListener {
    private static final String TAG = PaymentModeActivity.class.getSimpleName();
    String TotalPrice, id, order_id;
    SharedPreferences amountSharedPref, myPrefs;
    Button clickForPayment;
    WebView webView_payment;
    String token;
     SessonManager sessonManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_mode);
        amountSharedPref = getSharedPreferences("finalAmount", MODE_PRIVATE);
        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        sessonManager = new SessonManager(PaymentModeActivity.this);

        token = myPrefs.getString("token", "");


        id = amountSharedPref.getString("id", "");
        order_id = amountSharedPref.getString("order_id", "");

        TotalPrice = amountSharedPref.getString("paybleAmount", "");
        TotalPrice = String.valueOf(Integer.parseInt(TotalPrice));

        Log.d("dsaQWSAA", TotalPrice + " " + order_id );
        Checkout.preload(getApplicationContext());

        startPayment();


    }


    public void startPayment() {
        /**   * Instantiate Checkout   */
        Checkout checkout = new Checkout();
        /**   * Set your logo here   */
        checkout.setImage(R.drawable.bannersec);
        /**   * Reference to current activity   */
        final Activity activity = this;
        /**   * Pass your payment options to the Razorpay Checkout as a JSONObject   */
        try {
            JSONObject options = new JSONObject();
            /**      * Merchant Name      * eg: ACME Corp || HasGeek etc.      */

            options.put("name", "Packaging Spare");
            /**      * Description can be anything      * eg: Reference No. #123123 - This order number is passed by you for your internal reference. This is not the `razorpay_order_id`.      *     Invoice Payment      *     etc.      */
            options.put("description", "");
            options.put("order_id", order_id);
            options.put("currency", "INR");      /**      * Amount is always passed in currency subunits      * Eg: "500" = INR 5.00      */
            //   options.put("amount", TotalPrice);
            options.put("amount", "100");
            JSONObject preFill = new JSONObject();

            preFill.put("email", "");
            preFill.put("contact", "");
            options.put("prefill", preFill);

            checkout.open(activity, options);
        } catch (Exception e) {
            //   Log.e(TAG, "Error in starting Razorpay Checkout", e);
        }
    }


    @Override
    public void onPaymentSuccess(String s, PaymentData paymentData) {
        try {
            String paymentId = paymentData.getPaymentId();
            String signature = paymentData.getSignature();
            String orderId = paymentData.getOrderId();
            PaymentSuccessAPI(paymentId, signature, orderId);
            Log.d("dasdwqpo", s + "  " + paymentId + " " + signature + " " + orderId);

//            startActivity(new Intent(getApplicationContext(), MainPackagingSpare.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
//            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Log.e(TAG, "Exception in onPaymentSuccess", e);
        }
    }

    @Override
    public void onPaymentError(int i, String s, PaymentData paymentData) {
        try {
            Toast.makeText(this, "Payment failed: " + i + " " + s, Toast.LENGTH_SHORT).show();

            startActivity(new Intent(getApplicationContext(), PaymentFailActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            Log.d("lkts", String.valueOf(s));
        } catch (Exception e) {
            Log.e(TAG, "Exception in onPaymentError", e);

         Log.d("fwqfwfa",e.getMessage());
        }
    }

    private void PaymentSuccessAPI(final String paymentId, final String signature, final String orderId) {
        Log.d("lkts", "fds");
        final ProgressDialog dialog = ProgressDialog.show(PaymentModeActivity.this, "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(PaymentModeActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.PaymentSuccess, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("PaymentSuccess", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");

                    if (status.equalsIgnoreCase("success")) {
                        String qtyCart = sessonManager.getQty();
                        qtyCart ="0";
                        sessonManager.setQty(qtyCart);


                        Toast.makeText(getApplicationContext(), "Payment Successful: ", Toast.LENGTH_SHORT).show();
                        Intent intent1 = new Intent(PaymentModeActivity.this, ThankyouActivity.class);
                        intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent1);
                    } else {

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("safwqwaA", error.getMessage());
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();

                params.put("razorpay_order_id", orderId);
                params.put("razorpay_payment_id", paymentId);
                params.put("razorpay_signature", signature);
                Log.d("allItr", String.valueOf(params));

                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("Authorization", "Bearer " + token);
                Log.d("allIstr", String.valueOf(token));
                return hashMap;
            }
        };

        requestQueue.getCache().clear();
        requestQueue.add(request);

    }



        public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // your code
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
}
