package com.avaskm.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.avaskm.activity.CategorydetailActivity;
import com.avaskm.model.Subcategory;
import com.avaskm.packagingspare.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.Inflater;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.SearchHolder> {

    Context context;

    ArrayList<Subcategory> list;

    public SearchAdapter(Context context, ArrayList<Subcategory> list) {
        this.context = context;
        this.list = list;

    }

    @NonNull
    @Override
    public SearchHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_search, parent,false);
        return new SearchHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull SearchHolder holder, final int position) {

        Picasso.get().load(list.get(position).getImage()).into(holder.img_searchProduct);
        holder.txtNameProduct.setText(list.get(position).getFirt());
        holder.OriginalPrice.setText(list.get(position).getThird());
        holder.CutPrice.setText(list.get(position).getSecond());
        holder.CutPrice.setPaintFlags(holder.CutPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);

        holder.txtPercentSearch.setText(list.get(position).getPercent());

        holder.cardviewSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id  = list.get(position).getId();
                Log.d("sasdqwalmk",id);
                context.startActivity(new Intent(context, CategorydetailActivity.class).putExtra("id",id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });
    }

    @Override
    public int getItemCount() {
        Log.d("qwedsasdaq", String.valueOf(list.size()));
        return list.size();

    }


    public class SearchHolder extends RecyclerView.ViewHolder {

        ImageView img_searchProduct;
        TextView txtNameProduct, OriginalPrice, CutPrice,txtPercentSearch;
        CardView cardviewSearch;

        public SearchHolder(@NonNull View itemView) {
            super(itemView);
            img_searchProduct = itemView.findViewById(R.id.img_searchProduct);
            txtNameProduct = itemView.findViewById(R.id.txtNameProduct);
            OriginalPrice = itemView.findViewById(R.id.OriginalPrice);
            CutPrice = itemView.findViewById(R.id.CutPrice);
            txtPercentSearch = itemView.findViewById(R.id.txtPercentSearch);
            cardviewSearch = itemView.findViewById(R.id.cardviewSearch);

        }
    }

}
