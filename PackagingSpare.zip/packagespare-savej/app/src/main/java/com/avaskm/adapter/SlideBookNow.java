package com.avaskm.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.avaskm.model.CategoriesModel;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import uk.co.senab.photoview.PhotoView;

public class SlideBookNow extends PagerAdapter {
    Context mContext;
    ArrayList<CategoriesModel> listBook;
    int positionImage;

/*    Context mContext;

    int[] sliderImage;*/

    public SlideBookNow(Context context, ArrayList<CategoriesModel> listBook) {
        this.mContext = context;
        this.listBook = listBook;

//        this.positionImage = positionImage;;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((ImageView) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        PhotoView imageView = new PhotoView(mContext);

        try{

            Picasso.get().load(listBook.get(position).getBookMobileImage()).into(imageView);
            ((ViewPager) container).addView(imageView, 0);
            Log.d( "jio", String.valueOf( listBook.get(position).getBookMobileImage() ) );

        }catch (IllegalArgumentException e){

        }


        // imageView.setScaleType(PhotoView.ScaleType.FIT_XY);

        //  imageView.setImageResource(Book.all_image[position]);


        return imageView;
    }



    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        ((ViewPager) container).removeView((ImageView) object);
    }

    @Override
    public int getCount() {
        return listBook.size();
    }


}
