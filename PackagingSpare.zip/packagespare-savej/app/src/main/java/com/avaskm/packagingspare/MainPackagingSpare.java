package com.avaskm.packagingspare;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Bundle;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.SessonManager;
import com.avaskm.activity.CartActivity;
import com.avaskm.activity.CategorydetailActivity;
import com.avaskm.activity.SearchProduct;
import com.avaskm.model.Cartymodel;
import com.avaskm.packagingspare.ui.ContactFragment;
import com.avaskm.packagingspare.ui.gallery.AboutusFragment;
import com.avaskm.packagingspare.ui.home.HomeFragment;
import com.avaskm.packagingspare.ui.privacypolicy.PrivacypolicyFragment;
import com.avaskm.packagingspare.ui.profile.ProfileFragment;
import com.avaskm.packagingspare.ui.order.MyorderFragment;
import com.avaskm.packagingspare.ui.termsandcondition.TermsandconditionFragment;
import com.google.android.material.snackbar.Snackbar;

import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.ui.AppBarConfiguration;
import com.google.android.material.navigation.NavigationView;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static com.avaskm.Api.Api.cartdetail;

public class MainPackagingSpare extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    Snackbar snackbar;

    SharedPreferences myPrefs;
    SharedPreferences.Editor editor;
    String token;
    RelativeLayout relative_cart;
    TextView TvCartQty;
    SessonManager sessonManager;
    DrawerLayout drawer;
    long back_pressed=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_packaging_spare );
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Packaging Spare");

        TextView tv=(TextView) toolbar.getChildAt(0);
        tv.setTypeface((Typeface.SERIF));


        setSupportActionBar(toolbar);
        sessonManager = new SessonManager(MainPackagingSpare.this);


        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        editor = myPrefs.edit();
        token=myPrefs.getString("token", "");


         drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.content, new HomeFragment());
        ft.commit();



    }


    @Override
    protected void onRestart() {
        super.onRestart();

        TvCartQty.setText(sessonManager.getQty());
       // Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
    }

    /*  @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.packaging_spare, menu);
        return true;
    }*/

    private void getcardDetail() {

        //  String urll= http://appplace.xyz/api/product/;

        RequestQueue requestQueue = Volley.newRequestQueue(MainPackagingSpare.this);
        StringRequest stringRequest = new StringRequest( Request.Method.GET, cartdetail, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("cartcaard", response);

                try {
                    JSONObject jsonObjectFirst = new JSONObject(response);
                    TvCartQty.setText(jsonObjectFirst.getString("quantity"));
                    sessonManager.setQty( jsonObjectFirst.getString("quantity"));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e("onErrorResponse", error.toString());
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + token);
                Log.d("chejklf", String.valueOf(token));
                return headerMap;
            }

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart,menu);
        MenuItem item = menu.findItem(R.id.action_viewcart);

        MenuItemCompat.setActionView(item,R.layout.badge_menu);



        RelativeLayout notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        relative_cart = (RelativeLayout) notifCount.findViewById(R.id.relative_cart);

        TvCartQty = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);
        TvCartQty.setText(sessonManager.getQty());

        TvCartQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });
        getcardDetail();
//        invalidateOptionsMenu();

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_viewcart) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


//    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        Fragment fragment = null;

        int id = item.getItemId();
        if (id == R.id.nav_home) {
            fragment= new HomeFragment();
            FragmentTransaction(fragment);

        } else if (id == R.id.nav_aboutus) {
            fragment= new AboutusFragment();
            FragmentTransaction(fragment);
        }
        else if (id == R.id.nav_profile) {
            fragment= new ProfileFragment();
            FragmentTransaction(fragment);

        }
        else if (id == R.id.nav_order) {
            Fragment fragment2= new MyorderFragment();
            FragmentTransaction(fragment2);


        }else if (id == R.id.nav_termsandcon) {
            fragment = new TermsandconditionFragment();
            FragmentTransaction(fragment);
        }
        else if (id == R.id.nav_privacypolicy) {
            fragment = new PrivacypolicyFragment();
            FragmentTransaction(fragment);
        }
        else if (id == R.id.nav_contact) {
            fragment = new ContactFragment();
            FragmentTransaction(fragment);
        }
        else if (id == R.id.nav_logout) {

            editor.clear();
            editor.commit();
            sessonManager.setQty( "0" );
            Intent intent=new Intent(MainPackagingSpare.this,LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void FragmentTransaction(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentManager.popBackStack();
        fragmentTransaction.commit();
    }



    @Override
    public void onBackPressed() {

        if (back_pressed + 2000 > System.currentTimeMillis())
            super.onBackPressed();
        else
        {
            Snackbar snackbar=Snackbar.make(drawer, "Double Tap to Exit!", Snackbar.LENGTH_SHORT);
            View view=snackbar.getView();
            view.setBackgroundColor(getResources().getColor(R.color.black));
            snackbar.show();
            back_pressed = System.currentTimeMillis();
        }
    }
}
