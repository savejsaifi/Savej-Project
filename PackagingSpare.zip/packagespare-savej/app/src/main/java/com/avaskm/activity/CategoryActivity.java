package com.avaskm.activity;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.MenuItemCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.Api.Api;
import com.avaskm.SessonManager;
import com.avaskm.adapter.SliderAdapter;
import com.avaskm.model.BannerModel;
import com.avaskm.model.Categorymodel;
import com.avaskm.model.Pakagingmodel;
import com.avaskm.packagingspare.MainPackagingSpare;
import com.avaskm.packagingspare.R;
import com.avaskm.packagingspare.ui.home.HomeFragment;
import com.squareup.picasso.Picasso;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.avaskm.Api.Api.category;

public class CategoryActivity extends AppCompatActivity {
    RecyclerView categoryrecyclerview;
    List<Categorymodel> categorymodelList;
    Categoryadapter adapter;
    EditText searchClick_cat;
    RelativeLayout relative_cart;
    TextView TvCartQty;
    SessonManager sessonManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_category );
        sessonManager = new SessonManager(CategoryActivity.this);

        categoryrecyclerview=findViewById( R.id.recyclerviewcategory);
        searchClick_cat=findViewById( R.id.searchClick_cat);
        categorymodelList=new ArrayList<>();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Category");

        String id=getIntent().getStringExtra( "id" );
         Log.d("isecondpageid",id);

        SharedPreferences myPrefs;
        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
        String StoredValue=myPrefs.getString("token", "");
        Log.d( "categorykey",StoredValue );

        gethomecategoryAPI(id);


        //setpackaging();

        searchClick_cat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),SearchProduct.class));
            }
        });
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        TvCartQty.setText(sessonManager.getQty());
        // Toast.makeText(this, "onResume", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.cart,menu);
        MenuItem item = menu.findItem(R.id.action_viewcart);
        MenuItemCompat.setActionView(item,R.layout.badge_menu);



        RelativeLayout notifCount = (RelativeLayout) MenuItemCompat.getActionView(item);
        relative_cart = (RelativeLayout) notifCount.findViewById(R.id.relative_cart);

        TvCartQty = (TextView) notifCount.findViewById(R.id.actionbar_notifcation_textview);
        TvCartQty.setText(sessonManager.getQty());

        TvCartQty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CartActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
            }
        });


//        invalidateOptionsMenu();

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
    public class Categoryadapter extends RecyclerView.Adapter<Categoryadapter.ViewHolder>{
        private Context context;
        private ArrayList<Categorymodel>mData;

        public Categoryadapter(Context context, ArrayList<Categorymodel> mData) {
            this.context = context;
            this.mData = mData;
        }

        @NonNull
        @Override
        public Categoryadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_category,parent,false);
            Categoryadapter.ViewHolder viewHolder=new Categoryadapter.ViewHolder(view);
            return viewHolder;
        }


        @Override
        public void onBindViewHolder(@NonNull Categoryadapter.ViewHolder holder, final int position) {
           // holder.imageView.setImageResource( mData.get( position ).getImage());
          //  Picasso.with(context).load(arList.get(position).getImage()).into(holder.IvIMageCateFirst);
            Picasso.get().load( mData.get(position).getImage()).into( holder.imageView );
            holder.txtsubcategory.setText( mData.get( position).getItem());
            holder.cardviewitem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent=new Intent(CategoryActivity.this, SubcategoryActivity.class);

                    intent.putExtra("id",mData.get(position).getId() );

                    Log.d("idzs",mData.get(position).getId());


                    startActivity(intent);


                }
            });

        }


        @Override
        public int getItemCount() {
            return mData.size();
        }
        public class ViewHolder extends RecyclerView.ViewHolder{
            ImageView imageView;
            CardView cardviewitem;
            TextView txtsubcategory;

            public ViewHolder(@NonNull View itemView) {
                super( itemView );
                imageView=itemView.findViewById( R.id.imgcategoryimage);
                cardviewitem=itemView.findViewById( R.id.cardviewcategory );
                txtsubcategory=itemView.findViewById( R.id.txtsubcategory);
            }
        }
    }
    public void gethomecategoryAPI(String id){
        categorymodelList.clear();
        final ProgressDialog dialog = ProgressDialog.show( CategoryActivity.this, "", "Loading....", false);
        String url= category +"/" +id +"/subcategory";
      /*  public static String category=SITE_URL+"/category";*/
       /* http://appplace.xyz/api/category/{id}/subcategory*/ categoryrecyclerview.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(CategoryActivity.this,2);
        categoryrecyclerview.setLayoutManager(layoutManager);
        RequestQueue requestQueue = Volley.newRequestQueue(CategoryActivity.this);
        StringRequest stringRequest = new StringRequest( Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("categoray",response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray=new JSONArray( response );

                    for (int j=0;j<jsonArray.length();j++){
                        JSONObject jsonmain=jsonArray.getJSONObject(j);
                        Categorymodel bussiness=new Categorymodel();
                        String title=jsonmain.getString( "title" );
                        String image=jsonmain.getString( "image" );
                        bussiness.setItem(jsonmain.getString("title"));
                        bussiness.setImage( jsonmain.getString( "image" ) );
                        bussiness.setId( jsonmain.getString( "id" ) );
                        Log.d( "image",image );
                        categorymodelList.add( bussiness );
                    }

                    categoryrecyclerview.setHasFixedSize(true);
                    RecyclerView.LayoutManager layoutManager=new GridLayoutManager(CategoryActivity.this,2);
                    categoryrecyclerview.setLayoutManager(layoutManager);

                    adapter=new Categoryadapter(CategoryActivity.this, (ArrayList<Categorymodel>) categorymodelList );
                    categoryrecyclerview.setAdapter( adapter );

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {

        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }
}
