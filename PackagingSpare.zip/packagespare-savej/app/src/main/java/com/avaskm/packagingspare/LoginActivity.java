package com.avaskm.packagingspare;
import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.activity.OtpActivity;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;
import static com.avaskm.Api.Api.LOGIN_URL;

public class LoginActivity extends AppCompatActivity {
    Button btn_login;
    EditText edt_no;
    String mobileno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_login );
        edt_no=findViewById( R.id.edt_no );
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Login");
        getSupportActionBar().hide();

        btn_login=findViewById( R.id.btn_login );
        btn_login.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent( LoginActivity.this, MainPackagingSpare.class );
                startActivity( intent );
            }
        } );
        btn_login.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mobileno=edt_no.getText().toString();
                if (mobileno.isEmpty())
                {
                    edt_no.setError( "enter mobileno..." );
                }else if (mobileno.length()!=10){
                    edt_no.setError( "Please enter the 10 digit mobile No");

                }
                else {
               /* Intent intent=new Intent( LoginActivity.this, OtpActivity.class );
                startActivity( intent );}*/
              Loginapi();
            }}
        } );
}
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
    public void Loginapi(){
        final ProgressDialog dialog = ProgressDialog.show(LoginActivity.this, "", "Loading....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(LoginActivity.this);
        StringRequest   stringRequest = new StringRequest( Request.Method.POST, LOGIN_URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responsesee",response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject=new JSONObject( response );
                    String code=jsonObject.getString("message");
                    Log.d("mobileffff",code);
                    Intent intent=new Intent(LoginActivity.this, OtpActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("mobile",mobileno);
                    startActivity(intent);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }){
            @Override protected Map<String, String> getParams() throws AuthFailureError
            {
                HashMap<String,String> params=new HashMap<>();
                params.put("mobile",mobileno);
                return params;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);


    }


}