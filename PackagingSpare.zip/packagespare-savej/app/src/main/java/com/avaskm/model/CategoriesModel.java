package com.avaskm.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class CategoriesModel implements Serializable {
    int img_front;
    int img_back;
    int img_side;
    int img_slope;

    String bookMobileImage;
    String bookimageId;

    public CategoriesModel(){
    }

    public CategoriesModel(int img_front, int img_back, int img_side, int img_slope, String bookMobileImage, String bookimageId) {
        this.img_front = img_front;
        this.img_back = img_back;
        this.img_side = img_side;
        this.img_slope = img_slope;
        this.bookMobileImage = bookMobileImage;
        this.bookimageId = bookimageId;
    }

    public int getImg_front() {
        return img_front;
    }

    public void setImg_front(int img_front) {
        this.img_front = img_front;
    }

    public int getImg_back() {
        return img_back;
    }

    public void setImg_back(int img_back) {
        this.img_back = img_back;
    }

    public int getImg_side() {
        return img_side;
    }

    public void setImg_side(int img_side) {
        this.img_side = img_side;
    }

    public int getImg_slope() {
        return img_slope;
    }

    public void setImg_slope(int img_slope) {
        this.img_slope = img_slope;
    }

    public String getBookMobileImage() {
        return bookMobileImage;
    }

    public void setBookMobileImage(String bookMobileImage) {
        this.bookMobileImage = bookMobileImage;
    }

    public String getBookimageId() {
        return bookimageId;
    }

    public void setBookimageId(String bookimageId) {
        this.bookimageId = bookimageId;
    }
}
