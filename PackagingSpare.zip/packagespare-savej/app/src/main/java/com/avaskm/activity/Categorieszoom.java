package com.avaskm.activity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import com.avaskm.model.CategoriesModel;
import com.avaskm.packagingspare.R;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import uk.co.senab.photoview.PhotoView;

public class Categorieszoom extends AppCompatActivity {
    ArrayList<CategoriesModel> categoryImagelist;
    private ArrayList<String> imageModelArrayList;
    private static ViewPager mPager;
    private static int currentPage = 0;
    private static int NUM_PAGES = 0;
    int positionImage;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen_book);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("PackagingSpare");

        mPager = findViewById(R.id.pager2);

//        Bundle getBundle = this.getIntent().getExtras();
//        positionImage = getBundle.getInt("positionImage");

        Bundle loadInfo = getIntent().getExtras();
        positionImage = loadInfo.getInt("positionImage");
        categoryImagelist = (ArrayList<CategoriesModel>) loadInfo.getSerializable("fullImage");


        imageModelArrayList = new ArrayList<>();
        imageModelArrayList = populateList();
        init();
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    private ArrayList<String> populateList() {
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < categoryImagelist.size(); i++) {

            String imageModel = new String();
            list.add(imageModel);
            Log.d("imagess", String.valueOf(list.size()));
        }
        return list;
    }

    @Override
    public void onBackPressed()
    {
        // code here to show dialog
        super.onBackPressed();  // optional depending on your needs
    }

    private void init() {
        // mPager =getActivity().findViewById(R.id.pager2);
        mPager.setAdapter(new SlidingImage_Adapter( Categorieszoom.this, imageModelArrayList));
        mPager.setCurrentItem(positionImage);

        NUM_PAGES = imageModelArrayList.size();

        // Auto start of viewpager
        final Handler handler = new Handler();
        final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == NUM_PAGES) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };
        Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 1000000, 1000000);

    }

    public class SlidingImage_Adapter extends PagerAdapter {
        private ArrayList<String> imageModelArrayList;
        private LayoutInflater inflater;
        private Context context;

        public SlidingImage_Adapter(Context context, ArrayList<String> imageModelArrayList) {
            this.context = context;
            this.imageModelArrayList = imageModelArrayList;
            inflater = LayoutInflater.from(context);
        }

        @Override
        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        @Override
        public int getCount() {

            return imageModelArrayList.size();
        }

        @Override
        public View instantiateItem(ViewGroup container, int position) {
            PhotoView photoView = new PhotoView(container.getContext());
            Picasso.get().load(String.valueOf(categoryImagelist.get(position).getBookMobileImage())).into(photoView);
          //  Log.d("cheicmahes", categoryImagelist.get(position).getBookMobileImage());
            container.addView(photoView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            return photoView;
        }


        @Override
        public boolean isViewFromObject(View view, Object object) {
            return view.equals(object);
        }

        @Override
        public void restoreState(Parcelable state, ClassLoader loader) {
        }

        @Override
        public Parcelable saveState() {
            return null;
        }

    }

}
