package com.avaskm.model;

public class Cartymodel {


    String id;
    private String product;
    private String size;
    private String prize;
    private String image;
    private String quanityrs;
    private String txtcutprize;
    private String total;

    public String getMinimumQuantity() {
        return minimumQuantity;
    }

    public void setMinimumQuantity(String minimumQuantity) {
        this.minimumQuantity = minimumQuantity;
    }

    private String minimumQuantity;

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }


    public String getSizeid() {
        return sizeid;
    }

    public void setSizeid(String sizeid) {
        this.sizeid = sizeid;
    }

    private String sizeid;

    public String getGst() {
        return gst;
    }

    public void setGst(String gst) {
        this.gst = gst;
    }

    private String gst;

    public String getDelivery() {
        return delivery;
    }

    public void setDelivery(String delivery) {
        this.delivery = delivery;
    }

    private String delivery;
    public Cartymodel() {
    }

    public Cartymodel(String product, String size, String prize, String image, String quanityrs, String txtcutprize) {
        this.product = product;
        this.size = size;
        this.prize = prize;
        this.image = image;
        this.quanityrs = quanityrs;
        this.txtcutprize = txtcutprize;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPrize() {
        return prize;
    }

    public void setPrize(String prize) {
        this.prize = prize;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getQuanityrs() {
        return quanityrs;
    }

    public void setQuanityrs(String quanityrs) {
        this.quanityrs = quanityrs;
    }

    public String getTxtcutprize() {
        return txtcutprize;
    }

    public void setTxtcutprize(String txtcutprize) {
        this.txtcutprize = txtcutprize;
    }
}
