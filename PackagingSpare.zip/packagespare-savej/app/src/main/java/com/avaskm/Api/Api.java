package com.avaskm.Api;

public class Api {
    public static String SITE_URL = "http://appplace.xyz/api";
    public static String LOGIN_URL = SITE_URL+"/login";
    public static String home=SITE_URL+"/home";
    public static String category=SITE_URL+"/category";
    public static String makeorder=SITE_URL+"/make-order";
    public static String addcart=SITE_URL+"/add-cart";
    public static String orderdetail=SITE_URL+"/order-details/";
    public static String orderhistory=SITE_URL+"/order-history";
    public static String productdetail=SITE_URL+"/product";
    public static String cartdetail=SITE_URL+"/cart-details";
    public static String otpurl=SITE_URL+"/verify-otp";
    public static String canelOrder=SITE_URL+"/cancel-order/";
    public static String returnOrder=SITE_URL+"/return/";
    public static String searchProduct=SITE_URL+"/search";
    public static String getAdress=SITE_URL+"/get-address";
    public static String setAdress=SITE_URL+"/set-address";
    public static String getProfile=SITE_URL+"/get-profile";
    public static String updateProfile=SITE_URL+"/update-profile";
    public static String payNow=SITE_URL+"/pay-now";
    public static String PaymentSuccess=SITE_URL+"/verify-payment";

 /*   eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJodHRwOlwvXC9hcHBwbGFjZS54eXpcL2FwaVwvdmVyaWZ5LW90cCIsImlhdCI6MTU3ODI5MzIzNSwiZXhwIjoxNTc4NTkzMjM1LCJuYmYiOjE1NzgyOTMyMzUsImp0aSI6ImRkSllPYXh2M3hhZGdSelgiLCJzdWIiOjIwMCwicHJ2IjoiODdlMGFmMWVmOWZkMTU4MTJmZGVjOTcxNTNhMTRlMGIwNDc1NDZhYSJ9.GM9_-0ziCsKiFV6cdAz5cg4OR91xe_HEe67hmxguqhk*/



}
