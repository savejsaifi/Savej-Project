package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class Example_Model {

    @SerializedName("Table")
    @Expose
    private List<Table_Model> table = null;
    @SerializedName("Table1")
    @Expose
    private List<Table1_Model> table1 = null;
    @SerializedName("Table2")
    @Expose
    private List<Table2_Model> table2 = null;

    public List<Table_Model> getTable() {
        return table;
    }

    public void setTable(List<Table_Model> table) {
        this.table = table;
    }

    public List<Table1_Model> getTable1() {
        return table1;
    }

    public void setTable1(List<Table1_Model> table1) {
        this.table1 = table1;
    }

    public List<Table2_Model> getTable2() {
        return table2;
    }

    public void setTable2(List<Table2_Model> table2) {
        this.table2 = table2;
    }
}
