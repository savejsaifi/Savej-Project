package com.example.administrator.retrofit_example.activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.adapter.NewsAdapter;
import com.example.administrator.retrofit_example.model.Example;
import com.example.administrator.retrofit_example.model.Table;
import com.example.administrator.retrofit_example.service.Api;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class News extends AppCompatActivity {

    ArrayList<Table> tList;
    NewsAdapter nadapter;
    RecyclerView rView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        rView = findViewById(R.id.rView);
        tList = new ArrayList<>();
        nadapter = new NewsAdapter(getApplicationContext(), tList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rView.setLayoutManager(layoutManager);
        rView.setAdapter(nadapter);
        newsList();
    }
    public void newsList() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_DEFULTER_LIST)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();
        Api api = retrofit.create(Api.class);
        final Call<Example> nlist = api.newsList();
        final ProgressDialog progressDoalog;
        progressDoalog = new ProgressDialog(News.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.show();
        nlist.enqueue(new Callback<Example>() {
            @Override
            public void onResponse(Call<Example> call, Response<Example> response) {
                progressDoalog.dismiss();
                try {
                    ArrayList<Table> defulterLists = (ArrayList<Table>) response.body().getTable();

                    NewsAdapter nAdapter = new NewsAdapter(News.this, defulterLists);
                    rView.setAdapter(nAdapter);
                    nAdapter.notifyDataSetChanged();


                } catch (Exception e) {

                    e.printStackTrace();
                }


            }

            @Override
            public void onFailure(Call<Example> call, Throwable t) {
                progressDoalog.dismiss();

            }
        });


    }
}
