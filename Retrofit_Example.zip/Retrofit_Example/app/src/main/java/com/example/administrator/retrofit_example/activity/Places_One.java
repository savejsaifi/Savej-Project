package com.example.administrator.retrofit_example.activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.adapter.Place_adapter_Table1_Model;
import com.example.administrator.retrofit_example.adapter.Place_adapter_Table2_Model;
import com.example.administrator.retrofit_example.adapter.Place_adapter_table_model;
import com.example.administrator.retrofit_example.model.Example_Model;
import com.example.administrator.retrofit_example.model.Table1_Model;
import com.example.administrator.retrofit_example.model.Table2_Model;
import com.example.administrator.retrofit_example.model.Table_Model;
import com.example.administrator.retrofit_example.service.Api;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Places_One extends AppCompatActivity {

    ArrayList<Table2_Model> defulterLists_two;
    Place_adapter_Table2_Model place_adapter_table2_model;
    RecyclerView rview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places__one);
        rview = findViewById(R.id.rview);

        placeList_One();
    }

    public void placeList_One() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_DEFULTER_LIST)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();
        Api api = retrofit.create(Api.class);
        final Call<Example_Model> nlist = api.placeList();
        final ProgressDialog progressDoalog;
        progressDoalog = new ProgressDialog(Places_One.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.show();
        nlist.enqueue(new Callback<Example_Model>() {
            @Override
            public void onResponse(Call<Example_Model> call, Response<Example_Model> response) {
                progressDoalog.dismiss();
                try {

                    defulterLists_two   = (ArrayList<Table2_Model>) response.body().getTable2();
                    place_adapter_table2_model = new Place_adapter_Table2_Model(Places_One.this, defulterLists_two);
                    LinearLayoutManager layoutManager_two = new LinearLayoutManager(getApplicationContext());
                    layoutManager_two.setOrientation(LinearLayoutManager.VERTICAL);
                    rview.setLayoutManager(layoutManager_two);
                    rview.setAdapter(place_adapter_table2_model);

                    } catch (Exception e) {

                    e.printStackTrace();
                }
                
            }

            @Override
            public void onFailure(Call<Example_Model> call, Throwable t) {
                progressDoalog.dismiss();

            }
        });

    }
}
