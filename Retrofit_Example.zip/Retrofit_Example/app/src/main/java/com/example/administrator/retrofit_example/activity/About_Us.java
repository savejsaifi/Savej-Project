package com.example.administrator.retrofit_example.activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.adapter.About_us_adapter;
import com.example.administrator.retrofit_example.adapter.NewsAdapter;
import com.example.administrator.retrofit_example.model.AboutUs_Model;
import com.example.administrator.retrofit_example.model.About_usTable;
import com.example.administrator.retrofit_example.model.Example;
import com.example.administrator.retrofit_example.model.Table;
import com.example.administrator.retrofit_example.service.Api;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class About_Us extends AppCompatActivity {

    ArrayList<About_usTable> aList;
    About_us_adapter adapter;
    RecyclerView rView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about__us);

        rView = findViewById(R.id.mRecyler);
        aList = new ArrayList<>();
        adapter = new About_us_adapter(getApplicationContext(), aList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        rView.setLayoutManager(layoutManager);
        rView.setAdapter(adapter);
        aboutList();
    }

    public void aboutList() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_DEFULTER_LIST)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();
        Api api = retrofit.create(Api.class);
        final Call<AboutUs_Model> nlist = api.aboutUsList();
        final ProgressDialog progressDoalog;
        progressDoalog = new ProgressDialog(About_Us.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.show();
        nlist.enqueue(new Callback<AboutUs_Model>() {
            @Override
            public void onResponse(Call<AboutUs_Model> call, Response<AboutUs_Model> response) {
                progressDoalog.dismiss();
                try {
                    ArrayList<About_usTable> defulterLists = (ArrayList<About_usTable>) response.body().getTable();

                    About_us_adapter nAdapter = new About_us_adapter(About_Us.this, defulterLists);
                    rView.setAdapter(nAdapter);
                    nAdapter.notifyDataSetChanged();


                } catch (Exception e) {

                    e.printStackTrace();
                }


            }

            @Override
            public void onFailure(Call<AboutUs_Model> call, Throwable t) {
                progressDoalog.dismiss();

            }
        });


    }
}
