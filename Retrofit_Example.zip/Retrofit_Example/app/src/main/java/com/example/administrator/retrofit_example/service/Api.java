package com.example.administrator.retrofit_example.service;

import com.example.administrator.retrofit_example.model.AboutUs_Model;
import com.example.administrator.retrofit_example.model.DefulterList_Table;
import com.example.administrator.retrofit_example.model.Example;
import com.example.administrator.retrofit_example.model.Example_Model;

import retrofit2.Call;
import retrofit2.http.GET;

public interface Api {

    String BASE_DEFULTER_LIST="http://idawebsite.azurewebsites.net/api/";

    @GET("CtrlDefaultersList/GetDefaulterList")
    Call<DefulterList_Table> getDefaulterList();

    @GET("FrmAdmMstNews/GetNews")
    Call<Example> newsList();

    @GET("FrmAdmAboutUs/GetDatasetAboutUs?Ind=1")
    Call<AboutUs_Model> aboutUsList();

    @GET("FrmAdmMstHeritage/GetDsHeritageAllPhoto")
    Call<Example_Model> placeList();
}
