package com.example.administrator.retrofit_example.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.activity.News;
import com.example.administrator.retrofit_example.model.About_usTable;
import com.example.administrator.retrofit_example.model.DefulterList;
import com.example.administrator.retrofit_example.model.Table;

import java.util.ArrayList;

public class About_us_adapter extends RecyclerView.Adapter<About_us_adapter.UserViewHolder>{

    ArrayList<About_usTable> about_us;
    Context nContext;

    public About_us_adapter(Context nContext, ArrayList<About_usTable> about_us) {
        this.about_us = about_us;
        this.nContext = nContext;
    }

    @Override
    public About_us_adapter.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(nContext).inflate(R.layout.item_news_layout, parent, false);
        return new About_us_adapter.UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(About_us_adapter.UserViewHolder holder, final int position) {


        final About_usTable singleUser = about_us.get(position);
        holder.txtUser.setText(singleUser.getAboutUsDescE());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nContext, News.class);
                nContext.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return about_us.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView txtUser;

        public UserViewHolder(View itemView) {
            super(itemView);
            txtUser = itemView.findViewById(R.id.txtUser);


        }
    }

}
