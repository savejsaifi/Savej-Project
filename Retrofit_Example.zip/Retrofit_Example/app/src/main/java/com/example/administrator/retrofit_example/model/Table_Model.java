package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table_Model {
    @SerializedName("HeritId")
    @Expose
    private Integer heritId;
    @SerializedName("HeritTitleE")
    @Expose
    private String heritTitleE;
    @SerializedName("HeritTitleH")
    @Expose
    private String heritTitleH;

    public Integer getHeritId() {
        return heritId;
    }

    public void setHeritId(Integer heritId) {
        this.heritId = heritId;
    }

    public String getHeritTitleE() {
        return heritTitleE;
    }

    public void setHeritTitleE(String heritTitleE) {
        this.heritTitleE = heritTitleE;
    }

    public String getHeritTitleH() {
        return heritTitleH;
    }

    public void setHeritTitleH(String heritTitleH) {
        this.heritTitleH = heritTitleH;
    }
}
