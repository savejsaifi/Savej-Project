package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table {

    @SerializedName("SerNo")
    @Expose
    private Integer serNo;
    @SerializedName("NewsCode")
    @Expose
    private Integer newsCode;
    @SerializedName("OrgCode")
    @Expose
    private Integer orgCode;
    @SerializedName("CityCode")
    @Expose
    private Integer cityCode;
    @SerializedName("NewsDate")
    @Expose
    private String newsDate;
    @SerializedName("NewsCity")
    @Expose
    private String newsCity;
    @SerializedName("NewsSource")
    @Expose
    private String newsSource;
    @SerializedName("NewsTitleE")
    @Expose
    private String newsTitleE;
    @SerializedName("NewsTitleH")
    @Expose
    private String newsTitleH;
    @SerializedName("NewsDescE")
    @Expose
    private String newsDescE;
    @SerializedName("NewsDescH")
    @Expose
    private String newsDescH;
    @SerializedName("PdfDocPathView")
    @Expose
    private String pdfDocPathView;
    @SerializedName("PdfDocName")
    @Expose
    private String pdfDocName;
    @SerializedName("ImgDocPathView")
    @Expose
    private String imgDocPathView;
    @SerializedName("ImgDocName")
    @Expose
    private String imgDocName;
    @SerializedName("NewsDocPath_Mobile")
    @Expose
    private String newsDocPathMobile;
    @SerializedName("NewsImgPath_Mobile")
    @Expose
    private String newsImgPathMobile;

    public Integer getSerNo() {
        return serNo;
    }

    public void setSerNo(Integer serNo) {
        this.serNo = serNo;
    }

    public Integer getNewsCode() {
        return newsCode;
    }

    public void setNewsCode(Integer newsCode) {
        this.newsCode = newsCode;
    }

    public Integer getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(Integer orgCode) {
        this.orgCode = orgCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public String getNewsDate() {
        return newsDate;
    }

    public void setNewsDate(String newsDate) {
        this.newsDate = newsDate;
    }

    public String getNewsCity() {
        return newsCity;
    }

    public void setNewsCity(String newsCity) {
        this.newsCity = newsCity;
    }

    public String getNewsSource() {
        return newsSource;
    }

    public void setNewsSource(String newsSource) {
        this.newsSource = newsSource;
    }

    public String getNewsTitleE() {
        return newsTitleE;
    }

    public void setNewsTitleE(String newsTitleE) {
        this.newsTitleE = newsTitleE;
    }

    public String getNewsTitleH() {
        return newsTitleH;
    }

    public void setNewsTitleH(String newsTitleH) {
        this.newsTitleH = newsTitleH;
    }

    public String getNewsDescE() {
        return newsDescE;
    }

    public void setNewsDescE(String newsDescE) {
        this.newsDescE = newsDescE;
    }

    public String getNewsDescH() {
        return newsDescH;
    }

    public void setNewsDescH(String newsDescH) {
        this.newsDescH = newsDescH;
    }

    public String getPdfDocPathView() {
        return pdfDocPathView;
    }

    public void setPdfDocPathView(String pdfDocPathView) {
        this.pdfDocPathView = pdfDocPathView;
    }

    public String getPdfDocName() {
        return pdfDocName;
    }

    public void setPdfDocName(String pdfDocName) {
        this.pdfDocName = pdfDocName;
    }

    public String getImgDocPathView() {
        return imgDocPathView;
    }

    public void setImgDocPathView(String imgDocPathView) {
        this.imgDocPathView = imgDocPathView;
    }

    public String getImgDocName() {
        return imgDocName;
    }

    public void setImgDocName(String imgDocName) {
        this.imgDocName = imgDocName;
    }

    public String getNewsDocPathMobile() {
        return newsDocPathMobile;
    }

    public void setNewsDocPathMobile(String newsDocPathMobile) {
        this.newsDocPathMobile = newsDocPathMobile;
    }

    public String getNewsImgPathMobile() {
        return newsImgPathMobile;
    }

    public void setNewsImgPathMobile(String newsImgPathMobile) {
        this.newsImgPathMobile = newsImgPathMobile;
    }
}
