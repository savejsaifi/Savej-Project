package com.example.administrator.retrofit_example.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.activity.News;
import com.example.administrator.retrofit_example.activity.Places_One;
import com.example.administrator.retrofit_example.model.Table1_Model;
import com.example.administrator.retrofit_example.model.Table2_Model;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Place_adapter_Table2_Model extends RecyclerView.Adapter<Place_adapter_Table2_Model.UserViewHolder>{

    ArrayList<Table2_Model> about_place;
    Context pContext;

    public Place_adapter_Table2_Model(Context pContext, ArrayList<Table2_Model> about_place) {
        this.about_place = about_place;
        this.pContext = pContext;
    }

    @Override
    public Place_adapter_Table2_Model.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(pContext).inflate(R.layout.item_place_image, parent, false);
        return new Place_adapter_Table2_Model.UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(Place_adapter_Table2_Model.UserViewHolder holder, final int position) {


        final Table2_Model singleUser = about_place.get(position);
        Glide.with(pContext).load(singleUser.getCoverPhotoPathMobile()).into(holder.img);

        Log.e("Image",singleUser.getCoverPhotoPathMobile());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pContext, Places_One.class);
                pContext.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return about_place.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

       ImageView img;

        public UserViewHolder(View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img);


        }
    }
}

