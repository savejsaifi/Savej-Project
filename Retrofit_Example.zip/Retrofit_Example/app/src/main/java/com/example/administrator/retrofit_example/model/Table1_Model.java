package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table1_Model {

    @SerializedName("HeritPhotoId")
    @Expose
    private Integer heritPhotoId;
    @SerializedName("HeritId")
    @Expose
    private Integer heritId;
    @SerializedName("HeritPhotoDescE")
    @Expose
    private String heritPhotoDescE;
    @SerializedName("HeritPhotoDescH")
    @Expose
    private String heritPhotoDescH;
    @SerializedName("HeritPhotoPath")
    @Expose
    private String heritPhotoPath;

    public Integer getHeritPhotoId() {
        return heritPhotoId;
    }

    public void setHeritPhotoId(Integer heritPhotoId) {
        this.heritPhotoId = heritPhotoId;
    }

    public Integer getHeritId() {
        return heritId;
    }

    public void setHeritId(Integer heritId) {
        this.heritId = heritId;
    }

    public String getHeritPhotoDescE() {
        return heritPhotoDescE;
    }

    public void setHeritPhotoDescE(String heritPhotoDescE) {
        this.heritPhotoDescE = heritPhotoDescE;
    }

    public String getHeritPhotoDescH() {
        return heritPhotoDescH;
    }

    public void setHeritPhotoDescH(String heritPhotoDescH) {
        this.heritPhotoDescH = heritPhotoDescH;
    }

    public String getHeritPhotoPath() {
        return heritPhotoPath;
    }

    public void setHeritPhotoPath(String heritPhotoPath) {
        this.heritPhotoPath = heritPhotoPath;
    }

}
