package com.example.administrator.retrofit_example.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.activity.News;
import com.example.administrator.retrofit_example.model.Table1_Model;
import com.example.administrator.retrofit_example.model.Table_Model;

import java.util.ArrayList;

public class Place_adapter_table_model extends RecyclerView.Adapter<Place_adapter_table_model.UserViewHolder>{

    ArrayList<Table_Model> about_place;
    Context pContext;

    public Place_adapter_table_model(Context pContext, ArrayList<Table_Model> about_place) {
        this.about_place = about_place;
        this.pContext = pContext;
    }

    @Override
    public Place_adapter_table_model.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(pContext).inflate(R.layout.item_place_layout, parent, false);
        return new Place_adapter_table_model.UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(Place_adapter_table_model.UserViewHolder holder, final int position) {


        final Table_Model singleUser = about_place.get(position);
        holder.txtUser.setText(singleUser.getHeritTitleE());
        holder.txtUser2.setText(singleUser.getHeritTitleH());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pContext, News.class);
                pContext.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return about_place.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView txtUser, txtUser2;

        public UserViewHolder(View itemView) {
            super(itemView);
            txtUser = itemView.findViewById(R.id.txtUser);
            txtUser2 = itemView.findViewById(R.id.txtUser2);



        }
    }}

