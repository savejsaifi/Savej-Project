package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table2_Model {

    @SerializedName("HeritId")
    @Expose
    private Integer heritId;
    @SerializedName("HeritTitleE")
    @Expose
    private String heritTitleE;
    @SerializedName("HeritTitleH")
    @Expose
    private String heritTitleH;
    @SerializedName("HeritDescE")
    @Expose
    private String heritDescE;
    @SerializedName("HeritDescH")
    @Expose
    private String heritDescH;
    @SerializedName("CoverPhotoPath")
    @Expose
    private String coverPhotoPath;
    @SerializedName("CoverPhotoPathMobile")
    @Expose
    private String coverPhotoPathMobile;

    public Integer getHeritId() {
        return heritId;
    }

    public void setHeritId(Integer heritId) {
        this.heritId = heritId;
    }

    public String getHeritTitleE() {
        return heritTitleE;
    }

    public void setHeritTitleE(String heritTitleE) {
        this.heritTitleE = heritTitleE;
    }

    public String getHeritTitleH() {
        return heritTitleH;
    }

    public void setHeritTitleH(String heritTitleH) {
        this.heritTitleH = heritTitleH;
    }

    public String getHeritDescE() {
        return heritDescE;
    }

    public void setHeritDescE(String heritDescE) {
        this.heritDescE = heritDescE;
    }

    public String getHeritDescH() {
        return heritDescH;
    }

    public void setHeritDescH(String heritDescH) {
        this.heritDescH = heritDescH;
    }

    public String getCoverPhotoPath() {
        return coverPhotoPath;
    }

    public void setCoverPhotoPath(String coverPhotoPath) {
        this.coverPhotoPath = coverPhotoPath;
    }

    public String getCoverPhotoPathMobile() {
        return coverPhotoPathMobile;
    }

    public void setCoverPhotoPathMobile(String coverPhotoPathMobile) {
        this.coverPhotoPathMobile = coverPhotoPathMobile;
    }
}
