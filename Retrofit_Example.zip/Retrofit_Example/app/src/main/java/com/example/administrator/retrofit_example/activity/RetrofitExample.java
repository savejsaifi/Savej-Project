package com.example.administrator.retrofit_example.activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.adapter.Rteofit_Adapter;
import com.example.administrator.retrofit_example.model.DefulterList;
import com.example.administrator.retrofit_example.model.DefulterList_Table;
import com.example.administrator.retrofit_example.service.Api;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitExample extends AppCompatActivity {
    ArrayList<DefulterList> mList;
    Rteofit_Adapter madapter;
    RecyclerView mRecylerview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_retrofit_example);
        mRecylerview = findViewById(R.id.mRecyler);
        mList = new ArrayList<>();
        madapter = new Rteofit_Adapter(getApplicationContext(), mList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRecylerview.setLayoutManager(layoutManager);
        mRecylerview.setAdapter(madapter);
        getDefaulterList();
    }

    public void getDefaulterList() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_DEFULTER_LIST)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();
        Api api = retrofit.create(Api.class);
        final Call<DefulterList_Table> defaulterList = api.getDefaulterList();
        final ProgressDialog progressDoalog;
        progressDoalog = new ProgressDialog(RetrofitExample.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.show();
        defaulterList.enqueue(new Callback<DefulterList_Table>() {
            @Override
            public void onResponse(Call<DefulterList_Table> call, Response<DefulterList_Table> response) {
                progressDoalog.dismiss();
                try {
                    ArrayList<DefulterList> defulterLists = (ArrayList<DefulterList>) response.body().getData();

                    Rteofit_Adapter adapter_defaulterList = new Rteofit_Adapter(RetrofitExample.this, defulterLists);
                    mRecylerview.setAdapter(adapter_defaulterList);
                    adapter_defaulterList.notifyDataSetChanged();

                    } catch (Exception e) {

                    e.printStackTrace();
                }
                
            }

            @Override
            public void onFailure(Call<DefulterList_Table> call, Throwable t) {
                progressDoalog.dismiss();

            }
        });


    }
}