package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class DefulterList {
    @SerializedName("Reference_No")
    @Expose
    private String referenceNo;
    @SerializedName("Name")
    @Expose
    private String name;
    @SerializedName("Total_Due")
    @Expose
    private String totalDue;

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTotalDue() {
        return totalDue;
    }

    public void setTotalDue(String totalDue) {
        this.totalDue = totalDue;
    }



}
