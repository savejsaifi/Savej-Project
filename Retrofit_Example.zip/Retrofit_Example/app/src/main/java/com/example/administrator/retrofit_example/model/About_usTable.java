package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class About_usTable {

    @SerializedName("AboutUsCode")
    @Expose
    private Integer aboutUsCode;
    @SerializedName("IsActive")
    @Expose
    private Integer isActive;
    @SerializedName("AboutUsDescE")
    @Expose
    private String aboutUsDescE;
    @SerializedName("AboutUsDescH")
    @Expose
    private String aboutUsDescH;
    @SerializedName("OrgCode")
    @Expose
    private Integer orgCode;
    @SerializedName("CityCode")
    @Expose
    private Integer cityCode;
    @SerializedName("PragraphNo")
    @Expose
    private Integer pragraphNo;

    public Integer getAboutUsCode() {
        return aboutUsCode;
    }

    public void setAboutUsCode(Integer aboutUsCode) {
        this.aboutUsCode = aboutUsCode;
    }

    public Integer getIsActive() {
        return isActive;
    }

    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    public String getAboutUsDescE() {
        return aboutUsDescE;
    }

    public void setAboutUsDescE(String aboutUsDescE) {
        this.aboutUsDescE = aboutUsDescE;
    }

    public String getAboutUsDescH() {
        return aboutUsDescH;
    }

    public void setAboutUsDescH(String aboutUsDescH) {
        this.aboutUsDescH = aboutUsDescH;
    }

    public Integer getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(Integer orgCode) {
        this.orgCode = orgCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public Integer getPragraphNo() {
        return pragraphNo;
    }

    public void setPragraphNo(Integer pragraphNo) {
        this.pragraphNo = pragraphNo;
    }

}
