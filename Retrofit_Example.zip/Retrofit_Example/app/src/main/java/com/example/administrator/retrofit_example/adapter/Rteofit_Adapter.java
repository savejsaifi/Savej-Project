package com.example.administrator.retrofit_example.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.activity.News;
import com.example.administrator.retrofit_example.model.DefulterList;


import java.util.ArrayList;

public class Rteofit_Adapter extends RecyclerView.Adapter<Rteofit_Adapter.UserViewHolder> {
    ArrayList<DefulterList> list_ada;
    Context mContext;

    public Rteofit_Adapter(Context mContext, ArrayList<DefulterList> list_ada) {
        this.list_ada = list_ada;
        this.mContext = mContext;
    }

    @Override
    public UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(mContext).inflate(R.layout.item_user_layout, parent, false);
        return new UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(UserViewHolder holder, final int position) {


        final DefulterList singleUser = list_ada.get(position);
        holder.txtUser.setText(singleUser.getName());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, News.class);
                mContext.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return list_ada.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView txtUser;


        DefulterList _obj;

        public UserViewHolder(View itemView) {
            super(itemView);
            txtUser = itemView.findViewById(R.id.txtUser);


        }
    }

}