package com.example.administrator.retrofit_example.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AboutUs_Model {

    @SerializedName("Table")
    @Expose
    private List<About_usTable> table = null;

    public List<About_usTable> getTable() {
        return table;
    }

    public void setTable(List<About_usTable> table) {
        this.table = table;
    }
}
