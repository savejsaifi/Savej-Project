package com.example.administrator.retrofit_example.activity;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.adapter.Place_adapter_Table1_Model;
import com.example.administrator.retrofit_example.adapter.Place_adapter_Table2_Model;
import com.example.administrator.retrofit_example.adapter.Place_adapter_table_model;
import com.example.administrator.retrofit_example.model.Example_Model;
import com.example.administrator.retrofit_example.model.Table1_Model;
import com.example.administrator.retrofit_example.model.Table2_Model;
import com.example.administrator.retrofit_example.model.Table_Model;
import com.example.administrator.retrofit_example.service.Api;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Places extends AppCompatActivity {

    // ArrayList for table1
    ArrayList<Table1_Model> defulterLists;
    ArrayList<Table_Model> defulterLists_one;

    Place_adapter_Table1_Model place_adapter_table1_model;
    Place_adapter_table_model place_adapter_table_model;

    RecyclerView recycl_place1;
    RecyclerView recycl_place2;
    // ArrayList for table

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places);
        defulterLists=new ArrayList<>();
        recycl_place1 = findViewById(R.id.recycl_place1);
        recycl_place2 = findViewById(R.id.recycl_place2);

        placeList();
    }

    // Retrofit object for table1
    public void placeList() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_DEFULTER_LIST)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();
        Api api = retrofit.create(Api.class);
        final Call<Example_Model> nlist = api.placeList();
        final ProgressDialog progressDoalog;
        progressDoalog = new ProgressDialog(Places.this);
        progressDoalog.setMessage("Please Wait....");
        progressDoalog.show();
        nlist.enqueue(new Callback<Example_Model>() {
            @Override
            public void onResponse(Call<Example_Model> call, Response<Example_Model> response) {
                progressDoalog.dismiss();
                try {
                    defulterLists   = (ArrayList<Table1_Model>) response.body().getTable1();
                    defulterLists_one   = (ArrayList<Table_Model>) response.body().getTable();


                     place_adapter_table1_model = new Place_adapter_Table1_Model(Places.this, defulterLists);
                    LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    recycl_place1.setLayoutManager(layoutManager);
                    recycl_place1.setAdapter(place_adapter_table1_model);

                    //  recyclerview2
                    place_adapter_table_model = new Place_adapter_table_model(Places.this, defulterLists_one);
                    LinearLayoutManager layoutManager_one = new LinearLayoutManager(getApplicationContext());
                    layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                    recycl_place2.setLayoutManager(layoutManager_one);
                    recycl_place2.setAdapter(place_adapter_table_model);

                    // recyclerview3

                } catch (Exception e) {

                    e.printStackTrace();
                }
                }

            @Override
            public void onFailure(Call<Example_Model> call, Throwable t) {
                progressDoalog.dismiss();

            }
        });

    }
}
