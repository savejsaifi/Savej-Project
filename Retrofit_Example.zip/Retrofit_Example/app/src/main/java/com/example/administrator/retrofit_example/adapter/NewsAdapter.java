package com.example.administrator.retrofit_example.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.administrator.retrofit_example.R;
import com.example.administrator.retrofit_example.activity.About_Us;
import com.example.administrator.retrofit_example.activity.News;
import com.example.administrator.retrofit_example.activity.Places;
import com.example.administrator.retrofit_example.model.DefulterList;
import com.example.administrator.retrofit_example.model.Table;

import java.util.ArrayList;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.UserViewHolder>{

    ArrayList<Table> list_news;
    Context nContext;

    public NewsAdapter(Context nContext, ArrayList<Table> list_news) {
        this.list_news = list_news;
        this.nContext = nContext;
    }

    @Override
    public NewsAdapter.UserViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(nContext).inflate(R.layout.item_news_layout, parent, false);
        return new NewsAdapter.UserViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(NewsAdapter.UserViewHolder holder, final int position) {


        final Table singleUser = list_news.get(position);
        holder.txtUser.setText(singleUser.getNewsDescE());
        holder.txtUser2.setText(singleUser.getNewsDescH());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(nContext, Places.class);
                nContext.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return list_news.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        TextView txtUser,txtUser2;


        public UserViewHolder(View itemView) {
            super(itemView);
            txtUser = itemView.findViewById(R.id.txtUser);
            txtUser2 = itemView.findViewById(R.id.txtUser2);


        }
    }

}
