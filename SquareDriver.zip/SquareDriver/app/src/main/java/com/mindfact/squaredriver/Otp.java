package com.mindfact.squaredriver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mindfact.squaredriver.model.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Otp extends AppCompatActivity implements TextWatcher {

    EditText editTextone,editTexttwo,editTestthree,editTextfour;
    String url_otp = "http://driver.mindshiksha.com/api/reqOTP";
    // String edit1,edit2,edit3,edit4;
    Button verify;
    TextView resendOtp;
    String merge_otp;
    //static String phone_otp = "9898989898";
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otp);
        editTextone = findViewById(R.id.editTextOne);
        editTexttwo = findViewById(R.id.editTexttwo);
        editTestthree = findViewById(R.id.editTextthree);
        editTextfour = findViewById(R.id.editTextfour);
        resendOtp = findViewById(R.id.resendOtp);


        // receiving from mobile no. from preveious activity
        username=getIntent().getStringExtra("username");


        editTextone.requestFocus();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        verify = findViewById(R.id.verify);

        verifyOtp();

        editTextone.addTextChangedListener(this);
        editTexttwo.addTextChangedListener(this);
        editTestthree.addTextChangedListener(this);
        editTextfour.addTextChangedListener(this);


    }  // on create method


    public void verifyOtp() {

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String edit1 = editTextone.getText().toString().trim();
                String  edit2 = editTexttwo.getText().toString().trim();
                String edit3 = editTestthree.getText().toString().trim();
                String  edit4 = editTextfour.getText().toString().trim();

                merge_otp = edit1.concat(edit2).concat(edit3).concat(edit4);

                if (edit1.isEmpty() && edit2.isEmpty() && edit3.isEmpty() && edit4.isEmpty()) {
                    Toast.makeText(Otp.this,"Please enter the Otp",Toast.LENGTH_SHORT);
                }

                RequestQueue queue = Volley.newRequestQueue(Otp.this);
                StringRequest request = new StringRequest(Request.Method.POST, url_otp, new com.android.volley.Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonResponse = new JSONObject(response);

                           //   Toast.makeText(Otp.this,response,Toast.LENGTH_SHORT).show();
                            if ((boolean) jsonResponse.get("success")) {

                                Toast.makeText(Otp.this, "Registration Successfully", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Otp.this,Login.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);

                            } else {

                                Toast.makeText(Otp.this, " Enter the correct Otp", Toast.LENGTH_SHORT).show();
                            }
                        }
                        catch (JSONException e){
                            e.printStackTrace();
                        }


                    }
                }, new com.android.volley.Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(Otp.this, "my error :"+error, Toast.LENGTH_LONG).show();
                        Log.i("My error",""+error);
                    }
                }){

                    protected Map<String, String> getParams() throws AuthFailureError {

                        Map<String,String> map = new HashMap<String, String>();
                        map.put(Config.mobile_no,username);
                        map.put(Config.req_otp,merge_otp);

                        return map;
                    }
                };

                queue.add(request);

            }
        });
    }


    // for request focus
    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        if(editable.length()==1){

            if(editTextone.length()==1){
                editTexttwo.requestFocus();
            }
            if(editTexttwo.length()==1){
                editTestthree.requestFocus();
            }
            if(editTestthree.length()==1){
                editTextfour.requestFocus();
            }

        }

        else if(editable.length()==0){
            if(editTextfour.length()==0){
                editTestthree.requestFocus();
            }
            if(editTestthree.length()==0){
                editTexttwo.requestFocus();
            }
            if(editTexttwo.length()==0){
                editTextone.requestFocus();
            }
        }

    }

}
