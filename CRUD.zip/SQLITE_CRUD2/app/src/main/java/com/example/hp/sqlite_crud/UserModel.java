package com.example.hp.sqlite_crud;

import java.io.Serializable;

/**
 * Created by hp on 5/30/2019.
 */

public class UserModel implements Serializable {

    private String name, hobby;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHobby() {
        return hobby;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }
}