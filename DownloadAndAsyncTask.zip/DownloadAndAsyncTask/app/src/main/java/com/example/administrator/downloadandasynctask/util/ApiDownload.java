package com.example.administrator.downloadandasynctask.util;

import com.example.administrator.downloadandasynctask.model.TelephoneDirecoty;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiDownload {

    String BASE_TELEPHONE_DIRECTORY = "http://idawebsite.azurewebsites.net/api/FrmAdmMstTeleDirectory/";

    @GET("MstTeleDirectory")
    Call<TelephoneDirecoty> getTelephoneDirectory();

}
