package com.example.administrator.downloadandasynctask.activity;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.administrator.downloadandasynctask.R;
import com.example.administrator.downloadandasynctask.model.TelephoneDirecoty;
import com.example.administrator.downloadandasynctask.model.TelephoneDirecoty_Table;
import com.example.administrator.downloadandasynctask.util.ApiDownload;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DownloadBYManager extends AppCompatActivity {

    Button download;
    DownloadManager downloadManager;
    String pdf_file;
    String fileName;
    ArrayList<String> pdf_name_list = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download_bymanager);
        download =findViewById(R.id.download);
        download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getTelephoneDirectory();
            }
        });
    }

    void getTelephoneDirectory() {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ApiDownload.BASE_TELEPHONE_DIRECTORY)
                .addConverterFactory(GsonConverterFactory.create()).build();

        ApiDownload api = retrofit.create(ApiDownload.class);
        final Call<TelephoneDirecoty> niyamCall = api.getTelephoneDirectory();
        niyamCall.enqueue(new Callback<TelephoneDirecoty>() {
            @Override
            public void onResponse(Call<TelephoneDirecoty> call, Response<TelephoneDirecoty> response) {
                List<TelephoneDirecoty_Table> telephoneTable = (List<TelephoneDirecoty_Table>) response.body().getTable();
                for (int n = 0; n < telephoneTable.size(); n++) {
                    pdf_file = telephoneTable.get(n).getPhotoViewPathInMobile();
                    fileName = pdf_file.substring(pdf_file.lastIndexOf('/') + 1);
                    System.out.println("vyyam niyam" + pdf_file);// pdf_name_list.add(pdf_file);
                    pdf_name_list.add(fileName);
                }

                try {
                    //  Utilities.downloadPDF(getActivity(), pdf_file, fileName);
                    DownloadData(Uri.parse(pdf_file), fileName);
                } catch (NullPointerException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<TelephoneDirecoty> call, Throwable t) {
                System.out.println(">>>>>>>>>>>>>>>>>>exeception" + t.getMessage());
                //Toast.makeText(getActivity(), "" + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            //check if the broadcast message is for our enqueued download
            //  startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
            IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            registerReceiver(downloadReceiver, filter);

        }
    };

    private long DownloadData(Uri uri, String filename) {

        long downloadReference;
        // Create request for android download manager
        downloadManager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        DownloadManager.Request request = new DownloadManager.Request(uri);
        Log.e("URI", String.valueOf(uri));
        //Setting title of request
        request.setTitle(filename);
        request.setShowRunningNotification(true);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        //Set the local destination for the downloaded file to a path
        //within the application's external files directory

        request.setDestinationInExternalFilesDir(getApplicationContext(),
                Environment.DIRECTORY_DOWNLOADS, filename);

        //Enqueue download and save into referenceId
        downloadReference = downloadManager.enqueue(request);

        return downloadReference;
    }

}
