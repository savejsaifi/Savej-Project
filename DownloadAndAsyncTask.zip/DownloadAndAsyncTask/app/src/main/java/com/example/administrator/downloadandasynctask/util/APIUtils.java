package com.example.administrator.downloadandasynctask.util;

public class APIUtils {

public  static final String URL_GET = "http://103.21.54.53/IdaWebApi/api/MstBoardMem/getBoardMemDtlNew?Ind=1";
}
