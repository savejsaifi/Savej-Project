package com.example.administrator.downloadandasynctask.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Created by Administrator on 11-04-2018.
 */

public class TelephoneDirecoty_Table {

    @SerializedName("TeleDirCode")
    @Expose
    private Integer teleDirCode;
    @SerializedName("TeleDirHead")
    @Expose
    private String teleDirHead;
    @SerializedName("TeleDirHeadH")
    @Expose
    private String teleDirHeadH;
    @SerializedName("TeleDirName")
    @Expose
    private String teleDirName;
    @SerializedName("TeleDirPath")
    @Expose
    private String teleDirPath;
    @SerializedName("OrgCode")
    @Expose
    private Integer orgCode;
    @SerializedName("CityCode")
    @Expose
    private Integer cityCode;
    @SerializedName("PhotoViewPath")
    @Expose
    private String photoViewPath;
    @SerializedName("PhotoViewPathInMobile")
    @Expose
    private String photoViewPathInMobile;

    public Integer getTeleDirCode() {
        return teleDirCode;
    }

    public void setTeleDirCode(Integer teleDirCode) {
        this.teleDirCode = teleDirCode;
    }

    public String getTeleDirHead() {
        return teleDirHead;
    }

    public void setTeleDirHead(String teleDirHead) {
        this.teleDirHead = teleDirHead;
    }

    public String getTeleDirHeadH() {
        return teleDirHeadH;
    }

    public void setTeleDirHeadH(String teleDirHeadH) {
        this.teleDirHeadH = teleDirHeadH;
    }

    public String getTeleDirName() {
        return teleDirName;
    }

    public void setTeleDirName(String teleDirName) {
        this.teleDirName = teleDirName;
    }

    public String getTeleDirPath() {
        return teleDirPath;
    }

    public void setTeleDirPath(String teleDirPath) {
        this.teleDirPath = teleDirPath;
    }

    public Integer getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(Integer orgCode) {
        this.orgCode = orgCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public String getPhotoViewPath() {
        return photoViewPath;
    }

    public void setPhotoViewPath(String photoViewPath) {
        this.photoViewPath = photoViewPath;
    }

    public String getPhotoViewPathInMobile() {
        return photoViewPathInMobile;
    }

    public void setPhotoViewPathInMobile(String photoViewPathInMobile) {
        this.photoViewPathInMobile = photoViewPathInMobile;
    }
}
