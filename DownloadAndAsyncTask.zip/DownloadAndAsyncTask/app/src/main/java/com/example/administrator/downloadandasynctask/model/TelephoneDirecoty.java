package com.example.administrator.downloadandasynctask.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Administrator on 11-04-2018.
 */

public class TelephoneDirecoty {

    @SerializedName("Table")
    @Expose
    private List<TelephoneDirecoty_Table> table = null;

    public List<TelephoneDirecoty_Table> getTable() {
        return table;
    }

    public void setTable(List<TelephoneDirecoty_Table> table) {
        this.table = table;
    }

}
