package com.example.CondidateActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Emp_Activity.EmpMainActivity;
import com.example.Emp_Activity.MainNavigaton;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class OtpActivity extends AppCompatActivity {

    PinEntryEditText otpEDT;
    Button submitBTN;
    SessonManager sessonManager;
    private String mobile_number;
    private TextView numberTV;
    public String forget_value,emp_value;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_file);

        sessonManager = new SessonManager(OtpActivity.this);

        otpEDT = findViewById(R.id.pin_otp);
        submitBTN = findViewById(R.id.btnOtpSubmit);
        numberTV = findViewById(R.id.tv_mobile);

        mobile_number = getIntent().getStringExtra("mobile");

        numberTV.setText("+91 " + "We have sent you a SMS on " + mobile_number);

        SharedPreferences sharedPreferences=getSharedPreferences("share_mobile",MODE_PRIVATE);
        sharedPreferences.edit().putString("mobile",mobile_number).commit();

        SharedPreferences sharedPreferences1=getSharedPreferences("shared",MODE_PRIVATE);
        emp_value=sharedPreferences1.getString("employer","");

        //forget_value=sharedPreferences.getString("value","");
         forget_value = getIntent().getStringExtra("value");
        Log.d("checkmobile",mobile_number+" "+emp_value+" "+forget_value);

        submitBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (otpEDT.getText().toString().equals("")) {
                    Toast.makeText(OtpActivity.this, "Please enter valid OTP", Toast.LENGTH_SHORT).show();
                }

                else {

                    hitUrlForOtp();
                }


            }
        });
        hitUrlForOtp();

    }

    private void hitUrlForOtp() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.OTP_VERIFY, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("chekclohin", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    String message = jsonObject.getString("message");
                    String token = jsonObject.getString("token");
                    sessonManager.setToken(token);

                        Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();
                        if (emp_value.equals("emp")&&(forget_value==null)){
                            sessonManager.setSessonCanEmp("employee");


                            Intent intent = new Intent(OtpActivity.this, MainNavigaton.class).
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);

                        }
                        else if(emp_value.equals("candidate")&&(forget_value==null)){
                            sessonManager.setSessonCanEmp("candidate");

                            Intent intent = new Intent(OtpActivity.this, HomeActivity.class).
                                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        }

                        else {
                            if (forget_value.equals("1")) {
                                Intent intent = new Intent(OtpActivity.this, AccountActivity.class);
                                startActivity(intent);

                            } else {
                                Intent intent = new Intent(OtpActivity.this, HomeActivity.class);
                                intent.putExtra("mobile", mobile_number);
                                startActivity(intent);
                            }
                        }



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                if (forget_value==null) {
                    hashMap.put("mobile", mobile_number);
                    hashMap.put("otp", otpEDT.getText().toString());
                }
//                else if(emp_value.equals("candidate")&&(!forget_value.equals("1"))){
//                    hashMap.put("mobile", mobile_number);
//                    hashMap.put("otp", otpEDT.getText().toString());
//                }
                else {


                    if (forget_value.equals("1")) {
                        Log.d("adflsklf", forget_value);
                        hashMap.put("mobile", mobile_number);
                        hashMap.put("otp", otpEDT.getText().toString());
                        hashMap.put("type", "reset");
                    } else {
                        hashMap.put("mobile", mobile_number);
                        hashMap.put("otp", otpEDT.getText().toString());
                    }
                }

                    Log.d("checkparams", hashMap.toString());
                    return hashMap;
                }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

}
