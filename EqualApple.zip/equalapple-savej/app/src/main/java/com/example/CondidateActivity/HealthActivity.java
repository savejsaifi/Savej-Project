package com.example.CondidateActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HealthActivity extends AppCompatActivity {

    Spinner healthSPIN;
    EditText discriptionEDT;
    Button addHealthBTN;
    RecyclerView healthRV;
     HealthAdapter adapter;
    SessonManager sessonManager;
    ArrayList<EducationModel> arrHealthList=new ArrayList<>();
    ArrayList<String> arrKeyNameList=new ArrayList<>();
    ArrayList<EducationModel> arrKeyIDList=new ArrayList<>();

    String health_spin_id,healthID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health);
        
        sessonManager = new SessonManager(HealthActivity.this);

        healthSPIN=findViewById(R.id.spiner_health);
        discriptionEDT=findViewById(R.id.edt_health);
        addHealthBTN=findViewById(R.id.btn_add_health);
        healthRV=findViewById(R.id.rv_health);

        addHealthBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitSethealthApi();

            }
        });

        healthSPIN.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                health_spin_id = arrKeyIDList.get(i).getHealth_id();
               // health_spin_id = String.valueOf(healthSPIN.getSelectedItemId());
                Log.d("dnsaklj",health_spin_id);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        hitGetHealthApi();

    }

    public class HealthAdapter extends RecyclerView.Adapter<HealthActivity.HealthAdapter.ViewHolder> {


        private Context context;
        private ArrayList<EducationModel> healthArrList;


        public HealthAdapter(Context context, ArrayList<EducationModel> healthArrList) {
            this.context = context;
            this.healthArrList = healthArrList;
        }

        @NonNull
        @Override
        public HealthActivity.HealthAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.custom_health_layout, parent, false);
            return new HealthActivity.HealthAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final HealthActivity.HealthAdapter.ViewHolder holder, int position) {


            if (healthArrList.get(position).getIsCheked().equals("1")) {
                holder.healthNameTV.setText(healthArrList.get(position).getKey());
                holder.healthYearTV.setText(healthArrList.get(position).getHealth_discruption());
            }else {
                holder.healthNameTV.setVisibility(View.GONE);
                holder.healthYearTV.setVisibility(View.GONE);
                holder.removeIMG.setVisibility(View.GONE);
            }


        }

        @Override
        public int getItemCount() {
            return healthArrList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView healthNameTV,healthYearTV;
            ImageView removeIMG;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                healthNameTV=itemView.findViewById(R.id.tv_health_name);
                healthYearTV=itemView.findViewById(R.id.tv_health_diss);
                removeIMG=itemView.findViewById(R.id.image_health_remove);

                removeIMG.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        healthID=healthArrList.get(getAdapterPosition()).getHealth_id();
                        hitDeleteHelathApi();
                    }
                });

            }

        }


    }

    private void hitSethealthApi() {
        final ProgressDialog dialog = ProgressDialog.show(HealthActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_HEALTH, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("HelahtRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetHealthApi();

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(HealthActivity.this, MainActivity.class);
                    // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("health",health_spin_id);
                hashMap.put("description",discriptionEDT.getText().toString());
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


    private void hitDeleteHelathApi() {
        final ProgressDialog dialog = ProgressDialog.show(HealthActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.DELETE_HEALTH, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("DELETEHEALHRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetHealthApi();
                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(HealthActivity.this, MainActivity.class);
                    // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("health",healthID);

                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }



    private void hitGetHealthApi() {
        final ProgressDialog dialog = ProgressDialog.show(HealthActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_HEALTH, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresponse", response);
                arrHealthList.clear();
                arrKeyNameList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObjQualification = jsonObject.getJSONObject("health");
                    Iterator<String> keys = jsonObjQualification.keys();

                    while (keys.hasNext()) {
                        String key = keys.next();
                        Log.d("checkidd", key);

                        if (jsonObjQualification.get(key) instanceof JSONObject) {
                            EducationModel  educationModel = new EducationModel();

                            educationModel.setKey(key);
                            arrKeyNameList.add(key);
                            arrKeyIDList.add(educationModel);

                            educationModel.setHealth_id(((JSONObject) jsonObjQualification.get(key)).getString("id"));
                            educationModel.setHealth_discruption(((JSONObject) jsonObjQualification.get(key)).getString("description"));
                            educationModel.setIsCheked(((JSONObject) jsonObjQualification.get(key)).getString("ischecked"));

                            Log.d("cccvsadda", String.valueOf(arrHealthList.size()));
                            arrHealthList.add(educationModel);


                            ArrayAdapter healthAdpater = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item,arrKeyNameList);
                            healthAdpater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            healthSPIN.setAdapter(healthAdpater);
                        }


                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(HealthActivity.this, 1);
                    healthRV.setLayoutManager(layoutManager);
                    adapter = new HealthActivity.HealthAdapter(HealthActivity.this, arrHealthList);
                    healthRV.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(HealthActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }



}