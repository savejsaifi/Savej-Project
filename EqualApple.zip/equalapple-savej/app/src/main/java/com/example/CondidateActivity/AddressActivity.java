package com.example.CondidateActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AddressActivity extends AppCompatActivity {

    EditText addEDT,cityEDT,stateEDT,pincodeEDT;
    Button saveBTN;
    SessonManager sessonManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address);
        getSupportActionBar().setTitle("Address Details");

        sessonManager=new SessonManager(AddressActivity.this);

        addEDT=findViewById(R.id.edt_user_address);
        cityEDT=findViewById(R.id.edt_user_city);
        stateEDT=findViewById(R.id.edt_user_state);
        pincodeEDT=findViewById(R.id.edt_user_pincode);
        saveBTN=findViewById(R.id.btn_add_save);

        saveBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (addEDT.getText().toString().equals("")){
                    addEDT.setError("Befor enter address");
                }else if (stateEDT.getText().toString().equals("")){
                    stateEDT.setError("Befor enter state");
                }else if (cityEDT.getText().toString().equals("")){
                    cityEDT.setError("Befor enter city");
                }else if (pincodeEDT.getText().toString().equals("")){
                    pincodeEDT.setError("Befor enter pincode");
                }else {
                hitSetAddressApi();
            }}
        });

        hitGetAddressApi();

    }


    private void hitSetAddressApi() {
        final ProgressDialog dialog = ProgressDialog.show(AddressActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_ADDRESS, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("checkrespnse", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(AddressActivity.this, MainActivity.class);
                    startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AddressActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("address",addEDT.getText().toString() );
                    hashMap.put("city", cityEDT.getText().toString());
                    hashMap.put("state", stateEDT.getText().toString());
                    hashMap.put("pincode", pincodeEDT.getText().toString());
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void hitGetAddressApi(){
        final ProgressDialog dialog = ProgressDialog.show(AddressActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_ADDRESS, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresponse", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String address = jsonObject.getString("address");
                    String city = jsonObject.getString("city");
                    String state = jsonObject.getString("state");
                    String pincode= jsonObject.getString("pincode");

                    addEDT.setText(address);
                    cityEDT.setText(city);
                    stateEDT.setText(state);
                    pincodeEDT.setText(pincode);


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(AddressActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


}
