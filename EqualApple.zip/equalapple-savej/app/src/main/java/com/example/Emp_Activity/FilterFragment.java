package com.example.Emp_Activity;


import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.adapter.FilterAdapter;
import com.example.adapter.FilterExperienceAdapter;
import com.example.adapter.FilterGenderAdapter;
import com.example.adapter.FilterLanguageAdapter;
import com.example.adapter.FilterLocationAdapter;
import com.example.adapter.FilterQualificationAdapter;
import com.example.adapter.FilterReligionAdapter;
import com.example.adapter.SalaryAdapter;
import com.example.equalapple.R;
import com.example.modelpojo.FilterModel;
import com.example.modelpojo.SearchModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.graphics.Color.*;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * A simple {@link Fragment} subclass.
 */
public class FilterFragment extends AppCompatActivity {



 RelativeLayout relativeCategory,reLativelocation,relativeGender,relativeQualification,
         relativeLanguage,relativExperience,relativeReligion,relativeSalary;

    RecyclerView rvCategory,rvLocation,rvGender,rvQualification,rvLanguage,
            rvExperience,rvReligion,rvSallary;

    ImageView imgColseFilter,imgFilter;
    CardView cardFilterClear;
    Button btnApplyFilter;
    SessonManager sessonManager;
    String token;
    ArrayList<FilterModel> listCategory = new ArrayList<>();
    ArrayList<FilterModel> listCategorySearch = new ArrayList<>();
    ArrayList<FilterModel> listReligion = new ArrayList<>();
    ArrayList<FilterModel> listReligionSearch = new ArrayList<>();
    ArrayList<FilterModel> listQualification = new ArrayList<>();
    ArrayList<FilterModel> listQualificationSearch = new ArrayList<>();
    ArrayList<FilterModel> listGender = new ArrayList<>();
    ArrayList<FilterModel> listGenderSearch = new ArrayList<>();
    ArrayList<FilterModel> listLanguage = new ArrayList<>();
    ArrayList<FilterModel> listLanguageSearch = new ArrayList<>();
    ArrayList<FilterModel> listSalary = new ArrayList<>();
    ArrayList<FilterModel> listSalarySearch = new ArrayList<>();
    ArrayList<FilterModel> listLocation = new ArrayList<>();
    ArrayList<FilterModel> listLocationSearch = new ArrayList<>();
    ArrayList<FilterModel> listExperience = new ArrayList<>();
    ArrayList<FilterModel> listExperienceSearch = new ArrayList<>();

    FilterAdapter adapter;
    FilterQualificationAdapter adapterqualification ;
    FilterLocationAdapter adapterLocation ;
    FilterGenderAdapter adapterGender ;
    FilterLanguageAdapter adapterLanguage ;
    FilterExperienceAdapter adapterExperience ;
    FilterReligionAdapter adapterReligion ;
    SalaryAdapter adapterSalary ;


    @Override
    protected void  onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_filter);
        sessonManager=new SessonManager(FilterFragment.this);
        token = sessonManager.getToken();
        Log.d("weqolmnk",token);
        // Inflate the layout for this fragment
       // view = inflater.inflate(R.layout.fragment_filter, container, false);
        getSupportActionBar().hide();
        imgColseFilter =   findViewById(R.id.imgColseFilter);
        imgFilter =   findViewById(R.id.imgFilter);
        cardFilterClear =   findViewById(R.id.cardFilterClear);
        relativeCategory =   findViewById(R.id.relativeCategory);
        reLativelocation =   findViewById(R.id.reLativelocation);
        relativeGender =   findViewById(R.id.relativeGender);
        relativeQualification =   findViewById(R.id.relativeQualification);
        relativeLanguage =   findViewById(R.id.relativeLanguage);
        relativExperience =   findViewById(R.id.relativExperience);
        relativeReligion =   findViewById(R.id.relativeReligion);
        relativeSalary =   findViewById(R.id.relativeSalary);

        rvCategory =   findViewById(R.id.rvCategory);
        rvLocation =   findViewById(R.id.rvLocation);
        rvGender =   findViewById(R.id.rvGender);
        rvQualification =   findViewById(R.id.rvQualification);
        rvLanguage =   findViewById(R.id.rvLanguage);
        rvExperience =   findViewById(R.id.rvExperience);
        rvReligion =   findViewById(R.id.rvReligion);
        rvSallary =   findViewById(R.id.rvSallary);
        btnApplyFilter =   findViewById(R.id.btnApplyFilter);


        hitFiterItemApi();
        cliclkAll();

    }

    private void hitFiterItemApi() {
        listCategory.clear();
        listReligion.clear();
        listQualification.clear();
        listGender.clear();
        listLanguage.clear();
        listSalary.clear();
        listLocation.clear();
        listExperience.clear();

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.GET, Consent.getFilterItem, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("jkldfuwea",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray CategoryArray = jsonObject.getJSONArray("category");
                    for(int i=0;i<CategoryArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        JSONObject catogryObject = CategoryArray.getJSONObject(i);
                        filterModel.setId(catogryObject.getString("id"));
                        filterModel.setFilterItem(catogryObject.getString("name"));
                        listCategory.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(),1);
                    rvCategory.setLayoutManager(layoutManager);
                    adapter = new FilterAdapter(getApplicationContext(),listCategory);
                    rvCategory.setAdapter(adapter);

                    JSONArray religionArray = jsonObject.getJSONArray("religion");
                    for(int i=0;i<religionArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        JSONObject catogryObject = religionArray.getJSONObject(i);
                        filterModel.setId(catogryObject.getString("id"));
                        filterModel.setFilterItem(catogryObject.getString("name"));
                        listReligion.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager7 = new GridLayoutManager(getApplicationContext(),1);
                    rvReligion.setLayoutManager(layoutManager7);
                    adapterReligion = new FilterReligionAdapter(getApplicationContext(),listReligion);
                    rvReligion.setAdapter(adapterReligion);


                    JSONArray qualificationArray = jsonObject.getJSONArray("qualification");
                    for(int i=0;i<qualificationArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        JSONObject catogryObject = qualificationArray.getJSONObject(i);
                        filterModel.setId(catogryObject.getString("id"));
                        filterModel.setFilterItem(catogryObject.getString("name"));
                        listQualification.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager4 = new GridLayoutManager(getApplicationContext(),1);
                    rvQualification.setLayoutManager(layoutManager4);
                    adapterqualification = new FilterQualificationAdapter(getApplicationContext(),listQualification);
                    rvQualification.setAdapter(adapterqualification);

                    JSONArray genderArray = jsonObject.getJSONArray("gender");
                    for(int i=0;i<genderArray.length();i++){
                        FilterModel filterModel = new FilterModel();

                       // filterModel.setId(catogryObject.getString("id"));
                        filterModel.setFilterItem(genderArray.get(i).toString());
                        listGender.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager3 = new GridLayoutManager(getApplicationContext(),1);
                    rvGender.setLayoutManager(layoutManager3);
                    adapterGender = new FilterGenderAdapter(getApplicationContext(),listGender);
                    rvGender.setAdapter(adapterGender);

                    JSONArray languageArray = jsonObject.getJSONArray("language");
                    for(int i=0;i<languageArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        JSONObject catogryObject = languageArray.getJSONObject(i);
                        filterModel.setId(catogryObject.getString("id"));
                        filterModel.setFilterItem(catogryObject.getString("name"));
                        listLanguage.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager5 = new GridLayoutManager(getApplicationContext(),1);
                    rvLanguage.setLayoutManager(layoutManager5);
                    adapterLanguage = new FilterLanguageAdapter(getApplicationContext(),listLanguage);
                    rvLanguage.setAdapter(adapterLanguage);

                    JSONArray salaryArray = jsonObject.getJSONArray("salary");
                    for(int i=0;i<salaryArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        filterModel.setFilterItem(salaryArray.get(i).toString());
                        listSalary.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager8 = new GridLayoutManager(getApplicationContext(),1);
                    rvSallary.setLayoutManager(layoutManager8);
                    adapterSalary = new SalaryAdapter(getApplicationContext(),listSalary);
                    rvSallary.setAdapter(adapterSalary);

                   JSONArray locationArray = jsonObject.getJSONArray("location");
                    for(int i=0;i<locationArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        JSONObject jsonObject1 = locationArray.getJSONObject(i);
                        filterModel.setFilterItem(jsonObject1.getString("city"));
                        listLocation.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager2 = new GridLayoutManager(getApplicationContext(),1);
                    rvLocation.setLayoutManager(layoutManager2);
                    adapterLocation = new FilterLocationAdapter(getApplicationContext(),listLocation);
                    rvLocation.setAdapter(adapterLocation);

                    JSONArray experienceArray = jsonObject.getJSONArray("experience");
                    for(int i=0;i<experienceArray.length();i++){
                        FilterModel filterModel = new FilterModel();
                        filterModel.setFilterItem(experienceArray.get(i).toString());
                        listExperience.add(filterModel);
                    }
                    RecyclerView.LayoutManager layoutManager6 = new GridLayoutManager(getApplicationContext(),1);
                    rvExperience.setLayoutManager(layoutManager6);
                    adapterExperience = new FilterExperienceAdapter(getApplicationContext(),listExperience);
                    rvExperience.setAdapter(adapterExperience);



                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(FilterFragment.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<>();
                 hashMap.put("Authorization","Bearer "+token);
                return hashMap;
            }

        };
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void cliclkAll() {

        btnApplyFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String category="";
                String qualification="";
                String gender="";
                String location="";
                String language="";
                String experience="";
                String religion="";
                String salary="";

                ArrayList<FilterModel> lstCategory = ((FilterAdapter) adapter).getListCategory();
                getViewModelStore().clear();
                FilterModel singleData;
                for (int i = 0; i < lstCategory.size(); i++) {
                    singleData = lstCategory.get(i);
                    if (singleData.isSelected() == true) {

                        if (category.equals("")) {
                            category = singleData.getId();
                        } else {
                            category = category + "," + singleData.getId();
                        }
                    }

                }

                ArrayList<FilterModel> lstCategory2 = ((FilterQualificationAdapter) adapterqualification).getListCategoryQualification();
                getViewModelStore().clear();
                FilterModel singleData2;
                for (int i = 0; i < lstCategory2.size(); i++) {
                    singleData2 = lstCategory2.get(i);
                    if (singleData2.isSelected() == true) {

                        if (qualification.equals("")) {
                            qualification = singleData2.getId();
                        } else {
                            qualification = qualification + "," + singleData2.getId();
                        }
                    }

                }

                ArrayList<FilterModel> lstCategory3 = ((FilterGenderAdapter) adapterGender).getListGender();
                getViewModelStore().clear();
                FilterModel singleData3;
                for (int i = 0; i < lstCategory3.size(); i++) {
                    singleData3 = lstCategory3.get(i);
                    if (singleData3.isSelected() == true) {

                        if (gender.equals("")) {
                            gender = singleData3.getFilterItem();
                        } else {
                            gender = gender + "," + singleData3.getFilterItem();
                        }
                    }

                }

               ArrayList<FilterModel> lstCategory4 = ((FilterLocationAdapter) adapterLocation).getListLocation();
                getViewModelStore().clear();
                FilterModel singleData4;
                for (int i = 0; i < lstCategory4.size(); i++) {
                    singleData4 = lstCategory4.get(i);
                    if (singleData4.isSelected() == true) {

                        if (location.equals("")) {
                            location = singleData4.getFilterItem();
                        } else {
                            location = location + "," + singleData4.getFilterItem();
                        }
                    }

                }
            ArrayList<FilterModel> lstCategory5 = ((FilterLanguageAdapter) adapterLanguage).getListLanguage();
                getViewModelStore().clear();
                FilterModel singleData5;
                for (int i = 0; i < lstCategory5.size(); i++) {
                    singleData5 = lstCategory5.get(i);
                    if (singleData5.isSelected() == true) {

                        if (language.equals("")) {
                            language = singleData5.getFilterItem();
                        } else {
                            language = language + "," + singleData5.getId();
                        }
                    }

                }

                ArrayList<FilterModel> lstCategory6 = ((FilterExperienceAdapter) adapterExperience).getListExperience();
                getViewModelStore().clear();
                FilterModel singleData6;
                for (int i = 0; i < lstCategory6.size(); i++) {
                    singleData6 = lstCategory6.get(i);
                    if (singleData6.isSelected() == true) {

                        if (experience.equals("")) {
                            experience = singleData6.getFilterItem();
                        } else {
                            experience = experience + "," + singleData6.getFilterItem();
                        }
                    }

                }

                ArrayList<FilterModel> lstCategory7 = adapterReligion.getListReligion();
                getViewModelStore().clear();
                FilterModel singleData7;
                for (int i = 0; i < lstCategory7.size(); i++) {
                    singleData7 = lstCategory7.get(i);
                    if (singleData7.isSelected() == true) {

                        if (religion.equals("")) {
                            religion = singleData7.getId();
                        } else {
                            religion = religion + "," + singleData7.getId();
                        }
                    }

                }

                ArrayList<FilterModel> lstCategory8 = adapterSalary.getListSallary();
                getViewModelStore().clear();
                FilterModel singleData8;
                for (int i = 0; i < lstCategory8.size(); i++) {
                    singleData8 = lstCategory8.get(i);
                    if (singleData8.isSelected() == true) {

                        if (salary.equals("")) {
                            salary = singleData8.getFilterItem();
                        } else {
                            salary = salary + "," + singleData8.getFilterItem();
                        }
                    }

                }




                Log.d("qaedsxc",category+"    "+qualification);

                final String url = Consent.getSearchItem+"qualification="+qualification+"&category="+category+"&gender="
                        +gender+"&location="+location+"&language="+language+"&experience="+experience+"&religion="+religion
                        +"&salary="+salary;

                startActivity(new Intent(getApplicationContext(),SearchDetailActivity.class).putExtra("search_url",url));


            }
        });
        imgColseFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainNavigaton.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

            }
        });
        imgFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),MainNavigaton.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

            }
        });

        cardFilterClear.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);

            }
        });

        relativeCategory.setOnClickListener(new  View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( VISIBLE);

                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);


//                relativeCategory.setBackgroundColor(WHITE);

            }
        }); reLativelocation.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( VISIBLE);

                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);

            }
        });
        relativeGender.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( VISIBLE);

                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);

            }
        });

        relativeQualification.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( VISIBLE);

                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);

            }
        });

        relativeLanguage.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( VISIBLE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);

            }
        });
        relativExperience.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( VISIBLE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( GONE);


            }
        });
        relativeReligion.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( VISIBLE);
                rvSallary.setVisibility( GONE);


            }
        });
        relativeSalary.setOnClickListener(new  View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rvCategory.setVisibility( GONE);
                rvLocation.setVisibility( GONE);
                rvGender.setVisibility( GONE);
                rvQualification.setVisibility( GONE);
                rvLanguage.setVisibility( GONE);
                rvExperience.setVisibility( GONE);
                rvReligion.setVisibility( GONE);
                rvSallary.setVisibility( VISIBLE);


            }
        });


    }


//    @Override
//    public boolean onQueryTextSubmit(String query) {
//        return false;
//    }
//
//
//    @Override
//    public boolean onQueryTextChange(String newText) {
//        return false;
//    }
}
