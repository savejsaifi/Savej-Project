package com.example.adapter;

import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Emp_Activity.ProfileActiivity;
import com.example.Emp_Activity.SearchDetailActivity;
import com.example.equalapple.R;
import com.example.modelpojo.SearchModel;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class SearchDetailAdapter extends RecyclerView.Adapter<SearchDetailAdapter.searchHolder> {

    Context context;
    ArrayList<SearchModel> listSearch;

    public SearchDetailAdapter(Context context, ArrayList<SearchModel> listSearch) {
        this.context = context;
        this.listSearch = listSearch;
    }


    @NonNull
    @Override
    public searchHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view = LayoutInflater.from(context).inflate(R.layout.recycler_view_row,parent,false);

        return new searchHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull searchHolder holder, int position) {
            holder.tv_name.setText(listSearch.get(position).getName());
            holder.tv_category.setText(listSearch.get(position).getCategory());
            holder.tv_locatin.setText(listSearch.get(position).getCity());
            holder.tv_gender.setText(listSearch.get(position).getGender());

            if(listSearch.get(position).getImage().isEmpty()){
                Picasso.get().load(R.drawable.amir).into(holder.imageViewRecycle);
            }else{
                Picasso.get().load(listSearch.get(position).getImage()).into(holder.imageViewRecycle);
            }

    }


    @Override
    public int getItemCount() {
        return listSearch.size();
    }

    public class searchHolder extends RecyclerView.ViewHolder{
        CircularImageView imageViewRecycle;
        Button btnViewMore,btnDownload;
        TextView tv_name,tv_category,tv_gender,tv_locatin;

        public searchHolder(@NonNull View itemView) {
            super(itemView);
            imageViewRecycle = itemView.findViewById(R.id.imageViewRecycle);
            btnViewMore = itemView.findViewById(R.id.btnViewMore);
            tv_name = itemView.findViewById(R.id.tv_name);
            tv_category = itemView.findViewById(R.id.tv_category);
            tv_gender = itemView.findViewById(R.id.tv_gender);
            tv_locatin = itemView.findViewById(R.id.tv_locatin);
            btnDownload = itemView.findViewById(R.id.btnDownload);


            btnViewMore.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SearchModel model = listSearch.get(getAdapterPosition());
                    String id = model.getId();

                    Log.d("sadwqmnxwa",id+" ");

                    Intent intent = new Intent(context, ProfileActiivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("id",id);
                   // intent.putExtra("category",category);
                    context.startActivity(intent);
                }
            });

            btnDownload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {


                    DownloadManager manager  = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);;
                    SearchModel model = listSearch.get(getAdapterPosition());
                    String url = model.getPdfUrl();

                    Uri Download_Uri = Uri.parse( String.valueOf(url));

                    DownloadManager.Request request = new DownloadManager.Request(Download_Uri);
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

                    request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
                    request.setAllowedOverRoaming(false);
                    request.setTitle("Resume" + ".pdf");
                    request.setDescription("Downloading " + "Resume" + ".pdf");
                    request.setVisibleInDownloadsUi(true);
                     request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "/EqualApple/"  + "/" + "Resume");
                  //  request.setDestinationInExternalPublicDir("EqualApple",    ".pdf");

                    manager.enqueue(request);
                    Toast.makeText(context, "Download successfull", Toast.LENGTH_SHORT).show();
                   // PopDownloadPDF();
                }
            });


        }

    }
//    private void PopDownloadPDF() {
//
//            LayoutInflater inflater = LayoutInflater.from(context);
//            final Dialog mDialogConfirmPopUp = new Dialog(context,
//                    android.R.style.Theme_Translucent_NoTitleBar);
//
//            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
//            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
//                    LinearLayout.LayoutParams.MATCH_PARENT);
//            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
//            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
//            lp.dimAmount = 0.75f;
//            mDialogConfirmPopUp.getWindow()
//                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
//            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
//            mDialogConfirmPopUp.getWindow();
//
//            View dialoglayout = inflater.inflate(R.layout.pop_donwload, null);
//            mDialogConfirmPopUp.setContentView(dialoglayout);
//
//            Button btn_ok_pop_down_out_line = (Button) mDialogConfirmPopUp.findViewById(R.id.btn_ok_pop_down_out_line);
//            btn_ok_pop_down_out_line.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    mDialogConfirmPopUp.dismiss();
//                }
//            });
//            mDialogConfirmPopUp.show();
//
//    }


}
