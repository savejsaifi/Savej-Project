package com.example.CondidateActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class LanguageActivity extends AppCompatActivity {
    Spinner langSPIN;
    Button addlangBTN;
    RecyclerView langRV;
    LanguageAdapter adapter;
    SessonManager sessonManager;
    ArrayList<EducationModel> arrlangList = new ArrayList<>();
    ArrayList<String> arrKeyNameList = new ArrayList<>();
    ArrayList<EducationModel> arrKeyIDList = new ArrayList<>();

    String lang_spin_id, langID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_language);

        sessonManager = new SessonManager(LanguageActivity.this);

        langSPIN = findViewById(R.id.spiner_lang);
        addlangBTN = findViewById(R.id.btn_add_lang);
        langRV = findViewById(R.id.rv_lang);

        addlangBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitSetlangApi();

            }
        });

        langSPIN.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                lang_spin_id = arrKeyIDList.get(i).getLang_id();
                // lang_spin_id = String.valueOf(langSPIN.getSelectedItemId());
                Log.d("dnsaklj", lang_spin_id);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        hitGetlangApi();


    }

    private void hitSetlangApi() {
        final ProgressDialog dialog = ProgressDialog.show(LanguageActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_LANG, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("LANGRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetlangApi();

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(LanguageActivity.this, MainActivity.class);
                    // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("language", lang_spin_id);
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void hitDeletelangApi() {
        final ProgressDialog dialog = ProgressDialog.show(LanguageActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.DELETE_LANG, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("DELETELANGHRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetlangApi();
                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(LanguageActivity.this, MainActivity.class);
                    // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("language", langID);

                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void hitGetlangApi() {
        final ProgressDialog dialog = ProgressDialog.show(LanguageActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_LANG, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getLANGresponse", response);
                arrlangList.clear();
                arrKeyNameList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObjQualification = jsonObject.getJSONObject("languages");
                    Iterator<String> keys = jsonObjQualification.keys();

                    while (keys.hasNext()) {
                        String key = keys.next();
                        Log.d("checkidd", key);

                        if (jsonObjQualification.get(key) instanceof JSONObject) {
                            EducationModel educationModel = new EducationModel();

                            educationModel.setKey(key);
                            arrKeyNameList.add(key);
                            arrKeyIDList.add(educationModel);

                            educationModel.setLang_id(((JSONObject) jsonObjQualification.get(key)).getString("id"));
                            educationModel.setIsCheked(((JSONObject) jsonObjQualification.get(key)).getString("ischecked"));

                            Log.d("cccvsadda", String.valueOf(arrlangList.size()));
                            arrlangList.add(educationModel);


                            ArrayAdapter langAdpater = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_spinner_item, arrKeyNameList);
                            langAdpater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            langSPIN.setAdapter(langAdpater);
                        }


                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(LanguageActivity.this, 1);
                    langRV.setLayoutManager(layoutManager);
                    adapter = new LanguageActivity.LanguageAdapter(LanguageActivity.this, arrlangList);
                    langRV.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(LanguageActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    public class LanguageAdapter extends RecyclerView.Adapter<LanguageAdapter.ViewHolder> {


        private Context context;
        private ArrayList<EducationModel> langArrList;


        public LanguageAdapter(Context context, ArrayList<EducationModel> langArrList) {
            this.context = context;
            this.langArrList = langArrList;
        }

        @NonNull
        @Override
        public LanguageAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.custom_lang_layout, parent, false);
            return new LanguageAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final LanguageAdapter.ViewHolder holder, int position) {


            if (langArrList.get(position).getIsCheked().equals("1")) {
                holder.langNameTV.setText(langArrList.get(position).getKey());
            } else {
                holder.langNameTV.setVisibility(View.GONE);
                holder.removeIMG.setVisibility(View.GONE);
            }


        }

        @Override
        public int getItemCount() {
            return langArrList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView langNameTV, langYearTV;
            ImageView removeIMG;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                langNameTV = itemView.findViewById(R.id.tv_lang_name);
                removeIMG = itemView.findViewById(R.id.image_lang_remove);

                removeIMG.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        langID = langArrList.get(getAdapterPosition()).getLang_id();
                        hitDeletelangApi();
                    }
                });

            }

        }


    }
}
