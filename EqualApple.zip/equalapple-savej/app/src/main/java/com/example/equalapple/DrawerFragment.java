package com.example.equalapple;


import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class DrawerFragment extends Fragment implements View.OnClickListener {

    RelativeLayout relativeLayoutCategory;
    LinearLayout linearLayoutCategoryDetail;
    TextView textViewCategory;

    RelativeLayout relativeLayoutLocation;
    LinearLayout linearLayoutLocationDetail;
    TextView textViewLocation;

    CardView cardViewClear;

    RelativeLayout relativeLayoutGender;
    LinearLayout linearLayoutGenderDetail;
    TextView textViewGender;


    RelativeLayout relativeLayoutQualification;
    LinearLayout linearLayoutQualificationDetail;
    TextView textViewQualification;

    RelativeLayout relativeLayoutLangauge;
    LinearLayout linearLayoutLanguageDetail;
    TextView textViewLAnguage;


    RelativeLayout relativeLayoutExperience;
    LinearLayout linearLayoutExperienceDetail;
    TextView textViewExperience;


    RelativeLayout relativeLayoutReligion;
    LinearLayout linearLayoutReligionDetail;
    TextView textViewReligion;
    RelativeLayout relativeLayoutSalary;
    LinearLayout linearLayoutSalaryDetail;
    TextView textViewSalary;

    View view;

    Button buttonApplyNow;

    public DrawerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_drawer, container, false);

        ((AppCompatActivity) getActivity()).getSupportActionBar().hide();
        cardViewClear=view.findViewById(R.id.cardViewClear);


        buttonApplyNow=view.findViewById(R.id.btnApplyNow);

        relativeLayoutCategory =view.findViewById(R.id.category);
        linearLayoutCategoryDetail=view.findViewById(R.id.linearLayoutCategoryDetail);
        textViewCategory=view.findViewById(R.id.textViewCategory);


        relativeLayoutLocation =view.findViewById(R.id.location);
        linearLayoutLocationDetail=view.findViewById(R.id.linearLayoutLocationDetail);
        textViewLocation=view.findViewById(R.id.textViewLocation);

        relativeLayoutGender =view.findViewById(R.id.gender);
        linearLayoutGenderDetail=view.findViewById(R.id.linearLayoutGenderDetail);
        textViewGender=view.findViewById(R.id.textViewGender);


        relativeLayoutQualification =view.findViewById(R.id.qualification);
        linearLayoutQualificationDetail=view.findViewById(R.id.linearLayoutQualificationDetail);
        textViewQualification=view.findViewById(R.id.textViewQualification);


        relativeLayoutLangauge =view.findViewById(R.id.language);
        linearLayoutLanguageDetail=view.findViewById(R.id.linearLayoutLanguageDetail);
        textViewLAnguage=view.findViewById(R.id.textViewLanguage);


        relativeLayoutExperience =view.findViewById(R.id.experience);
        linearLayoutExperienceDetail=view.findViewById(R.id.linearLayoutExperienceDetail);
        textViewExperience=view.findViewById(R.id.textViewExperience);


        relativeLayoutReligion =view.findViewById(R.id.religion);
        linearLayoutReligionDetail=view.findViewById(R.id.linearLayoutReligionDetail);
        textViewReligion=view.findViewById(R.id.textViewReligion);



        relativeLayoutSalary =view.findViewById(R.id.salary);
        linearLayoutSalaryDetail=view.findViewById(R.id.linearLayoutSalaryDetail);
        textViewSalary=view.findViewById(R.id.textViewSalary);




        relativeLayoutCategory.setOnClickListener(this);
        relativeLayoutLocation.setOnClickListener(this);
        relativeLayoutGender.setOnClickListener(this);
        relativeLayoutQualification.setOnClickListener(this);
        relativeLayoutLangauge.setOnClickListener(this);
        relativeLayoutExperience.setOnClickListener(this);
        relativeLayoutReligion.setOnClickListener(this);
        relativeLayoutSalary.setOnClickListener(this);

        buttonApplyNow.setOnClickListener(this);


        return view;

    }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.category:
                linearLayoutCategoryDetail.setVisibility(View.VISIBLE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                break;


            case R.id.location:
                linearLayoutLocationDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                break;

            case R.id.gender:
                linearLayoutGenderDetail.setVisibility(View.VISIBLE);
                textViewGender.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.white));
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                break;

            case R.id.qualification:
                linearLayoutQualificationDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.blackText));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                break;


            case R.id.language:
                linearLayoutLanguageDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.blackText));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                break;


            case R.id.experience:
                linearLayoutExperienceDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                //linearLayoutLanguageDetail.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.blackText));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));


                break;

            case R.id.religion:
                linearLayoutReligionDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                linearLayoutExperienceDetail.setVisibility(View.GONE);
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.blackText));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));

                break;



            case R.id.salary:
                linearLayoutSalaryDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                linearLayoutExperienceDetail.setVisibility(View.GONE);
                linearLayoutReligionDetail.setVisibility(View.GONE);
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.blackText));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                break;


            case R.id.btnApplyNow:
                getFragmentManager().beginTransaction().replace(R.id.container,new FagmentResult()).addToBackStack(null).commit();



        }

    }
    }
