package com.example.CondidateActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.equalapple.R;
import com.squareup.picasso.Picasso;

import uk.co.senab.photoview.PhotoView;

public class ResumeImageZoom extends AppCompatActivity {
     ImageView crossIMG;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resume_image_zoom);
        getSupportActionBar().hide();

        String image=getIntent().getStringExtra("image");
        PhotoView photoView=findViewById(R.id.photoview);
        crossIMG=findViewById(R.id.iv_zoomImage_finish);

        Picasso.get().load(image).into(photoView);

        crossIMG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

    }
}
