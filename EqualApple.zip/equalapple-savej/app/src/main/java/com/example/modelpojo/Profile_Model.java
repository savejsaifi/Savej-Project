package com.example.modelpojo;

public class Profile_Model {

    private String name;
    private String category;
    private String gender;
    private String location;
    private int image;


    public Profile_Model(String name, String category, String gender, String location, int image) {
        this.name = name;
        this.category = category;
        this.gender = gender;
        this.location = location;
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
