package com.example.Emp_Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.CondidateActivity.LoginCandidateActivity;
import com.example.CondidateActivity.OtpActivity;
import com.example.CondidateActivity.RegisterActivity;
import com.example.Config.Consent;
import com.example.Util.CheckNetwork;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginEmployerActivity extends AppCompatActivity {

    private Button btnLogin,btnRegister;
    SessonManager sessonManager;
    EditText empMobEDT,empPassEDT,et_dialog_mob;
    TextView forgetPass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_employer_login);
        getSupportActionBar().setTitle("Login Employer");
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        sessonManager = new SessonManager(this);


        empMobEDT = findViewById(R.id.edt_emp_mobile);
        empPassEDT = findViewById(R.id.edt_emp_password);
        forgetPass = findViewById(R.id.tv_emp_forget);

//        empMobEDT.setText("7011635599");
//        empPassEDT.setText("7777777");

        btnLogin=findViewById(R.id.btnLoginEmployer);
        btnRegister=findViewById(R.id.btnrEgisterEmployer);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckNetwork.isInternetAvailable(LoginEmployerActivity.this)) //returns true if internet available
                {
                    if (empMobEDT.getText().toString().equals("")) {
                        empMobEDT.setError("Enter valid mobile no.");

                    } else if (empPassEDT.getText().toString().equals("")) {
                        empPassEDT.setError("Enter valid password");
                    } else {
                        hitLoginApi();

                    }
                } else {
                    Toast.makeText(LoginEmployerActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }

            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences=getSharedPreferences("shared",MODE_PRIVATE);
                sharedPreferences.edit().putString("employer","emp").apply();
                Intent intent=new Intent(LoginEmployerActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        forgetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final Dialog dialog = new Dialog(LoginEmployerActivity.this);
                dialog.setContentView(R.layout.forgot_mob_popup);
                dialog.show();
                et_dialog_mob = dialog.findViewById(R.id.et_MobileNum);
                Button btn_dialog_continue = dialog.findViewById(R.id.btn_continue);

                btn_dialog_continue.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (et_dialog_mob.getText().toString().equals("")) {
                            et_dialog_mob.setError("Enter Valid Number");
                        } else {

                            hitForgetPassApi();

                        }

                    }
                });
            }
        });
    }

    private void hitLoginApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(LoginEmployerActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(LoginEmployerActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.LOGIN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("GETLOGINempRESPONSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");
                    String message = jsonObject.getString("message");
                    String token = jsonObject.getString("token");
                    String type = jsonObject.getString("type");
                    sessonManager.setToken(token);

                    Log.d("chekcstatus", status);

                    if (status.equals("success")&&type.equalsIgnoreCase("employer")) {
                        sessonManager.setSessonCanEmp("employee");

                        Toast.makeText(LoginEmployerActivity.this, "" + message, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LoginEmployerActivity.this, MainNavigaton.class).
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        //getSupportFragmentManager().beginTransaction().replace(R.id.container, new EmpMainActivity()).addToBackStack(null).commit();


                    }
                    else if(!type.equalsIgnoreCase("employer")){
                        Toast.makeText(LoginEmployerActivity.this, "mobile number registerd for Candidate account", Toast.LENGTH_SHORT).show();
                    }
//                    else if (message.equals("Please verify OTP to continue")) {
//                        Intent intent = new Intent(LoginEmployerActivity.this, OtpActivity.class);
//                        intent.putExtra("mobile", empMobEDT.getText().toString());
//                        startActivity(intent);
//
//                    }
                    else {
                        Toast.makeText(LoginEmployerActivity.this, "" + message, Toast.LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();

                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("mobile", empMobEDT.getText().toString());
                hashMap.put("password", empPassEDT.getText().toString());

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    private void hitForgetPassApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(LoginEmployerActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(LoginEmployerActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.FORGET_PASSWORD, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("FORGETRESPONSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");
                    String message = jsonObject.getString("message");
                    if (status.equals("success")) {

                        SharedPreferences sharedPreferences=getSharedPreferences("shared",MODE_PRIVATE);
                        sharedPreferences.edit().putString("employer","emp").apply();
                        //  sharedPreferences.edit().putString("value", "1").commit();
                        Toast.makeText(LoginEmployerActivity.this, "" + message, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginEmployerActivity.this, OtpActivity.class);
                        intent.putExtra("mobile", et_dialog_mob.getText().toString());
                        intent.putExtra("value", "1");
                        startActivity(intent);

                    }else {
                        Toast.makeText(LoginEmployerActivity.this, "" + message, Toast.LENGTH_SHORT).show();


                    }
                } catch (JSONException e) {
                    e.printStackTrace();

                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("mobile", et_dialog_mob.getText().toString());


                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}
