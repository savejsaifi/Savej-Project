package com.example.CondidateActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.CheckNetwork;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginCandidateActivity extends AppCompatActivity {

    TextView fogetPass;
    SessonManager sessonManager;
    SharedPreferences sharedPreferences;
    EditText et_dialog_mob;
    String password;
    private Button btnLoginCandidate, btnRegisterCandidate;
    private EditText mobEDT, passEDT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_candidate_login);
        getSupportActionBar().setTitle("Login Candidate");

        btnLoginCandidate = findViewById(R.id.btnLoginCandidate);
        btnRegisterCandidate = findViewById(R.id.btnRegisterCandidate);
        mobEDT = findViewById(R.id.mobile_edt);
        passEDT = findViewById(R.id.pass_edt);
        fogetPass = findViewById(R.id.tv_forget_password);

//        mobEDT.setText("7011635590");
//        passEDT.setText("7777777");

        sessonManager = new SessonManager(this);

        sharedPreferences = getSharedPreferences("share_mobile", MODE_PRIVATE);
        sharedPreferences.edit().putString("mobile", mobEDT.getText().toString()).commit();


        btnLoginCandidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckNetwork.isInternetAvailable(LoginCandidateActivity.this)) //returns true if internet available
                {
                    if (mobEDT.getText().toString().equals("")) {
                        mobEDT.setError("Enter valid mobile no.");

                    } else if (passEDT.getText().toString().equals("")) {
                        passEDT.setError("Enter valid password");
                    } else {
                        hitLoginApi();

                    }
                } else {
                    Toast.makeText(LoginCandidateActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }

            }
        });


        btnRegisterCandidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences=getSharedPreferences("shared",MODE_PRIVATE);
                sharedPreferences.edit().putString("employer","candidate").apply();
                Intent intent = new Intent(LoginCandidateActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        fogetPass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                forgotPassMobDialog();
            }
        });
    }


    public void forgotPassMobDialog() {
        final Dialog dialog = new Dialog(LoginCandidateActivity.this);
        dialog.setContentView(R.layout.forgot_mob_popup);
        dialog.show();
        et_dialog_mob = dialog.findViewById(R.id.et_MobileNum);
        Button btn_dialog_continue = dialog.findViewById(R.id.btn_continue);

        btn_dialog_continue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (et_dialog_mob.getText().toString().equals("")) {
                    et_dialog_mob.setError("Enter Valid Number");
                } else {

                    hitForgetPassApi();


                }


            }
        });
    }

    private void hitLoginApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(LoginCandidateActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(LoginCandidateActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.LOGIN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("GETLOGINRESPONSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");
                    String message = jsonObject.getString("message");
                    String token = jsonObject.getString("token");
                    String type = jsonObject.getString("type");
                    sessonManager.setToken(token);

                    Log.d("chekcstatus", status);

                    if (status.equals("success")&&(!(type.equalsIgnoreCase("employer")))) {
                        sessonManager.setSessonCanEmp("candidate");

                        Toast.makeText(LoginCandidateActivity.this, "" + message, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(LoginCandidateActivity.this, HomeActivity.class).
                                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);

                    } else if(type.equalsIgnoreCase("employer")){
                        Toast.makeText(LoginCandidateActivity.this, "mobile number registerd for Employee account", Toast.LENGTH_SHORT).show();
                    }
//                    else if (message.equals("Please verify OTP to continue")) {
//                        Intent intent = new Intent(LoginCandidateActivity.this, OtpActivity.class);
//                        intent.putExtra("mobile", mobEDT.getText().toString());
//                        startActivity(intent);
//
//                    }
                    else {
                        Toast.makeText(LoginCandidateActivity.this, "" + message, Toast.LENGTH_SHORT).show();

                    }

                } catch (JSONException e) {
                    e.printStackTrace();

                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("mobile", mobEDT.getText().toString());
                hashMap.put("password", passEDT.getText().toString());

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }


    private void hitForgetPassApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(LoginCandidateActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(LoginCandidateActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.FORGET_PASSWORD, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("FORGETRESPONSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status = jsonObject.getString("status");
                    String message = jsonObject.getString("message");
                    if (status.equals("success")) {

                        SharedPreferences sharedPreferences=getSharedPreferences("shared",MODE_PRIVATE);
                        sharedPreferences.edit().putString("employer","candidate").apply();
                      //  sharedPreferences.edit().putString("value", "1").commit();
                        Toast.makeText(LoginCandidateActivity.this, "" + message, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LoginCandidateActivity.this, OtpActivity.class);
                        intent.putExtra("mobile", et_dialog_mob.getText().toString());
                        intent.putExtra("value", "1");
                        startActivity(intent);

                    }else {
                        Toast.makeText(LoginCandidateActivity.this, "" + message, Toast.LENGTH_SHORT).show();


                    }
                } catch (JSONException e) {
                    e.printStackTrace();

                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
            }
        }) {


            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("mobile", et_dialog_mob.getText().toString());


                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }


}
