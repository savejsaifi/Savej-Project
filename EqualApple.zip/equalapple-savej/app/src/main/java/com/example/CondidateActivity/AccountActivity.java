package com.example.CondidateActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Emp_Activity.LoginEmployerActivity;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class AccountActivity extends AppCompatActivity {

    EditText forgetEDT;
    Button submitBTN;
    SessonManager sessonManager;
    String emp_value;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);
        getSupportActionBar().setTitle("Change Password");
        SharedPreferences sharedPreferences1=getSharedPreferences("shared",MODE_PRIVATE);

        emp_value=sharedPreferences1.getString("employer","");
        sessonManager=new SessonManager(AccountActivity.this);

        forgetEDT=findViewById(R.id.edt_forget_password);
        submitBTN=findViewById(R.id.btn_change_password);


        submitBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (forgetEDT.getText().toString().equals("")){
                    forgetEDT.setError("Before enter password");
                }
                else if(forgetEDT.getText().toString().length()<6){
                    forgetEDT.setError("enter 6 digit password");
                }else {
                    hitForgetPssApi();
                }



            }
        });
    }


    private void hitForgetPssApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(AccountActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(AccountActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.UPDATE_PASSWORD, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("FORGETPASS", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String status=jsonObject.getString("status");
                   if(emp_value.equalsIgnoreCase("emp")){
                       Toast.makeText(AccountActivity.this, ""+ status, Toast.LENGTH_SHORT).show();
                       Intent intent = new Intent(AccountActivity.this, LoginEmployerActivity.class).
                               addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                       startActivity(intent);
                   }else {
                       Toast.makeText(AccountActivity.this, ""+ status, Toast.LENGTH_SHORT).show();
                       Intent intent = new Intent(AccountActivity.this, LoginCandidateActivity.class).
                               addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                       startActivity(intent);
                   }



                } catch (JSONException e) {
                    e.printStackTrace();

                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();


            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("fhrete", sessonManager.getToken());
                return headerMap;


            }
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("password", forgetEDT.getText().toString());
                Log.d("CHECKPARMS", String.valueOf(hashMap));

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}
