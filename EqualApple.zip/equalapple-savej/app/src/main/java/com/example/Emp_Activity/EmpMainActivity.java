package com.example.Emp_Activity;


import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.equalapple.DrawerFragment;
import com.example.equalapple.R;

public class EmpMainActivity extends AppCompatActivity {

    private Button btnSearchCandidate;


     @Override
     protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
         setContentView(R.layout.fragment_employer_profile);

        btnSearchCandidate = findViewById(R.id.btnSearchCandidate);


        btnSearchCandidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              //  getSupportFragmentManager().beginTransaction().replace(R.id.container, new DrawerFragment()).addToBackStack(null).commit();
                startActivity(new Intent(getApplicationContext(),MainNavigaton.class));
            }
        });

    }
}
