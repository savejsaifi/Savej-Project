package com.example.Emp_Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.adapter.SearchDetailAdapter;
import com.example.equalapple.R;
import com.example.modelpojo.SearchModel;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SearchDetailActivity extends AppCompatActivity {


    String url;
    SessonManager sessonManager;
    String token;
    ArrayList<SearchModel> searchModelArrayList = new ArrayList<>();
    RecyclerView rvSearch;
    SearchDetailAdapter adapter;
    boolean isScrolling = false;
    int currentitems, totalItems, scrolloutItems;
    RecyclerView.LayoutManager layoutManager;
    ProgressBar prgoessBarDetail;
    SearchModel model2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_detail);
        sessonManager = new SessonManager(SearchDetailActivity.this);
        token = sessonManager.getToken();
        Log.d("weqolmnk", token);
        url = getIntent().getStringExtra("search_url");

        model2 = new SearchModel();
        getSupportActionBar().setTitle("Search Result");


        Log.d("sdawqasd", url);
        rvSearch = findViewById(R.id.rvSearch);
        prgoessBarDetail = findViewById(R.id.prgoessBarDetail);
        layoutManager = new LinearLayoutManager(this);

        getSearchDetailApi(url);
//        rvSearch.addOnScrollListener(new RecyclerView.OnScrollListener() {
//
//            @Override
//            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
//                super.onScrollStateChanged(recyclerView, newState);
//                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
//                    isScrolling = true;
//
//                }
//
//            }
//
//
//            @Override
//            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
//                super.onScrolled(recyclerView, dx, dy);
//                //  prgoessBarDetail.setVisibility(View.VISIBLE);
//
//                currentitems = layoutManager.getChildCount();
//                totalItems = layoutManager.getItemCount();
//                scrolloutItems = ((LinearLayoutManager) layoutManager).findFirstVisibleItemPosition();
//
//                if (isScrolling && (currentitems + scrolloutItems == totalItems)) {
//                    isScrolling = false;
//
//
//                    searchModelArrayList.remove(searchModelArrayList.size() - 1);
//                  //  nextUrl();
//
//
//
//
//                    // Make a networking call to get the data on page scrolled
//
//                    //after you get response
//
//                    String nexturl = model2.getNextUrl();
//                    if(nexturl.contains("null")){
//
//                    }else{
//
//                        Log.d("sfdffwes", nexturl);
//                        getSearchDetailApi(nexturl);
//                    }
//
//
//                }
//
//
//            }
//        });
        requestMultiplePermissions();
        ActivityCompat.requestPermissions(SearchDetailActivity.this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                1);
    }



    private void requestMultiplePermissions() {
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                           // Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {

                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // contacts-related task you need to do.
                } else {

                    // permission denied, boo! Disable the
                    // functionality that depends on this permission.
                    Toast.makeText(SearchDetailActivity.this, "Permission denied to read your External storage", Toast.LENGTH_SHORT).show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }
    private void getSearchDetailApi(final String url) {

       //  searchModelArrayList.clear();
        final ProgressDialog progressDialog = ProgressDialog.show(SearchDetailActivity.this, "", "...Loading", false);

        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responseSearch", response);
                try {
                    progressDialog.dismiss();
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("users");

//                    String nextUrl = jsonObject.getString("next_page_url");
//                    Log.d("sfasqwfqwa", nextUrl);
//                    if(!(nextUrl.equalsIgnoreCase("null"))){
//                        String[] part = nextUrl.split("\\?");
//                        String part1 = part[0];
//                        String part2 = part[1];
//
//                        nextUrl = url + "&" + part2;
//                    }else{
//                        nextUrl = url + "&" + nextUrl;
//                    }
//
//                    model2.setNextUrl(nextUrl);
//                    Log.d("aswqaawqqwxx", nextUrl);


                    for (int i = 0; i < jsonArray.length(); i++) {
                        SearchModel model = new SearchModel();

                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setName(jsonObject1.getString("name"));
                        model.setId(jsonObject1.getString("id"));
                        model.setCategory(jsonObject1.getString("category"));
                        model.setCity(jsonObject1.getString("city"));
                        model.setGender(jsonObject1.getString("gender"));
                        model.setImage(jsonObject1.getString("image"));
                        model.setPdfUrl(jsonObject1.getString("pdf_link"));
                        searchModelArrayList.add(model);
                    }

                    layoutManager = new GridLayoutManager(getApplicationContext(), 1);
                    rvSearch.setLayoutManager(layoutManager);
                    adapter = new SearchDetailAdapter(getApplicationContext(), searchModelArrayList);
                    adapter.notifyDataSetChanged();
                    rvSearch.setAdapter(adapter);



                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(SearchDetailActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Toast.makeText(SearchDetailActivity.this, "" + error, Toast.LENGTH_SHORT).show();
            }
        }) {

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> hashmap = new HashMap<>();
                hashmap.put("Authorization", "Bearer " + token);
                Log.d("asdqwsazasdf", String.valueOf(hashmap));
                return hashmap;
            }
        };
        queue.getCache().clear();
        queue.add(request);
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
//        startActivity(new Intent(getApplicationContext(),FilterFragment.class).
//                addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
}
