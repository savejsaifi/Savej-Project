package com.example.Emp_Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.example.CondidateActivity.AddressActivity;
import com.example.CondidateActivity.HomeActivity;
import com.example.CondidateActivity.LaunchActivity;
import com.example.CondidateActivity.MainActivity;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

public class SplashActivity extends AppCompatActivity {
    SessonManager sessonManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        sessonManager = new SessonManager(SplashActivity.this);

        Log.d("saqwfaasc", sessonManager.getToken());
        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {


                                          if (sessonManager.getToken().length() > 0 && sessonManager.getSessonCanEmp().equalsIgnoreCase("candidate")) {
                                              Intent i = new Intent(SplashActivity.this, HomeActivity.class);
                                              startActivity(i);
                                              finish();
                                          }
                                          else if(sessonManager.getToken().length() > 0 && sessonManager.getSessonCanEmp().equalsIgnoreCase("employee")) {
                                              Intent i = new Intent(SplashActivity.this, MainNavigaton.class);
                                              startActivity(i);
                                              finish();
                                          }
                                          else {
                                              Intent i = new Intent(SplashActivity.this, LaunchActivity.class);
                                              startActivity(i);
                                              finish();
                                          }

                                      }
                                  },
                2000);
    }
}
