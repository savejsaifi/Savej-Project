package com.example.CondidateActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class EducationActivity extends AppCompatActivity {
    ArrayList<EducationModel> arrEducatonList = new ArrayList<>();
    ArrayList<String> arrEducatonListId = new ArrayList<>();
    SessonManager sessonManager;
    Button saveBTN;
    RecyclerView educationRV;


    @Override
    protected void onCreate(@Nullable final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.education);
        getSupportActionBar().setTitle("Education Details");

        hitGetQualificatonApi();

        sessonManager = new SessonManager(EducationActivity.this);
        educationRV = findViewById(R.id.rv_education);

        saveBTN = findViewById(R.id.btn_edu_save);

        saveBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitSetQualification();
            }
        });

    }

    private void hitSetQualification() {
        final ProgressDialog dialog = ProgressDialog.show(EducationActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_QUALIFICATION, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("setqualificaton", response);
                arrEducatonListId.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(EducationActivity.this, MainActivity.class);
                    startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                for (int i = 0; i < arrEducatonListId.size(); i++)
                    hashMap.put("qualifications[" + i + "]", arrEducatonListId.get(i));
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void hitGetQualificatonApi() {
        final ProgressDialog dialog = ProgressDialog.show(EducationActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_QUALIFICATION, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresponse", response);
                arrEducatonList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObjQualification = jsonObject.getJSONObject("qualifications");
                    Iterator<String> keys = jsonObjQualification.keys();

                    while (keys.hasNext()) {
                        String key = keys.next();
                        Log.d("checkidd", key);

                        if (jsonObjQualification.get(key) instanceof JSONObject) {

                            EducationModel educationModel = new EducationModel();

                            educationModel.setKey(key);
                            educationModel.setEducation_id(((JSONObject) jsonObjQualification.get(key)).getString("id"));
                            educationModel.setIsCheked(((JSONObject) jsonObjQualification.get(key)).getString("ischecked"));


                            //Log.d("checkidd", idd);
                            Log.d("logischecked", String.valueOf(arrEducatonList.size()));
                            arrEducatonList.add(educationModel);
                        }


                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(EducationActivity.this, 1);
                    educationRV.setLayoutManager(layoutManager);
                    EducationAdapter adapter = new EducationAdapter(EducationActivity.this, arrEducatonList);
                    educationRV.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(EducationActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    public class EducationAdapter extends RecyclerView.Adapter<EducationAdapter.ViewHolder> {


        private Context context;
        private ArrayList<EducationModel> eduArrList;


        public EducationAdapter(Context context, ArrayList<EducationModel> eduArrList) {
            this.context = context;
            this.eduArrList = eduArrList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.custom_education_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {

            holder.radioBTN.setText(eduArrList.get(position).getKey());
            // holder.radioGrouproupEDU.setTag(position);

            if (eduArrList.get(position).isCheked.equals("1")) {
                holder.radioBTN.setChecked(true);
                String id = eduArrList.get(position).getEducation_id();
                arrEducatonListId.add(id);
                Log.d("dfsfs", "dsfa");
            } else {
                holder.radioBTN.setChecked(false);
                Log.d("dfsfs", "dddsfsdsfa");
            }


        }

        @Override
        public int getItemCount() {
            return eduArrList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            RadioGroup radioGrouproupEDU;
            RadioButton radioBTN;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                radioGrouproupEDU = itemView.findViewById(R.id.radio_group_edu);
                radioBTN = (RadioButton) itemView.findViewById(R.id.radio_btn);


                radioBTN.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (!radioBTN.isSelected()) {
                            String id = eduArrList.get(getAdapterPosition()).getEducation_id();
                            Log.d("checkiddd", id);
                            arrEducatonListId.add(id);

                            radioBTN.setChecked(true);
                            radioBTN.setSelected(true);
                        } else {

                            String id = eduArrList.get(getAdapterPosition()).getEducation_id();
                            arrEducatonListId.removeAll(Collections.singleton(id));
                            Log.d("checkiddd", "dsnfaljkl");
                            radioBTN.setChecked(false);
                            radioBTN.setSelected(false);

                        }


                    }

                });


            }
        }


    }


}
