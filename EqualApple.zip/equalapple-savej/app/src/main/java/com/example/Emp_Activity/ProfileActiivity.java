package com.example.Emp_Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ProfileActiivity extends AppCompatActivity {
    LinearLayout linearLayoutCallNow;
    String id,category;
    CircularImageView imgProfile;
    TextView txtCategory,txtGender,txtExperience,txtSalary,txtDOB,txtLocation,txtName;
    SessonManager sessonManager;
    String token;
    String mobileNo;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.profile_layout);
        getSupportActionBar().setTitle("My Profile");
        sessonManager = new SessonManager(ProfileActiivity.this);
        token = sessonManager.getToken();

        Log.d("weqolmnk", token);

        id = getIntent().getStringExtra("id");
       // category = getIntent().getStringExtra("category");
        Log.d("asdjjwwq",id);
        linearLayoutCallNow=findViewById(R.id.linearCallNow);
        imgProfile=findViewById(R.id.imgProfile);
        txtCategory=findViewById(R.id.txtCategory);
        txtGender=findViewById(R.id.txtGender);
        txtExperience=findViewById(R.id.txtExperience);
        txtSalary=findViewById(R.id.txtSalary);
        txtDOB=findViewById(R.id.txtDOB);
        txtLocation=findViewById(R.id.txtLocation);
        txtName=findViewById(R.id.txtName);
        txtCategory.setText(category);
           hitSearchDetailApi();

//        linearLayoutCallNow.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent=new Intent(ProfileActiivity.this, LoginEmployerActivity.class);
//                startActivity(intent);
//            }
//        });


        linearLayoutCallNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            //    String number = mobileNo;
                Uri call = Uri.parse("tel:" + "9810273789");
                Intent surf = new Intent(Intent.ACTION_DIAL, call);
                startActivity(surf);
            }
        });
    }

    private void hitSearchDetailApi() {
        category="";
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        StringRequest  request = new StringRequest(Request.Method.GET, Consent.getSearchDetail + id, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("sfdjhkfsdhd",response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject userObject = jsonObject.getJSONObject("user");
                    txtName.setText(userObject.getString("name"));
                    txtGender.setText(userObject.getString("gender"));
                    txtSalary.setText(userObject.getString("salary"));

                    String img = userObject.getString("image");
                 //   mobileNo = userObject.getString("mobile");
                    if(img.isEmpty()){
                        Picasso.get().load(R.drawable.amir).into(imgProfile);
                    }else{
                        Picasso.get().load(img).into(imgProfile);
                    }

                    JSONArray skillArray = userObject.getJSONArray("skills");
                    for(int i=0;i<skillArray.length();i++){
                        JSONObject skillObject = skillArray.getJSONObject(i);
                        if(category==""){
                            category = skillObject.getString("name");
                        }
                        else{
                            category = category + ","+skillObject.getString("name");
                        }
                        txtCategory.setText(category);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.getMessage(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> hashmap = new HashMap<>();
                hashmap.put("Authorization", "Bearer " + token);
                Log.d("asdqwsazasdf", String.valueOf(hashmap));
                return hashmap;
            }
        };
        queue.add(request);
    }
}
