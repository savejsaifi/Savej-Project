package com.example.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.equalapple.R;
import com.example.modelpojo.FilterModel;

import java.util.ArrayList;

public class FilterReligionAdapter extends RecyclerView.Adapter<FilterReligionAdapter.FilterHoder> {

    ArrayList<FilterModel> listCategory;
    Context context;
    public FilterReligionAdapter(Context context,ArrayList<FilterModel> listCategory) {
        this.listCategory = listCategory;
        this.context= context;
    }

    @NonNull
    @Override
    public FilterReligionAdapter.FilterHoder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_filter_category,parent,false);
        return new FilterReligionAdapter.FilterHoder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull FilterReligionAdapter.FilterHoder holder, final int position) {
        holder.tv_item.setText(listCategory.get(position).getFilterItem());
        holder.chkSelected.setChecked(listCategory.get(position).isSelected());

        holder.chkSelected.setTag(listCategory.get(position));
        holder.chkSelected.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckBox checkBox = (CheckBox)v;
                FilterModel model = (FilterModel) checkBox.getTag();
                model.setSelected(checkBox.isChecked());
                listCategory.get(position).setSelected(checkBox.isChecked());
            }
        });
    }


    @Override
    public int getItemCount() {
        return listCategory.size();
    }

    public class FilterHoder extends RecyclerView.ViewHolder{
        TextView tv_item;
        CheckBox chkSelected;
        public FilterHoder(@NonNull View itemView) {
            super(itemView);
            tv_item = itemView.findViewById(R.id.tv_item);
            chkSelected = itemView.findViewById(R.id.chkSelected);
        }
    }

    // method to access in activity after updating selection

    public ArrayList<FilterModel> getListReligion(){
        return listCategory;
    }

}

