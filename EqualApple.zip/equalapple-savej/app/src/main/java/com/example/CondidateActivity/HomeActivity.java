package com.example.CondidateActivity;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.Navigation;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.CandidateFragment.CandidateHomeFragment;
import com.example.CandidateFragment.CandidateTermConditionFragment;
import com.example.Util.SessonManager;
import com.example.equalapple.R;
import com.google.android.material.navigation.NavigationView;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


Toolbar toolbar;
DrawerLayout drawer;
SessonManager sessonManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_home);

        sessonManager = new SessonManager(HomeActivity.this);
        CandidateHomeFragment frag = new CandidateHomeFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction =fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frameCandidate,frag);
        fragmentTransaction.commit();

        toolbar = findViewById(R.id.toolbarCadidate);

       // setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawer_layout_candidate);
        NavigationView navigationView = findViewById(R.id.nav_view_candidate);
        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_open,
                R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.white));


        navigationView.getMenu().getItem(0).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(1).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(2).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(3).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(4).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(5).setActionView(R.layout.right_chevron);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        int id = menuItem.getItemId();
        if(id==R.id.nav_home_candidate){
            CandidateHomeFragment fragment = new CandidateHomeFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.replace(R.id.frameCandidate,fragment);
            fragmentTransaction.commit();
        }
        else if(id==R.id.nav_term_candidate){
            CandidateTermConditionFragment fragment = new CandidateTermConditionFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.replace(R.id.frameCandidate,fragment);
            fragmentTransaction.commit();
        }else if(id==R.id.nav_Logout_candidate){
            Toast.makeText(HomeActivity.this, "Log Out Successfully", Toast.LENGTH_SHORT).show();
           String token =  sessonManager.getToken();
           String sessonCanEmp = sessonManager.getSessonCanEmp();
           sessonCanEmp ="";
           token = "";
           sessonManager.setSessonCanEmp(sessonCanEmp);
           sessonManager.setToken(token);
           startActivity(new Intent(getApplicationContext(),LaunchActivity.class).
                   addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        }

        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
