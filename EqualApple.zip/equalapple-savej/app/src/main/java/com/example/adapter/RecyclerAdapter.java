package com.example.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.Emp_Activity.DetailedProfileActivity;
import com.example.modelpojo.Profile_Model;
import com.example.equalapple.R;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ImageHOlder> {


    private Context context;
    private ArrayList<Profile_Model> profileArrayList;


    public RecyclerAdapter(Context context, ArrayList<Profile_Model> profileArrayList) {
        this.context = context;
        this.profileArrayList = profileArrayList;
    }

    @NonNull
    @Override
    public ImageHOlder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate( R.layout.recycler_view_row,parent,false);
        return new ImageHOlder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageHOlder holder, int position) {
        holder.textViewLocation.setText(profileArrayList.get(position).getLocation());
        holder.textViewGender.setText(profileArrayList.get(position).getGender());
        holder.textViewCategory.setText(profileArrayList.get(position).getCategory());
        holder.textViewName.setText(profileArrayList.get(position).getName());
        holder.imageView.setImageResource(profileArrayList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return profileArrayList.size();
    }

    public class ImageHOlder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textViewName,textViewCategory,textViewGender,textViewLocation;
        Button btnDetail;
        public ImageHOlder(@NonNull View itemView) {
            super(itemView);
            textViewName=itemView.findViewById(R.id.textViewName);
            textViewCategory=itemView.findViewById(R.id.textViewCategory);
            textViewGender=itemView.findViewById(R.id.textViewGender);
            textViewLocation=itemView.findViewById(R.id.textViewLocation);
            imageView=itemView.findViewById(R.id.imageViewRecycle);
            btnDetail=itemView.findViewById(R.id.btnViewMore);
            btnDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(context, DetailedProfileActivity.class);
                    context.startActivity(intent);

                }
            });
        }
    }

}
