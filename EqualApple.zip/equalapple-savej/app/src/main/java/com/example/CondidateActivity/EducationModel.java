package com.example.CondidateActivity;

class EducationModel {
    public  String education_id;
    public  String isCheked;
    public  String key;
    public  String exprience;
    public  String skils_id;

    public  String health_id;
    public  String health_discruption;

    public  String family_name;
    public  String family_mob;
    public  String family_id;
    public  String relation;
    public  String lang_id;
    public  String lang_name;

    public String getLang_name() {
        return lang_name;
    }

    public void setLang_name(String lang_name) {
        this.lang_name = lang_name;
    }



    public String getLang_id() {
        return lang_id;
    }

    public void setLang_id(String lang_id) {
        this.lang_id = lang_id;
    }



    public String getRelation() {
        return relation;
    }

    public void setRelation(String relation) {
        this.relation = relation;
    }

    public String getFamily_name() {
        return family_name;
    }

    public void setFamily_name(String family_name) {
        this.family_name = family_name;
    }

    public String getFamily_mob() {
        return family_mob;
    }

    public void setFamily_mob(String family_mob) {
        this.family_mob = family_mob;
    }

    public String getFamily_id() {
        return family_id;
    }

    public void setFamily_id(String family_id) {
        this.family_id = family_id;
    }



    public String getHealth_id() {
        return health_id;
    }

    public void setHealth_id(String health_id) {
        this.health_id = health_id;
    }

    public String getHealth_discruption() {
        return health_discruption;
    }

    public void setHealth_discruption(String health_discruption) {
        this.health_discruption = health_discruption;
    }


    public String getExprience() {
        return exprience;
    }

    public void setExprience(String exprience) {
        this.exprience = exprience;
    }

    public String getSkils_id() {
        return skils_id;
    }

    public void setSkils_id(String skils_id) {
        this.skils_id = skils_id;
    }



    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }


    public String getEducation_id() {
        return education_id;
    }

    public void setEducation_id(String education_id) {
        this.education_id = education_id;
    }

    public String getIsCheked() {
        return isCheked;
    }

    public void setIsCheked(String isCheked) {
        this.isCheked = isCheked;
    }






}
