package com.example.CondidateActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class WorkActivity extends AppCompatActivity {
    Spinner skilsSPIN;
    EditText yearEDT;
    Button addSkilsBTN,submitBTN;
    RecyclerView skilsRV;
    SkillsAdapter adapter;
    SessonManager sessonManager;
    ArrayList<EducationModel> arrSkilsList=new ArrayList<>();
    ArrayList<String> arrKeyNameList=new ArrayList<>();
    ArrayList<EducationModel> arrKeyIDList=new ArrayList<>();

    String skills_spin_id,skilsID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work);

        sessonManager = new SessonManager(WorkActivity.this);

        skilsSPIN=findViewById(R.id.spin_skils);
        yearEDT=findViewById(R.id.edt_skils);
        addSkilsBTN=findViewById(R.id.btn_add_skils);
        skilsRV=findViewById(R.id.rv_skils);

        addSkilsBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitSetSkilsApi();

            }
        });

        skilsSPIN.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                skills_spin_id = arrKeyIDList.get(i).getSkils_id();
               // skills_spin_id = String.valueOf(skilsSPIN.getSelectedItemId());
                Log.d("dnsaklj",skills_spin_id);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        hitGetSkilsApi();

    }

    public class SkillsAdapter extends RecyclerView.Adapter<SkillsAdapter.ViewHolder> {


        private Context context;
        private ArrayList<EducationModel> skilsArrList;


        public SkillsAdapter(Context context, ArrayList<EducationModel> skilsArrList) {
            this.context = context;
            this.skilsArrList = skilsArrList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.custom_skils_layout, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {


            if (skilsArrList.get(position).getIsCheked().equals("1")) {
                holder.skilsNameTV.setText(skilsArrList.get(position).getKey());
                holder.skilsYearTV.setText(skilsArrList.get(position).getExprience() +" Year");
            }else {
                holder.skilsNameTV.setVisibility(View.GONE);
                holder.skilsYearTV.setVisibility(View.GONE);
                holder.removeIMG.setVisibility(View.GONE);
            }


        }

        @Override
        public int getItemCount() {
            return skilsArrList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

           TextView skilsNameTV,skilsYearTV;
           ImageView removeIMG;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                skilsNameTV=itemView.findViewById(R.id.tv_skils_name);
                skilsYearTV=itemView.findViewById(R.id.tv_skils_year);
                removeIMG=itemView.findViewById(R.id.image_skils_remove);

                removeIMG.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        skilsID=skilsArrList.get(getAdapterPosition()).getSkils_id();
                        //removeAt(getPosition());
                        hitDeleteSkilsApi();
                    }
                });


            }

            public void removeAt(int position) {
                skilsArrList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, skilsArrList.size());
            }
        }


    }

    private void hitSetSkilsApi() {
        final ProgressDialog dialog = ProgressDialog.show(WorkActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_SKILLS, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("SKILSRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetSkilsApi();

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(WorkActivity.this, MainActivity.class);
                   // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                    hashMap.put("skill",skills_spin_id);
                    hashMap.put("experience",yearEDT.getText().toString());
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


    private void hitDeleteSkilsApi() {
        final ProgressDialog dialog = ProgressDialog.show(WorkActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.DELETE_SKILLS, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("DELETESKILSRESPNSE", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    hitGetSkilsApi();
                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                    //Intent intent = new Intent(WorkActivity.this, MainActivity.class);
                    // startActivity(intent);


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("skill",skilsID);

                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }



    private void hitGetSkilsApi() {
        final ProgressDialog dialog = ProgressDialog.show(WorkActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_SKILLS, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresponse", response);
                arrSkilsList.clear();
                arrKeyNameList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObjQualification = jsonObject.getJSONObject("skills");
                    Iterator<String> keys = jsonObjQualification.keys();

                    while (keys.hasNext()) {
                        String key = keys.next();
                        Log.d("checkidd", key);

                        if (jsonObjQualification.get(key) instanceof JSONObject) {
                            EducationModel  educationModel = new EducationModel();

                            educationModel.setKey(key);
                            arrKeyNameList.add(key);
                            arrKeyIDList.add(educationModel);

                            educationModel.setSkils_id(((JSONObject) jsonObjQualification.get(key)).getString("id"));
                            educationModel.setExprience(((JSONObject) jsonObjQualification.get(key)).getString("experience"));
                            educationModel.setIsCheked(((JSONObject) jsonObjQualification.get(key)).getString("ischecked"));

                            Log.d("logischecked", String.valueOf(arrSkilsList.size()));
                            arrSkilsList.add(educationModel);


                            ArrayAdapter skilsAdpater = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item,arrKeyNameList);
                            skilsAdpater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                            skilsSPIN.setAdapter(skilsAdpater);
                        }


                    }
                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(WorkActivity.this, 1);
                    skilsRV.setLayoutManager(layoutManager);
                    adapter = new SkillsAdapter(WorkActivity.this, arrSkilsList);
                    skilsRV.setAdapter(adapter);

                } catch (JSONException e) {
                                                                                                                                                        e.printStackTrace();
                    Toast.makeText(WorkActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }



}
