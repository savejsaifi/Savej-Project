package com.example.Util;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.Emp_Activity.ProfileActiivity;
import com.example.equalapple.R;

public class drawer extends AppCompatActivity implements View.OnClickListener {

     RelativeLayout relativeLayoutCategory;
     LinearLayout linearLayoutCategoryDetail;
     TextView textViewCategory;

    RelativeLayout relativeLayoutLocation;
    LinearLayout linearLayoutLocationDetail;
    TextView textViewLocation;

    CardView cardViewClear;

    RelativeLayout relativeLayoutGender;
    LinearLayout linearLayoutGenderDetail;
    TextView textViewGender;


    RelativeLayout relativeLayoutQualification;
    LinearLayout linearLayoutQualificationDetail;
    TextView textViewQualification;

   RelativeLayout relativeLayoutLangauge;
    LinearLayout linearLayoutLanguageDetail;
    TextView textViewLAnguage;


    RelativeLayout relativeLayoutExperience;
    LinearLayout linearLayoutExperienceDetail;
    TextView textViewExperience;


    RelativeLayout relativeLayoutReligion;
    LinearLayout linearLayoutReligionDetail;
    TextView textViewReligion;



    RelativeLayout relativeLayoutSalary;
    LinearLayout linearLayoutSalaryDetail;
    TextView textViewSalary;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_drawer);


        cardViewClear=findViewById(R.id.cardViewClear);


        relativeLayoutCategory =findViewById(R.id.category);
       linearLayoutCategoryDetail=findViewById(R.id.linearLayoutCategoryDetail);
       textViewCategory=findViewById(R.id.textViewCategory);


         relativeLayoutLocation =findViewById(R.id.location);
         linearLayoutLocationDetail=findViewById(R.id.linearLayoutLocationDetail);
        textViewLocation=findViewById(R.id.textViewLocation);

        relativeLayoutGender =findViewById(R.id.gender);
        linearLayoutGenderDetail=findViewById(R.id.linearLayoutGenderDetail);
        textViewGender=findViewById(R.id.textViewGender);


        relativeLayoutQualification =findViewById(R.id.qualification);
        linearLayoutQualificationDetail=findViewById(R.id.linearLayoutQualificationDetail);
        textViewQualification=findViewById(R.id.textViewQualification);


        relativeLayoutLangauge =findViewById(R.id.language);
        linearLayoutLanguageDetail=findViewById(R.id.linearLayoutLanguageDetail);
        textViewLAnguage=findViewById(R.id.textViewLanguage);


        relativeLayoutExperience =findViewById(R.id.experience);
        linearLayoutExperienceDetail=findViewById(R.id.linearLayoutExperienceDetail);
        textViewExperience=findViewById(R.id.textViewExperience);


        relativeLayoutReligion =findViewById(R.id.religion);
        linearLayoutReligionDetail=findViewById(R.id.linearLayoutReligionDetail);
        textViewReligion=findViewById(R.id.textViewReligion);



        relativeLayoutSalary =findViewById(R.id.salary);
        linearLayoutSalaryDetail=findViewById(R.id.linearLayoutSalaryDetail);
        textViewSalary=findViewById(R.id.textViewSalary);




        relativeLayoutCategory.setOnClickListener(this);
        relativeLayoutLocation.setOnClickListener(this);
        relativeLayoutGender.setOnClickListener(this);
        relativeLayoutQualification.setOnClickListener(this);
        relativeLayoutLangauge.setOnClickListener(this);
        relativeLayoutExperience.setOnClickListener(this);
        relativeLayoutReligion.setOnClickListener(this);
        relativeLayoutSalary.setOnClickListener(this);



        cardViewClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(drawer.this, ProfileActiivity.class);
                startActivity(intent);
            }
        });


    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){

            case R.id.category:
                linearLayoutCategoryDetail.setVisibility(View.VISIBLE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                break;


            case R.id.location:
                linearLayoutLocationDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                break;

            case R.id.gender:
                linearLayoutGenderDetail.setVisibility(View.VISIBLE);
                textViewGender.setTextColor(getResources().getColor(R.color.blackText));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.white));
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                break;

            case R.id.qualification:
                linearLayoutQualificationDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewQualification.setTextColor(getResources().getColor(R.color.blackText));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                break;


            case R.id.language:
               linearLayoutLanguageDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.blackText));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                break;


            case R.id.experience:
                linearLayoutExperienceDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                //linearLayoutLanguageDetail.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewExperience.setTextColor(getResources().getColor(R.color.blackText));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));


                break;

            case R.id.religion:
                linearLayoutReligionDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                linearLayoutExperienceDetail.setVisibility(View.GONE);
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewReligion.setTextColor(getResources().getColor(R.color.blackText));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));

                break;



            case R.id.salary:
                linearLayoutSalaryDetail.setVisibility(View.VISIBLE);
                linearLayoutCategoryDetail.setVisibility(View.GONE);
                linearLayoutLocationDetail.setVisibility(View.GONE);
                linearLayoutGenderDetail.setVisibility(View.GONE);
                linearLayoutQualificationDetail.setVisibility(View.GONE);
                linearLayoutLanguageDetail.setVisibility(View.GONE);
                linearLayoutExperienceDetail.setVisibility(View.GONE);
                linearLayoutReligionDetail.setVisibility(View.GONE);
                relativeLayoutSalary.setBackgroundColor(getResources().getColor(R.color.white));
                relativeLayoutReligion.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutCategory.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLocation.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutGender.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutQualification.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutExperience.setBackgroundColor(getResources().getColor(R.color.blue));
                relativeLayoutLangauge.setBackgroundColor(getResources().getColor(R.color.blue));
                textViewSalary.setTextColor(getResources().getColor(R.color.blackText));
                textViewReligion.setTextColor(getResources().getColor(R.color.white));
                textViewExperience.setTextColor(getResources().getColor(R.color.white));
                textViewCategory.setTextColor(getResources().getColor(R.color.white));
                textViewLAnguage.setTextColor(getResources().getColor(R.color.white));
                textViewLocation.setTextColor(getResources().getColor(R.color.white));
                textViewGender.setTextColor(getResources().getColor(R.color.white));
                textViewQualification.setTextColor(getResources().getColor(R.color.white));





        }

    }
}
