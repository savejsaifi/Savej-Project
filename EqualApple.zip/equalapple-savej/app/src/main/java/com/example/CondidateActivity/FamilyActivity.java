package com.example.CondidateActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FamilyActivity extends AppCompatActivity {

    Spinner familySPIN;
    EditText nameEDT,mobileEDT;
    Button addfamilyBTN;
    RecyclerView familyRV;
    FamilyAdapter adapter;
    SessonManager sessonManager;
    ArrayList<EducationModel> arrfamilyList=new ArrayList<>();
    ArrayList<String> arrKeyNameList=new ArrayList<>();


    String family_spin_name,familyID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_family);

        sessonManager = new SessonManager(FamilyActivity.this);

        familySPIN=findViewById(R.id.spiner_family);
        nameEDT=findViewById(R.id.edt_name_family);
        mobileEDT=findViewById(R.id.edt_mobile_family);
        addfamilyBTN=findViewById(R.id.btn_add_family);
        familyRV=findViewById(R.id.rv_family);

        addfamilyBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitSetfamilyApi();

            }
        });

        familySPIN.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                family_spin_name = String.valueOf(familySPIN.getSelectedItem());
                Log.d("dnsaklj",family_spin_name);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        hitGetfamilyApi();
    }

    public class FamilyAdapter extends RecyclerView.Adapter<FamilyAdapter.ViewHolder> {


        private Context context;
        private ArrayList<EducationModel> familyArrList;


        public FamilyAdapter(Context context, ArrayList<EducationModel> familyArrList) {
            this.context = context;
            this.familyArrList = familyArrList;
        }

        @NonNull
        @Override
        public FamilyAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.custom_family_layout, parent, false);
            return new FamilyAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final FamilyAdapter.ViewHolder holder, int position) {
            holder.familyKeyNameTV.setText(familyArrList.get(position).getRelation());
            holder.familyNameTV.setText(familyArrList.get(position).getFamily_name());
            holder.familyMobTV.setText(familyArrList.get(position).getFamily_mob());


        }

        @Override
        public int getItemCount() {
            return familyArrList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView familyNameTV,familyMobTV,familyKeyNameTV;
            ImageView removeIMG;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                familyKeyNameTV=itemView.findViewById(R.id.tv_family_relation);
                familyNameTV=itemView.findViewById(R.id.tv_family_name);
                familyMobTV=itemView.findViewById(R.id.tv_family_mobile);
                removeIMG=itemView.findViewById(R.id.image_family_remove);

                removeIMG.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        familyID=familyArrList.get(getAdapterPosition()).getFamily_id();
                        hitDeleteFamilyApi();
                    }
                });

            }

        }


    }

    private void hitSetfamilyApi() {
        final ProgressDialog dialog = ProgressDialog.show(FamilyActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.SET_FAMILY, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("familyrespons", response);

                try {
                    JSONObject jsonObject = new JSONObject(response);
                    //String message = jsonObject.getString("message");
                    hitGetfamilyApi();

                   // Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("relation",family_spin_name);
                hashMap.put("name",nameEDT.getText().toString());
                hashMap.put("mobile",mobileEDT.getText().toString());
                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


    private void hitDeleteFamilyApi() {
        final ProgressDialog dialog = ProgressDialog.show(FamilyActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.DELETE_FAMILY, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("DELETEFAMIlYRESPNSE", response);   

                try {
                    JSONObject jsonObject = new JSONObject(response);
                   // String message = jsonObject.getString("message");
                    hitGetfamilyApi();

                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Toast.makeText(OtpActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                hashMap.put("family",familyID);

                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }



    private void hitGetfamilyApi() {
        final ProgressDialog dialog = ProgressDialog.show(FamilyActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_FAMILY, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresponse", response);
                arrfamilyList.clear();
                arrKeyNameList.clear();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArrkeys=jsonObject.getJSONArray("keys");
                    for (int i=0; i < jsonArrkeys.length(); i++) {
                        String keys=jsonArrkeys.getString(i);
                        arrKeyNameList.add(keys);
                    }

                    ArrayAdapter familyAdpater = new ArrayAdapter(getApplicationContext(),android.R.layout.simple_spinner_item,arrKeyNameList);
                    familyAdpater.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    familySPIN.setAdapter(familyAdpater);

                    JSONArray jsonArrFamily=jsonObject.getJSONArray("family");

                    for (int i=0; i <jsonArrFamily.length(); i++){
                        JSONObject jsonObjFamily=jsonArrFamily.getJSONObject(i);
                        EducationModel  educationModel = new EducationModel();
                        educationModel.setFamily_id(jsonObjFamily.getString("id"));
                        educationModel.setFamily_name(jsonObjFamily.getString("name"));
                        educationModel.setFamily_mob(jsonObjFamily.getString("mobile"));
                        educationModel.setRelation(jsonObjFamily.getString("relation"));
                        Log.d("cccvsadda", String.valueOf(arrfamilyList.size()));
                        arrfamilyList.add(educationModel);


                    }



                    RecyclerView.LayoutManager layoutManager = new GridLayoutManager(FamilyActivity.this, 1);
                    familyRV.setLayoutManager(layoutManager);
                    adapter = new FamilyAdapter(FamilyActivity.this, arrfamilyList);
                    familyRV.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(FamilyActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


}
