package com.example.equalapple;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.adapter.RecyclerAdapter;
import com.example.modelpojo.Profile_Model;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FagmentResult extends Fragment {

    View view;
    private RecyclerView recyclerView;
    private RecyclerAdapter recyclerAdapter;
    private ArrayList<Profile_Model> profileArrayList;

    public FagmentResult() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_fagment_result, container, false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().show();
        recyclerView=view.findViewById(R.id.recyclerView);
        profileArrayList=new ArrayList<>();

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false));
        profileArrayList.add(new Profile_Model("Person","Category","Male","Delhi",R.drawable.images));
        profileArrayList.add(new Profile_Model("Person","Category","Male","Delhi",R.drawable.images));
        profileArrayList.add(new Profile_Model("Person","Category","Male","Delhi",R.drawable.images));
        profileArrayList.add(new Profile_Model("Person","Category","Male","Delhi",R.drawable.images));

        recyclerAdapter=new RecyclerAdapter(getContext(),profileArrayList);
        recyclerView.setAdapter(recyclerAdapter);
        return view;
    }

}
