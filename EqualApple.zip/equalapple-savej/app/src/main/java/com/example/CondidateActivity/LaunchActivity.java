package com.example.CondidateActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.Emp_Activity.LoginEmployerActivity;
import com.example.equalapple.R;

public class LaunchActivity extends AppCompatActivity {

    private Button btnEmploye,btnCandidate;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.launch_activity);
        btnEmploye=findViewById(R.id.btnEmployer);
        btnCandidate=findViewById(R.id.btnCandidate);

        btnEmploye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(LaunchActivity.this, LoginEmployerActivity.class);
                startActivity(intent);

            }
        });

        btnCandidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent=new Intent(LaunchActivity.this, LoginCandidateActivity.class);
            startActivity(intent);
            }
        });


    }
}
