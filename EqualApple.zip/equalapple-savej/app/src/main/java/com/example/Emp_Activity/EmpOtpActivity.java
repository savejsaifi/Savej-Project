package com.example.Emp_Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.alimuzaffar.lib.pin.PinEntryEditText;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class EmpOtpActivity extends AppCompatActivity {
    PinEntryEditText otpEDT;
    Button submitBTN;
    SessonManager sessonManager;
    private String mobile_number;
    private TextView numberTV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emp_otp);

        sessonManager = new SessonManager(EmpOtpActivity.this);

        otpEDT = findViewById(R.id.pin_otp);
        submitBTN = findViewById(R.id.btnOtpSubmit);
        numberTV = findViewById(R.id.tv_mobile);

        mobile_number = getIntent().getStringExtra("mobile");
        Log.d("checkmobile",mobile_number);
        numberTV.setText("+91 " + "We have sent you a SMS on " + mobile_number);

        submitBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (otpEDT.getText().toString().equals("")) {
                    Toast.makeText(EmpOtpActivity.this, "Please enter valid OTP", Toast.LENGTH_SHORT).show();
                } else {

                    hitUrlForOtp();
                }


            }
        });
        hitUrlForOtp();

    }

    private void hitUrlForOtp() {
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.OTP_VERIFY, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("chekclohin", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);

                    String message = jsonObject.getString("message");
                    String token = jsonObject.getString("token");
                    sessonManager.setToken(token);

                    Toast.makeText(getApplicationContext(), "" + message, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(EmpOtpActivity.this, MainNavigaton.class);
                        intent.putExtra("mobile", mobile_number);
                        startActivity(intent);




                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();
                    hashMap.put("mobile", mobile_number);
                    hashMap.put("otp", otpEDT.getText().toString());
                    hashMap.put("type", "reset");


                Log.d("checkparams", hashMap.toString());
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }
}
