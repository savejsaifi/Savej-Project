package com.example.CondidateActivity;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;

import com.example.equalapple.R;

public class ApprovalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_approval);
      //  getSupportActionBar().setTitle("Your Status");
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbar);

        PopDownloadPDF();
    }
    private void PopDownloadPDF() {

            LayoutInflater inflater = LayoutInflater.from(ApprovalActivity.this);
            final Dialog mDialogConfirmPopUp = new Dialog(ApprovalActivity.this,
                    android.R.style.Theme_Translucent_NoTitleBar);

            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
            lp.dimAmount = 0.75f;
            mDialogConfirmPopUp.getWindow()
                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialogConfirmPopUp.getWindow();

            View dialoglayout = inflater.inflate(R.layout.pop_donwload, null);
            mDialogConfirmPopUp.setContentView(dialoglayout);

            Button btn_ok_pop_down_out_line = (Button) mDialogConfirmPopUp.findViewById(R.id.btn_ok_pop_down_out_line);
            btn_ok_pop_down_out_line.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   startActivity(new Intent(getApplicationContext(),HomeActivity.class)
                   .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                }
            });
            mDialogConfirmPopUp.show();
            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.setCancelable(false);

    }
}
