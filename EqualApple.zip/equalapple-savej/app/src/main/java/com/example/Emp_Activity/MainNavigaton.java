package com.example.Emp_Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import com.example.CondidateActivity.LaunchActivity;
import com.example.Emp_Activity.ui.gallery.GalleryFragment;
import com.example.Emp_Activity.ui.send.SendFragment;
import com.example.Util.SessonManager;
import com.example.equalapple.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Toast;

public class MainNavigaton extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;
SessonManager sessonManager;
     DrawerLayout drawer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_navigaton);
        Toolbar toolbar = findViewById(R.id.toolbar);
        sessonManager = new SessonManager(MainNavigaton.this);



        setSupportActionBar(toolbar);
//        FloatingActionButton fab = findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
////                        .setAction("Action", null).show();
//
//                startActivity(new Intent(getApplicationContext(),FilterFragment.class));
//            }
//        });
       drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.getMenu().getItem(0).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(0).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                drawer.closeDrawer(Gravity.LEFT);
                SendFragment fragment = new SendFragment();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.replace(R.id.frame,fragment);
                fragmentTransaction.commit();

                return true;
            }
        });

        navigationView.getMenu().getItem(1).setActionView(R.layout.right_chevron);

        navigationView.getMenu().getItem(1).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                drawer.closeDrawer(Gravity.LEFT);
                GalleryFragment fragment = new GalleryFragment();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.replace(R.id.frame,fragment);
                fragmentTransaction.commit();

                return true;
            }
        });
        navigationView.getMenu().getItem(2).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(3).setActionView(R.layout.right_chevron);
        navigationView.getMenu().getItem(4).setActionView(R.layout.right_chevron);

        navigationView.getMenu().getItem(4).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                Toast.makeText(MainNavigaton.this, "Log Out Successfully", Toast.LENGTH_SHORT).show();
                String token = sessonManager.getToken();
                String sessonCanEmp = sessonManager.getSessonCanEmp();
                sessonCanEmp ="";
                token = "";
                sessonManager.setSessonCanEmp(sessonCanEmp);
                sessonManager.setToken(token);
                startActivity(new Intent(getApplicationContext(), LaunchActivity.class).
                        addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return true;
            }
        });

        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_send,  R.id.nav_home, R.id.nav_gallery, R.id.nav_slideshow,
                R.id.nav_share)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_navigaton, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @SuppressLint("WrongConstant")
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        drawer.closeDrawer(Gravity.START);
    }
}
