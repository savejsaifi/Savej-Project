package com.example.CondidateActivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.Util.VolleyMultipartRequest;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ResumeActivity extends AppCompatActivity {
    public static final int REQUEST_IMAGE_CAPTURE = 1;
    public static final int SELECT_IMAGE = 2;
    public Dialog mDialog;
    ImageView crossIMG;
    Bitmap bitmapResumeURL;
     SessonManager sessonManager;
    String url;
    TextView resumeURL,chooseResume;
    Button resumeViewBTN,sendBTN;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resume);
        getSupportActionBar().setTitle("Resume");

        sessonManager = new SessonManager(ResumeActivity.this);
        mDialog = new Dialog(this);
       // resumeURL=findViewById(R.id.tv_resume_url);
        chooseResume=findViewById(R.id.tv_choose_doc);
        resumeViewBTN=findViewById(R.id.btn_view_resume);
        sendBTN=findViewById(R.id.btn_send_resume);


        chooseResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });

        sendBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitUploadResumeApi();
            }
        });
        resumeViewBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(ResumeActivity.this, ResumeImageZoom.class);
                intent.putExtra("image",url);
                startActivity(intent);
            }
        });


        hitGetResumeApi();


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
      /*  if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            bitmapResumeURL = (Bitmap) extras.get("data");
            bitmapResumeURL = Bitmap.createScaledBitmap(bitmapResumeURL, 800, 800, false);

            //imageviewProfile.setImageBitmap(bitmapResumeURL);
        }
*/
        if (requestCode == SELECT_IMAGE && resultCode == RESULT_OK) {
            if (data != null) {
                try {
                    bitmapResumeURL = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    bitmapResumeURL = Bitmap.createScaledBitmap(bitmapResumeURL, 800, 800, false);
                    Log.d("checkbtimap", String.valueOf(bitmapResumeURL));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }


    private void hitUploadResumeApi() {
        final ProgressDialog dialog = ProgressDialog.show(ResumeActivity.this, "", "Loading", false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Consent.SET_DOC, new Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("docresponse", String.valueOf(response.data));

                dialog.dismiss();

                Toast.makeText(getApplicationContext(), "User image has been uploaded" , Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(ResumeActivity.this, MainActivity.class);
                startActivity(intent);

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("fhrete", sessonManager.getToken());
                return headerMap;


            }

            @Override
            protected Map<String, VolleyMultipartRequest.DataPart> getByteData() {
                Map<String, VolleyMultipartRequest.DataPart> params = new HashMap<>();
                VolleyMultipartRequest.DataPart dataPartUserImg = new VolleyMultipartRequest.DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(ResumeActivity.this, bitmapResumeURL));

                params.put("document", dataPartUserImg);
                Log.d("picture", String.valueOf(params));
                return params;


            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(ResumeActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    public byte[] convertBitmapToByteArray(Context context, Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, buffer);
        return buffer.toByteArray();
    }

    private void hitGetResumeApi(){
        final ProgressDialog dialog = ProgressDialog.show(ResumeActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_DOC, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("getresumeresponse", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    url = jsonObject.getString("url");


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(ResumeActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }






    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                showGallery();
                                break;
                            case 1:
                                //showCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }


    private void showCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
    }

    private void showGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_IMAGE);
    }


}
