package com.example.Config;

public class Consent {

    public static String BASE_URL="http://equalapple.appoffice.xyz/api/";

    public static String LOGIN=BASE_URL +"login";
    public static String REGISTER=BASE_URL +"register";
    public static String OTP_VERIFY=BASE_URL +"verify-otp";
    public static String FORGET_PASSWORD=BASE_URL +"forgot-password";
    public static String GET_ADDRESS=BASE_URL +"get-address";
    public static String SET_ADDRESS=BASE_URL +"set-address";
    public static String SET_CONTACT=BASE_URL +"set-contact";
    public static String GET_CONTACT=BASE_URL +"get-contact";
    public static String SET_QUALIFICATION=BASE_URL +"set-qualification";
    public static String GET_QUALIFICATION=BASE_URL +"get-qualification";
    public static String SET_IMAGE=BASE_URL +"set-image";
    public static String GET_IMAGE=BASE_URL +"get-image";
    public static String SET_DOC=BASE_URL +"set-doc";
    public static String GET_DOC=BASE_URL +"get-doc";
    public static String GET_SKILLS=BASE_URL +"get-skills";
    public static String SET_SKILLS=BASE_URL +"set-skills";
    public static String DELETE_SKILLS=BASE_URL +"delete-skills";
    public static String GET_HEALTH=BASE_URL +"get-health";
    public static String SET_HEALTH=BASE_URL +"set-health";
    public static String DELETE_HEALTH=BASE_URL +"delete-health";
    public static String GET_FAMILY=BASE_URL +"get-family";
    public static String SET_FAMILY=BASE_URL +"set-family";
    public static String DELETE_FAMILY=BASE_URL +"delete-family";
    public static String GET_LANG=BASE_URL +"get-language";
    public static String SET_LANG=BASE_URL +"set-language";
    public static String DELETE_LANG=BASE_URL +"delete-language";
    public static String empTermCond= "http://equalapple.appoffice.xyz/term/term.php";


    public static String UPDATE_PASSWORD=BASE_URL +"update-password";


    //////////////////employer Api //////////////////////////

    public static String getFilterItem = "http://equalapple.appoffice.xyz/api/get-filters";
    public static String getSearchItem = "http://equalapple.appoffice.xyz/api/search?";
    public static String getSearchDetail = "http://equalapple.appoffice.xyz/api/search-details/";


}
