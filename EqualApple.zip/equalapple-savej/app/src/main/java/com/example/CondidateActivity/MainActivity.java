package com.example.CondidateActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.SessonManager;
import com.example.Util.VolleyMultipartRequest;
import com.example.equalapple.R;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    public static final int REQUEST_IMAGE_CAPTURE = 1;
    public static final int SELECT_IMAGE = 2;
    public Dialog mDialog;
    // private ImageView imageViewEdit;
    CircularImageView imageviewProfile;
    Bitmap bitmapProfile;
    SessonManager sessonManager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sessonManager = new SessonManager(MainActivity.this);

        LinearLayout contactLisnner = findViewById(R.id.liner_contact);
        LinearLayout educationtLisnner = findViewById(R.id.liner_education);
        LinearLayout addressLisnner = findViewById(R.id.liner_address);
        LinearLayout accountLisnner = findViewById(R.id.liner_acount);
        LinearLayout uploadIMAGE = findViewById(R.id.liner_upload_image);
        LinearLayout uploadResume = findViewById(R.id.liner_resume);
        LinearLayout work = findViewById(R.id.liner_work);
        LinearLayout health = findViewById(R.id.liner_health);
        LinearLayout family = findViewById(R.id.liner_family);
        LinearLayout language = findViewById(R.id.liner_language);


        imageviewProfile = findViewById(R.id.iv_image_upload);

//
//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
//                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            ActivityCompat.requestPermissions(this, new String[]{
//                    Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
//


            mDialog = new Dialog(this);

        uploadIMAGE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                hitUpdateImsgeApi();
            }
        });

        imageviewProfile.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View view) {
                showPictureDialog();
            }
        });

        contactLisnner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, ContactusActivity.class));
            }
        });
        educationtLisnner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, EducationActivity.class));
            }
        });

        addressLisnner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AddressActivity.class));
            }
        });
        accountLisnner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AccountActivity.class));
            }
        });

        uploadResume.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, ResumeActivity.class));
            }
        });

        work.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, WorkActivity.class));
            }
        });

        health.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, HealthActivity.class));
            }
        });
        family.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, FamilyActivity.class));
            }
        });

        language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, LanguageActivity.class));
            }
        });



        hitGetImageApi();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            bitmapProfile = (Bitmap) extras.get("data");
            bitmapProfile = Bitmap.createScaledBitmap(bitmapProfile, 800, 800, false);
            imageviewProfile.setImageBitmap(bitmapProfile);
        }

        if (requestCode == SELECT_IMAGE && resultCode == RESULT_OK) {
            if (data != null) {
                try {
                    bitmapProfile = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    bitmapProfile = Bitmap.createScaledBitmap(bitmapProfile, 800, 800, false);
                    imageviewProfile.setImageBitmap(bitmapProfile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

        private void hitUpdateImsgeApi() {
            final ProgressDialog dialog = ProgressDialog.show(MainActivity.this, "", "Loading", false);
            VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Consent.SET_IMAGE, new Response.Listener<NetworkResponse>() {
                @Override
                public void onResponse(NetworkResponse response) {
                    Log.d("networkresponse", String.valueOf(response.data));

                    dialog.dismiss();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headerMap = new HashMap<String, String>();
                    headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                    Log.d("fhrete", sessonManager.getToken());
                    return headerMap;


                }

                @Override
                protected Map<String, VolleyMultipartRequest.DataPart> getByteData() {
                    Map<String, VolleyMultipartRequest.DataPart> params = new HashMap<>();

                    VolleyMultipartRequest.DataPart dataPartUserImg = new VolleyMultipartRequest.DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(MainActivity.this, bitmapProfile));

                    params.put("image", dataPartUserImg);
                    Log.d("picture", String.valueOf(params));
                    return params;


                }

            };
            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            requestQueue.getCache().clear();
            requestQueue.add(request);
        }


        public byte[] convertBitmapToByteArray(Context context, Bitmap bitmap) {
            ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, buffer);
            return buffer.toByteArray();
        }

    private void hitGetImageApi(){
        final ProgressDialog dialog = ProgressDialog.show(MainActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, Consent.GET_IMAGE, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();

                Log.d("imagerespnse", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String image = jsonObject.getString("url");
                    if(image.isEmpty()){
                        imageviewProfile.setImageResource(R.drawable.images);
                    }else {
                        Picasso.get().load(image).into(imageviewProfile);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {


            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("Authorization", "Bearer " + sessonManager.getToken());
                Log.d("rfgdfdf", String.valueOf(sessonManager.getToken()));
                return headerMap;
            }


        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }


    private void showPictureDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                showGallery();
                                break;
                            case 1:
                                showCamera();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }


    private void showCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, REQUEST_IMAGE_CAPTURE);
    }

    private void showGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), SELECT_IMAGE);
    }


}
