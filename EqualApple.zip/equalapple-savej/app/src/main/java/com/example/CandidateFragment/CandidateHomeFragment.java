package com.example.CandidateFragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.example.CondidateActivity.ApprovalActivity;
import com.example.CondidateActivity.HomeActivity;
import com.example.CondidateActivity.MainActivity;
import com.example.equalapple.R;


public class CandidateHomeFragment extends Fragment {

View view;
    public CandidateHomeFragment() {
        // Required empty public constructor
    }
 CardView cardApproval;
    LinearLayout linearLayoutProfile;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_candidate_home, container, false);

        linearLayoutProfile=view.findViewById(R.id.linearLayoutProfile);
        cardApproval=view.findViewById(R.id.cardApproval);
        linearLayoutProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getActivity(), MainActivity.class);
                startActivity(intent);
            }
        });

        cardApproval.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(getActivity(), ApprovalActivity.class));
            }
        });
        return view;
    }


}
