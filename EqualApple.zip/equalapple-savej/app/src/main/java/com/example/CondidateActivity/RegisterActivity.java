package com.example.CondidateActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.Config.Consent;
import com.example.Util.CheckNetwork;
import com.example.equalapple.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private Button btnRegister;
    ImageView arrowimg;
    public EditText nameEDT,mobileEDT,emailEDT,passwordEDT,confirmPassEDT,tpidEDT;
    public String emp_value;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView( R.layout.activity_register);


        nameEDT=findViewById(R.id.edt_name);
        mobileEDT=findViewById(R.id.edt_mobile);
        emailEDT=findViewById(R.id.edt_email);
        passwordEDT=findViewById(R.id.edt_password);
        confirmPassEDT=findViewById(R.id.edt_confirm_password);
        tpidEDT=findViewById(R.id.tpidEDT);


        SharedPreferences sharedPreferences=getSharedPreferences("shared",MODE_PRIVATE);
        emp_value=sharedPreferences.getString("employer","");
         if(!emp_value.equalsIgnoreCase("emp")){
             tpidEDT.setVisibility(View.VISIBLE);
         }else {
             tpidEDT.setVisibility(View.GONE);
         }

        btnRegister=findViewById(R.id.btnSubmitRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (CheckNetwork.isInternetAvailable(RegisterActivity.this)) //returns true if internet available
                {
                    if (nameEDT.getText().toString().equals("")){
                        nameEDT.setError("Enter name");
                    }else  if (mobileEDT.getText().toString().equals("")){
                        mobileEDT.setError("Enter valid mobile no.");
                    }else  if (passwordEDT.getText().toString().equals("")){
                        passwordEDT.setError("Enter Password");
                    }else  if (confirmPassEDT.getText().toString().equals("")){
                        confirmPassEDT.setError("Enter Confirm Password");
                    }else  if (passwordEDT.getText().toString() == confirmPassEDT.getText().toString()){
                        passwordEDT.setError("Your password not match ");
                    }else {
                        hitRegisterApi();
                    }
                } else {
                    Toast.makeText(RegisterActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
                }


            }
        });
    }


    private void hitRegisterApi() {
        RequestQueue requestQueue = Volley.newRequestQueue(RegisterActivity.this);
        final ProgressDialog dialog = ProgressDialog.show(RegisterActivity.this, "", "Loading", false);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Consent.REGISTER, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                dialog.dismiss();
                Log.d("GETRERESPONSE", response);

                try {

                    JSONObject jsonObject = new JSONObject(response);
                    String message = jsonObject.getString("message");
                    String status = jsonObject.getString("status");
                    if (status.equals("success")){
                        Toast.makeText(RegisterActivity.this, "" +message, Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(RegisterActivity.this, OtpActivity.class);
                        intent.putExtra("mobile",mobileEDT.getText().toString());
                        startActivity(intent);
                    }else {
                        Toast.makeText(RegisterActivity.this, "" +message, Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(RegisterActivity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
                    Log.d("qwaswqaslk",e.getMessage());
                    Toast.makeText(RegisterActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
          // Log.d("qwaswqaslk",error.getMessage());
                dialog.dismiss();
                Toast.makeText(RegisterActivity.this, ""+error.getMessage(), Toast.LENGTH_SHORT).show();

            }
        }) {
            

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> hashMap = new HashMap<>();

                if (emp_value.equals("emp")) {
                    hashMap.put("name", nameEDT.getText().toString());
                    hashMap.put("mobile", mobileEDT.getText().toString());
                    hashMap.put("email", emailEDT.getText().toString());
                    hashMap.put("password", confirmPassEDT.getText().toString());
                    hashMap.put("type", "employer");
                }else {
                    hashMap.put("name", nameEDT.getText().toString());
                    hashMap.put("mobile", mobileEDT.getText().toString());
                    hashMap.put("email", emailEDT.getText().toString());
                    hashMap.put("password", confirmPassEDT.getText().toString());
                    hashMap.put("tpid", tpidEDT.getText().toString());
                    hashMap.put("type", "jobseeker");
                }

                Log.d("allparms", String.valueOf(hashMap));

                return hashMap;
            }
        };
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

}
