package com.mindfact.squaredriver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mindfact.squaredriver.model.Config;
import com.mindfact.squaredriver.model.Driver;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Login extends AppCompatActivity {
    // for validating the password
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^" +
                    //"(?=.*[0-9])" +         //at least 1 digit
                    //"(?=.*[a-z])" +         //at least 1 lower case letter
                    //"(?=.*[A-Z])" +         //at least 1 upper case letter
                    "(?=.*[a-zA-Z])" +      //any letter
                    "(?=.*[@#$%^&+=])" +    //at least 1 special character
                    "(?=\\S+$)" +           //no white spaces
                    ".{4,}" +               //at least 4 characters
                    "$");

    EditText ed_loginPhone,ed_loginPassword;
    TextView txtRegister;
    Button btnLogin;
    String loginPhone,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ed_loginPhone = findViewById(R.id.ed_loginPhone);
        ed_loginPassword = findViewById(R.id.ed_loginPassword);
        txtRegister = findViewById(R.id.txtRegister);
        btnLogin = findViewById(R.id.btnLogin);

        btnlogin();
        txtRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this,Register.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    private void btnlogin() {
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginPhone = ed_loginPhone.getText().toString().trim();
                password = ed_loginPassword.getText().toString().trim();

                if (loginPhone.isEmpty() && password.isEmpty()) {
                    Toast.makeText(Login.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                }
                else if(loginPhone.isEmpty()){
                    Toast.makeText(Login.this, "Please enter the phone no.", Toast.LENGTH_SHORT).show();
                }
                else if(loginPhone.length()!=10){
                    Toast.makeText(Login.this, "Please enter the correct phone no.", Toast.LENGTH_SHORT).show();
                }
                else if(password.isEmpty()){
                    Toast.makeText(Login.this, "Please enter the paswword", Toast.LENGTH_SHORT).show();
                }
                else {

                    RequestQueue queue = Volley.newRequestQueue(Login.this);
                    StringRequest request = new StringRequest(Request.Method.POST, Config.login_url, new com.android.volley.Response.Listener<String>() {

                        @Override
                        public void onResponse(String response) {

                            try {
                                //Creating the json object from the response
                                JSONObject jsonResponse = new JSONObject(response);

                                //    Toast.makeText(Login.this,response,Toast.LENGTH_SHORT).show();
                                //If it is success
                                if ((boolean)jsonResponse.get("success")) {

                                    Driver driver = new Driver(Login.this);
                                    driver.setPhone(loginPhone);
                                    //              Toast.makeText(Login.this,response,Toast.LENGTH_SHORT).show();
                                    //starting the profile activity
                                    Toast.makeText(Login.this,"Logged In successfully",Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(Login.this,DriverMapsActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);


                                } else {
                                    //If not successful user may already have registered
                                    Toast.makeText(Login.this, "wrong username or password", Toast.LENGTH_LONG).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                        }
                    }, new com.android.volley.Response.ErrorListener() {

                        @Override
                        public void onErrorResponse(VolleyError error) {

                            Toast.makeText(Login.this, "Username or password is wrong", Toast.LENGTH_LONG).show();

                            Log.i("My error", "" + error);
                        }
                    }) {

                        protected Map<String, String> getParams() throws AuthFailureError {

                            Map<String, String> map = new HashMap<String, String>();

                            map.put(Config.loginid, loginPhone);
                            map.put(Config.password, password);

                            return map;
                        }
                    };

                    queue.add(request);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        this.finish();
    }
}
