package com.mindfact.squaredriver;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.mindfact.squaredriver.model.Config;
import com.mindfact.squaredriver.util.CheckNetwork;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class Register extends AppCompatActivity {

    String url = "http://driver.mindshiksha.com/api/add";
    String user_validation = "http://driver.mindshiksha.com/api/userValidation";
    // for validating the password
    private static final Pattern PASSWORD_PATTERN;

    static {
        PASSWORD_PATTERN = Pattern.compile("^" +
                //"(?=.*[0-9])" +         //at least 1 digit
                //"(?=.*[a-z])" +         //at least 1 lower case letter
                //"(?=.*[A-Z])" +         //at least 1 upper case letter
                "(?=.*[a-zA-Z])" +      //any letter
                "(?=.*[@#$%^&+=])" +    //at least 1 special character
                "(?=\\S+$)" +           //no white spaces
                ".{6,}" +               //at least 6 characters
                "$");
    }


    EditText ed_firstName, ed_lastName, ed_phone, ed_email, ed_password, ed_confirmpassword;
    Button btnRegistered;
    TextView txtLogin;
    CheckBox chkTerm;

    String firstname, lastname, email, password, confirmPassword;
    public String phone;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ed_firstName = findViewById(R.id.ed_firstName);
        ed_lastName = findViewById(R.id.ed_lastName);
        ed_phone = findViewById(R.id.ed_phone);
        ed_email = findViewById(R.id.ed_email);
        ed_password = findViewById(R.id.ed_password);
        ed_confirmpassword = findViewById(R.id.ed_confirmpassword);
        btnRegistered = findViewById(R.id.btnRegistered);
        txtLogin = findViewById(R.id.txtLogin);
        chkTerm = findViewById(R.id.chkTerm);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);


        btnClickListner();

        if(chkTerm.isChecked()){
            //Creating the instance of PopupMenu
            PopupMenu popup = new PopupMenu(Register.this, chkTerm);
            //Inflating the Popup using xml file
            //  popup.getMenuInflater().inflate(R.menu.term_menu, popup.getMenu());

            //registering popup with OnMenuItemClickListener
            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                public boolean onMenuItemClick(MenuItem item) {
                    Toast.makeText(Register.this,"You Clicked : " + item.getTitle(), Toast.LENGTH_SHORT).show();
                    return true;
                }
            });
            popup.show();
        }

    }



    private void btnClickListner() {
        txtLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Register.this, Login.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });

        btnRegistered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (CheckNetwork.isInternetAvailable(Register.this)) {
                    firstname = ed_firstName.getText().toString();
                    lastname = ed_lastName.getText().toString();
                    phone = ed_phone.getText().toString();
                    email = ed_email.getText().toString();
                    password = ed_password.getText().toString();
                    confirmPassword = ed_confirmpassword.getText().toString();

                    if ((firstname.isEmpty() && lastname.isEmpty() && phone.isEmpty() && password.isEmpty() && confirmPassword.isEmpty())) {
                        Toast.makeText(Register.this, "Fill all the fields", Toast.LENGTH_SHORT).show();
                        ed_firstName.requestFocus();
                    } else if (firstname.trim().equals("")) {
                        Toast.makeText(Register.this, "first name can not be blank", Toast.LENGTH_SHORT).show();
                        ed_firstName.requestFocus();
                    } else if (firstname.length() >= 20) {
                        Toast.makeText(Register.this, "You can not enter more than 20 character", Toast.LENGTH_SHORT).show();
                        ed_firstName.requestFocus();
                    } else if (lastname.trim().equals("")) {
                        Toast.makeText(Register.this, "last name can not be blank", Toast.LENGTH_SHORT).show();
                        ed_lastName.requestFocus();
                    } else if (lastname.length() >= 20) {
                        Toast.makeText(Register.this, "You can not enter more than 20 character", Toast.LENGTH_SHORT).show();
                        ed_lastName.requestFocus();
                    } else if (phone.trim().equals("")) {
                        Toast.makeText(Register.this, "phone number can not be empty", Toast.LENGTH_SHORT).show();
                        ed_phone.requestFocus();
                    } else if (phone.length() != 10) {
                        Toast.makeText(Register.this, "Please enter the 10 digit number", Toast.LENGTH_SHORT).show();
                        ed_phone.requestFocus();
                    } else if (password.trim().equals("")) {
                        Toast.makeText(Register.this, "Password can not be blank", Toast.LENGTH_SHORT).show();
                        ed_password.requestFocus();
                    } else if (confirmPassword.trim().equals("")) {
                        Toast.makeText(Register.this, " Confirm Password can not be blank", Toast.LENGTH_SHORT).show();
                        ed_confirmpassword.requestFocus();
                    } else if (!PASSWORD_PATTERN.matcher(password).matches()) {
                        Toast.makeText(Register.this, "Password should be At least One Special character,Upper case Letter and number", Toast.LENGTH_SHORT).show();
                        ed_password.requestFocus();
                    } else if (!PASSWORD_PATTERN.matcher(confirmPassword).matches()) {
                        Toast.makeText(Register.this, "Password should be At least One Special character,Upper case Letter and number", Toast.LENGTH_SHORT).show();
                        ed_confirmpassword.requestFocus();
                    } else if (!(password.equals(confirmPassword))) {
                        Toast.makeText(Register.this, "Password does not match", Toast.LENGTH_SHORT).show();
                    } else if ((password.equals(email))) {
                        Toast.makeText(Register.this, "Please do not enter the Password as a email", Toast.LENGTH_SHORT).show();
                        ed_password.requestFocus();
                    } else if (password.length() < 6) {
                        Toast.makeText(Register.this, "Please enter at least 6 character in password field", Toast.LENGTH_SHORT).show();
                        ed_password.requestFocus();
                    }


                    else {

                        progressBar.setVisibility(View.VISIBLE);
                        RequestQueue queue = Volley.newRequestQueue(Register.this);
                        StringRequest request = new StringRequest(Request.Method.POST, user_validation, new com.android.volley.Response.Listener<String>() {

                            @Override
                            public void onResponse(String response) {

                                progressBar.setVisibility(View.GONE);
                                try {
                                    //Creating the json object from the response
                                    JSONObject jsonResponse = new JSONObject(response);
                                    //   Toast.makeText(Register.this,jsonResponse.get("success").toString(),5).show();

                                    //If it is success
                                    if ((boolean) jsonResponse.get("success")) {
                                        //Asking user to confirm otp

                                        //starting the profile activity

                                        Toast.makeText(Register.this, "You have already registered", Toast.LENGTH_SHORT).show();


                                    } else {


                                        progressBar.setVisibility(View.VISIBLE);
                                        RequestQueue queue = Volley.newRequestQueue(Register.this);
                                        StringRequest request = new StringRequest(Request.Method.POST, url, new com.android.volley.Response.Listener<String>() {

                                            @Override
                                            public void onResponse(String response) {

                                                progressBar.setVisibility(View.GONE);
                                                try {
                                                    //Creating the json object from the response
                                                    JSONObject jsonResponse = new JSONObject(response);
                                                    //   Toast.makeText(Register.this,jsonResponse.get("success").toString(),5).show();

                                                    //If it is success
                                                    if ((boolean) jsonResponse.get("success")) {
                                                        //Asking user to confirm otp


                                                        Toast.makeText(Register.this, "please Enter the OTP", Toast.LENGTH_SHORT).show();
                                                        Intent intent = new Intent(Register.this, Otp.class);
                                                        intent.putExtra("username", phone);
                                                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                        startActivity(intent);


                                                    } else {
                                                        //If not successful user may already have registered
                                                        Toast.makeText(Register.this, "Username or Phone number already registered", Toast.LENGTH_LONG).show();
                                                    }
                                                } catch (JSONException e) {
                                                    e.printStackTrace();
                                                }


                                            }
                                        }, new com.android.volley.Response.ErrorListener() {

                                            @Override
                                            public void onErrorResponse(VolleyError error) {

                                                Toast.makeText(Register.this, "Please enter the valid email", Toast.LENGTH_LONG).show();
                                                progressBar.setVisibility(View.GONE);
                                                Log.i("My error", "" + error);
                                            }
                                        }) {

                                            protected Map<String, String> getParams() throws AuthFailureError {

                                                Map<String, String> map = new HashMap<String, String>();

                                                if (email.isEmpty()) {
                                                    map.put(Config.email_id, "null");
                                                    map.put(Config.first_name, firstname);
                                                    map.put(Config.last_name, lastname);
                                                    map.put(Config.mobile_no, phone);
                                                    map.put(Config.password, password);
                                                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {

                                                    Toast.makeText(Register.this, "Enter the valid email", Toast.LENGTH_SHORT);
                                                    ed_email.requestFocus();
                                                } else {
                                                    map.put(Config.first_name, firstname);
                                                    map.put(Config.last_name, lastname);
                                                    map.put(Config.email_id, email);
                                                    map.put(Config.mobile_no, phone);
                                                    map.put(Config.password, password);
                                                }

                                                return map;
                                            }
                                        };

                                        queue.add(request);


                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        }, new com.android.volley.Response.ErrorListener() {

                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Toast.makeText(Register.this, "Please enter the valid email", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);
                                Log.i("My error", "" + error);
                            }
                        }) {

                            protected Map<String, String> getParams() throws AuthFailureError {

                                Map<String, String> map = new HashMap<String, String>();


                                map.put(Config.mobile_no, phone);

                                return map;
                            }
                        };

                        queue.add(request);

                    }

                } // if inside onclick
                else{
                    Toast.makeText(Register.this,"No Internet Connection",Toast.LENGTH_SHORT).show();
                }

            }  // onclick vie
        });
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
