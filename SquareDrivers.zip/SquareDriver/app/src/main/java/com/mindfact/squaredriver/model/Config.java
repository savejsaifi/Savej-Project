package com.mindfact.squaredriver.model;

public class Config {
  public static final String url = "http://driver.mindshiksha.com/api/add";
  public static final String url_otp = "http://driver.mindshiksha.com/api/reqOTP";
  public static final String login_url = "http://driver.mindshiksha.com/api/login";

  //Keys to send username, password, phone and otp
  public static final String first_name = "first_name";
  public static final String last_name = "last_name";
  public static final String email_id = "email_id";
  public static final String mobile_no = "mobile_no";
  public static final String password = "password";
  public static final String req_otp = "req_otp";
  public static final String loginid  = "loginid";
}
