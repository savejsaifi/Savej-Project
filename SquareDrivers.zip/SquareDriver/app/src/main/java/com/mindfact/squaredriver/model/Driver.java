package com.mindfact.squaredriver.model;

import android.content.Context;
import android.content.SharedPreferences;

public class Driver {
    private String phone;

    Context context;
    SharedPreferences sharedPreferences;

    public void removeDriver(){
        sharedPreferences.edit().clear().commit();
    }

   public Driver(Context context){
       this.context = context;
       sharedPreferences=context.getSharedPreferences("driverInfo",Context.MODE_PRIVATE);
    }


    public String getPhone() {
       phone = sharedPreferences.getString("driverdata","");
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
        sharedPreferences.edit().putString("driverdata",phone).commit();

    }
}
