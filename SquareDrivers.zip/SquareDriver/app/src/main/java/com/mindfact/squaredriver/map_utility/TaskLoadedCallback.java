package com.mindfact.squaredriver.map_utility;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
