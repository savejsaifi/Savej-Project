/*
package com.datingx.jyotirecyclerview;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Recycleviewadapter extends RecyclerView.Adapter<Recycleviewadapter.MyviewHolder> {
    private ArrayList<Model> arLIstPartner;
    private RecyclerView recyclerView;
    private Model mAdapter;
    String[] name={"Jyoti","Kavita","HHhhhh","dhfhd","fgg","jjk","ghjhj","gjhjj","fghh","ghh"};


    private Context mcontext;
    private List<Model> mdata;

    public Recycleviewadapter(Context mcontext, List<Model> mdata) {
        this.mcontext = mcontext;
        this.mdata = mdata;
    }

    @NonNull
    @Override
    public MyviewHolder onCreateViewHolder(@NonNull ViewGroup lakshmi, int jyoti) {

        LayoutInflater inflater = LayoutInflater.from(mcontext);
        View view = inflater.inflate(R.layout.gv_item, null);
        recyclerView = (RecyclerView)view.findViewById(R.id.recyclerview);
        arLIstPartner=new ArrayList<>();
        prepareMovieData();

        return new MyviewHolder(view);





    }

    private void prepareMovieData() {
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(.this,1);
        recyclerView.setLayoutManager(layoutManager);
        arLIstPartner.clear();
        for(int i=0;i<name.length;i++){
            Model partnerllb=new Model();
            partnerllb.setTitle(name[i]);

        }

        mAdapter=new Recycleviewadapter(PartnerLLBActivity.this,arLIstPartner);
        recyclerView.setAdapter(mAdapter);

    }

    @Override
    public void onBindViewHolder(@NonNull MyviewHolder abcd, int position) {
        abcd.jyuti.setText(mdata.get(position).getTitle());
        abcd.shukla.setText(mdata.get(position).getTitle());
        abcd.image.setImageResource(mdata.get(position).getImagetwo());

    }

    @Override
    public int getItemCount() {
        return mdata.size();
    }

    public class MyviewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView jyuti,shukla;
        public MyviewHolder(@NonNull View itemView) {
            super(itemView);

            image = itemView.findViewById(R.id.image);
            jyuti = itemView.findViewById(R.id.jyoti);
            shukla=itemView.findViewById(R.id.shukla);

        }
    }
}
*/
