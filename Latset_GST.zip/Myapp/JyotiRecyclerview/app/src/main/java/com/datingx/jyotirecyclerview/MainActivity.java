package com.datingx.jyotirecyclerview;

import android.content.Context;
import android.content.Intent;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    private ArrayList<Model> arLIstPartner;
    private RecyclerView recyclerView;
    private Partneradapter mAdapter;
    String[] name={"Jyoti","Kavita","HHhhhh","dhfhd","fgg","jjk","ghjhj","gjhjj","fghh","ghh"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        arLIstPartner=new ArrayList<>();

        prepareMovieData();



    }
    public class Partneradapter extends RecyclerView.Adapter<Partneradapter.MyViewHolder> {
        ArrayList<Model> partnerllbs;

        Context mContext;

        public Partneradapter(Context context,ArrayList<Model>arrayList){
            this.mContext=context;
            this.partnerllbs=arrayList;

        }

        @NonNull
        @Override
        public Partneradapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.gv_item, parent, false);


            return new Partneradapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            Model partner=partnerllbs.get(position);
            holder.Nmae.setText(partner.getTitle());
            holder.Imageviewone.setImageResource(partner.getImagetwo());

        }

        @Override
        public int getItemCount() {
            return partnerllbs.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder{

            public TextView Nmae,shukla;

            public ImageView Imageviewone;
            public MyViewHolder(View view){
                super(view);
                Nmae=(TextView)view.findViewById(R.id.jyoti);
                shukla=(TextView)view.findViewById(R.id.shukla);
                Imageviewone=(ImageView)view.findViewById(R.id.image);



            }

        }}

    private void prepareMovieData() {
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(MainActivity.this,1);
        recyclerView.setLayoutManager(layoutManager);
        arLIstPartner.clear();
        for(int i=0;i<name.length;i++){
            Model partnerllb=new Model();
           partnerllb.setTitle(name[i]);
            arLIstPartner.add(partnerllb);
        }

        mAdapter=new Partneradapter(MainActivity.this,arLIstPartner);
        recyclerView.setAdapter(mAdapter);


    }
}
