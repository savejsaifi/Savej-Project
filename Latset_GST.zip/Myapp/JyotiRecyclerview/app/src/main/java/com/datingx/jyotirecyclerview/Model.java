package com.datingx.jyotirecyclerview;

public class Model {

    private Integer imagetwo;
    private String Title;

    public Model(Integer imagetwo, String title) {
        this.imagetwo = imagetwo;
        Title = title;
    }

    public Model() {
    }

    public Integer getImagetwo() {
        return imagetwo;
    }

    public void setImagetwo(Integer imagetwo) {
        this.imagetwo = imagetwo;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }
}
