package com.avaskm.gstseva.activity;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.model.Customermodel;
import java.util.ArrayList;

public class CustomerActivity extends AppCompatActivity {
    RecyclerView rvcustomer;
    ArrayList<Customermodel> arListCustomer;
    CustomerAdapter adapter;

    String[]rupess={"₹ 110","₹ 110"};
    String[]secondrupess={"₹ 110","₹ 250"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer);
        rvcustomer=(RecyclerView)findViewById(R.id.rv_custom);
        arListCustomer=new ArrayList<>();
        setRvCustomer();
    }

    private void setRvCustomer() {
        rvcustomer.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getApplicationContext(),1);
        rvcustomer.setLayoutManager(layoutManager);
        arListCustomer.clear();
        for(int i=0;i<rupess.length;i++){
            Customermodel model=new Customermodel();
            model.setRupess(rupess[i]);
            model.setSecondrupess(secondrupess[i]);
            arListCustomer.add(model);

        }
        adapter=new CustomerAdapter(getApplicationContext(),arListCustomer);
        rvcustomer.setAdapter(adapter);

    }
    public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder> {
        ArrayList<Customermodel>arList;
        Context mContext;

        public CustomerAdapter(Context context,ArrayList<Customermodel>arrayList){

            this.mContext=context;
            this.arList=arrayList;

        }
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

            View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_row,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            viewHolder.Tvrupess.setText(arList.get(i).getRupess());

            viewHolder.secondrupees.setText(arList.get(i).getSecondrupess());
        }
       // @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.main, menu);
            return true;
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder{
            TextView Tvrupess,location,secondrupees;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                Tvrupess=(TextView)itemView.findViewById(R.id.paymentdone);
                secondrupees=(TextView)itemView.findViewById(R.id.paynow);

            }
        }
    }
}
