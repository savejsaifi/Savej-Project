package com.avaskm.gstseva.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.avaskm.gstseva.R;

public class GSTfillingFormUploadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gstfilling_form_upload);
       // Intent intent = getIntent();
       // String orderid = intent.getStringExtra("orderid");
       // Log.d("hhhMakeOrderAPI",orderid);



    }
}
