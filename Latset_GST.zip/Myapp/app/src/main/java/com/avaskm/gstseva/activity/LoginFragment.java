package com.avaskm.gstseva.activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.avaskm.gstseva.R;
import com.avaskm.gstseva.navigation.MainsecActivity;

public class LoginFragment extends AppCompatActivity {
    TextView textView,forgetpass;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_login);

        textView = findViewById(R.id.register);
        button=findViewById(R.id.login);
        forgetpass = findViewById(R.id.forgetpass);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginFragment.this, MainsecActivity.class);
                startActivity(intent);

            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {/*
                RegistrationFragment fragment=new RegistrationFragment();
                FragmentManager fragmentManager = getFragmentManager();
                // fragmentManager.popBackStack();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();*/
                Intent intent=new Intent(LoginFragment.this,RegistrationFragment.class);
                startActivity(intent);

            }
        });
        forgetpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(LoginFragment.this,ForgetpasswordFragment.class);
                startActivity(intent);
          /*     ForgetpasswordFragment fragment=new ForgetpasswordFragment();
                FragmentManager fragmentManager = getFragmentManager();
                // fragmentManager.popBackStack();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame, fragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();*/
            }
        });
    }
}
