package com.avaskm.gstseva.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;

import com.avaskm.gstseva.R;
import com.avaskm.gstseva.navigation.NavigationActivity;
import android.util.Log;

public class Splash extends AppCompatActivity {

    Handler handler;
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                if (userId.isEmpty()) {
                    Intent intent = new Intent(Splash.this, RegistrationFragment.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                } else {
                    Intent intent = new Intent(Splash.this, NavigationActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }

            }
        }, 3000);

    }
}