package com.avaskm.gstseva.navigation;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.ActionBar;
import android.support.v4.view.GravityCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.util.Log;
import android.view.MenuItem;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import com.avaskm.gstseva.Bussiness;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.RegistrationFragment;
import com.avaskm.gstseva.fragment.CallFragment;
import com.avaskm.gstseva.fragment.CompleteorderFragment;
import com.avaskm.gstseva.fragment.DashboardFragment;
import com.avaskm.gstseva.fragment.DocumentFragment;
import com.avaskm.gstseva.fragment.Homefragment;
import com.avaskm.gstseva.fragment.MakepaymentFragment;
import com.avaskm.gstseva.fragment.OpenFragment;
import com.avaskm.gstseva.fragment.OrderFragment;
import com.avaskm.gstseva.fragment.PendingFragment;
import com.avaskm.gstseva.fragment.ProfileFragment;
import com.avaskm.gstseva.session.SessonManager;

import java.util.List;

public class MainsecActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private ActionBar toolbar;
    List<Bussiness> listbook;
    MenuItem cake,event,hotel;
    DrawerLayout mDrawerLayout;
    Snackbar snackbar;
    int BackCounter;
    SessonManager sessonManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitysec_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("GST SEVA");
        setSupportActionBar(toolbar);
        toolbar.setTitleTextColor(Color.parseColor("#C09006"));
       /* mDrawerLayout = findViewById(R.id.drawer_layout);
        /*FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        //  shareText();

        //snackbar = Snackbar.make(mDrawerLayout, "Press once again to exit!", Snackbar.LENGTH_LONG);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        DrawerLayout drawer = findViewById(R.id.secdrawer_layout);
        snackbar = Snackbar.make(drawer, "Press once again to exit!", Snackbar.LENGTH_LONG);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        cake  = navigationView.getMenu().findItem(R.id.nav_sub_order_cake);
        event = navigationView.getMenu().findItem(R.id.nav_sub_order_event);
        hotel = navigationView.getMenu().findItem(R.id.nav_sub_order_hotel);
        cake.setVisible(false);
        event.setVisible(false);
        hotel.setVisible(false);
        navigationView.setNavigationItemSelectedListener(this);
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.add(R.id.content, new Homefragment());
        ft.commit();//jyoti
        drawer.addDrawerListener(new DrawerLayout.DrawerListener() {
            @Override
            public void onDrawerSlide(@NonNull View view, float v) {

            }

            @Override
            public void onDrawerOpened(@NonNull View view) {

            }

            @Override
            public void onDrawerClosed(@NonNull View view) {

            }

            @Override
            public void onDrawerStateChanged(int i) {
//                InputMethodManager inputMethodManager = (InputMethodManager)
//                        getSystemService(Context.INPUT_METHOD_SERVICE);
//                inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

            }
        });
    }

    public void shareText() {
        Intent intent = new Intent(android.content.Intent.ACTION_SEND);
        intent.setType("text/plain");
        String shareBodyText = "Your shearing message goes here";
        intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject/Title");
        intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
        startActivity(Intent.createChooser(intent, "Choose sharing method"));
    }

    /*@Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        int count = getSupportFragmentManager().getBackStackEntryCount();

        Log.d("count=====", String.valueOf(count));



        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);

        } else if(count==0) {
            if (snackbar.isShown()) {
                super.onBackPressed();
            } else {
                getSupportFragmentManager().popBackStack();
                snackbar.show();

            }

        }
        else {

        }
    }*/
    @Override
    public void onBackPressed() {

        Log.d("backcounter", String.valueOf(BackCounter));
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.secdrawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {

            drawer.closeDrawer(GravityCompat.START);

            Log.d("backcounterif", String.valueOf(BackCounter));

        } else if (BackCounter == 0) {

            Log.d("backcounterelse", String.valueOf(BackCounter));
            if (snackbar.isShown()) {
                super.onBackPressed();
                // finish();

            } else {
                snackbar.show();
                BackCounter++;
                if(BackCounter==1)
                {
                    moveTaskToBack(true);

                   /*if(logoutclick==1)
                   {
                       sessonManager.setUserId("checklogin");

                   }*/

                }

            }
        } else {
            //  onNavigationItemSelected(R.id.bottom_home);
        }
    }



    /*  @Override
      public void onBackPressed() {
          DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
          if (drawer.isDrawerOpen(GravityCompat.START)) {
              drawer.closeDrawer(GravityCompat.START);

          } else {
              super.onBackPressed();
          }
      }*/
    @Override
    protected void onStart() {
        //setupBadge();

        // HItUrlFOrReadNotification();
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.notification) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    /*@Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_tools) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }*/
    //@SuppressWarnings("StatementWithEmptyBody")
//    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        Fragment fragment = null;

        int id = item.getItemId();
        if (id == R.id.nav_dashboard) {
            BackCounter = 0;
            fragment= new DashboardFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();
            // Handle the camera action
            // Handle the camera action
            // Handle the camera action
            // Handle the camera action
            // Handle the camera action
        }
        else if (id == R.id.nav_profile) {
            fragment= new ProfileFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();
            //startActivity(new Intent(MainsecActivity.this,ProfileFragment.class));


        }
        else if (id == R.id.nav_myorder) {
            if (!cake.isVisible() & !hotel.isVisible()  & ! event.isVisible()){
                cake.setVisible(true);
                hotel.setVisible(true);
                event.setVisible(true);
            }else {
                cake.setVisible(false);
                hotel.setVisible(false);
                event.setVisible(false);
            }
            return true;

        } else if (id == R.id.nav_document) {
            fragment= new DocumentFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();
        } else if (id == R.id.nav_sub_order_cake) {
            fragment= new OpenFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();

        }else if (id == R.id.nav_sub_order_event) {
            fragment= new PendingFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();

        }
        else if (id == R.id.nav_sub_order_hotel) {
            fragment= new CompleteorderFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();

        }
        else if (id == R.id.nav_makepayment) {
            fragment= new MakepaymentFragment();
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.popBackStack();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame, fragment);
            fragmentTransaction.commit();


        } else if (id == R.id.nav_feedback) {

        }else if (id == R.id.nav_sharetheapplication){
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
         /*   sharingIntent.setType("text/plain");
            String shareBodyText = "Check it out. Your message goes here";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT,"Subject here");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
            startActivity(Intent.createChooser(sharingIntent, "Shearing Option"));*/
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT,"Hey check out my app ");
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
            return true;
        }else if (id == R.id.nav_becomeourpartner){
        }else if (id == R.id.nav_logout){
//            BackCounter++;

            SharedPreferences sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.commit();
            Intent intent=new Intent(MainsecActivity.this, RegistrationFragment.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.secdrawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment = null;
            switch (item.getItemId()) {
                case R.id.bottom_order:
                    //  toolbar.setTitle("Shop");
                   /* fragment = new OrderFragment();
                    loadFragment(fragment);*/
                    fragment= new OrderFragment();
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    fragmentManager.popBackStack();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.frame, fragment);
                    fragmentTransaction.commit();
                    return true;
                case R.id.bottom_call:
                    // toolbar.setTitle("My Gifts");
                    startActivity(new Intent(MainsecActivity.this,CallFragment.class));
/*
                    fragment= new CallFragment();
                    FragmentManager fragmentManagerone = getSupportFragmentManager();
                    fragmentManagerone.popBackStack();
                    FragmentTransaction fragmentTransactionone = fragmentManagerone.beginTransaction();
                    fragmentTransactionone.replace(R.id.frame, fragment);
                    fragmentTransactionone.commit();*/
                    return true;
                case R.id.bottom_home:
                    //   toolbar.setTitle("Cart");
                    /*fragment = new Homefragment();
                    loadFragment(fragment);*/
                    fragment= new Homefragment();
                    FragmentManager fragmentManagertwo = getSupportFragmentManager();
                    fragmentManagertwo.popBackStack();
                    FragmentTransaction fragmentTransactiontwo = fragmentManagertwo.beginTransaction();
                    fragmentTransactiontwo.replace(R.id.frame, fragment);
                    fragmentTransactiontwo.commit();
                    return true;
                case R.id.bottom_document:
                    // toolbar.setTitle("Profile");
                  /*  fragment = new ProfileFragment();
                    loadFragment(fragment);*/
                    fragment= new DocumentFragment();
                    FragmentManager fragmentManagert = getSupportFragmentManager();
                    fragmentManagert.popBackStack();
                    FragmentTransaction fragmentTransactiont = fragmentManagert.beginTransaction();
                    fragmentTransactiont.replace(R.id.frame, fragment);
                    fragmentTransactiont.commit();
                    return true;
            }
            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}