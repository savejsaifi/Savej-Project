package com.avaskm.gstseva.fragment;


import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

/**
 * A simple {@link Fragment} subclass.
 */
public class PartnerFragment extends Fragment {

    Spinner SpnFrofession;
    String[] Profession = {"Select profession", "CA", "CS", "CWA", "Accountant", "Lawyer", "Shopkeeper", "Other"};
    LinearLayout linear_profession;
    EditText EtName, EtEmail, EtMobile, EtMaunally;
    String professionType;

    Button BtnSubmit;


    SharedPreferences sharedPreferences;
    String userId;

    public PartnerFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_partner, container, false);
        EtName = (EditText) view.findViewById(R.id.et_name_partner);
        EtEmail = (EditText) view.findViewById(R.id.et_email_partner);
        EtMobile = (EditText) view.findViewById(R.id.et_mobile_partner);
        EtMaunally = (EditText) view.findViewById(R.id.et_manually_partner);
        SpnFrofession = (Spinner) view.findViewById(R.id.spin_profession);
        linear_profession = (LinearLayout) view.findViewById(R.id.linear_profession);
        BtnSubmit = (Button) view.findViewById(R.id.btn_submit_partner);
        sharedPreferences = getActivity().getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");


        Log.d("userId", userId);

        SpnFrofession.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                professionType = String.valueOf(SpnFrofession.getItemAtPosition(i));
                Log.d("professionType", professionType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
                if (professionType.equalsIgnoreCase("Other")) {
                    linear_profession.setVisibility(View.VISIBLE);
                } else {
                    linear_profession.setVisibility(View.INVISIBLE);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> countTablet = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_dropdown_item, Profession);
        SpnFrofession.setAdapter(countTablet);
      BtnSubmit.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              if(setSubmit()){

              }
          }
      });
        return view;


    }


    private boolean setName() {
        if (EtName.getText().toString().length() > 0) {
            return true;
        } else {
            EtName.setError("Please enter name");
            return false;
        }
    }

    private boolean setMobile() {
        if (EtMobile.getText().toString().length() > 9) {
            return true;
        } else {
            EtMobile.setError("Please enter 10 degit mobile no");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtEmail.setError("Please enter email id");
            return false;
        }
    }

    private boolean setProfession() {
        if (!professionType.equalsIgnoreCase("Select profession")) {
            return true;
        } else {
            Toast.makeText(getActivity(), "Please select profession", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    private boolean setSubmit() {
        if (!setName()) {
            return false;
        } else if (!setMobile()) {
            return false;
        } else if (!setEmail()) {
            return false;
        } else if (!setProfession()) {
            return false;
        }
        BecomePartnerkAPI();
        return true;
    }

    private void BecomePartnerkAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.BecomePartner, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("BecomePartner", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(getActivity(), NavigationActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("name", EtName.getText().toString());
                params.put("mobile", EtMobile.getText().toString());
                params.put("profession", professionType);

                if (professionType.equalsIgnoreCase("Other")) {
                    params.put("profession", EtMaunally.getText().toString());
                }
                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
