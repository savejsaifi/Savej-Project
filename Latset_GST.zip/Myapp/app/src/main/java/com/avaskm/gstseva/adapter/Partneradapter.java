//package com.dating.myapp.adapter;
//import android.content.Context;
//import android.content.Intent;
//import android.provider.MediaStore;
//import android.support.annotation.NonNull;
//import android.support.v7.widget.RecyclerView;
//import android.util.Log;
//import android.view.LayoutInflater;
//import android.view.MenuItem;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageView;
//import android.widget.PopupMenu;
//import android.widget.TextView;
//import com.dating.myapp.R;
//import com.dating.myapp.activity.ProprietorActivity;
//import com.dating.myapp.model.Partnerllb;
//import java.util.ArrayList;
//import java.util.List;
//
//public class Partneradapter extends RecyclerView.Adapter<Partneradapter.MyViewHolder> {
//    private ArrayList<Partnerllb> partnerllbs;
//
//    Context mContext;
//
//    public Partneradapter(Context context,ArrayList<Partnerllb>arrayList){
//        this.mContext=context;
//        this.partnerllbs=arrayList;
//
//    }
//
//    @NonNull
//    @Override
//    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
//        View itemView = LayoutInflater.from(parent.getContext())
//                .inflate(R.layout.partnerlistview, parent, false);
//
//
//        return new MyViewHolder(itemView);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//        Partnerllb partner=partnerllbs.get(position);
//        holder.Nmae.setText(partner.getName());
//        holder.Pancardno.setText(partner.getPancardno());
////        Log.d("card",partner.getPancardno());
//        holder.Addharcardno.setText(partner.getAddharcardno());
//        holder.Imageviewone.setImageResource(partner.getImage_drawableone());
//        holder.imageViewtwo.setImageResource(partner.getGetImage_drawabletwo());
//        holder.Person.setImageResource(partner.getImage_drawable());//
//        holder.buttonone.setText(partner.getButtonone());
//        holder.buttontwo.setText(partner.getButtontwo());
//        holder.buttonthree.setText(partner.getButtonthree());
//    }
//
//    @Override
//    public int getItemCount() {
//        return partnerllbs.size();
//    }
//
//    public class MyViewHolder extends RecyclerView.ViewHolder{
//
//        public TextView Nmae,Pancardno,Addharcardno;
//        public Button buttonone,buttontwo,buttonthree;
//        public ImageView Person,Imageviewone,imageViewtwo;
//        public MyViewHolder(View view){
//            super(view);
//            Nmae=(TextView)view.findViewById(R.id.personname);
//            Pancardno=(TextView)view.findViewById(R.id.pancardno);
//            Addharcardno=(TextView)view.findViewById(R.id.addharcardno);
//            Person=(ImageView)view.findViewById(R.id.imgView);
//            Imageviewone=(ImageView)view.findViewById(R.id.imgViewone);
//            imageViewtwo=(ImageView)view.findViewById(R.id.imgViewtwo);//
//            buttonone=(Button)view.findViewById(R.id.uploadone);
//            buttontwo=(Button)view.findViewById(R.id.uploadsecond);
//            buttonthree=(Button)view.findViewById(R.id.uploadthird);
//
//            buttonone.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                }
//            });
//
//                }
//
//
//        }
//    }
//
//
//
