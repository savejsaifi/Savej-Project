package com.avaskm.gstseva.ourservices;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.databinding.ActivityImportExportBinding;
import com.avaskm.gstseva.databinding.ActivityPassportBinding;
import com.avaskm.gstseva.model.StateSpinnerModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
public class PassportActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    ActivityPassportBinding binding;
    SharedPreferences sharedPreferences;
    ArrayList<StateSpinnerModel> listState1_model = new ArrayList<>();
    ArrayList<String> listState1 = new ArrayList<>();
    String stateName;
    String userId,title;
    String price;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String[] genderDetails = {"Select Gender","Male","Female","TransGender"};
    String[] MarrigeDetails = {"Marital Status","Married","Unmarried"};
    String[] NationalityDetails = {"Nationality","Indian","Other"};
    String[] GovernmentDetails = {"Parent/Spouse Are Government Employee","Yes","No"};
    String[] CriminalDetails = {"Any Criminal Case","Yes","No"};
    String[] PassportAppliedDetails = {"Passport Applied Before","Yes","No"};
    String[] OccupationDetails = {"Select Occupation","Service","Self Employed","Buisness","Professional","Housewife","Student","Infant","Other"};
    String[] EducationDetails = {"Select Education","DOCTRATE","POST GRADUATE","GRADUATE","DIPLOMA","12 CLASS","11 CLASS","10 CLASS"
            ,"9 CLASS","8 CLASS","7 CLASS","6 CLASS","5 CLASS","4 CLASS","3 CLASS","2 CLASS","1 CLASS",
            "8 CLASS","NO EDUCATION","ILLITRATE","OTHER"};

    String gender,marrital_status,nationality,occupation,education,government,criminal,passport=" ";
    Spinner gender_spinner,marital_spinner,nationalitySpinner,Occupation_spinner,EducationSpinner,
            government_spinner,criminal_spinner,passportApplied_spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //  setContentView(R.layout.activity_passport);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_passport);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        gender_spinner = findViewById(R.id.gender_spinner);
        marital_spinner = findViewById(R.id.marital_spinner);
        nationalitySpinner = findViewById(R.id.nationality_spinner);
        Occupation_spinner = findViewById(R.id.Occupation_spinner);
        EducationSpinner = findViewById(R.id.Education_spinner);
        government_spinner = findViewById(R.id.government_spinner);
        criminal_spinner = findViewById(R.id.criminal_spinner);
        passportApplied_spinner = findViewById(R.id.passportApplied_spinner);
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        hitAPiPrice();
        hitstateSpinnerApi();
        spinnerClick();
        spinnerAdapter();


        binding.btnRegisterPassport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(binding.edtNamePassport.getText().toString().equals("")){
                    binding.edtNamePassport.setError("Please enter Name");
                    binding.edtNamePassport.requestFocus();
                }
                else if(binding.edtMobilePassport.getText().toString().equals("")){
                    binding.edtMobilePassport.setError("Please enter the Mobile No.");
                    binding.edtMobilePassport.requestFocus();
                }
                else if(!(binding.edtMobilePassport.getText().toString().length()==10)){
                    binding.edtMobilePassport.setError("Mobile No. should be 10 digit");
                    binding.edtMobilePassport.requestFocus();
                }
                else if(binding.edtemailPassport.getText().toString().equals("")){
                    binding.edtemailPassport.setError("Please enter Your Email.");
                    binding.edtemailPassport.requestFocus();
                }
                else if (!(binding.edtemailPassport.getText().toString().matches(emailPattern) && binding.edtemailPassport.getText().toString().length() > 0)) {
                    binding.edtemailPassport.setError("Please enter the valid Email");
                    binding.edtemailPassport.requestFocus();
                }
                else if(binding.edtAddressPassport.getText().toString().equals("")){
                    binding.edtAddressPassport.setError("Please enter Your Address.");
                    binding.edtAddressPassport.requestFocus();
                }

//                else if(stateName.equals("Select state")){
//                    Toast.makeText(PassportActivity.this, "Please Select State", Toast.LENGTH_SHORT).show();
//                }
                else if(binding.edtCity1.getText().toString().equals("")){
                    binding.edtCity1.setError("Please enter City.");
                    binding.edtCity1.requestFocus();
                }
                else if(binding.edtPincode.getText().toString().equals("")){
                    binding.edtPincode.setError("Please enter Pincode.");
                    binding.edtPincode.requestFocus();
                }
                else if(!(binding.edtPincode.getText().toString().length()==6)){
                    binding.edtPincode.setError("Pincode should be 6 digit");
                    binding.edtPincode.requestFocus();
                }
                else if(gender.equals("Select Gender")){
                    Toast.makeText(PassportActivity.this, "Please Select Gender", Toast.LENGTH_SHORT).show();
                }
                else if(marrital_status.equalsIgnoreCase("Marital Status")){
                    Toast.makeText(PassportActivity.this, "Please Select Marital status", Toast.LENGTH_SHORT).show();
                }
                  else if(nationality.equalsIgnoreCase("Nationality")){
                    Toast.makeText(PassportActivity.this, "Please Select Nationality", Toast.LENGTH_SHORT).show();
                }
                  else if(occupation.equalsIgnoreCase("Select Occupation")){
                    Toast.makeText(PassportActivity.this, "Please Select Occupation", Toast.LENGTH_SHORT).show();
                }
                  else if(education.equalsIgnoreCase("Select Education")){
                    Toast.makeText(PassportActivity.this, "Please Select Education", Toast.LENGTH_SHORT).show();
                }
                  else if(binding.edtResidence.getText().toString().equals("")){
                    binding.edtResidence.setError("Please Select Residence");
                    binding.edtResidence.requestFocus();
                }
                  else if(binding.edtMotherName.getText().toString().equals("")){
                    binding.edtMotherName.setError("Please Fill Mother name");
                    binding.edtMotherName.requestFocus();
                }
                  else if(binding.edtFatherName.getText().toString().equals("")){
                    binding.edtFatherName.setError("Please Fill Father name");
                    binding.edtFatherName.requestFocus();
                }
                  else if(binding.edtRefrence1Name.getText().toString().equals("")){
                    binding.edtRefrence1Name.setError("Please Fill Refrence1 name");
                    binding.edtRefrence1Name.requestFocus();
                }
                  else if(binding.edtRefrence1Mobile.getText().toString().equals("")){
                    binding.edtRefrence1Mobile.setError("Please Fill Refrence1 Mobile");
                    binding.edtRefrence1Mobile.requestFocus();
                }
                  else if(binding.refrenec1Address.getText().toString().equals("")){
                    binding.refrenec1Address.setError("Please Fill Refrence1 Address");
                    binding.refrenec1Address.requestFocus();
                }
                  else if(binding.edtRefrence2Name.getText().toString().equals("")){
                    binding.edtRefrence2Name.setError("Please Fill Refrence2 name");
                    binding.edtRefrence2Name.requestFocus();
                }
                  else if(binding.edtRefrence2Mobile.getText().toString().equals("")){
                    binding.edtRefrence2Mobile.setError("Please Fill Refrence2 Mobile");
                    binding.edtRefrence2Mobile.requestFocus();
                }
                  else if(binding.refrenec2Address.getText().toString().equals("")){
                    binding.refrenec2Address.setError("Please Fill Refrence2 Address");
                    binding.refrenec2Address.requestFocus();
                }
                  else if(binding.edtNameContact.getText().toString().equals("")){
                    binding.edtNameContact.setError("Please Fill emergency Contect Name");
                    binding.edtNameContact.requestFocus();
                }
                  else if(binding.edtMobileContact.getText().toString().equals("")){
                    binding.edtMobileContact.setError("Please Fill emergency Contect Person Mobile No.");
                    binding.edtMobileContact.requestFocus();
                }
                  else if(binding.edtBirthPlace.getText().toString().equals("")){
                      binding.edtBirthPlace.setError("Please Fill your birth place.");
                      binding.edtBirthPlace.requestFocus();
                }
                  else if(binding.edtPolice.getText().toString().equals("")){
                      binding.edtPolice.setError("Please Fill your nearest police station.");
                      binding.edtPolice.requestFocus();
                }
                  else if(binding.edtMark.getText().toString().equals("")){
                      binding.edtMark.setError("Please Fill Visible Mark.");
                      binding.edtMark.requestFocus();
                }
                  else if(government.equalsIgnoreCase("Parent/Spouse Are Government Employee")){
                    Toast.makeText(PassportActivity.this, "Please Select Government Employee", Toast.LENGTH_SHORT).show();
                }
                  else if(criminal.equalsIgnoreCase("Any Criminal Case")){
                    Toast.makeText(PassportActivity.this, "Please Select Criminal Case Option", Toast.LENGTH_SHORT).show();
                }
                  else if(passport.equalsIgnoreCase("Passport Applied Before")){
                    Toast.makeText(PassportActivity.this, "Please Select Passport Applied Before Option", Toast.LENGTH_SHORT).show();
                }
                  else{
                      passportApi();
                }

                //  startActivity(new Intent(getApplicationContext(),PassportUploadFormActivity.class));
            }
        });
    }

    private void passportApi() {

            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(PassportActivity.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(PassportActivity.this, PassportUploadFormActivity.class);
                        intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(PassportActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid",userId);
                    params.put("category",title);
                    params.put("price",price);
                    params.put("name",binding.edtNamePassport.getText().toString());
                    params.put("mobile", binding.edtMobilePassport.getText().toString());
                    params.put("email",binding.edtemailPassport.getText().toString());
                    params.put("address",binding.edtAddressPassport.getText().toString());
                    params.put("district",binding.edtCity1.getText().toString());
                    params.put("state",stateName);
                    params.put("pincode",binding.edtPincode.getText().toString());

                    if(gender.equalsIgnoreCase("Select Gender")){
                        params.put("gender","");
                    }else {
                        params.put("gender",gender);
                    }

                     if(marrital_status.equalsIgnoreCase("Married")){
                        params.put("marital_status",binding.edtSpouse.getText().toString());
                    }
                    else {
                        params.put("marital_status","");
                    }
                    if(nationality.equalsIgnoreCase("Other")){
                        params.put("nationality",binding.edtNationality.getText().toString());
                    }
                    else {
                        params.put("nationality",nationality);
                    }
                    if(occupation.equalsIgnoreCase("Other")){
                        params.put("occupation",binding.edtOccupation.getText().toString());
                    }
                    else {
                        params.put("occupation",occupation);
                    }

                    if(education.equalsIgnoreCase("OTHER")){
                        params.put("education",binding.edtEducation.getText().toString());
                    }
                    else {
                        params.put("education",education);
                    }
                    params.put("residence_since",binding.edtResidence.getText().toString());
                    params.put("mother",binding.edtMotherName.getText().toString());
                    params.put("father",binding.edtFatherName.getText().toString());
                    params.put("reference1_name",binding.edtRefrence1Name.getText().toString());
                    params.put("reference1_mobile",binding.edtRefrence1Mobile.getText().toString());
                    params.put("reference1_address",binding.refrenec1Address.getText().toString());
                    params.put("reference2_name",binding.edtRefrence2Name.getText().toString());
                    params.put("reference2_mobile",binding.edtRefrence2Mobile.getText().toString());
                    params.put("reference2_address",binding.refrenec2Address.getText().toString());
                    params.put("emergency_name",binding.edtNameContact.getText().toString());
                    params.put("emergency_contact",binding.edtMobileContact.getText().toString());
                    params.put("birth_place",binding.edtBirthPlace.getText().toString());
                    params.put("nearest_police_station",binding.edtPolice.getText().toString());
                    params.put("visible_mark",binding.edtMark.getText().toString());

                    if(government.equalsIgnoreCase("Parent/Spouse Are Government Employee")){
                        params.put("parent_spouse_govt_emp","");
                    }else {
                        params.put("parent_spouse_govt_emp",government);
                    }
                    if(criminal.equalsIgnoreCase("Yes")){
                        params.put("case_details",binding.edtCriminalCase.getText().toString());
                        params.put("criminal_case",criminal);
                    }else {
                        params.put("criminal_case",criminal);
                    }
                    if(passport.equalsIgnoreCase("Yes")){
                        params.put("details",binding.edtPassport.getText().toString());
                        params.put("applied_before",passport);
                    }else {
                        params.put("applied_before",passport);
                    }


                    //   params.put("gst_type",String.valueOf(constitutePosition));

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);

    }

    private void spinnerAdapter() {
        binding.genderSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,genderDetails);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.genderSpinner.setAdapter(aa);

        binding.maritalSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,MarrigeDetails);
        aaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.maritalSpinner.setAdapter(aaa);

        binding.nationalitySpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,NationalityDetails);
        aaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.nationalitySpinner.setAdapter(aaaa);

        binding.OccupationSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,OccupationDetails);
        aaaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.OccupationSpinner.setAdapter(aaaaa);

        binding.EducationSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,EducationDetails);
        aaaaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.EducationSpinner.setAdapter(aaaaaa);

        binding.governmentSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaaaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,GovernmentDetails);
        aaaaaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.governmentSpinner.setAdapter(aaaaaaa);

        binding.criminalSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaaaaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,CriminalDetails);
        aaaaaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.criminalSpinner.setAdapter(aaaaaaaa);

        binding.passportAppliedSpinner.setOnItemSelectedListener(this);
        ArrayAdapter aaaaaaaaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,PassportAppliedDetails);
        aaaaaaaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.passportAppliedSpinner.setAdapter(aaaaaaaaa);
    }

    private  void hitAPiPrice(){
        final ProgressDialog progressDialog=ProgressDialog.show(PassportActivity.this,"","wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject=jsonObject.getJSONObject("data");
                    price =dataObject.getString("price");
                    binding.basePricePassport.setText(price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("category",title);
                hashMap.put("userid",userId);
                return hashMap;
            }
        };
        requestQueue.add(request);
    }
    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(PassportActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                listState1.add("Select state");
                StateSpinnerModel model = new StateSpinnerModel();
                model.setStateName("Select state");
                model.setId("");
                listState1_model.add(model);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i =0;i<jsonArray.length();i++){
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_model.add(model);
                        listState1.add(jsonObject1.getString("state_name"));
                    }
                    ArrayAdapter aa = new ArrayAdapter(PassportActivity.this,android.R.layout.simple_spinner_dropdown_item,listState1);
                    binding.stateSpinner1.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }
    private void spinnerClick() {
        binding.stateSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                stateName = listState1_model.get(position).getStateName();
                Log.d("asdds",stateName);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if(parent.getId() == R.id.gender_spinner){
            gender = genderDetails[position];
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
            Log.d("asdklweo",gender);

        }
       if(parent.getId()==R.id.marital_spinner){
           marrital_status = MarrigeDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           Log.d("asdklweo",gender);
           if(marrital_status.equals("Married")){
               binding.textinputSpouse.setVisibility(View.VISIBLE);
           }else{
               binding.textinputSpouse.setVisibility(View.GONE);
           }

       }
       if(parent.getId()==R.id.nationality_spinner){
           nationality = NationalityDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           Log.d("asdkldweo",nationality);
           if(nationality.equals("Other")){
               binding.textinputNationality.setVisibility(View.VISIBLE);
           }else{
               binding.textinputNationality.setVisibility(View.GONE);
           }

       }
       if(parent.getId()==R.id.Occupation_spinner){
           occupation = OccupationDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           Log.d("asweo",occupation);
           if(occupation.equalsIgnoreCase("Other")){
               binding.textinputOccupation.setVisibility(View.VISIBLE);
           }else{
               binding.textinputOccupation.setVisibility(View.GONE);
           }

       }
       if(parent.getId()==R.id.Education_spinner){
           education = EducationDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           Log.d("asweo",education);
           if(education.equalsIgnoreCase("OTHER")){
               binding.textinputEducation.setVisibility(View.VISIBLE);
           }else{
               binding.textinputEducation.setVisibility(View.GONE);
           }

       }
       if(parent.getId()==R.id.government_spinner){
           government = GovernmentDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);

       }
       if(parent.getId()==R.id.criminal_spinner){
           criminal = CriminalDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           if(criminal.equalsIgnoreCase("Yes")){
               binding.textinputCriminal.setVisibility(View.VISIBLE);
           }
           else {
               binding.textinputCriminal.setVisibility(View.GONE);
           }
       }
       if(parent.getId()==R.id.passportApplied_spinner){
           passport = PassportAppliedDetails[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
           if(passport.equalsIgnoreCase("Yes")){
               binding.textinputPassport.setVisibility(View.VISIBLE);
           }
           else {
               binding.textinputPassport.setVisibility(View.GONE);
           }
       }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

}
