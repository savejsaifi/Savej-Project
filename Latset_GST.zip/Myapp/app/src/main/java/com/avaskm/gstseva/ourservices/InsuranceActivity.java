package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class InsuranceActivity extends AppCompatActivity {
    Spinner SpnInsurance, SpnLife, SpnTerm, SpnSumAssured, SpnHealth, SpnSumAssuredHealth, SpnMotor;

    EditText EtNameLife, EtDOBLife, EtMobileLife, EtEmailLife, EtNameTerm, EtDOBTerm, EtMobileTerm, EtEmailTerm, EtWriteAdult, EtWriteChildern, EtNameMotor;

    LinearLayout LinearLifeInSurance, LinearTerm, LinearHealth, LinearMotor;
    String[] Insurance = {"Select insurance type", "Life insurance", "Term insurance", "Health insurance", "Motor insurance"};
    String[] SumAssured = {"25 Lakh", "50 Lakh", "75 Lakh", "01 CR", "02 CR", "05 CR"};
    String[] SumAssuredHealth = {"2 Lakh", "3 Lakh", "4 Lakh", "5 Lakh", "10 Lakh", "15 Lakh", "20 Lakh", "25 Lakh", "30 Lakh"};
    String insuranceType, LifeType, termtype, sumAssuredType, HealthType, sumAssuredHealthType, MotorType, orderid,title;

    Button BtnSubmit;

    ArrayList<String> arListLife = new ArrayList<>();
    ArrayList<String> arListTerm = new ArrayList<>();
    ArrayList<String> arListHealth = new ArrayList<>();
    ArrayList<String> arListMotor = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insurance);
        EtNameLife = (EditText) findViewById(R.id.et_name_insurance);
        EtDOBLife = (EditText) findViewById(R.id.et_dob_insurance);
        EtMobileLife = (EditText) findViewById(R.id.et_mobile_insurance);
        EtEmailLife = (EditText) findViewById(R.id.et_email_insurance);

        EtNameLife = (EditText) findViewById(R.id.et_name_term);
        EtDOBLife = (EditText) findViewById(R.id.et_dob_term);
        EtMobileLife = (EditText) findViewById(R.id.et_mobile_term);
        EtEmailLife = (EditText) findViewById(R.id.et_email_term);

        EtWriteAdult = (EditText) findViewById(R.id.et_no_of_adult);
        EtWriteChildern = (EditText) findViewById(R.id.et_childern);

        EtNameLife = (EditText) findViewById(R.id.et_name_motor_insurance);
        SpnInsurance = (Spinner) findViewById(R.id.spin_insurance_insuranse);
        LinearLifeInSurance = (LinearLayout) findViewById(R.id.linear_life_insurance);
        LinearTerm = (LinearLayout) findViewById(R.id.linear_term);
        SpnLife = (Spinner) findViewById(R.id.spin_life_insurance);
        SpnTerm = (Spinner) findViewById(R.id.spin_term_insurance);
        SpnSumAssured = (Spinner) findViewById(R.id.spin_sum_assured_insurance);
        SpnHealth = (Spinner) findViewById(R.id.spin_health_insurance);
        SpnSumAssuredHealth = (Spinner) findViewById(R.id.spin_sum_assured_health);
        LinearHealth = (LinearLayout) findViewById(R.id.linear_health);
        SpnMotor = (Spinner) findViewById(R.id.spin_motor);
        LinearMotor = (LinearLayout) findViewById(R.id.linear_motor);

        BtnSubmit = (Button) findViewById(R.id.btn_submit_insurance);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setSubmit()) {

                }
            }
        });

        SpnInsurance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                insuranceType = String.valueOf(SpnInsurance.getItemAtPosition(i));
                Log.d("insuranceType", insuranceType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));

                if (insuranceType.equalsIgnoreCase("Life insurance")) {
                    LinearLifeInSurance.setVisibility(View.VISIBLE);
                    LinearTerm.setVisibility(View.GONE);
                    LinearHealth.setVisibility(View.GONE);
                    LinearMotor.setVisibility(View.GONE);
                } else if (insuranceType.equalsIgnoreCase("Term insurance")) {
                    LinearTerm.setVisibility(View.VISIBLE);
                    LinearLifeInSurance.setVisibility(View.GONE);
                    LinearHealth.setVisibility(View.GONE);
                    LinearMotor.setVisibility(View.GONE);
                } else if (insuranceType.equalsIgnoreCase("Health insurance")) {
                    LinearHealth.setVisibility(View.VISIBLE);
                    LinearTerm.setVisibility(View.GONE);
                    LinearLifeInSurance.setVisibility(View.GONE);
                    LinearMotor.setVisibility(View.GONE);
                } else if (insuranceType.equalsIgnoreCase("Motor insurance")) {
                    LinearHealth.setVisibility(View.GONE);
                    LinearTerm.setVisibility(View.GONE);
                    LinearLifeInSurance.setVisibility(View.GONE);
                    LinearMotor.setVisibility(View.VISIBLE);
                } else if (insuranceType.equalsIgnoreCase("Select insurance type")) {
                    LinearHealth.setVisibility(View.GONE);
                    LinearTerm.setVisibility(View.GONE);
                    LinearLifeInSurance.setVisibility(View.GONE);
                    LinearMotor.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnSumAssured.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                sumAssuredType = String.valueOf(SpnSumAssured.getItemAtPosition(i));
                Log.d("insuranceType", sumAssuredType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnSumAssuredHealth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                sumAssuredHealthType = String.valueOf(SpnSumAssuredHealth.getItemAtPosition(i));
                Log.d("sumAssuredHealthType", sumAssuredHealthType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnLife.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                LifeType = String.valueOf(SpnLife.getItemAtPosition(i));
                Log.d("LifeType", LifeType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnTerm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                termtype = String.valueOf(SpnTerm.getItemAtPosition(i));
                Log.d("termtype", termtype);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnHealth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                HealthType = String.valueOf(SpnHealth.getItemAtPosition(i));
                Log.d("HealthType", HealthType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnMotor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                MotorType = String.valueOf(SpnMotor.getItemAtPosition(i));
                Log.d("MotorType", MotorType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> countTablet = new ArrayAdapter<String>(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, Insurance);
        SpnInsurance.setAdapter(countTablet);

        ArrayAdapter<String> SumAssuredAdapter = new ArrayAdapter<String>(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, SumAssured);
        SpnSumAssured.setAdapter(SumAssuredAdapter);


        ArrayAdapter<String> SumAssuredHealthAdapter = new ArrayAdapter<String>(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, SumAssuredHealth);
        SpnSumAssuredHealth.setAdapter(SumAssuredHealthAdapter);

        GetCategoryInforApi();
    }


    private boolean setInsuranceType() {
        if (!insuranceType.equalsIgnoreCase("Select insurance type")) {
            return true;

        } else {
            Toast.makeText(InsuranceActivity.this, "Please Select insurance type", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    private boolean setName() {
        if (EtNameLife.getText().toString().length() > 0) {
            return true;

        } else {
            EtNameLife.setError("Please enter name");
            return false;
        }
    }

    private boolean setDOB() {
        if (EtDOBLife.getText().toString().length() > 0) {
            return true;

        } else {
            EtDOBLife.setError("Please enter date of birth");
            return false;
        }
    }

    private boolean setMobile() {
        if (EtMobileLife.getText().toString().length() > 0) {
            return true;

        } else {
            EtMobileLife.setError("Please enter 10 digit no");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmailLife.getText().toString().length() > 0) {
            return true;

        } else {
            EtEmailLife.setError("Please enter email");
            return false;
        }

    }

    private boolean setSubmit() {
        if (!setInsuranceType()) {
            return false;

        }/* else if (!setName()) {
            return false;

        } else if (!setDOB()) {
            return false;

        } else if (!setMobile()) {
            return false;

        } else if (!setEmail()) {
            return false;

        }*/
        MakeOrderAPI();
        return true;
    }


    private void GetCategoryInforApi() {
        RequestQueue queue = Volley.newRequestQueue(InsuranceActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("GetCateInsurancefor", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    JSONObject categoriesObject = dataObject.getJSONObject("categories");
                    JSONArray lifeInsurance = categoriesObject.getJSONArray("Life Insurance");


                    for (int i = 0; i < lifeInsurance.length(); i++) {
                        JSONObject lifeObject = lifeInsurance.getJSONObject(i);
                        String name = lifeObject.getString("name");
                        Log.d("naaa", name);
                        arListLife.add(name);

                    }
                    JSONArray termInsurance = categoriesObject.getJSONArray("Term Insurance");
                    for (int i = 0; i < termInsurance.length(); i++) {
                        JSONObject termObject = termInsurance.getJSONObject(i);
                        String name = termObject.getString("name");
                        Log.d("naaaterm", name);
                        arListTerm.add(name);

                    }


                    JSONArray healthInsurance = categoriesObject.getJSONArray("Health Insurance");
                    for (int i = 0; i < healthInsurance.length(); i++) {
                        JSONObject healthObject = healthInsurance.getJSONObject(i);
                        String name = healthObject.getString("name");
                        Log.d("naaaHealth", name);
                        arListHealth.add(name);

                    }

                    JSONArray motorInsurance = categoriesObject.getJSONArray("Motor Insurance");
                    for (int i = 0; i < motorInsurance.length(); i++) {
                        JSONObject motorObject = motorInsurance.getJSONObject(i);
                        String name = motorObject.getString("name");
                        Log.d("naaaMotor", name);
                        arListMotor.add(name);

                    }


                    ArrayAdapter lifeAdapter = new ArrayAdapter(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, arListLife);
                    SpnLife.setAdapter(lifeAdapter);

                    ArrayAdapter termAdapter = new ArrayAdapter(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, arListTerm);
                    SpnTerm.setAdapter(termAdapter);

                    ArrayAdapter healthAdapter = new ArrayAdapter(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, arListHealth);
                    SpnHealth.setAdapter(healthAdapter);

                    ArrayAdapter motorAdapter = new ArrayAdapter(InsuranceActivity.this, android.R.layout.simple_spinner_dropdown_item, arListMotor);
                    SpnMotor.setAdapter(motorAdapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(InsuranceActivity.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("category", title);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(InsuranceActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("InsuranceResponse", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("Insurancorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {

                        if (insuranceType.equalsIgnoreCase("Motor insurance")) {
                            Intent intent = new Intent(InsuranceActivity.this, InsuranceUploadFormActivity.class);
                            intent.putExtra("orderid", orderid);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            Toast.makeText(InsuranceActivity.this, msg, Toast.LENGTH_SHORT).show();
                        } else {
                            Intent intent = new Intent(InsuranceActivity.this, NavigationActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            Toast.makeText(InsuranceActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }


                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", "2");
                params.put("category", title);
                params.put("type1", insuranceType);

                if (insuranceType.equalsIgnoreCase("Life insurance")) {
                    params.put("type2", LifeType);
                    params.put("name", EtNameLife.getText().toString());
                    params.put("dob", EtDOBLife.getText().toString());
                    params.put("email", EtEmailLife.getText().toString());
                    params.put("mobile", EtMobileLife.getText().toString());

                } else if (insuranceType.equalsIgnoreCase("Term insurance")) {
                    params.put("type2", termtype);
                    params.put("name", EtNameLife.getText().toString());
                    params.put("dob", EtDOBLife.getText().toString());
                    params.put("email", EtEmailLife.getText().toString());
                    params.put("mobile", EtMobileLife.getText().toString());
                    params.put("sum_required", sumAssuredType);
                } else if (insuranceType.equalsIgnoreCase("Health insurance")) {

                    params.put("type2", HealthType);
                    params.put("no_adult", EtWriteAdult.getText().toString());
                    params.put("no_children", EtWriteChildern.getText().toString());
                    params.put("sum_required", sumAssuredHealthType);
                } else if (insuranceType.equalsIgnoreCase("Motor insurance")) {
                    params.put("type2", MotorType);
                    params.put("name", EtNameLife.getText().toString());

                }


                Log.d("allItr", String.valueOf(params));


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(InsuranceActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }

}
