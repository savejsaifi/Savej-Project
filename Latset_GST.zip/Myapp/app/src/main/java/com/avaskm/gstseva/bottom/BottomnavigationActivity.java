package com.avaskm.gstseva.bottom;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.avaskm.gstseva.R;

public class BottomnavigationActivity extends AppCompatActivity {
    private ActionBar toolbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bottomnavigation);
        toolbar = getSupportActionBar();

        // load the store fragment by default
        toolbar.setTitle("Shop");
       // loadFragment(new OrderFragment());
    }
   /* private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.bottom_order:
                    toolbar.setTitle("Shop");
                    fragment = new OrderFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.bottom_call:
                    toolbar.setTitle("My Gifts");
                    fragment = new CallFragment();
                    loadFragment(fragment);
                    return true;
                case R.id.bottom_home:
                    toolbar.setTitle("Cart");
                    fragment = new Homefragment();
                    loadFragment(fragment);
                    return true;
                case R.id.bottom_document:
                    toolbar.setTitle("Profile");
                    fragment = new ProfileFragment();
                    loadFragment(fragment);
                    return true;
            }

            return false;
        }
    };

    private void loadFragment(Fragment fragment) {
        // load fragment
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }*/

}

