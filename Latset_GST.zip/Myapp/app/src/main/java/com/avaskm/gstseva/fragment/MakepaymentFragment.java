package com.avaskm.gstseva.fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.payment.PaymentModeActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;


public class MakepaymentFragment extends Fragment {

    EditText EtName, EtEmail, EtMobile, EtAmount, EtPurpose;
    Button BtnPaynow;
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_makepayment, container, false);
        EtName = (EditText) view.findViewById(R.id.et_name_make);
        EtEmail = (EditText) view.findViewById(R.id.et_email_make);
        EtMobile = (EditText) view.findViewById(R.id.et_mobile_make);
        EtAmount = (EditText) view.findViewById(R.id.et_amount_make);
        EtPurpose = (EditText) view.findViewById(R.id.et_purpose_make);
        BtnPaynow = (Button) view.findViewById(R.id.btn_pay_now_make);

        sharedPreferences = getActivity().getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        BtnPaynow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setPayment()) {

                }
            }
        });
        return view;
    }


    private boolean setName() {
        if (EtName.getText().toString().length() > 0) {
            return true;
        } else {
            EtName.setError("Please enter name");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtEmail.setError("Please enter email id");
            return false;
        }

    }

    private boolean setMobile() {
        if (EtMobile.getText().toString().length() > 9) {
            return true;
        } else {
            EtMobile.setError("Please enter 10 digit mobile no");
            return false;
        }
    }


    private boolean setAmount() {
        if (EtAmount.getText().toString().length() > 0) {
            return true;

        } else {
            EtAmount.setError("Please enter amount");
            return false;
        }
    }


    private boolean setPurpose() {
        if (EtPurpose.getText().toString().length() > 0) {
            return true;
        } else {
            EtPurpose.setError("Please enter purpose");
            return false;
        }
    }


    private boolean setPayment() {
        if (!setName()) {
            return false;
        } else if (!setEmail()) {
            return false;
        } else if (!setMobile()) {
            return false;
        } else if (!setAmount()) {
            return false;
        } else if (!setPurpose()) {
            return false;
        }
        MakePaymentAPI();
        return true;
    }

    private void MakePaymentAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakePayment, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("MakePayment", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(getActivity(), PaymentModeActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("name", EtName.getText().toString());
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("purpose", EtPurpose.getText().toString());
                params.put("amount", EtAmount.getText().toString());
                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
