package com.avaskm.gstseva.activity;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.ApiFactory;
import com.avaskm.gstseva.Helper;
import com.avaskm.gstseva.IApiServices;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.VolleyMultipartRequest;
import com.avaskm.gstseva.adapter.DeedPartnerAdapter;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.PartnerLLP;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.google.gson.JsonObject;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import id.zelory.compressor.Compressor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.media.MediaRecorder.VideoSource.CAMERA;
import static com.avaskm.gstseva.activity.ProprietorActivity.CAMERA_REQUEST;
import static com.avaskm.gstseva.activity.ProprietorActivity.GALLERY_PICTURE;

public class TrustActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    Spinner trustSpinner;
    LinearLayout linear_trust1,linear_trust2;
    RecyclerView rv_deed_trust,rv_pan_trust,rv_adhar_trust,rv_photo_trust;
    View view1_trust;
    ImageView pan_trust,passbook_trust,elctricity_trust,img_rent_trust;
    Button btn_pan_trust,btn_passbook_trust,btn_electricity_trust,btn_rent_Trust;
    int count;
    Bitmap panBitmap,deedBitmap,panMultipleBitmap,AadharMultipleBitmap,PhotographMultipleBitmap,passbookBitmap,
    electricityBitmap,rentBitmap;
    Button btn_deed_select_trust,btn_pan_select_trust,btn_aadhar_select_trust,btn_photo_select_trust;
    Button btn_deed_upload_trust,btn_pan_upload_trust,btn_aadhar_upload_trust,btn_photo_upload_trust;
    Button btn_submitrust;
    SharedPreferences sharedPreferences_OrderId;
    SharedPreferences sharedPreferences_userId;
    SharedPreferences.Editor editor;
    String orderId,userId,formId;
    int PICK_IMAGE_MULTIPLE = 1;
    private static final int CAMERA_REQUEST1 = 100;
    private  String photoPathDEED,photoPathPan,photoPathAadhar,photoPathPhotograph;
    ArrayList<String> imagePathListDEED = new ArrayList<>();
    ArrayList<String> imagePathListPan = new ArrayList<>();
    ArrayList<String> imagePathListAadhar = new ArrayList<>();
    ArrayList<String> imagePathListPhotograph = new ArrayList<>();
    ArrayList<PartnerLLP> DEEDlist = new ArrayList<>();
    ArrayList<PartnerLLP> panlist = new ArrayList<>();
    ArrayList<PartnerLLP> aadharlist = new ArrayList<>();
    ArrayList<PartnerLLP> photolist = new ArrayList<>();
    String imageEncodedDEED,imageEncodedPan,imageEncodedAadhar,imageEncodedPhotograph;
    private DeedPartnerAdapter DEEDAdapter,panAdapter,aadharAdapter,photoAdapter;
    ProgressBar progressbarTrust;
    EditText edt_authorized;
    Spinner memberSpiner;
    String premiseType = "";
    int no_member;
    ArrayList<String> member = new ArrayList<String>();
    File photoDeedFile,photoPanFile,photoAadharFile,photoPhotographFile =null;
    Uri photoUriDeed,photoUriPAN,photoUriAadhar,photoUriPhotograph;
    String mCurrentDeedPath,mCurrentPanPath,mCurrentAadharPath,mCurrentPhotoPath;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trust);
        askForPermissioncamera(Manifest.permission.CAMERA, CAMERA);
        sharedPreferences_OrderId = getSharedPreferences("orderId",MODE_PRIVATE);
        editor = sharedPreferences_OrderId.edit();
        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        orderId = sharedPreferences_OrderId.getString("orderId","");
        formId = sharedPreferences_OrderId.getString("formId", "");
        userId = sharedPreferences_userId.getString("userid","");

        Log.d("jhjkksl",orderId + " "+userId);
        linear_trust2=findViewById(R.id.linear_trust2);
        linear_trust1=findViewById(R.id.linear_trust1);
        view1_trust=findViewById(R.id.view1_trust);
        pan_trust=findViewById(R.id.pan_trust);
        passbook_trust=findViewById(R.id.passbook_trust);
        elctricity_trust=findViewById(R.id.elctricity_trust);
        img_rent_trust=findViewById(R.id.img_rent_trust);
        btn_pan_trust=findViewById(R.id.btn_pan_trust);
        btn_passbook_trust=findViewById(R.id.btn_passbook_trust);
        btn_electricity_trust=findViewById(R.id.btn_electricity_trust);
        btn_rent_Trust=findViewById(R.id.btn_rent_Trust);
        rv_deed_trust=findViewById(R.id.rv_deed_trust);
        rv_pan_trust=findViewById(R.id.rv_pan_trust);
        rv_adhar_trust=findViewById(R.id.rv_adhar_trust);
        rv_photo_trust=findViewById(R.id.rv_photo_trust);
        btn_deed_select_trust=findViewById(R.id.btn_deed_select_trust);
        btn_pan_select_trust=findViewById(R.id.btn_pan_select_trust);
        btn_aadhar_select_trust=findViewById(R.id.btn_aadhar_select_trust);
        btn_photo_select_trust=findViewById(R.id.btn_photo_select_trust);
        btn_deed_upload_trust=findViewById(R.id.btn_deed_upload_trust);
        btn_pan_upload_trust=findViewById(R.id.btn_pan_upload_trust);
        btn_aadhar_upload_trust=findViewById(R.id.btn_aadhar_upload_trust);
        btn_photo_upload_trust=findViewById(R.id.btn_photo_upload_trust);
        btn_submitrust=findViewById(R.id.btn_submitrust);
        progressbarTrust=findViewById(R.id.progressbarTrust);
        edt_authorized=findViewById(R.id.edt_authorized);
        memberSpiner = (Spinner) findViewById(R.id.memberSpiner);
        memberSpiner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);
        member.add("Select No. Of Members");
        member.add("2");
        member.add("3");
        member.add("4");
        member.add("5");
        member.add("6");
        member.add("7");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, member);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        memberSpiner.setAdapter(dataAdapter);

        addItemsOnSpinner2();
        trustSpinner.setOnItemSelectedListener(new CustomOnItemSelectedListener());

        allSingleImageBtnUpload();
        uploadMultiple();
        btn_submitrust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edt_authorized.getText().toString().equals("")){
                    edt_authorized.setError("Please Enter Authorized Person Name");
                    edt_authorized.requestFocus();
                }
                else if(no_member==0){
                    Toast.makeText(TrustActivity.this, "Please Select No. Of Members", Toast.LENGTH_SHORT).show();
                }
                else if (premiseType.equalsIgnoreCase("premises type")) {
                    Toast.makeText(TrustActivity.this, "Please Select premises type", Toast.LENGTH_SHORT).show();
                }
                else{

                    hitFinalApi();

                }

            }
        });
    }

    private void hitFinalApi() {
        final ProgressDialog progressDialog = ProgressDialog.show(TrustActivity.this, "", "Wait...", false);
        progressDialog.show();
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setCancelable(false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.PartnershipUpdate, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    if(code.equals("200")){
                        Toast.makeText(TrustActivity.this, msg, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(TrustActivity.this, NavigationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        editor.clear();
                        editor.commit();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("orderid",orderId);
                hashMap.put("form_id", formId);
                hashMap.put("dir_name",edt_authorized.getText().toString());
                hashMap.put("no_of_members", String.valueOf(no_member));
                hashMap.put("premises_type", premiseType);

                Log.d("asdqwec", String.valueOf(hashMap));
                return hashMap;
            }
        };
        requestQueue.add(request);
    }

    private void uploadMultiple() {
        btn_deed_upload_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListDEED.size()==0){
                    Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitDeedApi();
                }

            }
        });
        btn_pan_upload_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListPan.size()==0){
                    Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitPanMultipleApi();
                }

            }
        });
        btn_aadhar_upload_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListAadhar.size()==0){
                    Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitAadharApi();
                }

            }
        });
        btn_photo_upload_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListPhotograph.size()==0){
                    Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitPhotoApi();
                }

            }
        });

    }

    public void hitDeedApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarTrust.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("partnershipdeed"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListDEED.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListDEED.get(i));
            try {
                File compressedfile = new Compressor(TrustActivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);
                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //  Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        Log.d("asfji",code);
                        Log.d("asasffji",msg);
                        if(imagePathListDEED.size()==0){
                            Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(TrustActivity.this, "Deed Documents upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(TrustActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Toast.makeText(TrustActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void hitPanMultipleApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarTrust.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("pan"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPan.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListPan.get(i));
            try {
                File compressedfile = new Compressor(TrustActivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);
                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //  Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        Log.d("asfji",code);
                        Log.d("asasffji",msg);
                        if(imagePathListPan.size()==0){
                            Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(TrustActivity.this, "Pan Documents upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(TrustActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Toast.makeText(TrustActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void hitAadharApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarTrust.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("aadhaar"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListAadhar.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListAadhar.get(i));
            try {
                File compressedfile = new Compressor(TrustActivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);
                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //  Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        Log.d("asfji",code);
                        Log.d("asasffji",msg);
                        if(imagePathListAadhar.size()==0){
                            Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(TrustActivity.this, "Aadhar Documents upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(TrustActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Toast.makeText(TrustActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void hitPhotoApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarTrust.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("photo"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPhotograph.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListPhotograph.get(i));
            try {
                File compressedfile = new Compressor(TrustActivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);
                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //  Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        Log.d("asfji",code);
                        Log.d("asasffji",msg);
                        if(imagePathListPhotograph.size()==0){
                            Toast.makeText(TrustActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(TrustActivity.this, "Photograph Documents upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(TrustActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarTrust.setVisibility(View.GONE);
//                        progressDialog.dismiss();
                        Toast.makeText(TrustActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }

    private void allSingleImageBtnUpload() {
        btn_pan_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=1;
                startDialog();
            }
        });
        btn_deed_select_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=2;
                startDialogMultipleDEED();
            }
        });
        btn_pan_select_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(no_member==0){
                    Toast.makeText(TrustActivity.this, "Please Select No. of Members", Toast.LENGTH_SHORT).show();
                }else{
                    count=3;
                    startDialogMultiplePan();
                }

            }
        });
        btn_aadhar_select_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(no_member==0){
                    Toast.makeText(TrustActivity.this, "Please Select No. of Members", Toast.LENGTH_SHORT).show();
                }else{
                    count=4;
                    startDialogMultipleaadhar();
                }

            }
        });
        btn_photo_select_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(no_member==0){
                    Toast.makeText(TrustActivity.this, "Please Select No. of Members", Toast.LENGTH_SHORT).show();
                }else{
                    count=5;
                    startDialogMultiplePhotograph();
                }

            }
        });
        btn_passbook_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=6;
                startDialog();
            }
        });
        btn_electricity_trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=7;
                startDialog();
            }
        });
        btn_rent_Trust.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=8;
                startDialog();
            }
        });
    }

    private void startDialog() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });

//        myAlertDialog.setNeutralButton("Pdf", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Intent intent = new Intent();
//                intent.setType("application/pdf");
//                intent.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
//            }
//        });
        myAlertDialog.show();
    }
    private void startDialogMultipleDEED() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }else {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);
                }


            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }
                else {
                    try {
                        takeDeedCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultiplePan() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }else {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);
                }


            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }
                else {
                    try {
                        takePanCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultipleaadhar() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }else {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);
                }


            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }
                else {
                    try {
                        takeAadharCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultiplePhotograph() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }else {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);
                }


            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(TrustActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                }
                else {
                    try {
                        takePhotoCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }

    public void addItemsOnSpinner2() {

        trustSpinner=findViewById(R.id.trustSpinner);
        List<String> list = new ArrayList<String>();
        list.add("premises type");
        list.add("owned");
        list.add("rented/leased");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        trustSpinner.setOnItemSelectedListener(new TrustActivity.CustomOnItemSelectedListener());
        trustSpinner.setAdapter(dataAdapter);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId()==R.id.memberSpiner){
            if (position == 1) {
                no_member = 2;
            }
            else if (position == 2) {
                no_member = 3;
            }
           else if (position == 3) {
                no_member = 4;
            }
            else if (position == 4) {
                no_member = 5;
            }
            else if (position == 5) {
                no_member = 6;
            }
            else if (position == 6) {
                no_member = 7;
            }
            else {
                no_member = 0;
            }
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (parent.getId() == R.id.trustSpinner) {
                if (position == 1) {
                    premiseType = "owned";
                    linear_trust1.setVisibility(View.VISIBLE);
                    view1_trust.setVisibility(View.VISIBLE);
                    linear_trust2.setVisibility(View.GONE);

                } else if (position == 2) {
                    premiseType = "rented / leased";
                    linear_trust1.setVisibility(View.VISIBLE);
                    view1_trust.setVisibility(View.VISIBLE);
                    linear_trust2.setVisibility(View.VISIBLE);
                } else {
                    premiseType = "premises type";
                    linear_trust1.setVisibility(View.GONE);
                    view1_trust.setVisibility(View.GONE);
                    linear_trust2.setVisibility(View.GONE);
                }

            }

        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }

    }
        protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            super.onActivityResult(requestCode, resultCode, data);

            panBitmap = null;
            rentBitmap=null;
            deedBitmap=null;
            panMultipleBitmap=null;
            AadharMultipleBitmap=null;
            PhotographMultipleBitmap=null;
            passbookBitmap=null;
            electricityBitmap=null;


            if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 1) {

                    try {
                        if (Build.VERSION.SDK_INT > 23) {
                            panBitmap = (Bitmap) data.getExtras().get("data");
                            pan_trust.setImageBitmap(panBitmap);
                            panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                            hitUrlForUploadImagePAN();
                        } else {
                            panBitmap = (Bitmap) data.getExtras().get("data");
                            pan_trust.setImageBitmap(panBitmap);
                            panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                            hitUrlForUploadImagePAN();
                        }

                    } catch (Exception e) {
                        e.printStackTrace();

                    }



            }
            else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 1) {
                if (data != null) {

                    try {
                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            panBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                            pan_trust.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                            hitUrlForUploadImagePAN();

                        } else {

                            Log.d("inelse", "inelse");

                            panBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                            panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                            Picasso.get().load(data.getDataString()).into(pan_trust);
                            hitUrlForUploadImagePAN();
                        }


                    } catch (Exception e) {
                    }


                }
            }
            else if ((resultCode == RESULT_OK && requestCode == 10) && count == 2) {

                    try {
                        Log.d("fsdjdksfa","dsffds");
                        rotateImageDeed();
                    } catch (Exception e) {
                        e.printStackTrace();


                }

            }
            else if ((requestCode == 786) && count == 2) {
                Log.d("asdewdfx","adspowdf");
                selectFromGalleryDEED(data);
            }
            else if ((resultCode == RESULT_OK && requestCode == 11) && count == 3) {
                   try {
                        Log.d("fsdjdksfa","dsffds");
                        rotateImagePan();
                    } catch (Exception e) {
                        e.printStackTrace();

                    }


            }
            else if ((requestCode == 786) && count == 3) {
                Log.d("asdewdfx","adspowdf");
                selectFromGalleryPan(data);
            }
            else if ((resultCode == RESULT_OK && requestCode == 12) && count == 4) {
                   try {
                        Log.d("fsdjdksfa","dsffds");
                       rotateImageAadhar();
                    } catch (Exception e) {
                        e.printStackTrace();

                    }

            }
            else if ((requestCode == 786) && count == 4) {
                Log.d("asdewdfx","adspowdf");
                selectFromGalleryAadhar(data);
            }
            else if ((resultCode == RESULT_OK && requestCode == 13) && count == 5) {
                   try {
                        Log.d("fsdjdksfa","dsffds");
                       rotateImagePhoto();
                    } catch (Exception e) {
                        e.printStackTrace();

                    }

            }
            else if ((requestCode == 786) && count == 5) {
                Log.d("asdewdfx","adspowdf");
                selectFromGalleryPhotograph(data);
            }
            else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 6) {

                try {
                    if (Build.VERSION.SDK_INT > 23) {
                        passbookBitmap = (Bitmap) data.getExtras().get("data");
                        passbook_trust.setImageBitmap(passbookBitmap);
                        passbookBitmap = Bitmap.createScaledBitmap(passbookBitmap, 800, 800, false);
                        hitUrlForUploadImagePassbook();
                    } else {
                        passbookBitmap = (Bitmap) data.getExtras().get("data");
                        passbook_trust.setImageBitmap(passbookBitmap);
                        passbookBitmap = Bitmap.createScaledBitmap(passbookBitmap, 800, 800, false);
                        hitUrlForUploadImagePassbook();
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                }



            }
            else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 6) {
                if (data != null) {

                    try {
                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            passbookBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                            passbook_trust.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                            hitUrlForUploadImagePassbook();

                        } else {

                            Log.d("inelse", "inelse");

                            passbookBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                            passbookBitmap = Bitmap.createScaledBitmap(passbookBitmap, 800, 800, false);
                            Picasso.get().load(data.getDataString()).into(passbook_trust);
                            hitUrlForUploadImagePassbook();
                        }


                    } catch (Exception e) {
                    }


                }
            }
            else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 7) {

                try {
                    if (Build.VERSION.SDK_INT > 23) {
                        electricityBitmap = (Bitmap) data.getExtras().get("data");
                        elctricity_trust.setImageBitmap(electricityBitmap);
                        electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                        hitUrlForUploadImageElectricity();
                    } else {
                        electricityBitmap = (Bitmap) data.getExtras().get("data");
                        elctricity_trust.setImageBitmap(electricityBitmap);
                        electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                        hitUrlForUploadImageElectricity();
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                }



            }
            else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 7) {
                if (data != null) {

                    try {
                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            electricityBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                            elctricity_trust.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                            hitUrlForUploadImageElectricity();

                        } else {

                            Log.d("inelse", "inelse");

                            electricityBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                            electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                            Picasso.get().load(data.getDataString()).into(elctricity_trust);
                            hitUrlForUploadImageElectricity();
                        }


                    } catch (Exception e) {
                    }


                }
            }
            else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 8) {

                try {
                    if (Build.VERSION.SDK_INT > 23) {
                        rentBitmap = (Bitmap) data.getExtras().get("data");
                        img_rent_trust.setImageBitmap(rentBitmap);
                        rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                        hitUrlForUploadImagerent();
                    } else {
                        rentBitmap = (Bitmap) data.getExtras().get("data");
                        img_rent_trust.setImageBitmap(rentBitmap);
                        rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                        hitUrlForUploadImagerent();
                    }

                } catch (Exception e) {
                    e.printStackTrace();

                }



            }
            else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 8) {
                if (data != null) {

                    try {
                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            rentBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                            img_rent_trust.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                            hitUrlForUploadImagerent();

                        } else {

                            Log.d("inelse", "inelse");

                            rentBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                            rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                            Picasso.get().load(data.getDataString()).into(img_rent_trust);
                            hitUrlForUploadImagerent();
                        }


                    } catch (Exception e) {
                    }


                }
            }

        }

    ///////////////////////////////////// single image api ///////////////////////////////////////////////////////////
    private void hitUrlForUploadImagePAN() {

        final ProgressDialog progressDialog=ProgressDialog.show(TrustActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(TrustActivity.this, "PanCard Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(panBitmap));
                params.put("document[]", dataPart);

                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImagePassbook() {

        final ProgressDialog progressDialog=ProgressDialog.show(TrustActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(TrustActivity.this, "Passbook Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "passbook");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(passbookBitmap));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImageElectricity() {

        final ProgressDialog progressDialog=ProgressDialog.show(TrustActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(TrustActivity.this, "Electricity Documents Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "electricitybill");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(electricityBitmap));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImagerent() {

        final ProgressDialog progressDialog=ProgressDialog.show(TrustActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(TrustActivity.this, "Rent Documents Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "rentagreement");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(rentBitmap));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }



    //////////////////////////////////////// select from camera ////////////////////////////////////////////////////

    private void takeDeedCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoDeedFile = createDeedFile();
                Log.d("checkexcesdp", String.valueOf(photoDeedFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoDeedFile = createDeedFile();
            photoUriDeed = FileProvider.getUriForFile(TrustActivity.this, getPackageName() + ".provider", photoDeedFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriDeed);
            startActivityForResult(takePictureIntent, 10);
        }

    }
    private File createDeedFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentDeedPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImageDeed() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoDeedFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListDEED.add(photoPath);
            deedBitmap = MediaStore.Images.Media.getBitmap(TrustActivity.this.getContentResolver(), photoUriDeed);
            deedBitmap = Bitmap.createScaledBitmap(deedBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                deedBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriDeed);

            } else {
                Log.d("inelse", "inelse");
                deedBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriDeed);
                deedBitmap = Bitmap.createScaledBitmap(deedBitmap, 800, 800, false);

            }

            imageModel.setImageMobile(deedBitmap);

            if (DEEDlist.size() < 20) {
                DEEDlist.add(imageModel);
            }


            if (DEEDlist.size() > 20) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_deed_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
            DEEDAdapter = new DeedPartnerAdapter(DEEDlist, TrustActivity.this);
            rv_deed_trust.setAdapter(DEEDAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    private void takePanCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPanFile = createPanFile();
                Log.d("checkexcesdp", String.valueOf(photoPanFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoPanFile = createPanFile();
            photoUriPAN = FileProvider.getUriForFile(TrustActivity.this, getPackageName() + ".provider", photoPanFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPAN);
            startActivityForResult(takePictureIntent, 11);
        }

    }
    private File createPanFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPanPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImagePan() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPanFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPan.add(photoPath);
            panMultipleBitmap = MediaStore.Images.Media.getBitmap(TrustActivity.this.getContentResolver(), photoUriPAN);
            panMultipleBitmap = Bitmap.createScaledBitmap(panMultipleBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                panMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPAN);

            } else {
                Log.d("inelse", "inelse");
                panMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPAN);
                panMultipleBitmap = Bitmap.createScaledBitmap(panMultipleBitmap, 800, 800, false);

            }

            imageModel.setImageMobile(panMultipleBitmap);

            if (panlist.size() < no_member) {
                panlist.add(imageModel);
            }


            if (panlist.size() > no_member) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_pan_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new DeedPartnerAdapter(panlist, TrustActivity.this);
            rv_pan_trust.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    private void takeAadharCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoAadharFile = createAadharFile();
                Log.d("checkexcesdp", String.valueOf(photoAadharFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoAadharFile = createAadharFile();
            photoUriAadhar = FileProvider.getUriForFile(TrustActivity.this, getPackageName() + ".provider", photoAadharFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriAadhar);
            startActivityForResult(takePictureIntent, 12);
        }

    }
    private File createAadharFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentAadharPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImageAadhar() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoAadharFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListAadhar.add(photoPath);
            AadharMultipleBitmap = MediaStore.Images.Media.getBitmap(TrustActivity.this.getContentResolver(), photoUriAadhar);
            AadharMultipleBitmap = Bitmap.createScaledBitmap(AadharMultipleBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                AadharMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriAadhar);

            } else {
                Log.d("inelse", "inelse");
                AadharMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriAadhar);
                AadharMultipleBitmap = Bitmap.createScaledBitmap(AadharMultipleBitmap, 800, 800, false);

            }

            imageModel.setImageMobile(AadharMultipleBitmap);

            if (aadharlist.size() < no_member) {
                aadharlist.add(imageModel);
            }


            if (aadharlist.size() > no_member) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_adhar_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
            aadharAdapter = new DeedPartnerAdapter(aadharlist, TrustActivity.this);
            rv_adhar_trust.setAdapter(aadharAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    private void takePhotoCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPhotographFile = createPhotoFile();
                Log.d("checkexcesdp", String.valueOf(photoPhotographFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoPhotographFile = createPhotoFile();
            photoUriPhotograph = FileProvider.getUriForFile(TrustActivity.this, getPackageName() + ".provider", photoPhotographFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPhotograph);
            startActivityForResult(takePictureIntent, 13);
        }

    }
    private File createPhotoFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImagePhoto() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPhotographFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPhotograph.add(photoPath);
            PhotographMultipleBitmap = MediaStore.Images.Media.getBitmap(TrustActivity.this.getContentResolver(), photoUriPhotograph);
            PhotographMultipleBitmap = Bitmap.createScaledBitmap(PhotographMultipleBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                PhotographMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPhotograph);

            } else {
                Log.d("inelse", "inelse");
                PhotographMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPhotograph);
                PhotographMultipleBitmap = Bitmap.createScaledBitmap(PhotographMultipleBitmap, 800, 800, false);

            }

            imageModel.setImageMobile(PhotographMultipleBitmap);

            if (photolist.size() < no_member) {
                photolist.add(imageModel);
            }


            if (photolist.size() > no_member) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_photo_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
            photoAdapter = new DeedPartnerAdapter(photolist, TrustActivity.this);
            rv_photo_trust.setAdapter(photoAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    //////////////////////////////////////// select from gallery ////////////////////////////////////////////////////

    private void selectFromGalleryDEED(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathDEED = Helper.pathFromUri(TrustActivity.this, mImageUri);
                        imagePathListDEED.add(photoPathDEED);


                        Log.d("kjdlsa", String.valueOf(mImageUri));
                        Log.d("kjdlwqsa", String.valueOf(photoPathDEED));

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedDEED = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            deedBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            deedBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            deedBitmap = Bitmap.createScaledBitmap(deedBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(deedBitmap);

                        if (DEEDlist.size() < 20) {
                            DEEDlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathDEED = Helper.pathFromUri(TrustActivity.this, mImageUri);
                    imagePathListDEED.add(photoPathDEED);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedDEED = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        deedBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        deedBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        deedBitmap = Bitmap.createScaledBitmap(deedBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(deedBitmap);

                    if (DEEDlist.size() < 20) {
                        DEEDlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(DEEDlist));
                    }
                }

                if (DEEDlist.size() > 20) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_deed_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
                DEEDAdapter = new DeedPartnerAdapter(DEEDlist, TrustActivity.this);
                rv_deed_trust.setAdapter(DEEDAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }
    private void selectFromGalleryPan(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPan = Helper.pathFromUri(TrustActivity.this, mImageUri);
                        imagePathListPan.add(photoPathPan);


                        Log.d("kjdlsa", String.valueOf(mImageUri));
                        Log.d("kjdlwqsa", String.valueOf(photoPathPan));

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPan = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            panMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            panMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            panMultipleBitmap = Bitmap.createScaledBitmap(panMultipleBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(panMultipleBitmap);

                        if (panlist.size() < no_member) {
                            panlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPan = Helper.pathFromUri(TrustActivity.this, mImageUri);
                    imagePathListPan.add(photoPathPan);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPan = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        panMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        panMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        panMultipleBitmap = Bitmap.createScaledBitmap(panMultipleBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(panMultipleBitmap);

                    if (panlist.size() < no_member) {
                        panlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(panlist));
                    }
                }

                if (panlist.size() > no_member) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_pan_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new DeedPartnerAdapter(panlist, TrustActivity.this);
                rv_pan_trust.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }
    private void selectFromGalleryAadhar(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathAadhar = Helper.pathFromUri(TrustActivity.this, mImageUri);
                        imagePathListAadhar.add(photoPathAadhar);


                        Log.d("kjdlsa", String.valueOf(mImageUri));
                        Log.d("kjdlwqsa", String.valueOf(photoPathAadhar));

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedAadhar = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            AadharMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            AadharMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            AadharMultipleBitmap = Bitmap.createScaledBitmap(AadharMultipleBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(AadharMultipleBitmap);

                        if (aadharlist.size() < no_member*2) {
                            aadharlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathAadhar = Helper.pathFromUri(TrustActivity.this, mImageUri);
                    imagePathListAadhar.add(photoPathAadhar);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedAadhar = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        AadharMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        AadharMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        AadharMultipleBitmap = Bitmap.createScaledBitmap(AadharMultipleBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(AadharMultipleBitmap);

                    if (aadharlist.size() < no_member*2) {
                        aadharlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(aadharlist));
                    }
                }

                if (aadharlist.size() > no_member*2) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_adhar_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
                aadharAdapter = new DeedPartnerAdapter(aadharlist, TrustActivity.this);
                rv_adhar_trust.setAdapter(aadharAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }
    private void selectFromGalleryPhotograph(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPhotograph = Helper.pathFromUri(TrustActivity.this, mImageUri);
                        imagePathListPhotograph.add(photoPathPhotograph);


                        Log.d("kjdlsa", String.valueOf(mImageUri));
                        Log.d("kjdlwqsa", String.valueOf(photoPathPhotograph));

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPhotograph = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            PhotographMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            PhotographMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            PhotographMultipleBitmap = Bitmap.createScaledBitmap(PhotographMultipleBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(PhotographMultipleBitmap);

                        if (photolist.size() < no_member) {
                            photolist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPhotograph = Helper.pathFromUri(TrustActivity.this, mImageUri);
                    imagePathListPhotograph.add(photoPathPhotograph);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPhotograph = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        PhotographMultipleBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        PhotographMultipleBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        PhotographMultipleBitmap = Bitmap.createScaledBitmap(PhotographMultipleBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(PhotographMultipleBitmap);

                    if (photolist.size() < no_member) {
                        photolist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(photolist));
                    }
                }

                if (photolist.size() > no_member) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_photo_trust.setLayoutManager(new LinearLayoutManager(TrustActivity.this, LinearLayoutManager.HORIZONTAL, false));
                photoAdapter = new DeedPartnerAdapter(photolist, TrustActivity.this);
                rv_photo_trust.setAdapter(photoAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    public byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, buffer);
        return buffer.toByteArray();
    }
    public static Bitmap handleSamplingAndRotationBitmap(Context context, Uri selectedImage)
            throws IOException {
        int MAX_HEIGHT = 1024;
        int MAX_WIDTH = 1024;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(selectedImage);
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(context, img, selectedImage);
        return img;
    }
    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }
    private static Bitmap rotateImageIfRequired(Context context, Bitmap img, Uri selectedImage) throws IOException {

        InputStream input = context.getContentResolver().openInputStream(selectedImage);
        ExifInterface ei = null;
        if (Build.VERSION.SDK_INT > 23) {
            ei = new ExifInterface(input);
        }


        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }


    }
    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }

    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(TrustActivity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(TrustActivity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(TrustActivity.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }

}
