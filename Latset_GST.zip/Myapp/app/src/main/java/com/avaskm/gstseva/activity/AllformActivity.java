package com.avaskm.gstseva.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.avaskm.gstseva.R;

public class AllformActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_allform);
    }
}
