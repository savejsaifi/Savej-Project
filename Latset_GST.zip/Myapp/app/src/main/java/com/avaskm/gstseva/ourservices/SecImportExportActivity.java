package com.avaskm.gstseva.ourservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.avaskm.gstseva.R;
import com.squareup.picasso.Picasso;

public class SecImportExportActivity extends AppCompatActivity {
    Button btn_uploadpan,btn_importaddharcardCard,btn_importphotograph;
    ImageView importpancard,importaddharcard,importuploadphoto;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_import_export);
        btn_uploadpan=findViewById(R.id.btnuploadpan);
        btn_importaddharcardCard=findViewById(R.id.btnimportaddharCard);
        btn_importphotograph=findViewById(R.id.btnimportphotograph);
        importpancard=findViewById(R.id.importpancard);
        importaddharcard=findViewById(R.id.importaddharcard);
        importuploadphoto=findViewById(R.id.importuploadphoto);
        btn_uploadpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 1;
                abc(v);
            }
        });
        btn_importaddharcardCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 2;
                abc(v);
            }
        });

        btn_importphotograph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 3;
                abc(v);
            }
        });
    }

    private void abc(View v){
        PopupMenu popupMenu = new PopupMenu(SecImportExportActivity.this,v);
        popupMenu.getMenuInflater().inflate(R.menu.menu_image, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {

//                    case R.id.Camera:
//                        try {
//                            Intent intent = new Intent();
//                            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
//                            startActivityForResult(intent, 1);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        break;
                    case R.id.Gallery:

                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_PICK);
                        startActivityForResult(intent, 0);
                        break;
                }
                return false;
            }
        });
        popupMenu.show();

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try{
            if (requestCode ==0 && count==1) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(importpancard);


            }
            else if( requestCode ==1 && count==1){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                importpancard.setImageBitmap(bitmap);
            }
            if (requestCode ==0 && count==2) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(importaddharcard);


            }
            else if( requestCode ==1 && count==2){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                importaddharcard.setImageBitmap(bitmap);
            }
            if (requestCode ==0 && count==3) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(importuploadphoto);


            }
            else if( requestCode ==1 && count==3){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                importuploadphoto.setImageBitmap(bitmap);
            }
        }
        catch (Exception e) {

        }

    }}
