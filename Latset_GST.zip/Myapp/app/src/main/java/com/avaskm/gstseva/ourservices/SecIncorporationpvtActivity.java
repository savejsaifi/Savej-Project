package com.avaskm.gstseva.ourservices;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.avaskm.gstseva.R;

import java.util.ArrayList;
import java.util.List;

public class SecIncorporationpvtActivity extends AppCompatActivity {
    Spinner spinSecorpo;
    LinearLayout secincorporation,ownsecincorpo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_incorporationpvt);
        secincorporation=findViewById(R.id.newseclineartancard);
        ownsecincorpo=findViewById(R.id.secsecsecondtanlinear);
        addItemsOnSpinner1();
    }
    public void addItemsOnSpinner1() {

        spinSecorpo = (Spinner) findViewById(R.id.selecrented);
        List<String> list = new ArrayList<String>();
        list.add("PRIMISES RENTED");
        list.add("OWNED");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinSecorpo.setOnItemSelectedListener(new SecIncorporationpvtActivity.CustomOnItemSelectedListener());
        spinSecorpo.setAdapter(dataAdapter);
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener{

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (parent.getId() == R.id.selecrented) {
                if (position == 0) {
                    secincorporation.setVisibility(View.VISIBLE);
                } else {
                    secincorporation.setVisibility(View.GONE);
                }
                if(position==1){
                    ownsecincorpo.setVisibility(View.VISIBLE);
                }
                else{
                    ownsecincorpo.setVisibility(View.GONE);
                }

            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
}
