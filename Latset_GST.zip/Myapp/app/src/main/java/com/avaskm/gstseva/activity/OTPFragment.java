package com.avaskm.gstseva.activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
public class OTPFragment extends AppCompatActivity {
    Button btnnext;
    EditText edt_username;
    String msgfrgt;
    String otpfrgt;
    String otpVerification,numberEt,msg,mobile;
    TextView resend,otpsubmitt,textnumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_otp);
        btnnext=findViewById(R.id.next);
        resend=findViewById(R.id.text_resend);
        edt_username=findViewById(R.id.txt_pin_entry1);
        textnumber=findViewById(R.id.textnumber);


        mobile=getIntent().getStringExtra("mobile");
        textnumber.setText(mobile);
        Log.d("jyoti",mobile);
        hitUrlForOtpagain();

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                 hitUrlForOtpagain();
            }
        });

        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!edt_username.getText().toString().equals(otpVerification)){

                    edt_username.setError("Please enter valid otp");
                    //RegisterAPI();
                }
                else if(edt_username.getText().toString().equals(" ")){
                    edt_username.setError("Please enter otp");
                }else {

                    hitRegisterApi();

                }
            }
        });
    }

    private void hitRegisterApi() {
        final ProgressDialog dialog = ProgressDialog.show(OTPFragment.this,"","Wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(OTPFragment.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.register_Url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        dialog.dismiss();

                        try {
                            Log.e("onResponse", ": " + response);
                            JSONArray jsonArray = new JSONArray(response);
                            JSONObject jo=jsonArray.getJSONObject(0);
                            String resultcode = jo.getString("code");
                            String msg = jo.getString("msg");
                            // String message = jsonObject.getString("data post sucessfully!");
                            if (resultcode.equalsIgnoreCase("200")) {
                                Intent intent=new Intent(OTPFragment.this, NavigationActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);

                             //   Toast.makeText(OTPFragment.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                                String userid = jo.getString("id");
                                String userMobile = jo.getString("mobile");
                                SharedPreferences sharedPreferences = getSharedPreferences("GstUser", Context.MODE_PRIVATE);
                                sharedPreferences.edit().putString("userid",userid).apply();
                                sharedPreferences.edit().putString("mobile",userMobile).apply();
//                                intent.putExtra("mobile",Mobileno);
//                                startActivity(intent);
                                // Toast.makeText(RegistrationFragment.this,msg,Toast.LENGTH_SHORT).show();

                            }else if(resultcode.equalsIgnoreCase("401")){
                                Intent intent=new Intent(OTPFragment.this,NavigationActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                // Toast.makeText(OTPFragment.this, "Login Successfully", Toast.LENGTH_SHORT).show();
                                String userid = jo.getString("id");
                                String userMobile = jo.getString("mobile");
                                SharedPreferences sharedPreferences = getSharedPreferences("GstUser", Context.MODE_PRIVATE);
                                sharedPreferences.edit().putString("userid",userid).apply();
                                sharedPreferences.edit().putString("mobile",userMobile).apply();
                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                dialog.dismiss();
                Toast.makeText(OTPFragment.this,
                        error.getMessage(), Toast.LENGTH_LONG).show();
            }
        })

        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("key", Api.key);
                params.put("mobile", mobile);
                params.put("status","1");
                Log.e("ParamResone", ": " + params);
                return params;
            }
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String, String>();
                params.put("Content-Type","application/x-www-form-urlencoded");
                return params;
            }
        };
        stringRequest.setRetryPolicy(
                new DefaultRetryPolicy(
                        500000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );
        requestQueue.add(stringRequest);

    }

    private void hitUrlForOtpagain(){
        otpfrgt = String.valueOf(randomOtp());
        msgfrgt = "Your verification code is "+otpfrgt;
        Log.d("msg",msgfrgt);
        Log.d("ekmulakataho",otpfrgt);
        String OTP_URL = "http://www.smsalert.co.in/api/push.json?";
        otpVerification=String.valueOf(randomOtp());

        msg = "Your verification code is "+otpVerification;

        Log.d("mssfg",msg);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, OTP_URL, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response)
            {
                Log.d("OTPppP",response);




                // Toast.makeText(OTPFragment.this, "OTP sent Again", Toast.LENGTH_SHORT).show();
            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(OTPFragment.this, "Something Wrong With Otp.", Toast.LENGTH_SHORT).show();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("apikey","5d441afed3490");
                hashMap.put("route", "transactional");
                hashMap.put("sender","BLUMON");
                hashMap.put("text",msg);
                hashMap.put("mobileno",  mobile);
                Log.d("hsdhs",mobile);
                return hashMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue = Volley.newRequestQueue(OTPFragment.this);

        requestQueue.add(stringRequest);
    }
    private int randomOtp(){
        Random rnd = new Random();
        int n = 1000 + rnd.nextInt(9000);
        // sp.edit().putInt("otp_id",n).commit();

        return n;
    }
}