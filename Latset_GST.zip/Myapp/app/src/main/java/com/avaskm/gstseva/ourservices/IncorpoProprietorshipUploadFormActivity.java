package com.avaskm.gstseva.ourservices;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.ApiFactory;
import com.avaskm.gstseva.FilePath;
import com.avaskm.gstseva.IApiServices;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.VolleyMultipartRequest;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.ImageModel;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.google.gson.JsonObject;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import net.gotev.uploadservice.MultipartUploadRequest;
import net.gotev.uploadservice.UploadNotificationConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class IncorpoProprietorshipUploadFormActivity extends AppCompatActivity  {

    LinearLayout linear_propreiter,linear_propreiter2,linear_propreiter3;
    ImageView adhar_front,adhar_back,passbook_properieter,photo_properieter,pancard,NOC,electricity_bill,rentAgreement;
    Button btn_panCard,btn_adhar_front,btn_adhar_back,btn_photo,btn_Passbook,btn_electricity,btn_NOC,btn_rent;
    Button btn_submit_Properieter;
    View view2,view1,view3;
    int count;
    Bitmap panBitmap,adharFrontBitmap,adharBackBitmap,photoBitmap,passbookBitmap,electricityBitmap,rentBitmap,nocBitmap;

    protected static final int CAMERA_REQUEST = 100;
    protected static final int GALLERY_PICTURE = 1;
    //Pdf request code

    private int PICK_PDF_REQUEST = 1;
    //storage permission code
    private static final int STORAGE_PERMISSION_CODE = 123;
    //Uri to store the image uri
    private Uri filePath;

    ArrayList<String> imagePathList;
    ArrayList<String> imagePathListPdf = new ArrayList<>();
    ArrayList<ImageModel> listPan;
    SharedPreferences sharedPreferences_userId;
    String premise;
    String orderid,userId;
    private static final String IMAGE_DIRECTORY = "/demonuts_upload_gallery";
    private static final int BUFFER_SIZE = 1024 * 2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorpo_proprietorship_upload_form);
        listPan = new ArrayList<>();
        imagePathList = new ArrayList<>();
        
        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences_userId.getString("userid","");
        Intent intent=getIntent();
        orderid=intent.getStringExtra("orderid");
        premise=intent.getStringExtra("premises");
        Log.d("Stringorderid",orderid+" "+premise);

        askForPermissioncamera(Manifest.permission.CAMERA,CAMERA);
        requestStoragePermission();
        requestMultiplePermissions();

        // Spinner element

        linear_propreiter =  findViewById(R.id.linear_propreiter_inc);
        linear_propreiter2 =  findViewById(R.id.linear_propreiter2_inc);
        linear_propreiter3 =  findViewById(R.id.linear_propreiter3_inc);
        view1 =  findViewById(R.id.view1_inc);
        view2 =  findViewById(R.id.view2_inc);
        view3 =  findViewById(R.id.view3_inc);

        adhar_front =  findViewById(R.id.adhar_front_inc_prop);
        adhar_back =  findViewById(R.id.adhar_back_inc_prop);
        passbook_properieter =  findViewById(R.id.passbook_properieter_inc);
        photo_properieter =  findViewById(R.id.photo_properieter_inc);
        pancard =  findViewById(R.id.prioritypancard_inc_prop);
        NOC =  findViewById(R.id.NOC_inc);
        electricity_bill =  findViewById(R.id.electricity_bill_inc_prop);
        rentAgreement =  findViewById(R.id.rentAgreement_inc_prop);

        btn_panCard =  findViewById(R.id.btn_panCardProperieter_inc_Prop);
        btn_adhar_front =  findViewById(R.id.btn_adhar_front_inc_prop);
        btn_adhar_back =  findViewById(R.id.btn_adhar_back_inc_prop);
        btn_photo =  findViewById(R.id.btn_photo_inc);
        btn_Passbook =  findViewById(R.id.btn_passbook_inc);
        btn_electricity =  findViewById(R.id.btn_electricity_inc_prop);
        btn_NOC =  findViewById(R.id.btn_NOC_inc);
        btn_rent =  findViewById(R.id.btn_rent_inc_prop);
        btn_submit_Properieter =  findViewById(R.id.btn_submit_Properieter_inc);


        spinnerPremise();

        allSingleImageBtnUpload();
        submit();
    }

    private void spinnerPremise() {
        if(premise.equalsIgnoreCase("owned")){
            linear_propreiter.setVisibility(View.VISIBLE);
            linear_propreiter3.setVisibility(View.VISIBLE);
            view1.setVisibility(View.VISIBLE);
            view3.setVisibility(View.VISIBLE);

            linear_propreiter2.setVisibility(View.GONE);
            view2.setVisibility(View.GONE);
        }
        if(premise.equalsIgnoreCase("rented / leased")){
            linear_propreiter2.setVisibility(View.VISIBLE);
            linear_propreiter3.setVisibility(View.VISIBLE);
            view2.setVisibility(View.VISIBLE);
            view3.setVisibility(View.VISIBLE);

            linear_propreiter.setVisibility(View.GONE);
            view1.setVisibility(View.GONE);
        }

    }


    //Requesting permission
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }

    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Displaying a toast
                Toast.makeText(this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }


    private void allSingleImageBtnUpload() {
        btn_panCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=1;
                startDialog();
//                hitUrlForUploadImagePan();
            }
        });
        btn_adhar_front.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=2;
                startDialog();

            }
        });
        btn_adhar_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=3;
                startDialog();
            }
        });
        btn_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=4;
                startDialog();



            }
        });
        btn_Passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=5;
                startDialog();

            }
        });

        btn_electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=6;
                startDialog();
            }
        });


        btn_rent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=7;
                startDialog();

            }
        });


        btn_NOC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=8;
                startDialogNOC();
            }
        });
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        panBitmap = null;
        adharFrontBitmap=null;
        adharBackBitmap=null;
        photoBitmap=null;
        passbookBitmap=null;


        if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==1) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    panBitmap = (Bitmap) data.getExtras().get("data");
                    pancard.setImageBitmap(panBitmap);
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    hitUrlForUploadImagePan();
                }
                else {
                    panBitmap = (Bitmap) data.getExtras().get("data");
                    pancard.setImageBitmap(panBitmap);
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    hitUrlForUploadImagePan();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==1) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    panBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    pancard.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagePan();

                } else {

                    Log.d("inelse", "inelse");

                    panBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(pancard);
                    hitUrlForUploadImagePan();
                }


            } catch (Exception e) {
            }

        }

//        else if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null && count==1) {
//            filePath = data.getData();
//        }


        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==2) {

            try {
                adharFrontBitmap = (Bitmap) data.getExtras().get("data");
                adharFrontBitmap = Bitmap.createScaledBitmap(adharFrontBitmap, 800, 800, false);
                adhar_front.setImageBitmap(adharFrontBitmap);

                hitUrlForUploadImageAadharFront();
            } catch (Exception e) {
                e.printStackTrace();

            }

        } else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==2) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    adharFrontBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    adhar_front.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageAadharFront();

                } else {

                    Log.d("inelse", "inelse");

                    adharFrontBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    adharFrontBitmap = Bitmap.createScaledBitmap(adharFrontBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(adhar_front);
                    hitUrlForUploadImageAadharFront();
                }


            } catch (Exception e) {
            }

        }

        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==3) {


            try {
                adharBackBitmap = (Bitmap) data.getExtras().get("data");
                adharBackBitmap = Bitmap.createScaledBitmap(adharBackBitmap, 800, 800, false);
                adhar_back.setImageBitmap(adharBackBitmap);
                hitUrlForUploadImageAadharBack();

            } catch (Exception e) {
                e.printStackTrace();

            }

        } else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==3) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    adharBackBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    adhar_back.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageAadharBack();

                } else {

                    Log.d("inelse", "inelse");

                    adharBackBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    adharBackBitmap = Bitmap.createScaledBitmap(adharBackBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(adhar_back);
                    hitUrlForUploadImageAadharBack();
                }


            } catch (Exception e) {
            }


        }

        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==4) {


            try {
                photoBitmap = (Bitmap) data.getExtras().get("data");
                photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
                photo_properieter.setImageBitmap(photoBitmap);
                hitUrlForUploadImagePhoto();
            } catch (Exception e) {
                e.printStackTrace();

            }

        } else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==4) {

            try {

                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    photo_properieter.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagePhoto();

                } else {

                    Log.d("inelse", "inelse");

                    photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(photo_properieter);
                    hitUrlForUploadImagePhoto();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==5) {


            try {
                passbookBitmap = (Bitmap) data.getExtras().get("data");
                passbookBitmap = Bitmap.createScaledBitmap(passbookBitmap, 800, 800, false);
                passbook_properieter.setImageBitmap(passbookBitmap);
                hitUrlForUploadImagePassbook();
            } catch (Exception e) {
                e.printStackTrace();


            }

        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==5) {

            try {

                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    passbookBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    passbook_properieter.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagePassbook();

                } else {

                    Log.d("inelse", "inelse");

                    passbookBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    passbookBitmap = Bitmap.createScaledBitmap(passbookBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(passbook_properieter);
                    hitUrlForUploadImagePassbook();
                }


            } catch (IOException e) {
                e.printStackTrace();
            }


        }


        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==6) {


            try {
                electricityBitmap = (Bitmap) data.getExtras().get("data");
                electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                electricity_bill.setImageBitmap(electricityBitmap);
                hitUrlForUploadImageElectricitty();
            } catch (Exception e) {
                e.printStackTrace();


            }

        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==6) {

            try {


                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    electricityBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    electricity_bill.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageElectricitty();

                } else {

                    Log.d("inelse", "inelse");

                    electricityBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(electricity_bill);
                    hitUrlForUploadImageElectricitty();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }


        }

        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==7) {


            try {
                rentBitmap = (Bitmap) data.getExtras().get("data");
                rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                rentAgreement.setImageBitmap(rentBitmap);

                hitUrlForUploadImagerent();
            } catch (Exception e) {
                e.printStackTrace();

            }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==7) {

            try {


                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    rentBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    rentAgreement.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagerent();

                } else {

                    Log.d("inelse", "inelse");
                    rentBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(rentAgreement);
                    hitUrlForUploadImagerent();
                }

            } catch (IOException e) {
                e.printStackTrace();

            }
        }


        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==8) {


            try {
                nocBitmap = (Bitmap) data.getExtras().get("data");
                nocBitmap = Bitmap.createScaledBitmap(nocBitmap, 800, 800, false);
                NOC.setImageBitmap(nocBitmap);

                hitUrlForUploadImageNOC();
            } catch (Exception e) {
                e.printStackTrace();


            }

        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==8) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    nocBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    NOC.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageNOC();

                } else {

                    Log.d("inelse", "inelse");
                    nocBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    nocBitmap = Bitmap.createScaledBitmap(nocBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(NOC);
                    hitUrlForUploadImageNOC();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        if ((resultCode == RESULT_OK && requestCode == 200) && count==8) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(IncorpoProprietorshipUploadFormActivity.this,uri);
            Log.d("ioooo",path);
            imagePathListPdf.add(path);
            uploadPDF(path);
        }

    }

    private void uploadPDF(String path){

        String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
        //Create a file object using file path

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
        partMap.put("type", ApiFactory.getRequestBodyFromString("noc"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderid));

        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        //File f1= new File(path);
        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPdf.size()];
        File file = new File(path);
        // Parsing any Media type file
        RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

        Log.d("filename===",file.getName());
        imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
        RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);



        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {

                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        if(imagePathListPdf.size()==0){
                            Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        //  progressbarPrivate.setVisibility(View.GONE);
                        // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });

    }

    public static String getFilePathFromURI(Context context, Uri contentUri) {
        //copy file and send new file path
        String fileName = getFileName(contentUri);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }
        if (!TextUtils.isEmpty(fileName)) {
            File copyFile = new File(wallpaperDirectory + File.separator + fileName);
            // create folder if not exists

            copy(context, contentUri, copyFile);
            return copyFile.getAbsolutePath();
        }
        return null;
    }

    public static String getFileName(Uri uri) {
        if (uri == null) return null;
        String fileName = null;
        String path = uri.getPath();
        int cut = path.lastIndexOf('/');
        if (cut != -1) {
            fileName = path.substring(cut + 1);
        }
        return fileName;
    }

    public static void copy(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            copystream(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int copystream(InputStream input, OutputStream output) throws Exception, IOException {
        byte[] buffer = new byte[BUFFER_SIZE];

        BufferedInputStream in = new BufferedInputStream(input, BUFFER_SIZE);
        BufferedOutputStream out = new BufferedOutputStream(output, BUFFER_SIZE);
        int count = 0, n = 0;
        try {
            while ((n = in.read(buffer, 0, BUFFER_SIZE)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
            try {
                in.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
        }
        return count;
    }




    private void submit(){
        btn_submit_Properieter.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void onClick(View v) {

                //   Toast.makeText(IncorpoProprietorshipUploadFormActivity.this,"Upload Documents Successfully",Toast.LENGTH_SHORT);

//                if((pancard.isInLayout())||(adhar_front.isInLayout())||
//                        (adhar_back.isInLayout())||(photo_properieter.isInLayout())||
//                        (passbook_properieter.isInLayout())||(NOC.isInLayout())||
//                        (rentAgreement.isInLayout())){

                if(!(count==1)&&(count==2)&& (count==3)&&(count==4)&& (count==5)&&(count==6)&&
                        (count==7)&&(count==8)){

                    Log.d("adasd","alad");
                    startActivity(new Intent(getApplicationContext(), NavigationActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    //   Toast.makeText(IncorpoProprietorshipUploadFormActivity.this,"Please Upload PanCard Image",Toast.LENGTH_SHORT).show();

                }

                
                else{
                    startActivity(new Intent(getApplicationContext(), NavigationActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    Toast.makeText(IncorpoProprietorshipUploadFormActivity.this,"Upload Dcoument Successfully",Toast.LENGTH_SHORT);
                }

            }
        });
    }

    public byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, buffer);
        return buffer.toByteArray();
    }



    private void startDialog() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });

//        myAlertDialog.setNeutralButton("Pdf", new DialogInterface.OnClickListener() {
//            @Override
//            public void onClick(DialogInterface dialog, int which) {
//                Intent intent = new Intent();
//                intent.setType("application/pdf");
//                intent.setAction(Intent.ACTION_GET_CONTENT);
//                startActivityForResult(Intent.createChooser(intent, "Select Pdf"), PICK_PDF_REQUEST);
//            }
//        });
        myAlertDialog.show();
    }
    private void startDialogNOC() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });

        myAlertDialog.setNeutralButton("Pdf", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(intent,200);
            }
        });
        myAlertDialog.show();
    }
    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(IncorpoProprietorshipUploadFormActivity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(IncorpoProprietorshipUploadFormActivity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(IncorpoProprietorshipUploadFormActivity.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }

    private void hitUrlForUploadImagePan() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "PanCard Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(panBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImageAadharFront() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Aadhar Card Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "aadhaar");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(adharFrontBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImageAadharBack() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Aadhar Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "aadhaar");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(adharBackBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImagePhoto() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Photo Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "photo");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(photoBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImagePassbook() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Passbook Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "passbook");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(passbookBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImageElectricitty() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Electricity Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "electricitybill");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(electricityBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImagerent() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "Rent image Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "rent_aggrement");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(rentBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImageNOC() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoProprietorshipUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST,Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(IncorpoProprietorshipUploadFormActivity.this, "noc image Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderid);
                params.put("userid", userId);
                params.put("type", "noc");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(nocBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }


    private void  requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }
    public static Bitmap handleSamplingAndRotationBitmap(Context context, Uri selectedImage)
            throws IOException {
        int MAX_HEIGHT = 1024;
        int MAX_WIDTH = 1024;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(selectedImage);
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(context, img, selectedImage);
        return img;
    }

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }

    private static Bitmap rotateImageIfRequired(Context context, Bitmap img, Uri selectedImage) throws IOException {

        InputStream input = context.getContentResolver().openInputStream(selectedImage);
        ExifInterface ei = null;
        if (Build.VERSION.SDK_INT > 23) {
            ei = new ExifInterface(input);
        }


        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }


    }
    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }
}