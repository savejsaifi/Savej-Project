package com.avaskm.gstseva.ourservices;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.NoOfYearModel;
import com.avaskm.gstseva.model.StateSpinnerModel;
import com.avaskm.gstseva.navigation.MainsecActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FoodlincenseActivity extends AppCompatActivity {
    Spinner SpnConstitution, SpnState, SpnAnyOther, SpnStateSecond, SpnBusiness, SpnTurnOver, SpnYear;
    LinearLayout LinearYesNo, linear_customer_write_here, linear_no_of_year;

    EditText EtNameOfFirmShop, EtAddress, EtDistrict, EtPinCode, EtLandmark, EtAddressSecond, EtDistrictSecond, EtPinCodeSecond, EtLandmarkSecond, EtMobile, EtEmail, EtCustomerWriteHere;


    Button BtnSubmit;

    final Context context = this;
    String[] constitutions = {"Select constitution", "Proprietor/ shopkeeper", "Partnership", "Private limited company", "Huf"};
    String[] AnyOtherBusiness = {"Any other business address in same state", "No", "Yes"};
    String[] Business = {"Select business type", "Shopkeeper/Retailer", "Restaurant/ Dhaba", "Cater/Supplier", "Wholesaler", "Distributor", "Supplier", "Milk/Dairy Products Manufacturer", "Oil/Ghee Manufacturer", "Salughtering Unit", "Meat Reprocessing Unit", "Importer", "Storage/Cold Storage", "Hotel", "Tea Shop", "Other"};
    String[] Turnover = {"Selcet turnover", "Turnover upto 12 lakh", "Turnover more than 12 lakh"};
    TextView TvRegistationFirst, TvYearFirst, TvPriceValueFirst, TvMaxFirst, TvRegistationSecond, TvYearSecond, TvPriceValueSecond, TvMaxSecond, TvOk, TvPrice;
    String constitut, state, anyOther, stateSecond, businessType, turnoverType, NoOfYear, Price, orderid, title;

    ArrayList<StateSpinnerModel> listState1_model = new ArrayList<>();
    ArrayList<String> listState1 = new ArrayList<>();

    ArrayList<StateSpinnerModel> listState1_mode2 = new ArrayList<>();
    ArrayList<String> listState2 = new ArrayList<>();

    ArrayList<NoOfYearModel> arListNoOfYearMOdel = new ArrayList<>();
    ArrayList<String> arListYear = new ArrayList<>();


    private Dialog mDialogConfirmPopUp;
    SharedPreferences sharedPreferences;
    String userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodlincense);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Log.d("asdfw",userId);
        TvPrice = (TextView) findViewById(R.id.tv_price_food);
        EtNameOfFirmShop = (EditText) findViewById(R.id.tv_name_firm_shop_food);
        EtAddress = (EditText) findViewById(R.id.et_address_food);
        EtDistrict = (EditText) findViewById(R.id.et_district_food);
        EtPinCode = (EditText) findViewById(R.id.et_pin_code_food);
        EtLandmark = (EditText) findViewById(R.id.et_landmark_food);
        EtDistrictSecond = (EditText) findViewById(R.id.et_district_food_second_spn);
        EtAddressSecond = (EditText) findViewById(R.id.et_address_food_second_spn);
        EtPinCodeSecond = (EditText) findViewById(R.id.et_pin_code_food_second_spn);
        EtLandmarkSecond = (EditText) findViewById(R.id.et_landmark_food_second_spn);
        EtMobile = (EditText) findViewById(R.id.et_mobile_food);
        EtEmail = (EditText) findViewById(R.id.et_email_food);
        EtCustomerWriteHere = (EditText) findViewById(R.id.et_customer_write_here);
        TvRegistationFirst = (TextView) findViewById(R.id.tv_registration_first_food);
        TvYearFirst = (TextView) findViewById(R.id.tv_year_first_food);
        TvPriceValueFirst = (TextView) findViewById(R.id.tv_price_value_first_food);
        TvMaxFirst = (TextView) findViewById(R.id.tv_max_first_food);
        TvRegistationSecond = (TextView) findViewById(R.id.tv_registration_second_food);
        TvYearSecond = (TextView) findViewById(R.id.tv_year_second_food);
        TvPriceValueSecond = (TextView) findViewById(R.id.tv_price_value_second_food);
        TvMaxSecond = (TextView) findViewById(R.id.tv_max_second_food);


        SpnConstitution = (Spinner) findViewById(R.id.spn_constitution_food);
        SpnState = (Spinner) findViewById(R.id.spn_state_food);
        SpnAnyOther = (Spinner) findViewById(R.id.spn_any_other_business);
        SpnStateSecond = (Spinner) findViewById(R.id.spn_state_food_second_spn);
        SpnBusiness = (Spinner) findViewById(R.id.spn_business_food);
        LinearYesNo = (LinearLayout) findViewById(R.id.linear_yes_no);
        linear_customer_write_here = (LinearLayout) findViewById(R.id.linear_customer_write_here);
        SpnTurnOver = (Spinner) findViewById(R.id.spn_turnover_food);
        linear_no_of_year = (LinearLayout) findViewById(R.id.linear_no_of_year);
        SpnYear = (Spinner) findViewById(R.id.spn_no_of_year_food);
        BtnSubmit = (Button) findViewById(R.id.btn_submit_gstfill);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        SpnConstitution.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                constitut = String.valueOf(SpnConstitution.getItemAtPosition(i));
                Log.d("repeatSpin", constitut);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                state = String.valueOf(SpnState.getItemAtPosition(i));
                Log.d("state", state);
              /* String stateName1 = listState1_model.get(i).getStateName();
                Log.d("stateName1", stateName1);*/
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnAnyOther.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                anyOther = String.valueOf(SpnAnyOther.getItemAtPosition(i));
                Log.d("anyOther", anyOther);


                if (anyOther.equalsIgnoreCase("Yes")) {
                    LinearYesNo.setVisibility(View.VISIBLE);
                } else if (anyOther.equalsIgnoreCase("No")) {
                    LinearYesNo.setVisibility(View.GONE);
                }

                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnStateSecond.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                stateSecond = String.valueOf(SpnStateSecond.getItemAtPosition(i));
                Log.d("stateSecond", stateSecond);
              /* String stateName1 = listState1_model.get(i).getStateName();
                Log.d("stateName1", stateName1);*/
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnBusiness.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                businessType = String.valueOf(SpnBusiness.getItemAtPosition(i));
                Log.d("businessType", businessType);
                if (businessType.equalsIgnoreCase("Other")) {
                    linear_customer_write_here.setVisibility(View.VISIBLE);

                } else {
                    linear_customer_write_here.setVisibility(View.GONE);
                }


                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnTurnOver.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                turnoverType = String.valueOf(SpnTurnOver.getItemAtPosition(i));
                Log.d("turnoverType", turnoverType);

                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
                if (turnoverType.equalsIgnoreCase("Turnover more than 12 lakh")) {
                    FoodPop();

                } else if (turnoverType.equalsIgnoreCase("Turnover upto 12 lakh")) {
                    linear_no_of_year.setVisibility(View.VISIBLE);
                } else {
                    linear_no_of_year.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                Price = arListNoOfYearMOdel.get(i).getPrice();
                Log.d("PricePrice", Price);
                TvPrice.setText(Price);

                NoOfYear = String.valueOf(SpnYear.getItemAtPosition(i));
                Log.d("NoOfYear", NoOfYear);

                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> countTablet = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, constitutions);
        SpnConstitution.setAdapter(countTablet);

        ArrayAdapter<String> anyOtherBusiness = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, AnyOtherBusiness);
        SpnAnyOther.setAdapter(anyOtherBusiness);

        ArrayAdapter<String> businessAdapter = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Business);
        SpnBusiness.setAdapter(businessAdapter);


        ArrayAdapter<String> TurnoverAdapter = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Turnover);
        SpnTurnOver.setAdapter(TurnoverAdapter);

        GetCategoryInForAPI();
        hitstateSpinnerApi();
        hitstateSpinnerSecondApi();
        NoOfYearSpinnerApi();


        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setSubmit()) {

                }

            }
        });


    }


    private boolean setName() {
        if (EtNameOfFirmShop.getText().toString().length() > 0) {
            return true;
        } else {
            EtNameOfFirmShop.setError("Please enter name of firm/shop");
            return false;
        }
    }

    private boolean setConstitution() {
        if (!constitut.equalsIgnoreCase("Select constitution")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please seclect constitution", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setAddress() {
        if (EtAddress.getText().toString().length() > 0) {
            return true;
        } else {
            EtAddress.setError("Please enter address");
            return false;
        }
    }

    private boolean setDistrict() {
        if (EtDistrict.getText().toString().length() > 0) {
            return true;
        } else {
            EtDistrict.setError("Please enter district");
            return false;
        }
    }

    private boolean setState() {
        if (!state.equalsIgnoreCase("Select state")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please select state", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setPincode() {
        if (EtPinCode.getText().toString().length() > 0) {
            return true;
        } else {
            EtPinCode.setError("Pleae enter pincode");
            return false;
        }
    }

    private boolean setLandmark() {
        if (EtLandmark.getText().toString().length() > 0) {
            return true;
        } else {
            EtLandmark.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setDistrictSecond() {
        if (EtDistrictSecond.getText().toString().length() > 0) {
            return true;

        } else {
            EtDistrictSecond.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setStateSecond() {
        if (!stateSecond.equalsIgnoreCase("Select state")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please Select state", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setPincodeSecond() {
        if (EtPinCodeSecond.getText().toString().length() > 0) {
            return true;

        } else {
            EtPinCodeSecond.setError("Please enter pincode");
            return false;
        }
    }

    private boolean setLandmarkSecond() {
        if (EtLandmarkSecond.getText().toString().length() > 0) {
            return true;
        } else {
            EtLandmarkSecond.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setAnyOther() {
        if (!anyOther.equalsIgnoreCase("Any other business address in same state")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please select any other business", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setMobile() {
        if (EtMobile.getText().toString().length() > 0) {
            return true;
        } else {
            EtMobile.setError("Please enter 10 digit no");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtEmail.setError("Please enter email");
            return false;
        }
    }

    private boolean setBusinessType() {
        if (!businessType.equalsIgnoreCase("Select business type")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please Select business type", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setTurn() {
        if (!turnoverType.equalsIgnoreCase("Selcet turnover")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please selcet turnover", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setNoOfYear() {
        if (!NoOfYear.equalsIgnoreCase("Select no of year")) {
            return true;
        } else {
            Toast.makeText(FoodlincenseActivity.this, "Please Select no of year", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setSubmit() {
        if (!setName()) {
            return false;
        } else if (!setConstitution()) {
            return false;
        } else if (!setAddress()) {
            return false;
        } else if (!setDistrict()) {
            return false;
        } else if (!setState()) {
            return false;
        } else if (!setPincode()) {
            return false;
        } else if (!setLandmark()) {
            return false;
        } /*else if (!setDistrictSecond()) {
            return false;

        } else if (!setStateSecond()) {
            return false;
        } else if (!setPincodeSecond()) {
            return false;
        } else if (!setLandmarkSecond()) {
            return false;
        }*/ else if (!setAnyOther()) {
            return false;
        } else if (!setMobile()) {
            return false;
        } else if (!setEmail()) {
            return false;
        } else if (!setBusinessType()) {
            return false;
        } else if (!setTurn()) {
            return false;
        } else if (!setNoOfYear()) {
            return false;
        }

        MakeOrderAPI();
        return true;
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(FoodlincenseActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCategoryFoodAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    JSONArray priceArray = dataObject.getJSONArray("prices");
                    JSONObject priceObject = priceArray.getJSONObject(0);
                    String type = priceObject.getString("type");
                    String key = priceObject.getString("key");
                    String validity = priceObject.getString("validity");
                    String value = priceObject.getString("value");

                    TvRegistationFirst.setText(type);
                    TvYearFirst.setText(key);
                    TvPriceValueFirst.setText(value);
                    TvMaxFirst.setText(validity);
                    Log.d("typefood", type);
                    JSONObject priceObjectsecond = priceArray.getJSONObject(1);

                    String typesecond = priceObjectsecond.getString("type");
                    String keysecond = priceObjectsecond.getString("key");
                    String validitysecond = priceObjectsecond.getString("validity");
                    String valuesecond = priceObjectsecond.getString("value");

                    TvRegistationSecond.setText(typesecond);
                    TvYearSecond.setText(keysecond);
                    TvPriceValueSecond.setText(valuesecond);

                    TvMaxSecond.setText(validitysecond);
                    Log.d("valuesecond", valuesecond);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("category", title);


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(FoodlincenseActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(FoodlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responseState", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    listState1.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState1_model.add(model);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_model.add(model);
                        listState1.add(jsonObject1.getString("state_name"));
                    }


                    ArrayAdapter aa = new ArrayAdapter(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, listState1);
                    SpnState.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void hitstateSpinnerSecondApi() {
        RequestQueue queue = Volley.newRequestQueue(FoodlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responseState", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    listState2.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState1_mode2.add(model);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_mode2.add(model);
                        listState2.add(jsonObject1.getString("state_name"));
                    }


                    ArrayAdapter aa = new ArrayAdapter(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, listState2);
                    SpnStateSecond.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void FoodPop() {
        {
            LayoutInflater inflater = LayoutInflater.from(FoodlincenseActivity.this);
            mDialogConfirmPopUp = new Dialog(FoodlincenseActivity.this,
                    android.R.style.Theme_Translucent_NoTitleBar);
            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
            lp.dimAmount = 0.75f;
            mDialogConfirmPopUp.getWindow()
                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialogConfirmPopUp.getWindow();

            View dialoglayout = inflater.inflate(R.layout.pop_food, null);
            mDialogConfirmPopUp.setContentView(dialoglayout);
            TvOk = (TextView) mDialogConfirmPopUp.findViewById(R.id.tv_ok_pop_food);
            TvOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    mDialogConfirmPopUp.dismiss();
                    ArrayAdapter<String> TurnoverAdapter = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Turnover);
                    SpnTurnOver.setAdapter(TurnoverAdapter);

                }
            });
            mDialogConfirmPopUp.show();
        }
        ArrayAdapter<String> TurnoverAdapter = new ArrayAdapter<String>(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, Turnover);
        SpnTurnOver.setAdapter(TurnoverAdapter);

    }


    private void NoOfYearSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(FoodlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responYear", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    JSONArray priceArray = dataObject.getJSONArray("prices");

                    arListYear.add("Select no of year");
                    NoOfYearModel model = new NoOfYearModel();
                    model.setYear("Select no of year");
                    model.setPrice("");
                    arListNoOfYearMOdel.add(model);

                    for (int i = 0; i < priceArray.length(); i++) {
                        model = new NoOfYearModel();
                        JSONObject priceObject = priceArray.getJSONObject(i);
                        model.setPrice(priceObject.getString("value"));
                        model.setYear(priceObject.getString("key"));
                        String key = priceObject.getString("key");
                        Log.d("keyy", key);
                        arListNoOfYearMOdel.add(model);
                        arListYear.add(priceObject.getString("key"));
                    }
                    ArrayAdapter noOfYearAdapter = new ArrayAdapter(FoodlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, arListYear);
                    SpnYear.setAdapter(noOfYearAdapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("category", "Food License");


                return hashMap;
            }
        };
        queue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(FoodlincenseActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("FoodResponse", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("Foodorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {

                        Intent intent = new Intent(FoodlincenseActivity.this, FoodLicenseUploadFormActivity.class);
                        intent.putExtra("orderid", orderid);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(FoodlincenseActivity.this, msg, Toast.LENGTH_SHORT).show();


                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category", title);
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("firm_name", EtNameOfFirmShop.getText().toString());
                params.put("business_type", businessType);
                if (businessType.equalsIgnoreCase("Other")) {
                    params.put("business_type", EtCustomerWriteHere.getText().toString());
                }

                params.put("district", EtDistrict.getText().toString());
                params.put("state", state);
                params.put("pincode", EtPinCode.getText().toString());
                params.put("constitution", constitut);
                params.put("landmark", EtLandmark.getText().toString());
                params.put("other_business", anyOther);
                if (anyOther.equalsIgnoreCase("Yes")) {

                    params.put("other_state", stateSecond);
                    params.put("other_disctrict", EtDistrictSecond.getText().toString());
                    params.put("other_pincode", EtPinCodeSecond.getText().toString());
                    params.put("other_landmark", EtLandmarkSecond.getText().toString());
                } else if (anyOther.equalsIgnoreCase("No")) {
                    params.put("other_state", "");
                    params.put("other_disctrict", "");
                    params.put("other_pincode", "");
                    params.put("other_landmark", "");
                }
                params.put("address", EtAddress.getText().toString());
                params.put("turnover", turnoverType);
                params.put("number_of_years", NoOfYear);
                params.put("price", Price);

                Log.d("allItr", String.valueOf(params));


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(FoodlincenseActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}