package com.avaskm.gstseva.ourservices;
import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.Helper;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.ImageModel;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TancardActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{

  Spinner tan_spinner;
    String[] typeTan = {"Select Type Tan","New Tan No.","correction in old Tan No."};
    String tan;
    Button btn_submit_tan;
    EditText edt_mobile_Tan,edt_email_Tan;
    TextView tv_price_tancard;
    String price;
    String userId,title;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tancard);

        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        btn_submit_tan = findViewById(R.id.btn_submit_tan);
        edt_mobile_Tan = findViewById(R.id.edt_mobile_Tan);
        edt_email_Tan = findViewById(R.id.edt_email_Tan);
        tv_price_tancard = findViewById(R.id.tv_price_tancard);
        hitAPiPrice();

        tan_spinner = findViewById(R.id.tan_spinner);
        tan_spinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,typeTan);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        tan_spinner.setAdapter(aa);

        btn_submit_tan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edt_mobile_Tan.getText().toString().equals("")){
                    edt_mobile_Tan.setError("Please enter Mobile No.");
                    edt_mobile_Tan.requestFocus();
                }
                else if(edt_mobile_Tan.getText().toString().length()!=10){
                    edt_mobile_Tan.setError("Mobile No. should be 10 digit");
                    edt_mobile_Tan.requestFocus();
                }
                if(edt_email_Tan.getText().toString().equals("")){
                    edt_email_Tan.setError("Please enter Email");
                    edt_email_Tan.requestFocus();
                }
                else if (!(edt_email_Tan.getText().toString().matches(emailPattern) && edt_email_Tan.getText().toString().length() > 0)) {
                    edt_email_Tan.setError("Please enter the valid Email");
                    edt_email_Tan.requestFocus();
                }
               else if(tan.equals("Select Type Tan")) {
                    Toast.makeText(TancardActivity.this, "Please Select Tan Type", Toast.LENGTH_SHORT).show();
                    //  startActivity(new Intent(getApplicationContext(),PancardActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                }

                else {

                    hitRegisterApi();

                }
            }
        });
    }

    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(TancardActivity.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");
                         if(tan.equalsIgnoreCase("New Tan No.")){
                             Intent intent = new Intent(TancardActivity.this, TancardNewUploadActivity.class);
                             intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                             startActivity(intent);
                             Toast.makeText(TancardActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();

                         }
                        else{
                             Intent intent = new Intent(TancardActivity.this, TancardCorrectionUploadActivity.class);
                             intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                             startActivity(intent);
                             Toast.makeText(TancardActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();

                         }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid",userId);
                    params.put("category",title);
                    params.put("price",price);
                    params.put("tan_apply_type",tan);
                    params.put("email_id",edt_email_Tan.getText().toString());
                    params.put("mobile",edt_mobile_Tan.getText().toString());

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

    private  void hitAPiPrice(){
        final ProgressDialog progressDialog=ProgressDialog.show(TancardActivity.this,"","wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject=jsonObject.getJSONObject("data");
                    price =dataObject.getString("price");
                    tv_price_tancard.setText(price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("category",title);
                hashMap.put("userid",userId);
                return hashMap;
            }
        };
        requestQueue.add(request);
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId()==R.id.tan_spinner){
            ((TextView)parent.getChildAt(0)).setTextColor(Color.WHITE);
            if(position==0){
                tan = "Select Type Tan";
            }
            else if(position==1){
                tan = "New Tan No.";
            }
            else if(position==2){
                tan = "correction in old Tan No.";
            }
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}