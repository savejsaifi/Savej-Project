package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PanCardDescription extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{


    Spinner pan_spinner;

    Button btn_submit_panDesc;
    String[] typePan = {"Select Type Pan","New Pan card","correction in old pan card"};
    TextView tv_price_pancard;
    String panType;
    String price="";
    String userId,title;
    SharedPreferences sharedPreferences;
    EditText edt_panNo;
    CardView cardPanNo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pan_card_description);
        btn_submit_panDesc = findViewById(R.id.btn_submit_panDesc);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        hitAPiPrice();

        tv_price_pancard = findViewById(R.id.tv_price_pancard);
        cardPanNo = findViewById(R.id.cardPanNo);
        edt_panNo = findViewById(R.id.edt_panNo);
        pan_spinner = findViewById(R.id.pan_spinner);
        pan_spinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,typePan);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        pan_spinner.setAdapter(aa);

        btn_submit_panDesc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(panType.equals("Select Type Pan")) {
                    Toast.makeText(PanCardDescription.this, "Please Select Pan Type", Toast.LENGTH_SHORT).show();
                  //  startActivity(new Intent(getApplicationContext(),PancardActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                }
                else if(panType.equalsIgnoreCase("Correction in old pan card") && edt_panNo.getText().toString().equals("")) {
                    Toast.makeText(PanCardDescription.this, "Please Fill Pan no", Toast.LENGTH_SHORT).show();

                }
                else if(panType.equals("New Pan card")) {
                    startActivity(new Intent(getApplicationContext(),PancardActivity.class).
                            putExtra("price",price));

                }
//                if(panType.equals("Correction in old pan card"))
                else {
                    hitRegisterApi();

                   // Toast.makeText(PanCardDescription.this, "Please Select Pan Type", Toast.LENGTH_SHORT).show();
                   // startActivity(new Intent(getApplicationContext(),PancardCorrectionUploadForm.class));


                }

            }
        });
    }


    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(PanCardDescription.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(PanCardDescription.this, PancardCorrectionUploadForm.class);
                        intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(PanCardDescription.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid",userId);
                    params.put("category",title);
                    params.put("price",price);
                    params.put("pancard_apply","Correction in old pan card");

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

    private  void hitAPiPrice(){
        final ProgressDialog progressDialog=ProgressDialog.show(PanCardDescription.this,"","wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject=jsonObject.getJSONObject("data");
                    price =dataObject.getString("price");
                    tv_price_pancard.setText(price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("category",title);
                hashMap.put("userid",userId);
                return hashMap;
            }
        };
        requestQueue.add(request);
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if(parent.getId()==R.id.pan_spinner){
                ((TextView)parent.getChildAt(0)).setTextColor(Color.WHITE);
                if(position==0){
                    panType = "Select Type Pan";
                    cardPanNo.setVisibility(View.GONE);
                }
                else if(position==1){
                    panType = "New Pan card";
                    cardPanNo.setVisibility(View.GONE);

                }else if(position==2){
                    panType = "correction in old pan card";
                    cardPanNo.setVisibility(View.VISIBLE);
                }
            }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
