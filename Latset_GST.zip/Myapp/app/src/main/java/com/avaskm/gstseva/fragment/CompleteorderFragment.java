package com.avaskm.gstseva.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.CompleteModel;
import com.avaskm.gstseva.model.PendingModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class CompleteorderFragment extends Fragment {

    RecyclerView RvComplete;
    CompleteAdapter adapter;
    ArrayList<CompleteModel> arListComplete;
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_completeorder, container, false);
        RvComplete = (RecyclerView) view.findViewById(R.id.rv_complete_order);
        arListComplete=new ArrayList<>();
        sharedPreferences = getActivity().getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        setRvComplete();
        GetCompleteOrderAPI();
        return view;
    }


    private void setRvComplete() {
        RvComplete.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        RvComplete.setLayoutManager(layoutManager);
        arListComplete.clear();
    }

    public class CompleteAdapter extends RecyclerView.Adapter<CompleteAdapter.ViewHolder> {

        Context mContext;
        ArrayList<CompleteModel> arList;

        public CompleteAdapter(Context context, ArrayList<CompleteModel> arrayList) {
            this.mContext = context;
            this.arList = arrayList;

        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_complete, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            viewHolder.TvCategoryName.setText(arList.get(i).getCategoryName());
            viewHolder.TvReferenceNo.setText(arList.get(i).getReferenceNo());
            viewHolder.TvPrice.setText(arList.get(i).getPrice());
            viewHolder.TvStatus.setText(arList.get(i).getStatus());
            viewHolder.TvDate.setText(arList.get(i).getDate());
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView TvCategoryName, TvReferenceNo, TvPrice, TvStatus, TvDate;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                TvCategoryName = (TextView) itemView.findViewById(R.id.tv_category_name_complete);
                TvReferenceNo = (TextView) itemView.findViewById(R.id.tv_reference_complete);
                TvPrice = (TextView) itemView.findViewById(R.id.tv_price_complete);
                TvStatus = (TextView) itemView.findViewById(R.id.tv_status_complete);
                TvDate = (TextView) itemView.findViewById(R.id.tv_date_complete);
            }
        }
    }

    private void GetCompleteOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCompleteOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCompleteOrder", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONArray dataArray = jsonObject.getJSONArray("data");
                    for (int i = 0; i < dataArray.length(); i++) {
                        CompleteModel model = new CompleteModel();
                        JSONObject dataObject = dataArray.getJSONObject(i);
                        model.setCategoryName(dataObject.getString("category_name"));
                        model.setReferenceNo(dataObject.getString("refid"));
                        model.setPrice(dataObject.getString("price"));
                        model.setStatus(dataObject.getString("status"));
                        model.setDate(dataObject.getString("cdate"));
                        arListComplete.add(model);

                    }
                    adapter = new CompleteAdapter(getActivity(), arListComplete);
                    RvComplete.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }



}
