package com.avaskm.gstseva.model;

public class NewGstFillingModel {

    private String BillName;

    public String getBillName() {
        return BillName;
    }

    public void setBillName(String billName) {
        BillName = billName;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }

    private String Price;
}
