package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.NewGstFillingModel;
import com.avaskm.gstseva.model.StateSpinnerModel;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DigitalsignatureActivity extends AppCompatActivity {

    Spinner spinner_type_digital;
    EditText edt_name_Digital, edt_mobile_digital, edt_email_digital;
    TextView tv_price_digital;
    ArrayList<NewGstFillingModel> arListModel = new ArrayList<>();
    ArrayList<String> arList = new ArrayList<>();
    String price, billName;
    Button btn_submit_digital;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digitalsignature);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        edt_name_Digital = findViewById(R.id.edt_name_Digital);
        edt_mobile_digital = findViewById(R.id.edt_mobile_digital);
        edt_email_digital = findViewById(R.id.edt_email_digital);
        tv_price_digital = findViewById(R.id.tv_price_digital);
        spinner_type_digital = findViewById(R.id.spinner_type_digital);
        btn_submit_digital = findViewById(R.id.btn_submit_digital);
        GetCategoryInForAPI();

        spinner_type_digital.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                billName = String.valueOf(spinner_type_digital.getItemAtPosition(position));
                price = arListModel.get(position).getPrice();
                Log.d("billPrice", price);
                tv_price_digital.setText("\u20B9" + " " + price);
                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn_submit_digital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edt_name_Digital.getText().toString().equals("")) {
                    edt_name_Digital.setError("Please enter Your Name");
                    edt_name_Digital.requestFocus();
                } else if (edt_mobile_digital.getText().toString().equals("")) {
                    edt_mobile_digital.setError("Please enter Your Mobile No.");
                    edt_mobile_digital.requestFocus();
                } else if (edt_mobile_digital.getText().toString().length() != 10) {
                    edt_mobile_digital.setError("Mobile No. should be 10 digit");
                    edt_mobile_digital.requestFocus();
                } else if (edt_email_digital.getText().toString().equals("")) {
                    edt_email_digital.setError("Please enter Email");
                    edt_email_digital.requestFocus();
                } else if (!(edt_email_digital.getText().toString().matches(emailPattern) && edt_email_digital.getText().toString().length() > 0)) {
                    edt_email_digital.setError("Please enter the valid Email");
                    edt_email_digital.requestFocus();
                } else if (billName.equalsIgnoreCase("Select Type Of Digital Signature")) {
                    Toast.makeText(DigitalsignatureActivity.this, "Please Select Signature Type", Toast.LENGTH_SHORT).show();
                    //  startActivity(new Intent(getApplicationContext(),PancardActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } else {

                    hitRegisterApi();

                }

            }
        });
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(DigitalsignatureActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCategoryInForAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");

                    arListModel.clear();
                    JSONObject dataObject = jsonObject.getJSONObject("data");

                    JSONArray priceArray = dataObject.getJSONArray("categories");

                    arList.add("Select Type Of Digital Signature");
                    NewGstFillingModel model = new NewGstFillingModel();
                    model.setBillName("Select Type Of Digital Signature");
                    model.setPrice("");
                    arListModel.add(model);


                    for (int i = 0; i < priceArray.length(); i++) {
                        model = new NewGstFillingModel();
                        JSONObject priceObject = priceArray.getJSONObject(i);
                        String key = priceObject.getString("name");
                        model.setBillName(priceObject.getString("name"));
                        Log.d("key", key);
                        String value = priceObject.getString("price");
                        model.setPrice(value);
                        Log.d("value", value);

                        arListModel.add(model);
                        arList.add(key);
                    }
                    ArrayAdapter aa = new ArrayAdapter(DigitalsignatureActivity.this, android.R.layout.simple_spinner_dropdown_item, arList);
                    spinner_type_digital.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("userid", userId);
                params.put("category", "Digital Signature");

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(DigitalsignatureActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }

    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(DigitalsignatureActivity.this, "", "Wait....", false);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn", response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject = jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(DigitalsignatureActivity.this, DigitalsignatureUploadForm.class);
                        intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(DigitalsignatureActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid", userId);
                    params.put("category", "Digital Signature");
                    params.put("price", price);
                    params.put("sel_dig_signature", billName);
                    params.put("name", edt_name_Digital.getText().toString());
                    params.put("mobile", edt_mobile_digital.getText().toString());
                    params.put("email", edt_email_digital.getText().toString());

                    Log.d("msggsaqw", params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

}

