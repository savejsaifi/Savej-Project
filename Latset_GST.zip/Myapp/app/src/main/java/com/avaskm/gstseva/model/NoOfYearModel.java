package com.avaskm.gstseva.model;

public class NoOfYearModel {

    private String Year;
    private String price;

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
