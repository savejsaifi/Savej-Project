package com.avaskm.gstseva.model;

import android.graphics.Bitmap;
import android.net.Uri;

public class ModelClass {



    public Bitmap image;
    public Uri uri;

    public Uri getUri() {
        return uri;
    }

    public void setUri(Uri uri) {
        this.uri = uri;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }

}
