package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PancardActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

  EditText edt_name_Pan,edt_dob_pan,edt_fatherName_Pan,edt_mobile_Pan,edt_email_Pan;
  Button btn_submit_Pan;
  Spinner firm_spinner;
    String[] firmDetails = {"Select","individual firm","company","HUF"};
    String firmName =" ";
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    String userId,price;
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pancard);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        price =  getIntent().getStringExtra("price");

        firm_spinner = findViewById(R.id.firm_spinner);
        edt_name_Pan = findViewById(R.id.edt_name_Pan);
        edt_dob_pan = findViewById(R.id.edt_dob_pan);
        edt_fatherName_Pan = findViewById(R.id.edt_fatherName_Pan);
        edt_mobile_Pan = findViewById(R.id.edt_mobile_Pan);
        edt_email_Pan = findViewById(R.id.edt_email_Pan);
        btn_submit_Pan = findViewById(R.id.btn_submit_Pan);

        firm_spinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,firmDetails);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        firm_spinner.setAdapter(aa);

        btn_submit_Pan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(firmName.equalsIgnoreCase("Select")){
                    Toast.makeText(PancardActivity.this, "Please Select One Option from Dropdown", Toast.LENGTH_SHORT).show();
                }
                if(edt_name_Pan.getText().toString().equals("")){
                    edt_name_Pan.setError("Please enter Your Name");
                    edt_name_Pan.requestFocus();
                }
                else if(edt_dob_pan.getText().toString().equals("")){
                    edt_dob_pan.setError("Please enter Your Dob");
                    edt_dob_pan.requestFocus();
                }
                else if(edt_fatherName_Pan.getText().toString().equals("")){
                    edt_fatherName_Pan.setError("Please enter Your Father Name");
                    edt_fatherName_Pan.requestFocus();
                }
                else if(edt_mobile_Pan.getText().toString().equals("")){
                    edt_mobile_Pan.setError("Please enter Your Mobile No.");
                    edt_mobile_Pan.requestFocus();
                }
                else if(edt_mobile_Pan.getText().toString().length()!=10){
                    edt_mobile_Pan.setError("Mobile No. Should be 10 digit");
                    edt_mobile_Pan.requestFocus();
                }
                else if(edt_email_Pan.getText().toString().equals("")){
                    edt_email_Pan.setError("Please enter Your Email");
                    edt_email_Pan.requestFocus();
                }
                else if(!(edt_email_Pan.getText().toString().matches(emailPattern)&&edt_email_Pan.getText().toString().length()>0)){
                    edt_email_Pan.setError("Please enter Valid Email");
                    edt_email_Pan.requestFocus();
                }
                else {
                    hitRegisterApi();
                }
            }
        });

    }

    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(PancardActivity.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(PancardActivity.this, PancardNewActivityUploadForm.class);
                        intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(PancardActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid",userId);
                    params.put("category","Pancard");
                    params.put("price",price);
                    params.put("pancard_apply","New Pan card");
                    params.put("firm_name",firmName);
                    params.put("full_name",edt_name_Pan.getText().toString());
                    params.put("dob",edt_dob_pan.getText().toString());
                    params.put("father_name",edt_fatherName_Pan.getText().toString());
                    params.put("email_id",edt_email_Pan.getText().toString());
                    params.put("mobile",edt_mobile_Pan.getText().toString());

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId() == R.id.firm_spinner){
            firmName = firmDetails[position];
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
            Log.d("asdklweo",firmName);

        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
