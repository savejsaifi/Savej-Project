package com.avaskm.gstseva.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.avaskm.gstseva.R;

public class DetailsOrderActivity extends AppCompatActivity {

    String orderId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_order);
        Intent intent=getIntent();
        orderId=intent.getStringExtra("orderId");

    }
}
