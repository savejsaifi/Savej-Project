package com.avaskm.gstseva.ourservices;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.ApiFactory;
import com.avaskm.gstseva.IApiServices;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.VolleyMultipartRequest;
import com.avaskm.gstseva.activity.ProprietorActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.databinding.ActivityImportExportBinding;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.google.gson.JsonObject;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class ImportExportUploadFormActivity extends AppCompatActivity {


    SharedPreferences sharedPreferences_userId;
    String orderId,userId;
    ImageView pancard_import,aadhar_import,photo_import,checque_import;
    Button btn_panCard_import,btn_aadharCard_import,btn_photo_import,btn_check_import;
    Button submit;
    private static final int GALLERY_PICTURE = 1;
    private static final int CAMERA_REQUEST = 100;
    private static final int STORAGE_PERMISSION_CODE = 123;
    int count;
    Bitmap panBitmap,aadharBitmap,photoBitmap,chequeBitmap;
    private static final String IMAGE_DIRECTORY = "/demonuts_upload_gallery";
    private static final int BUFFER_SIZE = 1024 * 2;
    ArrayList<String> imagePathListPdf = new ArrayList<>();
    ArrayList<String> imagePathListAadharPdf = new ArrayList<>();
    ArrayList<String> imagePathListPhotoPdf = new ArrayList<>();
    ArrayList<String> imagePathListChequePdf = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import_export_upload_form);


        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences_userId.getString("userid","");
        orderId = getIntent().getExtras().getString("order");
        requestStoragePermission();
        askForPermissioncamera(Manifest.permission.CAMERA,CAMERA);
        requestMultiplePermissions();
        pancard_import = findViewById(R.id.pancard_import);
        aadhar_import = findViewById(R.id.aadhar_import);
        photo_import = findViewById(R.id.photo_import);
        checque_import = findViewById(R.id.checque_import);
        btn_panCard_import = findViewById(R.id.btn_panCard_import);
        btn_aadharCard_import = findViewById(R.id.btn_aadharCard_import);
        btn_photo_import = findViewById(R.id.btn_photo_import);
        btn_check_import = findViewById(R.id.btn_check_import);
        submit = findViewById(R.id.btn_importExport_submit);

        allSingleImageBtnUpload();
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NavigationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });
        Log.d("asdas",orderId + " "+userId);


    }

    private void allSingleImageBtnUpload() {
        btn_panCard_import.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=1;
                startDialog();

            }
        });
        btn_aadharCard_import.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=2;
                startDialog();
            }
        });
        btn_photo_import.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=3;
                startDialog();
            }
        });
        btn_check_import.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=4;
                startDialog();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        panBitmap = null;
        aadharBitmap=null;
        photoBitmap=null;
        chequeBitmap=null;


        if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==1) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    panBitmap = (Bitmap) data.getExtras().get("data");
                    pancard_import.setImageBitmap(panBitmap);
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    hitUrlForUploadImagePan();
                }
                else {
                    panBitmap = (Bitmap) data.getExtras().get("data");
                    pancard_import.setImageBitmap(panBitmap);
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    hitUrlForUploadImagePan();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==1) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    panBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    pancard_import.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagePan();

                } else {

                    Log.d("inelse", "inelse");

                    panBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(pancard_import);
                    hitUrlForUploadImagePan();
                }


            } catch (Exception e) {
            }
        }
       else if ((resultCode == RESULT_OK && requestCode == 200) && count==1) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(ImportExportUploadFormActivity.this,uri);
            Log.d("ioooo",path);
            imagePathListPdf.add(path);
            uploadPDF(path);
        }

      else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==2) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    aadharBitmap = (Bitmap) data.getExtras().get("data");
                    aadhar_import.setImageBitmap(aadharBitmap);
                    aadharBitmap = Bitmap.createScaledBitmap(aadharBitmap, 800, 800, false);
                    hitUrlForUploadImageAadhar();
                }
                else {
                    aadharBitmap = (Bitmap) data.getExtras().get("data");
                    aadhar_import.setImageBitmap(aadharBitmap);
                    aadharBitmap = Bitmap.createScaledBitmap(aadharBitmap, 800, 800, false);
                    hitUrlForUploadImageAadhar();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
      else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==2) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    aadharBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    aadhar_import.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageAadhar();

                } else {

                    Log.d("inelse", "inelse");

                    aadharBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    aadharBitmap = Bitmap.createScaledBitmap(aadharBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(aadhar_import);
                    hitUrlForUploadImageAadhar();
                }


            } catch (Exception e) {
            }
        }
      else if ((resultCode == RESULT_OK && requestCode == 200) && count==2) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(ImportExportUploadFormActivity.this,uri);
            Log.d("ioooo",path);
            imagePathListAadharPdf.add(path);
            uploadPDFAadhar(path);
        }

      else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==3) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    photoBitmap = (Bitmap) data.getExtras().get("data");
                    photo_import.setImageBitmap(photoBitmap);
                    photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
                    hitUrlForUploadImagePhoto();
                }
                else {
                    photoBitmap = (Bitmap) data.getExtras().get("data");
                    photo_import.setImageBitmap(photoBitmap);
                    photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
                    hitUrlForUploadImagePhoto();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
      else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==3) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    photo_import.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImagePhoto();

                } else {

                    Log.d("inelse", "inelse");

                    photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(photo_import);
                    hitUrlForUploadImagePhoto();
                }


            } catch (Exception e) {
            }
        }
      else if ((resultCode == RESULT_OK && requestCode == 200) && count==3) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(ImportExportUploadFormActivity.this,uri);
            Log.d("ioooo",path);
            imagePathListPhotoPdf.add(path);
            uploadPDFPhoto(path);
        }

      else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==4) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    chequeBitmap = (Bitmap) data.getExtras().get("data");
                    checque_import.setImageBitmap(chequeBitmap);
                    chequeBitmap = Bitmap.createScaledBitmap(chequeBitmap, 800, 800, false);
                    hitUrlForUploadImageCheque();
                }
                else {
                    chequeBitmap = (Bitmap) data.getExtras().get("data");
                    checque_import.setImageBitmap(chequeBitmap);
                    chequeBitmap = Bitmap.createScaledBitmap(chequeBitmap, 800, 800, false);
                    hitUrlForUploadImageCheque();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
      else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==4) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    chequeBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    checque_import.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImageCheque();

                } else {

                    Log.d("inelse", "inelse");

                    chequeBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    chequeBitmap = Bitmap.createScaledBitmap(chequeBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(checque_import);
                    hitUrlForUploadImageCheque();
                }


            } catch (Exception e) {
            }
        }
      else if ((resultCode == RESULT_OK && requestCode == 200) && count==4) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(ImportExportUploadFormActivity.this,uri);
            Log.d("ioooo",path);
            imagePathListChequePdf.add(path);
            uploadPDFCheque(path);
        }

    }




        ///////////////////////////////////////// api using camera and gallery //////////////////////////////////////////////////////

    private void hitUrlForUploadImagePan() {

        final ProgressDialog progressDialog=ProgressDialog.show(ImportExportUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(ImportExportUploadFormActivity.this, "PanCard Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(panBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImageAadhar() {

        final ProgressDialog progressDialog=ProgressDialog.show(ImportExportUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(ImportExportUploadFormActivity.this, "Aadhar Card Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "aadhaar");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(aadharBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImagePhoto() {

        final ProgressDialog progressDialog=ProgressDialog.show(ImportExportUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(ImportExportUploadFormActivity.this, "Photo Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "photo");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(photoBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    private void hitUrlForUploadImageCheque() {

        final ProgressDialog progressDialog=ProgressDialog.show(ImportExportUploadFormActivity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        Toast.makeText(ImportExportUploadFormActivity.this, "Document Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "cancelcheque");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(chequeBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

 //////////////////////////    api pdf /////////////////////////////////////////////
   private void uploadPDF(String path){

     String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
     //Create a file object using file path

     HashMap<String, RequestBody> partMap = new HashMap<>();
     partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
     partMap.put("type", ApiFactory.getRequestBodyFromString("pan"));
     partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
     partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

     String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

     //File f1= new File(path);
     MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPdf.size()];
     File file = new File(path);
     // Parsing any Media type file
     RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

     Log.d("filename===",file.getName());
     imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
     RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

     IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
     iApiServices.hitMultiple(imageArray1, partMap)
             .enqueue(new Callback<JsonObject>() {
                 @Override
                 public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                     Log.d("qwaszaqwsx", String.valueOf(response));
                     JsonObject jsonObject = response.body();
                     String code = jsonObject.get("code").getAsString();
                     String msg = jsonObject.get("msg").getAsString();

                     if(imagePathListPdf.size()==0){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                     }

                     if(code.equals("200")){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                     }
                     else if(code.equals("400")){
                         Toast.makeText(ImportExportUploadFormActivity.this, msg, Toast.LENGTH_SHORT).show();
                     }
                 }

                 @Override
                 public void onFailure(Call<JsonObject> call, Throwable t) {
                     //  progressbarPrivate.setVisibility(View.GONE);
                     // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                     //   progressDialog.dismiss();
                     Log.d("data_error", t.getMessage());

                 }
             });

 }
   private void uploadPDFAadhar(String path){

     String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
     //Create a file object using file path

     HashMap<String, RequestBody> partMap = new HashMap<>();
     partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
     partMap.put("type", ApiFactory.getRequestBodyFromString("aadhaar"));
     partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
     partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

     String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

     //File f1= new File(path);
     MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListAadharPdf.size()];
     File file = new File(path);
     // Parsing any Media type file
     RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

     Log.d("filename===",file.getName());
     imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
     RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

     IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
     iApiServices.hitMultiple(imageArray1, partMap)
             .enqueue(new Callback<JsonObject>() {
                 @Override
                 public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                     Log.d("qwaszaqwsx", String.valueOf(response));
                     JsonObject jsonObject = response.body();
                     String code = jsonObject.get("code").getAsString();
                     String msg = jsonObject.get("msg").getAsString();

                     if(imagePathListAadharPdf.size()==0){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                     }

                     if(code.equals("200")){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                     }
                     else if(code.equals("400")){
                         Toast.makeText(ImportExportUploadFormActivity.this, msg, Toast.LENGTH_SHORT).show();
                     }
                 }

                 @Override
                 public void onFailure(Call<JsonObject> call, Throwable t) {
                     //  progressbarPrivate.setVisibility(View.GONE);
                     // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                     //   progressDialog.dismiss();
                     Log.d("data_error", t.getMessage());

                 }
             });

 }
   private void uploadPDFPhoto(String path){

     String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
     //Create a file object using file path

     HashMap<String, RequestBody> partMap = new HashMap<>();
     partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
     partMap.put("type", ApiFactory.getRequestBodyFromString("aadhaar"));
     partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
     partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

     String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

     //File f1= new File(path);
     MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPhotoPdf.size()];
     File file = new File(path);
     // Parsing any Media type file
     RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

     Log.d("filename===",file.getName());
     imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
     RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

     IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
     iApiServices.hitMultiple(imageArray1, partMap)
             .enqueue(new Callback<JsonObject>() {
                 @Override
                 public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                     Log.d("qwaszaqwsx", String.valueOf(response));
                     JsonObject jsonObject = response.body();
                     String code = jsonObject.get("code").getAsString();
                     String msg = jsonObject.get("msg").getAsString();

                     if(imagePathListPhotoPdf.size()==0){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                     }

                     if(code.equals("200")){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                     }
                     else if(code.equals("400")){
                         Toast.makeText(ImportExportUploadFormActivity.this, msg, Toast.LENGTH_SHORT).show();
                     }
                 }

                 @Override
                 public void onFailure(Call<JsonObject> call, Throwable t) {
                     //  progressbarPrivate.setVisibility(View.GONE);
                     // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                     //   progressDialog.dismiss();
                     Log.d("data_error", t.getMessage());

                 }
             });

 }
   private void uploadPDFCheque(String path){

     String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
     //Create a file object using file path

     HashMap<String, RequestBody> partMap = new HashMap<>();
     partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
     partMap.put("type", ApiFactory.getRequestBodyFromString("cancelcheque"));
     partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
     partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

     String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

     //File f1= new File(path);
     MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListChequePdf.size()];
     File file = new File(path);
     // Parsing any Media type file
     RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

     Log.d("filename===",file.getName());
     imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
     RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

     IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
     iApiServices.hitMultiple(imageArray1, partMap)
             .enqueue(new Callback<JsonObject>() {
                 @Override
                 public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                     Log.d("qwaszaqwsx", String.valueOf(response));
                     JsonObject jsonObject = response.body();
                     String code = jsonObject.get("code").getAsString();
                     String msg = jsonObject.get("msg").getAsString();

                     if(imagePathListChequePdf.size()==0){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                     }

                     if(code.equals("200")){
                         Toast.makeText(ImportExportUploadFormActivity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                     }
                     else if(code.equals("400")){
                         Toast.makeText(ImportExportUploadFormActivity.this, msg, Toast.LENGTH_SHORT).show();
                     }
                 }

                 @Override
                 public void onFailure(Call<JsonObject> call, Throwable t) {
                     //  progressbarPrivate.setVisibility(View.GONE);
                     // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                     //   progressDialog.dismiss();
                     Log.d("data_error", t.getMessage());

                 }
             });

 }

    ////////////////////////////////////// upload pdf ////////////////////////////////////////////////////

    public static String getFilePathFromURI(Context context, Uri contentUri) {
        //copy file and send new file path
        String fileName = getFileName(contentUri);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }
        if (!TextUtils.isEmpty(fileName)) {
            File copyFile = new File(wallpaperDirectory + File.separator + fileName);
            // create folder if not exists

            copy(context, contentUri, copyFile);
            return copyFile.getAbsolutePath();
        }
        return null;
    }

    public static String getFileName(Uri uri) {
        if (uri == null) return null;
        String fileName = null;
        String path = uri.getPath();
        int cut = path.lastIndexOf('/');
        if (cut != -1) {
            fileName = path.substring(cut + 1);
        }
        return fileName;
    }

    public static void copy(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            copystream(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int copystream(InputStream input, OutputStream output) throws Exception, IOException {
        byte[] buffer = new byte[BUFFER_SIZE];

        BufferedInputStream in = new BufferedInputStream(input, BUFFER_SIZE);
        BufferedOutputStream out = new BufferedOutputStream(output, BUFFER_SIZE);
        int count = 0, n = 0;
        try {
            while ((n = in.read(buffer, 0, BUFFER_SIZE)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
            try {
                in.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
        }
        return count;
    }


    public byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, buffer);
        return buffer.toByteArray();
    }

    public static Bitmap handleSamplingAndRotationBitmap(Context context, Uri selectedImage)
            throws IOException {
        int MAX_HEIGHT = 1024;
        int MAX_WIDTH = 1024;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(selectedImage);
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(context, img, selectedImage);
        return img;
    }

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }

    private static Bitmap rotateImageIfRequired(Context context, Bitmap img, Uri selectedImage) throws IOException {

        InputStream input = context.getContentResolver().openInputStream(selectedImage);
        ExifInterface ei = null;
        if (Build.VERSION.SDK_INT > 23) {
            ei = new ExifInterface(input);
        }


        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }


    }
    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }
    private void startDialog() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });

        myAlertDialog.setNeutralButton("Pdf", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(intent,200);
            }
        });

        myAlertDialog.show();
    }

    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(ImportExportUploadFormActivity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(ImportExportUploadFormActivity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(ImportExportUploadFormActivity.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Displaying a toast
                Toast.makeText(this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void  requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }
}
