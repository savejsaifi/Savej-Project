

package com.avaskm.gstseva.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.Bussiness;
import com.avaskm.gstseva.DescriptionActivity;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.adapter.SliderAdapter;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.BannerModel;
import com.avaskm.gstseva.ourservices.AuditActivity;
import com.avaskm.gstseva.ourservices.DigitalsignatureActivity;
import com.avaskm.gstseva.ourservices.FoodlincenseActivity;
import com.avaskm.gstseva.ourservices.ITRfillingActivity;
import com.avaskm.gstseva.ourservices.ImportExportActivity;
import com.avaskm.gstseva.ourservices.IncorpoPartnershipAcvitity;
import com.avaskm.gstseva.ourservices.IncorpoProprietorship;
import com.avaskm.gstseva.ourservices.Incorporationofllp;
import com.avaskm.gstseva.ourservices.Incorporationpvtltd;
import com.avaskm.gstseva.ourservices.InsuranceActivity;
import com.avaskm.gstseva.ourservices.LabourlincenseActivity;
import com.avaskm.gstseva.ourservices.NewGSTfilling;
import com.avaskm.gstseva.ourservices.PanCardDescription;
import com.avaskm.gstseva.ourservices.PassportActivity;
import com.avaskm.gstseva.ourservices.RegistrationfillActivity;
import com.avaskm.gstseva.ourservices.TancardActivity;
import com.avaskm.gstseva.ourservices.UdyogaadhaarActivity;
import com.avaskm.gstseva.ourservices.websiteActivity;
import com.avaskm.gstseva.session.SessonManager;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class Homefragment extends Fragment {
    List<Bussiness> listbook;
    TabLayout tabLayout;
    ViewPager mViewPager;
    RecyclerView RvFome;
    Rcyclerviewviewadapter myadapter;
    RecyclerView myrv;
    SessonManager sessonManager;
    ArrayList<BannerModel> arListBanner;
    private static int currentpage;
    int[] pic = {R.drawable.gst1,
            R.drawable.gst2,
            R.drawable.gst3,
            R.drawable.gst4,
            R.drawable.gst6,
            R.drawable.gst5};

    public Homefragment() {
    }

    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_homefragment, container, false);
       /* listbook = new ArrayList<>();
        arListBanner=new ArrayList<>();
        HomeAPI();
        RvFome = (RecyclerView) view.findViewById(R.id.rv_home);
        myadapter = new Rcyclerviewviewadapter(getContext(), (ArrayList<Bussiness>) listbook);
        RvFome.setLayoutManager(new GridLayoutManager(getContext(), 3));*/
        HomeAPI();
        listbook = new ArrayList<>();
        arListBanner = new ArrayList<>();
        /*listbook.add(new Bussiness("GST Lincense", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("GST Filling", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("ITR Filling", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Food Lincense", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Labour Lincense", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Udyog Aadhaar", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Import Export", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Registration Fill", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Passport", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Pancard", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Tancard", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Audit", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Digital Signature", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Insurance", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Incorporation pvt.ltd", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Incorpo. proprietorship", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Incorpo.partnership", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Incorporation LLPA", "", "", R.drawable.gstfilling));
        listbook.add(new Bussiness("Website", "", "", R.drawable.gstfilling));*/
        myrv = (RecyclerView) view.findViewById(R.id.rv_home);

        myrv.setLayoutManager(new GridLayoutManager(getContext(), 3));

        mViewPager = (ViewPager) view.findViewById(R.id.viewPage);
        myrv.setFocusable(false);//important
        mViewPager = (ViewPager) view.findViewById(R.id.viewPage);
        SliderAdapter adapterView = new SliderAdapter(getActivity(), arListBanner);
        mViewPager.setAdapter(adapterView);

        tabLayout = view.findViewById(R.id.tab_dots);
        tabLayout.setupWithViewPager(mViewPager, true);
        init();
        return view;
    }

    private void init() {

        tabLayout.setupWithViewPager(mViewPager, true);

        final Handler handler = new Handler();
        final Runnable runnable = new Runnable() {
            @Override
            public void run() {
                if (currentpage == pic.length) {
                    currentpage = 0;
                }
                mViewPager.setCurrentItem(currentpage++, true);
            }
        };
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(runnable);
            }
        }, 2000, 2000);
    }

    public class Rcyclerviewviewadapter extends RecyclerView.Adapter<Rcyclerviewviewadapter.MyviewHolder> {

        private Context context;
        private ArrayList<Bussiness> mData;

        public Rcyclerviewviewadapter(Context context, ArrayList<Bussiness> mData) {
            this.context = context;
            this.mData = mData;
        }

        @NonNull
        @Override
        public Rcyclerviewviewadapter.MyviewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater minflater = LayoutInflater.from(context);
            view = minflater.inflate(R.layout.cardview_item_back, parent, false);
            return new MyviewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MyviewHolder holder, final int position) {
            holder.textView.setText(mData.get(position).getTitle());
            Picasso.get().load(mData.get(position).getCategoryImage()).into(holder.IvCategory);
            //Picasso.get().load(mData.get(position).getThumbnail()).fit().into(holder.mybook);
            holder.cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bussiness bussiness = listbook.get(position);
                    String title = bussiness.getTitle();
                    Log.d("title", title);
                    final Intent intent;
                    SharedPreferences sp12 = context.getSharedPreferences("checkforuploadform", 0);
                    sp12 = context.getSharedPreferences("checkforuploadform", 0);
                    SharedPreferences.Editor editor12 = sp12.edit();
                    switch (position) {
                        case 0:
                            intent = new Intent(context, DescriptionActivity.class);
                            intent.putExtra("title",title);
                            //String s=textView.getText().toString();
                            startActivity(intent);

                            editor12.putInt("position", 100);
                            editor12.commit();
                            SharedPreferences foodlincense12 = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor food123 = foodlincense12.edit();
                            food123.putString("checkform", "jyoti");

                            /* food123.putString("name", "GST");*/
                            food123.commit();//jyoticode
                            break;

                        case 1:
                            intent = new Intent(context, NewGSTfilling.class);
                            intent.putExtra("title",title);
                            SharedPreferences newgstfill = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor fill = newgstfill.edit();
                            fill.putString("checkform", "newgstfill");
                            fill.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;
                        case 2:
                            intent = new Intent(context, ITRfillingActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences itrfill = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor itr = itrfill.edit();
                            itr.putString("checkform", "Itrfill");
                            itr.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();
                            break;
                        case 3:
                            intent = new Intent(context, FoodlincenseActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences foodlincense = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor food = foodlincense.edit();
                            food.putString("checkform", "Foodlicense");
                            food.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;
                        case 4:

                            SharedPreferences setting = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor edit = setting.edit();
                            edit.putString("checkform", "labour");
                            edit.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            intent = new Intent(context, LabourlincenseActivity.class);
                            intent.putExtra("title",title);
                            break;
                        case 5:
                            intent = new Intent(context, UdyogaadhaarActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences udog = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor udoge = udog.edit();
                            udoge.putString("checkform", "udog");
                            udoge.commit();

                            editor12.putInt("position", 100);
                            editor12.commit();


                            break;
                        case 6:

                            // sp12.putInt
                            SharedPreferences settings = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor editor = settings.edit();
                            editor.putString("checkform", "import");
                            editor.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            //sharedpreference
                      /*  SharedPreferences setting = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor edito = setting.edit();
                        edito.putString("checkform", "import");
                        edito.commit();*/


                            intent = new Intent(context, ImportExportActivity.class);
                            intent.putExtra("title",title);
                            break;
                        case 7:
                            intent = new Intent(context, RegistrationfillActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences reg = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor regis = reg.edit();
                            regis.putString("checkform", "registra");
                            regis.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;

                        case 8:
                            SharedPreferences pass = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor port = pass.edit();
                            port.putString("checkform", "passport");
                            port.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();


                            intent = new Intent(context, PassportActivity.class);
                            intent.putExtra("title",title);
                            break;
                        case 9:
                            SharedPreferences pancard = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor pan = pancard.edit();
                            pan.putString("checkform", "pancard");
                            pan.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            intent = new Intent(context, PanCardDescription.class);
                            intent.putExtra("title",title);
                            break;
                        case 10:
                            SharedPreferences tancard = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor tan = tancard.edit();
                            tan.putString("checkform", "tancard");
                            tan.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            intent = new Intent(context, TancardActivity.class);
                            intent.putExtra("title",title);
                            break;
                        case 11:
                            SharedPreferences aduit = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor audui = aduit.edit();
                            audui.putString("checkform", "Audit");
                            audui.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            intent = new Intent(context, AuditActivity.class);
                            intent.putExtra("title",title);
                            break;
                        case 12:
                            intent = new Intent(context, DigitalsignatureActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences digital = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor edi = digital.edit();
                            edi.putString("checkform", "digital");
                            edi.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();


                            break;
                        case 13:
                            intent = new Intent(context, InsuranceActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences insurance = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor insurar = insurance.edit();
                            insurar.putString("checkform", "insurance");
                            insurar.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;
                        case 14:
                            intent = new Intent(context, Incorporationpvtltd.class);
                            intent.putExtra("title",title);
                            SharedPreferences sett = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor editin = sett.edit();
                            editin.putString("checkform", "incorpo");
                            editin.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;
                        case 15:
                            intent = new Intent(context, IncorpoProprietorship.class);
                            intent.putExtra("title",title);
                            SharedPreferences incorpo = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor incoporat = incorpo.edit();
                            incoporat.putString("checkform", "incorpopro");
                            incoporat.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;

                        case 16:
                            intent = new Intent(context, Incorporationofllp.class);
                            intent.putExtra("title",title);
                            SharedPreferences incorporfllp = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor incopo = incorporfllp.edit();
                            incopo.putString("checkform", "incorfllp");
                            incopo.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;

                        case 17:
                            intent = new Intent(context, websiteActivity.class);
                            intent.putExtra("title",title);
                            SharedPreferences jwebsite = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor website = jwebsite.edit();
                            website.putString("checkform", "website");
                            website.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;

                        case 18:
                            intent = new Intent(context, IncorpoPartnershipAcvitity.class);
                            intent.putExtra("title",title);
                            SharedPreferences incorpart = context.getSharedPreferences("checkform", 0);
                            //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                            SharedPreferences.Editor incopora = incorpart.edit();
                            incopora.putString("checkform", "incorpart");
                            incopora.commit();
                            editor12.putInt("position", 100);
                            editor12.commit();

                            break;


                        default:
                            intent = new Intent(context, PartnershipLLpactivity.class);
                            break;
                    }
                    context.startActivity(intent);
                }
            });
        }

        @Override
        public int getItemCount() {
            return mData.size();
        }

        public class MyviewHolder extends RecyclerView.ViewHolder {
            TextView textView;
            ImageView IvCategory;
            CardView cardView;

            public MyviewHolder(@NonNull View itemView) {
                super(itemView);
                textView = (TextView) itemView.findViewById(R.id.gstview);
                IvCategory = (ImageView) itemView.findViewById(R.id.imageview);
                cardView = (CardView) itemView.findViewById(R.id.cardviewitem);
            }
        }
    }

    public void HomeAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.gethomecategory, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("DIENFHFHS", response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    JSONArray bannerArray = jsonObject.getJSONArray("banner");
                    for (int i = 0; i < bannerArray.length(); i++) {
                        JSONObject bannerobject = bannerArray.getJSONObject(i);
                        BannerModel model = new BannerModel();
                        model.setImage(bannerobject.getString("image"));
                        String BannerId = bannerobject.getString("id");
                        String BannerImage = bannerobject.getString("image");
                        Log.d("sdjijhfk", BannerImage);
                        arListBanner.add(model);
                        Log.d("jyimage", String.valueOf(arListBanner.size()));

                    }

                    SliderAdapter imageSliderAdapter = new SliderAdapter(getActivity(), arListBanner);
                    mViewPager.setAdapter(imageSliderAdapter);
                    tabLayout.setupWithViewPager(mViewPager);

                    JSONArray categoryArray = jsonObject.getJSONArray("category");
                    for (int k = 0; k < categoryArray.length(); k++) {
                        JSONObject categoryObject = categoryArray.getJSONObject(k);
                        Bussiness bussiness = new Bussiness();
                        String title = categoryObject.getString("title");
                        String categoryImage = categoryObject.getString("image");
                        bussiness.setCategoryImage(categoryImage);
                        bussiness.setTitle(categoryObject.getString("title"));
                        Log.d("IMage", categoryImage);
                        listbook.add(bussiness);

                    }
                    myadapter = new Rcyclerviewviewadapter(getActivity(), (ArrayList<Bussiness>) listbook);
                    myrv.setAdapter(myadapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
}