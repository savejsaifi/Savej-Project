package com.avaskm.gstseva;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.avaskm.gstseva.ourservices.AuditActivity;
import com.avaskm.gstseva.ourservices.DigitalsignatureActivity;
import com.avaskm.gstseva.ourservices.FoodlincenseActivity;
import com.avaskm.gstseva.ourservices.ITRfillingActivity;
import com.avaskm.gstseva.ourservices.ImportExportActivity;
import com.avaskm.gstseva.ourservices.IncorpoProprietorship;
import com.avaskm.gstseva.ourservices.Incorporationpvtltd;
import com.avaskm.gstseva.ourservices.InsuranceActivity;
import com.avaskm.gstseva.ourservices.websiteActivity;
import com.avaskm.gstseva.ourservices.LabourlincenseActivity;
import com.avaskm.gstseva.ourservices.Incorporationofllp;
import com.avaskm.gstseva.ourservices.NewGSTfilling;
import com.avaskm.gstseva.ourservices.PancardActivity;
import com.avaskm.gstseva.ourservices.PassportActivity;
import com.avaskm.gstseva.ourservices.RegistrationfillActivity;
import com.avaskm.gstseva.ourservices.IncorpoPartnershipAcvitity;
import com.avaskm.gstseva.ourservices.TancardActivity;
import com.avaskm.gstseva.ourservices.UdyogaadhaarActivity;
import com.squareup.picasso.Picasso;

import java.util.List;
public class Rcyclerviewviewadapter extends RecyclerView.Adapter<Rcyclerviewviewadapter.MyViewHolder> {
private Context context;
private List<Bussiness> mData;

    public Rcyclerviewviewadapter(Context context, List<Bussiness> mData) {
        this.context = context;
        this.mData = mData;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view;
        LayoutInflater minflater=LayoutInflater.from(context);
        view=minflater.inflate(R.layout.cardview_item_back,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.textView.setText(mData.get(position).getTitle());

        //String image=mData.get(position).getThumbnail();
       // Log.d("Djh",image);

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent intent;

                SharedPreferences sp12 = context.getSharedPreferences("checkforuploadform", 0);
                sp12 = context.getSharedPreferences("checkforuploadform", 0);
                SharedPreferences.Editor editor12 = sp12.edit();

                switch(position)
                {
                    case 0:
                        intent =  new Intent(context, DescriptionActivity.class);
                        editor12.putInt("position", 100);
                        editor12.commit();

                        SharedPreferences foodlincense12 = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor food123 = foodlincense12.edit();
                        food123.putString("checkform", "jyoti");
                        food123.commit();
                        break;

                    case 1:
                        intent =  new Intent(context, NewGSTfilling.class);
                        SharedPreferences newgstfill = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor fill = newgstfill.edit();
                        fill.putString("checkform", "newgstfill");
                        fill.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 2:
                        intent =  new Intent(context, ITRfillingActivity.class);
                        SharedPreferences itrfill = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor itr = itrfill.edit();
                        itr.putString("checkform", "Itrfill");
                        itr.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();
                        break;
                    case 3:
                        intent =  new Intent(context, FoodlincenseActivity.class);
                        SharedPreferences foodlincense = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor food = foodlincense.edit();
                        food.putString("checkform", "Foodlicense");
                        food.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 4:

                        SharedPreferences setting = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor edit = setting.edit();
                        edit.putString("checkform", "labour");
                        edit.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        intent =  new Intent(context, LabourlincenseActivity.class);
                        break;
                    case 5:
                        intent =  new Intent(context, UdyogaadhaarActivity.class);
                        SharedPreferences udog = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor udoge = udog.edit();
                        udoge.putString("checkform", "udog");
                        udoge.commit();

                        editor12.putInt("position", 100);
                        editor12.commit();


                        break;
                    case 6:

                       // sp12.putInt
                        SharedPreferences settings = context.getSharedPreferences("checkform", 0);
                      //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editor = settings.edit();
                        editor.putString("checkform", "import");
                        editor.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                       //sharedpreference
                      /*  SharedPreferences setting = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor edito = setting.edit();
                        edito.putString("checkform", "import");
                        edito.commit();*/


                        intent =  new Intent(context, ImportExportActivity.class);
                        break;
                    case 7:
                        intent =  new Intent(context, RegistrationfillActivity.class);
                        SharedPreferences reg = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor regis = reg.edit();
                        regis.putString("checkform", "registra");
                        regis.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;

                    case 8:
                        SharedPreferences pass = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor port = pass.edit();
                        port.putString("checkform", "passport");
                        port.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();


                        intent =  new Intent(context, PassportActivity.class);
                        break;
                    case 9:
                        SharedPreferences pancard = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor pan = pancard.edit();
                        pan.putString("checkform", "pancard");
                        pan.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        intent =  new Intent(context, PancardActivity.class);
                        break;
                    case 10:
                        SharedPreferences tancard = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor tan = tancard.edit();
                        tan.putString("checkform", "tancard");
                        tan.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        intent =  new Intent(context, TancardActivity.class);
                        break;
                    case 11:
                        SharedPreferences aduit = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor audui = aduit.edit();
                        audui.putString("checkform", "Audit");
                        audui.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        intent =  new Intent(context, AuditActivity.class);
                        break;
                    case 12:
                        intent =  new Intent(context, DigitalsignatureActivity.class);
                        SharedPreferences digital = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor edi = digital.edit();
                        edi.putString("checkform", "digital");
                        edi.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();


                        break;
                    case 13:
                        intent =  new Intent(context, InsuranceActivity.class);
                        SharedPreferences insurance = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor insurar = insurance.edit();
                        insurar.putString("checkform", "insurance");
                        insurar.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 14:
                        intent =  new Intent(context, Incorporationpvtltd.class);
                        SharedPreferences sett = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor editin = sett.edit();
                        editin.putString("checkform", "incorpo");
                        editin.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 15:
                        intent =  new Intent(context, IncorpoProprietorship.class);

                        SharedPreferences incorpo = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor incoporat = incorpo.edit();
                        incoporat.putString("checkform", "incorpopro");
                        incoporat.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 16:
                        intent =  new Intent(context, IncorpoPartnershipAcvitity.class);
                        SharedPreferences incorpart = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor incopora = incorpart.edit();
                        incopora.putString("checkform", "incorpart");
                        incopora.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;
                    case 17:
                        intent =  new Intent(context, Incorporationofllp.class);
                        SharedPreferences incorporfllp = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor incopo = incorporfllp.edit();
                        incopo.putString("checkform", "incorfllp");
                        incopo.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();


                        break;
                    case 18:
                        intent =  new Intent(context, websiteActivity.class);
                        SharedPreferences jwebsite = context.getSharedPreferences("checkform", 0);
                        //  settings = ctx.getSharedPreferences(PREFS_NAME, 0);
                        SharedPreferences.Editor website = jwebsite.edit();
                        website.putString("checkform", "website");
                        website.commit();
                        editor12.putInt("position", 100);
                        editor12.commit();

                        break;

                    default:
                        intent =  new Intent(context, PartnershipLLpactivity.class);
                        break;
                }
                context.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView textView;
        ImageView mybook,tumbnail;
        CardView cardView;
        public MyViewHolder(View itemView){
            super(itemView);
            textView=(TextView)itemView.findViewById(R.id.gstview);
            mybook=(ImageView)itemView.findViewById(R.id.imageview);
            cardView=(CardView)itemView.findViewById(R.id.cardviewitem);
        }
    }
}
