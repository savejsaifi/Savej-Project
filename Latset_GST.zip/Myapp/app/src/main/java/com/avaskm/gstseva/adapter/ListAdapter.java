//package com.dating.myapp.adapter;
//
//import android.content.Context;
//import android.support.v7.widget.RecyclerView;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.dating.myapp.R;
//
//import java.util.ArrayList;
//
//public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ListViewHolder> {
//    ArrayList<ImageModel> list;
//    Context context;
//
//    public ListAdapter(ArrayList<ImageModel> list, Context context) {
//        this.context = context;
//        this.list = list;
//    }
//
//    @Override
//    public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        LayoutInflater inflater = LayoutInflater.from(context);
//        View view = inflater.inflate(R.layout.gv_item, null);
//
//        return new ListViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(ListAdapter.ListViewHolder holder, final int position) {
//        final ImageModel imageModel = list.get(position);
//        //holder.image.setImageBitmap(imageModel.getImage());
//        holder.image.setImageResource(imageModel.getImage_drawable());
//
//
//        holder.close.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                removeAt(position);
//            }
//        });
//    }
//
//    public void removeAt(int position) {
//        list.remove(position);
//        notifyItemRemoved(position);
//        notifyItemChanged(position);
//    }
//
//    @Override
//    public int getItemCount() {
//        return list.size();
//    }
//
//    class ListViewHolder extends RecyclerView.ViewHolder {
//
//        ImageView image;
//        TextView close;
//
//        public ListViewHolder(View itemView) {
//            super(itemView);
//
//            image = itemView.findViewById(R.id.ivGallery);
//            close = itemView.findViewById(R.id.badge_view);
//        }
//
//    }
//}