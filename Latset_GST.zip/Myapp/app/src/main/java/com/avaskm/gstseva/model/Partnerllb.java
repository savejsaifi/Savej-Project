package com.avaskm.gstseva.model;

public class Partnerllb {
    private String name,pancardno,addharcardno,buttonone,buttontwo,buttonthree;
    private int image_drawable;
    private int image_drawableone;
    private  int getImage_drawabletwo;

    public Partnerllb() {
    }

    public Partnerllb(String name, String pancardno, String addharcardno, String buttonone, String buttontwo, String buttonthree, int image_drawable, int image_drawableone, int getImage_drawabletwo) {
        this.name = name;
        this.pancardno = pancardno;
        this.addharcardno = addharcardno;
        this.buttonone = buttonone;
        this.buttontwo = buttontwo;
        this.buttonthree = buttonthree;
        this.image_drawable = image_drawable;
        this.image_drawableone = image_drawableone;
        this.getImage_drawabletwo = getImage_drawabletwo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPancardno() {
        return pancardno;
    }

    public void setPancardno(String pancardno) {
        this.pancardno = pancardno;
    }

    public String getAddharcardno() {
        return addharcardno;
    }

    public void setAddharcardno(String addharcardno) {
        this.addharcardno = addharcardno;
    }

    public String getButtonone() {
        return buttonone;
    }

    public void setButtonone(String buttonone) {
        this.buttonone = buttonone;
    }

    public String getButtontwo() {
        return buttontwo;
    }

    public void setButtontwo(String buttontwo) {
        this.buttontwo = buttontwo;
    }

    public String getButtonthree() {
        return buttonthree;
    }

    public void setButtonthree(String buttonthree) {
        this.buttonthree = buttonthree;
    }

    public int getImage_drawable() {
        return image_drawable;
    }

    public void setImage_drawable(int image_drawable) {
        this.image_drawable = image_drawable;
    }

    public int getImage_drawableone() {
        return image_drawableone;
    }

    public void setImage_drawableone(int image_drawableone) {
        this.image_drawableone = image_drawableone;
    }

    public int getGetImage_drawabletwo() {
        return getImage_drawabletwo;
    }

    public void setGetImage_drawabletwo(int getImage_drawabletwo) {
        this.getImage_drawabletwo = getImage_drawabletwo;
    }
    /*  public Partnerllb(String name, String pancardno, String addharcardno, int image_drawable, int image_drawableone, int getImage_drawabletwo) {
        this.name = name;
        this.pancardno = pancardno;
        this.addharcardno = addharcardno;
        this.image_drawable = image_drawable;
        this.image_drawableone = image_drawableone;
        this.getImage_drawabletwo = getImage_drawabletwo;
    }*//*

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPancardno() {
        return pancardno;
    }

    public void setPancardno(String pancardno) {
        this.pancardno = pancardno;
    }

    public String getAddharcardno() {
        return addharcardno;
    }

    public void setAddharcardno(String addharcardno) {
        this.addharcardno = addharcardno;
    }

    public int getImage_drawable() {
        return image_drawable;
    }

    public void setImage_drawable(int image_drawable) {
        this.image_drawable = image_drawable;
    }

    public int getImage_drawableone() {
        return image_drawableone;
    }

    public void setImage_drawableone(int image_drawableone) {
        this.image_drawableone = image_drawableone;
    }

    public int getGetImage_drawabletwo() {
        return getImage_drawabletwo;
    }

    public void setGetImage_drawabletwo(int getImage_drawabletwo) {
        this.getImage_drawabletwo = getImage_drawabletwo;
    }*/
}
