package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.NewGstFillingModel;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class websiteActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    Button btn_Register_website;
    Spinner spinnerWebsite_pages,spinnerWebsite_eccomrse;
    ArrayList<NewGstFillingModel> arListModel = new ArrayList<>();
    ArrayList<String> arList = new ArrayList<>();
    TextView tv_price_website;
    String price, pageNo;
    String ecommerse =" ";
    String[] ecommerse_details = {"Is this E-Commerce","Yes","No"};
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    SharedPreferences sharedPreferences;
    String userId;
    EditText edt_name_website,edt_mobile_website,edt_email_website;
    String title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jwebsite);


        spinnerWebsite_pages = findViewById(R.id.spinnerWebsite_pages);
        spinnerWebsite_eccomrse = findViewById(R.id.spinnerWebsite_eccomrse);
        tv_price_website = findViewById(R.id.tv_price_website);
        btn_Register_website = findViewById(R.id.btn_Register_website);
        edt_name_website = findViewById(R.id.edt_name_website);
        edt_mobile_website = findViewById(R.id.edt_mobile_website);
        edt_email_website = findViewById(R.id.edt_email_website);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        title = getIntent().getStringExtra("title");
        GetCategoryInForAPI();
        spinnerWebsite_eccomrse.setOnItemSelectedListener(this);
        ArrayAdapter aaa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,ecommerse_details);
        aaa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerWebsite_eccomrse.setAdapter(aaa);

        spinnerWebsite_pages.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                pageNo = String.valueOf(spinnerWebsite_pages.getItemAtPosition(position));
                price = arListModel.get(position).getPrice();
                Log.d("billPrice", price);
                tv_price_website.setText("\u20B9" + " " + price);
                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn_Register_website.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edt_name_website.getText().toString().equals("")){
                    edt_name_website.setError("Please enter the Name");
                    edt_name_website.requestFocus();
                }
                else if(edt_mobile_website.getText().toString().equals("")){
                    edt_mobile_website.setError("Please enter the Mobile");
                    edt_mobile_website.requestFocus();
                }
                else if (edt_mobile_website.getText().toString().length() != 10) {
                    edt_mobile_website.setError("Mobile No. should be 10 digit");
                    edt_mobile_website.requestFocus();
                } else if (edt_email_website.getText().toString().equals("")) {
                    edt_email_website.setError("Please enter Email");
                    edt_email_website.requestFocus();
                } else if (!(edt_email_website.getText().toString().matches(emailPattern) && edt_email_website.getText().toString().length() > 0)) {
                    edt_email_website.setError("Please enter the valid Email");
                    edt_email_website.requestFocus();
                }
                else if(pageNo.equalsIgnoreCase("Select No Of Pages Required")){
                    Toast.makeText(websiteActivity.this, "Please Select no. of pages You required", Toast.LENGTH_SHORT).show();
                }
                else if(ecommerse.equalsIgnoreCase("Is this E-Commerce")){
                    Toast.makeText(websiteActivity.this, "Please Select Website type", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitRegisterApi();
                    //startActivity(new Intent(getApplicationContext(), MainsecActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                }

            }
        });

    }


    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(websiteActivity.this, "", "Wait....", false);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn", response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject = jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(websiteActivity.this, NavigationActivity.class);
                      //  intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(websiteActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid", userId);
                    params.put("category", title);
                    params.put("price", price);
                    params.put("page_reqire", pageNo);
                    params.put("e_commere_type", ecommerse);
                    params.put("name", edt_name_website.getText().toString());
                    params.put("mobile", edt_mobile_website.getText().toString());
                    params.put("email", edt_email_website.getText().toString());

                    Log.d("msggsaqw", params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(websiteActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCategoryInForAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");

                    arListModel.clear();
                    JSONObject dataObject = jsonObject.getJSONObject("data");

                    JSONArray priceArray = dataObject.getJSONArray("prices");

                    arList.add("Select No Of Pages Required");
                    NewGstFillingModel model = new NewGstFillingModel();
                    model.setBillName("Select No Of Pages Required");
                    model.setPrice("");
                    arListModel.add(model);


                    for (int i = 0; i < priceArray.length(); i++) {
                        model = new NewGstFillingModel();
                        JSONObject priceObject = priceArray.getJSONObject(i);
                        String key = priceObject.getString("key");
                        model.setBillName(priceObject.getString("key"));
                        Log.d("key", key);
                        String value = priceObject.getString("value");
                        model.setPrice(value);
                        Log.d("value", value);

                        arListModel.add(model);
                        arList.add(key);
                    }
                    ArrayAdapter aa = new ArrayAdapter(websiteActivity.this, android.R.layout.simple_spinner_dropdown_item, arList);
                    spinnerWebsite_pages.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("userid", userId);
                params.put("category", title);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(websiteActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

       if(parent.getId()==R.id.spinnerWebsite_eccomrse){
           ecommerse = ecommerse_details[position];
           ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
       }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
