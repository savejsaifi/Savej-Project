package com.avaskm.gstseva;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.activity.Descrip;
import com.avaskm.gstseva.activity.My_Profile;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.avaskm.gstseva.session.SessonManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DescriptionActivity extends AppCompatActivity {
    Button button;
    ImageView show_description_image, showfirst_description_image;
    LinearLayout linear_Text, recycler_descrip;
    int add = R.drawable.add;
    int subtract = R.drawable.sub;
    TextView textView, rupes, textViewservice, textViewlifetype, textViewstate;
    RecyclerView RvCity;
    int counter;
    SessonManager sessonManager;
    String title;
    ArrayList<Descrip> arListCity;
    String CityName[] = {"What is your name?", "What r you doing now?", "Where r u living?", "What is your father name?"};
    String CityAnswer[] = {"My name is jyoti", "nothin", "Indirapuram", "Pradeep shukla"};
    SharedPreferences sharedPreferences_userId;
    String userId;
    ArrayList<String> list = new ArrayList<>();
    ArrayList<Descrip> listModel = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);
        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences_userId.getString("userid","");

        textViewservice = findViewById(R.id.servicename);
        textViewlifetype = findViewById(R.id.lifetype);
        textViewstate = findViewById(R.id.state);
        sessonManager = new SessonManager(DescriptionActivity.this);
        priceshow();
       /* SharedPreferences sp1 = getSharedPreferences("checkform", ThankspaymentActivity.MODE_PRIVATE);
        String  check = sp1.getString("name", "");
        Log.d("check======",check);*/
        //   Intent iin= getIntent();
        //  Bundle b = iin.getExtras();

        //if(b!=null)
        {
            //String j =(String) b.get("name");
            /*textViewservice.setText(check);*/
        }


        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        Log.d("title", title);


        textViewservice.setText(title);
        counter = 0;
        arListCity = new ArrayList<>();

        RvCity = (RecyclerView) findViewById(R.id.recycler_descrip);
        RvCity.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(DescriptionActivity.this, 1);
        RvCity.setLayoutManager(layoutManager);
        RvCity = findViewById(R.id.recycler_descrip);

        /*for(int i=0;i<CityName.length;i++){
            Descrip descrip=new Descrip();
            descrip.setQuestion(CityName[i]);
            descrip.setAnswer(CityAnswer[i]);
            arListCity.add(descrip);
        }*/
        // rcyclerviewviewadapter=new Rcyclerviewviewadapter(SelectcityActivity.this,arListCity);
        DescripRcyclerview myadpter = new DescripRcyclerview(DescriptionActivity.this, arListCity);
        RvCity.setAdapter(myadpter);

        showfirst_description_image = findViewById(R.id.show_faq);
        show_description_image = findViewById(R.id.show_description_image);
        linear_Text = findViewById(R.id.linear_Text);
        recycler_descrip = findViewById(R.id.description_linear);
        textView = findViewById(R.id.price);
        rupes = findViewById(R.id.rupes);
        button = findViewById(R.id.applynow);
        RvCity.setVisibility(View.GONE);
        // subtract_recy();
        showfirst_description_image.setImageResource(add);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DescriptionActivity.this, My_Profile.class);

                intent.putExtra("servicename", textViewservice.getText().toString());
                intent.putExtra("validity", textViewlifetype.getText().toString());
             //   intent.putExtra("price", textView.getText().toString());
                intent.putExtra("geo_state", textViewstate.getText().toString());
                intent.putExtra("title", title);

                Log.d("sadsdpo", textViewservice.getText().toString() + "\n" + textViewlifetype.getText().toString() + "\n"
                        + textView.getText().toString() + "\n" + textViewstate.getText().toString() + "\n");


                startActivity(intent);
            }
        });

        showfirst_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // priceshow();
                counter++;
                if (counter % 2 == 0) {
                    RvCity.setVisibility(View.GONE);
                    showfirst_description_image.setImageResource(add);

                } else {
                    RvCity.setVisibility(View.VISIBLE);
                    showfirst_description_image.setImageResource(subtract);
                    priceshow();


                }

                //subtract_recy();

            }
        });


        show_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linear_Text.setVisibility(View.GONE);
                textView.setVisibility(View.GONE);
                rupes.setVisibility(View.GONE);
                /*  recycler_descrip.setVisibility(View.GONE);*/
                subtract_description();
            }
        });
    }

    private void subtract_description() {
        show_description_image.setImageResource(add);
        show_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linear_Text.setVisibility(View.VISIBLE);
                textView.setVisibility(View.VISIBLE);
                rupes.setVisibility(View.VISIBLE);
                add_description();
                priceshow();
            }
        });
    }

    private void add_description() {
        show_description_image.setImageResource(subtract);
        show_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linear_Text.setVisibility(View.GONE);
                textView.setVisibility(View.GONE);
                rupes.setVisibility(View.GONE);
                subtract_description();
                // addition();
                // sub();
            }
        });

    }

    public void subtract_recy() {
        showfirst_description_image.setImageResource(add);
        showfirst_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RvCity.setVisibility(View.VISIBLE);
                add_recy();
            }
        });
    }

    public void add_recy() {
        showfirst_description_image.setImageResource(subtract);
        showfirst_description_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RvCity.setVisibility(View.GONE);
                add_recy();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public class DescripRcyclerview extends RecyclerView.Adapter<DescriptionActivity.DescripRcyclerview.ViewHolder> {
        private Context context;
        private List<Descrip> mData;

        public DescripRcyclerview(Context context, List<Descrip> mData) {
            this.context = context;
            this.mData = mData;
        }

        @NonNull
        @Override
        public DescripRcyclerview.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view;
            LayoutInflater minflater = LayoutInflater.from(context);
            view = minflater.inflate(R.layout.description_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull DescripRcyclerview.ViewHolder holder, final int position) {
          /* holder.textViewques.setTag(position);

            holder.textViewques.setText(mData.get(position).getTitle());*/
            holder.textViewques.setText(mData.get(position).getQuestion());
            holder.textView_ans.setText(mData.get(position).getAnswer());
        }

        @Override
        public int getItemCount() {
            return mData.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView textViewques, textView_ans;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                textViewques = (TextView) itemView.findViewById(R.id.desquestion);
                textView_ans = (TextView) itemView.findViewById(R.id.answer);
            }
        }
    }

    public void priceshow() {
        final ProgressDialog dialog = ProgressDialog.show(DescriptionActivity.this, "", "Loading....", false);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("fgfgdfgdfgg", response);


                dialog.dismiss();
                // arListCity.size()

                if (arListCity.size() > 0) {
                    arListCity.clear();

                }
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject jsonObject1 = jsonObject.getJSONObject("data");

                    String price = jsonObject1.getString("price");
                    String validity = jsonObject1.getString("validity");
                    String city = jsonObject1.getString("geo_status");

                    Log.d("asuydasd",validity+" "+city+" "+jsonObject1.getString("price"));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    textView.setText(price);
                    textViewlifetype.setText(validity);
                    textViewstate.setText(city);

                    JSONArray faq = jsonObject1.getJSONArray("Faq");
                    for (int i = 0; i < jsonObject1.length(); i++) {
                        JSONObject categoryObject = faq.getJSONObject(i);
                        // JSONObject faqtone=categoryObject.getJSONObject(String.valueOf(0));
//                        String question = categoryObject.getString("question");
//                        String answer = categoryObject.getString("answer");

                        Descrip historymodel = new Descrip();
                        historymodel.setQuestion(categoryObject.getString("question"));
                        historymodel.setAnswer(categoryObject.getString("answer"));
                        arListCity.add(historymodel);
                        DescripRcyclerview myadpter = new DescripRcyclerview(DescriptionActivity.this, arListCity);
                        RvCity.setAdapter(myadpter);
                    }


                    list.add("Select Constitution");
                    Descrip model = new Descrip();
                    model.setConstName("Select Constitution");
                    model.setPrice("");

                    JSONArray catogryArray = jsonObject1.getJSONArray("categories");
                    for(int i =0;i<jsonObject1.length();i++){
                        model = new Descrip();
                      JSONObject jsonObject2 = catogryArray.getJSONObject(i);
                      model.setConstName(jsonObject2.getString("name"));
                      model.setPrice(jsonObject2.getString("price"));
                        listModel.add(model);
                        list.add(jsonObject2.getString("name"));

                    }

//                    if (code.equalsIgnoreCase("200")) {
//
//                    } else {
//
//                        Toast.makeText(DescriptionActivity.this, "" + msg, Toast.LENGTH_SHORT).show();
//                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("category", title);
                params.put("userid", userId);

               /* params.put("mobile",et_username_login.getText().toString());
                Log.d("mobileee",et_username_login.getText().toString());
                params.put("password",et_password_login.getText().toString());
                Log.d("passworddd",et_password_login.getText().toString());
*/
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        startActivity(new Intent(getApplicationContext(), NavigationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
}
