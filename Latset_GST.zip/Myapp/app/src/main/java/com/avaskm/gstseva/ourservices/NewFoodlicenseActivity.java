package com.avaskm.gstseva.ourservices;
import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.avaskm.gstseva.R;
import com.squareup.picasso.Picasso;

public class NewFoodlicenseActivity extends AppCompatActivity {
    ImageView pancard, photograph, singnature, addharcard;
    Button btn_pancard,btnfoodphotographofpro,btn_sinnature,btn_addharcard,btn_photograph;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_foodlicense);
        pancard = findViewById(R.id.priopancard);
        addharcard = findViewById(R.id.foodaddharcard);
        photograph = findViewById(R.id.photographfood);
        singnature = findViewById(R.id.foodsignature);
        btn_pancard=findViewById(R.id.foodbtnpanCard);
        btn_sinnature=findViewById(R.id.foodbtnsinnature);
        btn_addharcard=findViewById(R.id.btnfoodaddharcard);
        btn_photograph=findViewById(R.id.btnfoodphotographofpro);
        btn_pancard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 1;
                abc(v);
            }
        });
        btn_sinnature.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 2;
                abc(v);
            }
        });
        btn_addharcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 3;
                abc(v);
            }
        });
        btn_photograph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 4;
                abc(v);
            }
        });

    }


    private void abc(View v){
        PopupMenu popupMenu = new PopupMenu(NewFoodlicenseActivity.this,v);
        popupMenu.getMenuInflater().inflate(R.menu.menu_image, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {
//
//                    case R.id.Camera:
//                        try {
//                            Intent intent = new Intent();
//                            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
//                            startActivityForResult(intent, 1);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        break;
                    case R.id.Gallery:

                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_PICK);
                        startActivityForResult(intent, 0);
                        break;
                }
                return false;
            }
        });
        popupMenu.show();

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try{
            if (requestCode ==0 && count==1) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(pancard);


            }
            else if( requestCode ==1 && count==1){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                pancard.setImageBitmap(bitmap);
            }
            if (requestCode ==0 && count==2) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(singnature);


            }
            else if( requestCode ==1 && count==2){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                singnature.setImageBitmap(bitmap);
            }
            if (requestCode ==0 && count==3) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(addharcard);


            }
            else if( requestCode ==1 && count==3){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                addharcard.setImageBitmap(bitmap);
            }
            if (requestCode ==0 && count==4) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(photograph);


            }
            else if( requestCode ==1 && count==4){
                Bundle bt= data.getExtras();
                Bitmap bitmap= (Bitmap) bt.get("data");
                photograph.setImageBitmap(bitmap);
            }


        }
        catch (Exception e) {

        }



}}
