package com.avaskm.gstseva.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.avaskm.gstseva.R;

public class WevViewPDFFileActivity extends AppCompatActivity {
    String documentUrl;
    ProgressBar progressbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wev_view_pdffile);
        final ProgressDialog dialog = ProgressDialog.show(WevViewPDFFileActivity.this, "", "Loading....", false);
        Intent intent = getIntent();
        documentUrl = intent.getStringExtra("documentUrl");
        Log.d("dh", documentUrl);
        WebView mywebview = (WebView) findViewById(R.id.webView);
        mywebview.getSettings().setJavaScriptEnabled(true);
        //String filename ="http://www3.nd.edu/~cpoellab/teaching/cse40816/android_tutorial.pdf";
        mywebview.loadUrl("http://docs.google.com/gview?embedded=true&url=" + documentUrl);

        //mywebview.loadUrl(SAMPLE_FILE);
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(documentUrl));
        startActivity(browserIntent);


        mywebview.setWebViewClient(new WebViewClient() {

            public void onPageFinished(WebView view, String url) {
                // do your stuff here
                //   progressbar.setVisibility(View.GONE);
                dialog.dismiss();
            }
        });
    }

}
