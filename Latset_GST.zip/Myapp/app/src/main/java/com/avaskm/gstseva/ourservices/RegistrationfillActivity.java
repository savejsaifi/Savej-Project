package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.My_Profile;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.databinding.ActivityRegistrationfillBinding;
import com.avaskm.gstseva.model.StateSpinnerModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RegistrationfillActivity extends AppCompatActivity {

    ActivityRegistrationfillBinding binding;
    ArrayList<String> listState = new ArrayList<>();
    ArrayList<StateSpinnerModel> listState_model = new ArrayList<>();
    String stateName;
    String price;
    SharedPreferences sharedPreferences;
    String userId,title;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.activity_registrationfill);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_registrationfill);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        hitstateSpinnerApi();
        spinnerClick();
        hitPriceApi();
        Log.d("sfssw",userId );


        binding.btnRegisterESI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if( binding.edtNameESI.getText().toString().equals("")){
                   binding.edtNameESI.setError("Please enter the Name");
                }
               else if(binding.edtMobileESI.getText().toString().equals("")){
                   binding.edtMobileESI.setError("Please enter the Mobile");
               }
               else if(!(binding.edtMobileESI.getText().toString().length()==10)){
                   binding.edtMobileESI.setError("Mobile No. should be 10 digit");
                }
               else if(binding.edtEmailESI.getText().toString().equals("")){
                   binding.edtEmailESI.setError("Please enter the Email");
                }
               else if (!(binding.edtEmailESI.getText().toString().matches(emailPattern) && binding.edtEmailESI.getText().toString().length() > 0)) {
                   binding.edtEmailESI.setError("Please enter the valid Email");
               }
               else if(binding.edtUserFirmNameESI.getText().toString().equals("")){
                   binding.edtUserFirmNameESI.setError("Please enter the FirmName");
                }
               else if(binding.edtAddress.getText().toString().equals("")){
                   binding.edtAddress.setError("Please enter the Address");
                }
               else if(binding.edtLandmark.getText().toString().equals("")){
                   binding.edtLandmark.setError("Please enter the Landmark");
                }
               else if(stateName.equals("Select state")){
                   Toast.makeText(RegistrationfillActivity.this, "Please Select State", Toast.LENGTH_SHORT).show();
                }
               else if(binding.edtCity1.getText().toString().equals("")){
                   binding.edtCity1.setError("Please enter the City");
                }
               else if(binding.edtPincode.getText().toString().equals("")){
                    binding.edtPincode.setError("Please enter the Pincode");
                }
               else if(!(binding.edtPincode.getText().toString().length()==6)){
                    binding.edtPincode.setError("Pincode Should be 6 digit");
                }
               else if(binding.edtNoESI.getText().toString().equals("")){
                    binding.edtNoESI.setError("Please enter No. of total employees");
                }
               else if(binding.edtFemaleESI.getText().toString().equals("")){
                    binding.edtFemaleESI.setError("Please enter Female employees");
                }
               else if(binding.edtMaleESI.getText().toString().equals("")){
                    binding.edtMaleESI.setError("Please enter Male employees");
                }
               else {
                   hitRegisterApi();
               }
              //  startActivity(new Intent(getApplicationContext(),RegistrationfillUploadFormActivity.class));
            }
        });


    }

    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(RegistrationfillActivity.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                        Intent intent = new Intent(RegistrationfillActivity.this, RegistrationfillUploadFormActivity.class);
                        intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                        startActivity(intent);
                        Toast.makeText(RegistrationfillActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    //params.put("userid",sessonManager.getUserid());
                    params.put("userid",userId);
                    params.put("category",title);
                    params.put("price",price);
                    params.put("name",binding.edtNameESI.getText().toString());
                    params.put("mobile", binding.edtMobileESI.getText().toString());
                    params.put("email",binding.edtEmailESI.getText().toString());
                    params.put("firm_name",binding.edtUserFirmNameESI.getText().toString());
                    params.put("district",binding.edtCity1.getText().toString());
                    params.put("state",stateName);
                    params.put("pincode",binding.edtPincode.getText().toString());
                    params.put("landmark",binding.edtLandmark.getText().toString());
                    params.put("business_address",binding.edtAddress.getText().toString());
//                    params.put("business_address",binding.edtNoESI.getText().toString());
//                    params.put("business_address",binding.edtFemaleESI.getText().toString());
//                    params.put("business_address",binding.edtMaleESI.getText().toString());

                    //   params.put("gst_type",String.valueOf(constitutePosition));

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }
    private void spinnerClick() {
        binding.stateSpinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                stateName = listState_model.get(position).getStateName();
                Log.d("asdds",stateName);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void hitPriceApi() {
        final ProgressDialog progressDialog=ProgressDialog.show(RegistrationfillActivity.this,"","wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(RegistrationfillActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    Log.d("resljls",response);
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject=jsonObject.getJSONObject("data");

                    price =dataObject.getString("price");
                    Log.d("pricccc",price);
                    binding.basePriceESI.setText(price);

                    /*JSONObject jsonObject1 = jsonObject.getJSONObject("data");
                    binding.basePriceImport.setText(jsonObject1.getString("price"));*/

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("category","Registration Fill");
                return hashMap;
            }

        };
        requestQueue.add(request);
    }
    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(RegistrationfillActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                listState.add("Select state");
                StateSpinnerModel model = new StateSpinnerModel();
                model.setStateName("Select state");
                model.setId("");
                listState_model.add(model);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i =0;i<jsonArray.length();i++){
                         model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState_model.add(model);
                        listState.add(jsonObject1.getString("state_name"));
                    }
                    ArrayAdapter aa = new ArrayAdapter(RegistrationfillActivity.this,android.R.layout.simple_spinner_dropdown_item,listState);
                    binding.stateSpinner1.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }

}
