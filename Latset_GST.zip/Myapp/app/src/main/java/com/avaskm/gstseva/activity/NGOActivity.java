package com.avaskm.gstseva.activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.avaskm.gstseva.R;

import java.util.ArrayList;
import java.util.List;

public class NGOActivity extends AppCompatActivity {
    Spinner ngolimited;
    LinearLayout linearbillfirst,ngolinearsecond;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ngo);
        linearbillfirst=findViewById(R.id.linearnegobillelectricity);
        ngolinearsecond=findViewById(R.id.negobillinearlayout);
        addItemsOnSpinner2();

        addItemsOnSpinner2();
    }
    public void addItemsOnSpinner2() {

        ngolimited=findViewById(R.id.negopermissiontype);
        List<String> list = new ArrayList<String>();
        list.add("premises type");
        list.add("owned");
        list.add("rented/leased");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ngolimited.setOnItemSelectedListener(new NGOActivity.CustomOnItemSelectedListener());
        ngolimited.setAdapter(dataAdapter);
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener{

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (parent.getId() == R.id.negopermissiontype) {
                if (position == 1) {
                    linearbillfirst.setVisibility(View.VISIBLE);
                } else {
                    linearbillfirst.setVisibility(View.GONE);
                }
                if(position==2){
                    ngolinearsecond.setVisibility(View.VISIBLE);
                }
                else{
                    ngolinearsecond.setVisibility(View.GONE);
                }

            }

        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }

}
