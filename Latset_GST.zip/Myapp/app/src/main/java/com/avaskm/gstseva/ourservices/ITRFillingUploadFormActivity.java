package com.avaskm.gstseva.ourservices;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.avaskm.gstseva.ApiFactory;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.avaskm.gstseva.pdfFile.PDFInterface;
import com.avaskm.gstseva.pdfFile.PdfActivity;
import com.google.gson.JsonObject;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

public class ITRFillingUploadFormActivity extends AppCompatActivity {

    String orderid;

    Button BtnUpload;
    TextView TvSubmit;

    private static final int BUFFER_SIZE = 1024 * 2;
    private static final String IMAGE_DIRECTORY = "/demonuts_upload_gallery";
    ArrayList<String> imagePathListMOA = new ArrayList<>();
    SharedPreferences sharedPreferences;
    String userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itrfilling_upload_form);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        requestMultiplePermissions();
        BtnUpload=(Button)findViewById(R.id.btn_upload_itr_upload_form);
        TvSubmit=(TextView)findViewById(R.id.tv_submit_itr_upload_form);


        Intent intent=getIntent();
        orderid=intent.getStringExtra("orderid");

        BtnUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(intent, 1);
            }
        });




        TvSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1=new Intent(ITRFillingUploadFormActivity.this, NavigationActivity.class);
                intent1.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent1);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode==1) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(ITRFillingUploadFormActivity.this, uri);
            Log.d("ioooo", path);
            imagePathListMOA.add(path);

            uploadPDF(path);

        }

        super.onActivityResult(requestCode, resultCode, data);

    }

    private void uploadPDF(String path) {

        String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis()) + ".pdf";

       /* Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(PDFInterface.IMAGEURL)
                .addConverterFactory(ScalarsConverterFactory.create())
                .build();
*/
        //Create a file object using file path

        HashMap<String, RequestBody> partMap = new HashMap<>();
       /* partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString("1234567890"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString("45"));
        partMap.put("type", ApiFactory.getRequestBodyFromString("other"));*/
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderid));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("type", ApiFactory.getRequestBodyFromString("form16"));




        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        //File f1= new File(path);
        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListMOA.size()];
        File file = new File(path);
        // Parsing any Media type file
        RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

        Log.d("filename===", file.getName());
        imageArray1[0] = MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
        RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

      /*  MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListMOA.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListMOA.get(i));
            try {
               // File compressedfile = new Compressor(PdfActivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("pdf/*"), f1);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", f1.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }*/

        PDFInterface iApiServices = ApiFactory.createRetrofitInstance(PDFInterface.IMAGEURL).create(PDFInterface.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();
                        //  progressbarPrivate.setVisibility(View.GONE);
                        Log.d("resposed_data", String.valueOf(response.body()));

                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();
                        if(code.equalsIgnoreCase("200")){
                            Toast.makeText(ITRFillingUploadFormActivity.this, "Document upload Successfully", Toast.LENGTH_SHORT).show();
                        }
                        // Log.d("asfji",code);
                        //  Log.d("asasffji",msg);


//                        else {
//                            Toast.makeText(PdfActivity.this, "Document upload Successfully", Toast.LENGTH_SHORT).show();
//                        }
                       /* if(code.equals("200")){
                          //  Toast.makeText(PrivateLimitedActivity.this, "MOA Documents Upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                          //  Toast.makeText(PrivateLimitedActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }*/


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        //  progressbarPrivate.setVisibility(View.GONE);
                        // Toast.makeText(PrivateLimitedActivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });

    }





    public static String getFilePathFromURI(Context context, Uri contentUri) {
        //copy file and send new file path
        String fileName = getFileName(contentUri);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }
        if (!TextUtils.isEmpty(fileName)) {
            File copyFile = new File(wallpaperDirectory + File.separator + fileName);
            // create folder if not exists

            copy(context, contentUri, copyFile);
            return copyFile.getAbsolutePath();
        }
        return null;
    }

    public static String getFileName(Uri uri) {
        if (uri == null) return null;
        String fileName = null;
        String path = uri.getPath();
        int cut = path.lastIndexOf('/');
        if (cut != -1) {
            fileName = path.substring(cut + 1);
        }
        return fileName;
    }

    public static void copy(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            copystream(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int copystream(InputStream input, OutputStream output) throws Exception, IOException {
        byte[] buffer = new byte[BUFFER_SIZE];

        BufferedInputStream in = new BufferedInputStream(input, BUFFER_SIZE);
        BufferedOutputStream out = new BufferedOutputStream(output, BUFFER_SIZE);
        int count = 0, n = 0;
        try {
            while ((n = in.read(buffer, 0, BUFFER_SIZE)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
            try {
                in.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
        }
        return count;
    }

    private void requestMultiplePermissions() {
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<com.karumi.dexter.listener.PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }

                   /* @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }*/
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }
}
