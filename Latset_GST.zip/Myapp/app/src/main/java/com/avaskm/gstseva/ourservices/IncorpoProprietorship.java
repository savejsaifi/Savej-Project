package com.avaskm.gstseva.ourservices;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.ExtraLicenseModel;
import com.avaskm.gstseva.model.StateSpinnerModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IncorpoProprietorship extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner SpnState;
    Spinner spinner;
    String[] PrimisesOwned = {"Select primises type", "Owned", "Rented/leased"};
    String state, primisesType, orderid, price, ExtraPirce, name, perdirectorprice,title;
    String premiseType = "";
    EditText EtName, EtMobile, EtEmail, EtFirmName, EtFirmAddress, EtFirmDistrict, EtPincode, EtLandmark;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    TextView TvPrice, TvExtra, TvOk;
    Button BtnSubmit;

    private Dialog mDialogConfirmPopUp;
    RecyclerView RvExtra;
    ExtraLinecseRequiredAdapter adapter;
    ArrayList<ExtraLicenseModel> arListExtra = new ArrayList<>();

    List<String> extraitems = new ArrayList<>();
    int extraprice = 0;
    int directorsprice = 0;
    int setprice = 0, TotalResult;
    ArrayList<StateSpinnerModel> listState1_model = new ArrayList<>();
    ArrayList<String> listState1 = new ArrayList<>();
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorpo_proprietorship);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        TvPrice = (TextView) findViewById(R.id.tv_price_incorporation_Proprietorship);
        TvExtra = (TextView) findViewById(R.id.tv_extra_Proprietorship);
        SpnState = (Spinner) findViewById(R.id.spn_state_Proprietorship);
        spinner = (Spinner) findViewById(R.id.permission_inc_prop);


        EtName = (EditText) findViewById(R.id.et_name_Proprietorship);
        EtMobile = (EditText) findViewById(R.id.et_mobile_Proprietorship);
        EtEmail = (EditText) findViewById(R.id.et_email_Proprietorship);
        EtFirmName = (EditText) findViewById(R.id.et_firm_name_Proprietorship);
        EtFirmAddress = (EditText) findViewById(R.id.et_firm_address_Proprietorship);
        EtFirmDistrict = (EditText) findViewById(R.id.et_firm_district_Proprietorship);
        EtPincode = (EditText) findViewById(R.id.et_pincode_Proprietorship);
        EtLandmark = (EditText) findViewById(R.id.et_landmark_Proprietorship);
        BtnSubmit=(Button)findViewById(R.id.btn_submit_Proprietorship);

        Intent intent=getIntent();
        title=intent.getStringExtra("title");
        SpnState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                state = String.valueOf(SpnState.getItemAtPosition(i));
                Log.d("state", state);
              /* String stateName1 = listState1_model.get(i).getStateName();
                Log.d("stateName1", stateName1);*/
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });







        TvExtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialogConfirmPopUp.show();
                //  IncorporationGetCategoryApi();
            }
        });

        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(EtName.getText().toString().equals("")){
                    EtName.setError("Please enter the name");
                    EtName.requestFocus();
                }
                else if(EtMobile.getText().toString().equals("")){
                    EtMobile.setError("Please enter the Mobile No.");
                    EtMobile.requestFocus();

                }
                else if(!(EtMobile.getText().toString().length()==10)){
                    EtMobile.setError("Mobile No. should be 10 digit");
                    EtMobile.requestFocus();

                } else if(EtEmail.getText().toString().equals("")){
                    EtEmail.setError("Please enter the Email");
                    EtEmail.requestFocus();

                }
                else if (!(EtEmail.getText().toString().matches(emailPattern) && EtEmail.getText().toString().length() > 0)) {
                    EtEmail.setError("Please enter the valid Email");
                    EtEmail.requestFocus();
                }
                else if(EtFirmName.getText().toString().equals("")){
                    EtFirmName.setError("Please enter the Firm name");
                    EtFirmName.requestFocus();

                }else if(EtFirmAddress.getText().toString().equals("")){
                    EtFirmAddress.setError("Please enter the Firm Address");
                    EtFirmAddress.requestFocus();

                }else if(EtFirmDistrict.getText().toString().equals("")){
                    EtFirmDistrict.setError("Please enter the District");
                    EtFirmDistrict.requestFocus();

                }else if(state.equalsIgnoreCase("Select state")){
                    Toast.makeText(getApplicationContext(), "Please select state", Toast.LENGTH_SHORT).show();
                }
                else if(EtPincode.getText().toString().equals("")){
                    EtPincode.setError("Please enter the Pincode");
                    EtPincode.requestFocus();

                }
                else if(!(EtPincode.getText().toString().length()==6)){
                    EtPincode.setError("Please enter the Pincode");
                    EtPincode.requestFocus();

                } else if(EtLandmark.getText().toString().equals("")){
                    EtLandmark.setError("Please enter the Landmark");
                    EtLandmark.requestFocus();

                }
                else if(premiseType.equalsIgnoreCase("premises type")){
                    Toast.makeText(getApplicationContext(), "Please select Premises type", Toast.LENGTH_SHORT).show();
                }else {
                    MakeOrderAPI();
                }

            }
        });


        // Spinner click listener
        spinner.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("premises type");
        categories.add("owned");
        categories.add("rented / leased");

        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinner.setAdapter(dataAdapter);


        IncorpoProprietorshipGetCategoryApi();
        ExtraPop();
        hitstateSpinnerApi();
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if(parent.getId()==R.id.permission_inc_prop) {
            if(position==0){
                Log.d("asdfas","sdaasd");
                premiseType = "premises type";
            }

            else if(position==1){
                Log.d("asdfas","sdaasd");
                premiseType = "owned";
            }


            else if(position==2){
                Log.d("asdfas","sdaasd");
                premiseType = "rented / leased";
            }
            else{
                Log.d("asdfas","sdaasd");
                premiseType = "premises type";
            }
        }


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void ExtraPop() {
        {
            LayoutInflater inflater = LayoutInflater.from(IncorpoProprietorship.this);
            mDialogConfirmPopUp = new Dialog(IncorpoProprietorship.this,
                    android.R.style.Theme_Translucent_NoTitleBar);
            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
            lp.dimAmount = 0.75f;
            mDialogConfirmPopUp.getWindow()
                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialogConfirmPopUp.getWindow();

            View dialoglayout = inflater.inflate(R.layout.pop_extra_license_incorporation, null);
            mDialogConfirmPopUp.setContentView(dialoglayout);
            RvExtra = (RecyclerView) mDialogConfirmPopUp.findViewById(R.id.rv_extra_license);
            TvOk = (TextView) mDialogConfirmPopUp.findViewById(R.id.tv_ok_pop_extra);

            TvOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (extraitems.size() > 0) {
                        StringBuilder csvBuilder = new StringBuilder();
                        for (String item : extraitems) {
                            csvBuilder.append(item);
                            csvBuilder.append(",");
                        }
                        String extra_items = csvBuilder.toString();

                        extra_items = extra_items.substring(0, extra_items.length() - ",".length());
                        TvExtra.setText(extra_items);


                    } else {
                        TvExtra.setText("Extra license required?");
                    }
                    //extraitems.clear();
//                    System.out.println(Integer.parseInt(price));
                   /*setprice = extraprice + directorsprice;
                    TvPrice.setText(setprice);*/
                    mDialogConfirmPopUp.dismiss();
                }
            });


            RvExtra.setHasFixedSize(true);
            RecyclerView.LayoutManager layoutManager = new GridLayoutManager(IncorpoProprietorship.this, 1);
            RvExtra.setLayoutManager(layoutManager);
            arListExtra.clear();


        }
    }


    public class ExtraLinecseRequiredAdapter extends RecyclerView.Adapter<ExtraLinecseRequiredAdapter.ViewHolder> {

        Context mContext;
        ArrayList<ExtraLicenseModel> arList;

        public ExtraLinecseRequiredAdapter(Context mContext, ArrayList<ExtraLicenseModel> arList) {
            this.mContext = mContext;
            this.arList = arList;
        }


        @NonNull
        @Override
        public ExtraLinecseRequiredAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_extra_license, viewGroup, false);
            return new ExtraLinecseRequiredAdapter.ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ExtraLinecseRequiredAdapter.ViewHolder viewHolder, int i) {
            viewHolder.TvName.setText(arList.get(i).getName());
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView TvName;
            CheckBox CbExtra;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                CbExtra = (CheckBox) itemView.findViewById(R.id.cb_extra);
                TvName = (TextView) itemView.findViewById(R.id.tv_name_extra);
                CbExtra.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ExtraLicenseModel model = arListExtra.get(getAdapterPosition());
                        ExtraPirce = model.getPrice();
                        name = model.getName();
                        if (CbExtra.isChecked()) {
                            extraitems.add(name);
                            extraprice = extraprice + Integer.parseInt(ExtraPirce);
                            Log.d("extraprice", String.valueOf(extraprice));
                        } else {
                            extraitems.remove(extraitems.indexOf(name));
                            extraprice = extraprice - Integer.parseInt(ExtraPirce);
                            Log.d("extraprice", String.valueOf(extraprice));
                        }

                        setprice = Integer.parseInt(price) + extraprice + directorsprice;
                        TvPrice.setText("" + setprice);
//                        int result = extraprice;
//                        Log.d("result", String.valueOf(result));
//                        TotalResult = Integer.parseInt(price) + result;
//                        Log.d("TotalResult", String.valueOf(TotalResult));
//                        TvPrice.setText("" + TotalResult);
                    }
                });


            }
        }

    }


    private void IncorpoProprietorshipGetCategoryApi() {
        final ProgressDialog dialog1 = ProgressDialog.show(IncorpoProprietorship.this, "", "Loading....", false);
        RequestQueue queue = Volley.newRequestQueue(IncorpoProprietorship.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("IncorpoProietorshipResp", response);
                dialog1.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    price = dataObject.getString("price");
                    TvPrice.setText(price);
                    JSONArray categoryArray = dataObject.getJSONArray("categories");
                    for (int i = 0; i < categoryArray.length(); i++) {
                        ExtraLicenseModel model = new ExtraLicenseModel();
                        JSONObject categoryObject = categoryArray.getJSONObject(i);
                        String name = categoryObject.getString("name");
                        model.setName(categoryObject.getString("name"));
                        model.setPrice(categoryObject.getString("price"));
                        arListExtra.add(model);
                    }
                    adapter = new ExtraLinecseRequiredAdapter(IncorpoProprietorship.this, arListExtra);
                    RvExtra.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(IncorpoProprietorship.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
                dialog1.dismiss();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("category", title);
                return hashMap;
            }
        };
        queue.add(request);
    }


    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(IncorpoProprietorship.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("InCoPropriState", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    listState1.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState1_model.add(model);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_model.add(model);
                        listState1.add(jsonObject1.getString("state_name"));
                    }


                    ArrayAdapter aa = new ArrayAdapter(IncorpoProprietorship.this, android.R.layout.simple_spinner_dropdown_item, listState1);
                    SpnState.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(IncorpoProprietorship.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(IncorpoProprietorship.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("IncorpoProprietorship", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("Insurancorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent=new Intent(IncorpoProprietorship.this,IncorpoProprietorshipUploadFormActivity.class);
                        intent.putExtra("orderid",orderid);
                        intent.putExtra("premises",premiseType);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category",title);
                params.put("name", EtName.getText().toString());
                params.put("mobile_no", EtMobile.getText().toString());
                params.put("email_id", EtEmail.getText().toString());
                params.put("firm_name", EtFirmName.getText().toString());
                params.put("firm_address", EtFirmAddress.getText().toString());
                params.put("district", EtFirmDistrict.getText().toString());
                params.put("state", state);
                params.put("pincode", EtPincode.getText().toString());
                params.put("landmark", EtLandmark.getText().toString());
                params.put("extra_requirements", TvExtra.getText().toString());
                params.put("price", TvPrice.getText().toString());
                params.put("premises_type", premiseType);
                Log.d("allItrz", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(IncorpoProprietorship.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
