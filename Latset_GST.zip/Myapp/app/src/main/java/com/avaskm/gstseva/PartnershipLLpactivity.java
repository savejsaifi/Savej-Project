package com.avaskm.gstseva;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.activity.ProprietorActivity;
import com.avaskm.gstseva.adapter.DeedPartnerAdapter;
import com.avaskm.gstseva.adapter.PanPartnerAdapter;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.ImageModel;
import com.avaskm.gstseva.model.ModelClass;
import com.avaskm.gstseva.model.PartnerLLP;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import id.zelory.compressor.Compressor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class PartnershipLLpactivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner permissionLLP;
    LinearLayout linearpartnership1, linearpartnership2;
    Bitmap panBitmap, passBookBitmap, electricityBitmap, rentBitmap, deedBitMap, panBitMapmultiple,aadharBitmapMultiple,photoBitmap;
    ImageView  passbookpartnership, pancard, NOC, electricity_bill, rentAgreement;
    Button btnpanCardLLp, btn_deed_select, btn_panCard_select,btn_Aadhar_select, btn_photo_select, btn_Passbook, btn_electricity, btn_NOC, btn_rent;
    Button btnsubmitPartnership;
    Button btn_deed_upload, btn_panCard_upload,btn_AadharCard_upload,btn_photo_upload;
    View view1_llp, view2_llp;
    EditText edt_partnerName;
    int count;
    RecyclerView rv_deed, rv_Pan,rv_adhar,rv_photograph;
    int PICK_IMAGE_MULTIPLE = 1;
    String premiseType = "";
    // ListViewAdapter adapter;
    ArrayList<ImageModel> list;
    private RecyclerView gvGallery;
    String mCurrentDEEDPath,mCurrentPanPath,mCurrentAadharPath,mCurrentPhotographPath;
    private String photoPathDEED, photoPathPan,photoPathAadhar,photoPathPhotograph;
    String imageEncodedDeed, imageEncodedPan,imageEncodedAadhar,imageEncodedPhotograph;
    Uri photoUriDEED1,photoUriPan,photoUriAadhar,photoUriPhotograph;
    ArrayList<String> imagePathListDEED;
    ArrayList<String> imagePathListPan=new ArrayList<>();
    ArrayList<String> imagePathListAadhar=new ArrayList<>();
    ArrayList<String> imagePathListPhoto=new ArrayList<>();
    ArrayList<PartnerLLP>  Deedlist = new ArrayList<>();
    ArrayList<PartnerLLP>  Panlist = new ArrayList<>();
    ArrayList<PartnerLLP>  Aadharlist = new ArrayList<>();
    ArrayList<PartnerLLP>  Photographlist = new ArrayList<>();

    public DeedPartnerAdapter deedAdapter;
    public PanPartnerAdapter panAdapter;
    protected static final int CAMERA_REQUEST = 100;
    protected static final int GALLERY_PICTURE = 1;
    ProgressBar progressbarPartnership;
    Spinner partnerSpinner;
    int no_partner = 0;
    File photoDeedFile1 = null;
    File photoPanFile = null;
    File photoAadharFile = null;
    File photoPhotographFile = null;

    SharedPreferences sharedPreferences_OrderId;
    SharedPreferences sharedPreferences_userId;
    SharedPreferences.Editor editor;
    String orderId,userId,formId;


    private static final int STORAGE_PERMISSION_CODE = 123;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partnershipllp);
        askForPermissioncamera(Manifest.permission.CAMERA, CAMERA);
        requestStoragePermission();
        requestMultiplePermissions();

        sharedPreferences_OrderId = getSharedPreferences("orderId",MODE_PRIVATE);
        editor = sharedPreferences_OrderId.edit();
        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        orderId = sharedPreferences_OrderId.getString("orderId","");
        formId = sharedPreferences_OrderId.getString("formId","");
        userId = sharedPreferences_userId.getString("userid","");


        Log.d("sdaa",orderId+"  "+userId+ " "+formId);
       // Panlist = new ArrayList<>();

        permissionLLP = (Spinner) findViewById(R.id.permissionLLP);
        partnerSpinner = findViewById(R.id.partnerSpinner);
        linearpartnership1 = findViewById(R.id.linearpartnership1);
        linearpartnership2 = findViewById(R.id.linearpartnership2);
        view1_llp = findViewById(R.id.view1_llp);
        view2_llp = findViewById(R.id.view2_llp);

        edt_partnerName = findViewById(R.id.edt_partnerName);
    //    chkpan = findViewById(R.id.chkpan);
     //   builder = new AlertDialog.Builder(getApplicationContext());


        passbookpartnership = findViewById(R.id.passbookpartnership);
        progressbarPartnership = findViewById(R.id.progressbarPartnership);


        pancard = findViewById(R.id.imgLLPpan);
        //   NOC =  findViewById(R.id.newNOC);
        electricity_bill = findViewById(R.id.electricitybill);
        rentAgreement = findViewById(R.id.newrentAgreement);

        btnpanCardLLp = findViewById(R.id.btnpanCardLLp);
        btn_deed_select = findViewById(R.id.btn_deed_select);
        btn_panCard_select = findViewById(R.id.btn_panCard_select);
        btn_Aadhar_select = findViewById(R.id.btn_Aadhar_select);
        btn_photo_select = findViewById(R.id.btn_photo_select);
        btn_panCard_upload = findViewById(R.id.btn_panCard_upload);
        btn_deed_upload = findViewById(R.id.btn_deed_upload);
        btn_AadharCard_upload = findViewById(R.id.btn_AadharCard_upload);
        btn_photo_upload = findViewById(R.id.btn_photo_upload);

        btn_Passbook = findViewById(R.id.btnPassbook);
        btn_electricity = findViewById(R.id.btnelectricity);
        // btn_NOC =  findViewById(R.id.btnNOC);
        btn_rent = findViewById(R.id.btnrent);
        btnsubmitPartnership = findViewById(R.id.btnsubmitPartnership);

        gvGallery = findViewById(R.id.recycler);//jyoti
        rv_deed = findViewById(R.id.rv_deed);
        rv_Pan = findViewById(R.id.rv_Pan);
        rv_adhar = findViewById(R.id.rv_adhar);
        rv_photograph = findViewById(R.id.rv_photograph);

        list = new ArrayList<>();
        imagePathListDEED = new ArrayList<>();
        permissionLLP.setOnItemSelectedListener(this);
        partnerSpinner.setOnItemSelectedListener(this);
        List<String> categories = new ArrayList<String>();
        List<String> partners = new ArrayList<String>();
        categories.add("premises type");
        categories.add("owned");
        categories.add("rented / leased");

        partners.add("Select no. of Partners");
        partners.add("2");
        partners.add("3");
        partners.add("4");
        partners.add("5");
        partners.add("6");
        partners.add("7");


        // Creating adapter for spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        permissionLLP.setAdapter(dataAdapter);

        ArrayAdapter<String> partnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, partners);
        partnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        partnerSpinner.setAdapter(partnerAdapter);


        btnpanCardLLp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count = 1;
                startDialog();

            }
        });

        btn_Passbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count = 2;
                startDialog();

            }
        });

        btn_electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count = 3;
                startDialog();


            }
        });

        btn_rent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count = 4;
                startDialog();


            }
        });
        btn_deed_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count = 5;
                startDialogMultipleDeed();


            }
        });

        btn_panCard_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 if(no_partner==0){
                     Toast.makeText(PartnershipLLpactivity.this, "Please Select no. of Partners", Toast.LENGTH_SHORT).show();
                 }
                 else{
                     count = 6;
                     startDialogMultiplePan();
                 }

            }
        });
        btn_Aadhar_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(no_partner==0){
                    Toast.makeText(PartnershipLLpactivity.this, "Please Select no. of Partners", Toast.LENGTH_SHORT).show();
                }else {
                    count = 7;
                    startDialogMultipleAadhar();
                }


            }
        });
        btn_photo_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(no_partner==0){
                    Toast.makeText(PartnershipLLpactivity.this, "Please Select no. of Partners", Toast.LENGTH_SHORT).show();
                }else {
                    count = 8;
                    startDialogMultiplePhoto();
                }


            }
        });


        uploadMultiple();
        submit();
        checkBoxClick();
    }

    private void checkBoxClick() {
//        chkpan.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if(chkpan.isChecked()){
//                    AlertDialog alert = builder.create();
//                    //Setting the title manually
//                    alert.show();
//
//                    builder.setMessage("Please Upload Pan Card According to the no. of Partners(eg,2,3,4,5,6,7)")
//                            .setCancelable(true)
//                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    // View view1 = view;
//                                  dialog.dismiss();
//
//                        }
//                    });
//                    //Creating dialog box
//
//
//                }
//            }
//        });
    }

    private void uploadMultiple() {
        btn_deed_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DEEDSubmitApi();
            }
        });
        btn_panCard_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PanSubmitApi();
            }
        });
        btn_AadharCard_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aadharSubmitApi();
            }
        });

        btn_photo_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PhotoSubmitApi();
            }
        });
    }


    public void DEEDSubmitApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarPartnership.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("partnershipdeed"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListDEED.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListDEED.get(i));
            try {
                File compressedfile = new Compressor(PartnershipLLpactivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();
                        progressbarPartnership.setVisibility(View.GONE);
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        Log.d("asfji",code);
                        Log.d("asasffji",msg);
                        if(imagePathListDEED.size()==0){
                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the Documents", Toast.LENGTH_SHORT).show();
                        }

                        if(code.equals("200")){
                            Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();
                        }





//                        if(imagePathListDEED.size()==0){
//                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
//                        }
//
//
////                        Log.w("afljasd",new GsonBuilder().setPrettyPrinting().create().toJson(response));
//                       else{
//
//                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarPartnership.setVisibility(View.GONE);
                        Toast.makeText(PartnershipLLpactivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void PanSubmitApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarPartnership.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("pan"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPan.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListPan.get(i));
            try {
                File compressedfile = new Compressor(PartnershipLLpactivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();

                        progressbarPartnership.setVisibility(View.GONE);
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        if(imagePathListPan.size()==0){
                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("200")){
                            Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();

                        }

//                        if(imagePathListPan.size()==0){
//                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
//                        }
//
////                        Log.d("resposed_data",response.toString());
////                        Log.w("afljasd",new GsonBuilder().setPrettyPrinting().create().toJson(response));
//                       else{
//                            Toast.makeText(PartnershipLLpactivity.this, "Upload Successfully", Toast.LENGTH_SHORT).show();
//                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarPartnership.setVisibility(View.GONE);
                        Toast.makeText(PartnershipLLpactivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void aadharSubmitApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarPartnership.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("aadhaar"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListAadhar.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListAadhar.get(i));
            try {
                File compressedfile = new Compressor(PartnershipLLpactivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();

                        progressbarPartnership.setVisibility(View.GONE);

                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        if(imagePathListAadhar.size()==0){
                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("200")){
                             Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();

                         }

//                        if(imagePathListAadhar.size()==0){
//                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
//                        }
//
////                        Log.d("resposed_data",response.toString());
////                        Log.w("afljasd",new GsonBuilder().setPrettyPrinting().create().toJson(response));
//                       else{
//                            Toast.makeText(PartnershipLLpactivity.this, "Upload Successfully", Toast.LENGTH_SHORT).show();
//                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarPartnership.setVisibility(View.GONE);
                        Toast.makeText(PartnershipLLpactivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }
    public void PhotoSubmitApi() {

//        final ProgressDialog progressDialog = new ProgressDialog(getApplicationContext(),R.style.MyTheme);
//        progressDialog.setMessage("Please wait while uploading image.");
//        progressDialog.setCancelable(false);
//        progressDialog.show();
        progressbarPartnership.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString("photo"));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        MultipartBody.Part[] imageArray1 = new MultipartBody.Part[imagePathListPhoto.size()];


        for (int i = 0; i < imageArray1.length; i++) {
            File file = new File(imagePathListPhoto.get(i));
            try {
                File compressedfile = new Compressor(PartnershipLLpactivity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();

                        progressbarPartnership.setVisibility(View.GONE);
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        if(imagePathListPhoto.size()==0){
                            Toast.makeText(PartnershipLLpactivity.this, "Please Select the documents", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("200")){
                            Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();

                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarPartnership.setVisibility(View.GONE);
                        Toast.makeText(PartnershipLLpactivity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if (parent.getId() == R.id.permissionLLP) {
            if (position == 1) {
                premiseType = "owned";
                linearpartnership1.setVisibility(View.VISIBLE);
                view1_llp.setVisibility(View.VISIBLE);
                linearpartnership2.setVisibility(View.GONE);
                view2_llp.setVisibility(View.GONE);
            } else if (position == 2) {
                premiseType = "rented / leased";
                linearpartnership2.setVisibility(View.VISIBLE);
                linearpartnership1.setVisibility(View.VISIBLE);
                view1_llp.setVisibility(View.VISIBLE);
                view2_llp.setVisibility(View.VISIBLE);
            } else {
                premiseType = "premises type";
                linearpartnership2.setVisibility(View.GONE);
                linearpartnership1.setVisibility(View.GONE);
                view1_llp.setVisibility(View.GONE);
                view2_llp.setVisibility(View.GONE);
            }
            ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);

        }

        if (parent.getId() == R.id.partnerSpinner) {
            if (position == 1) {
                no_partner = 2;
            }
           else if (position == 2) {
                no_partner = 3;
            }
           else if (position == 3) {
                no_partner = 4;
            }
           else if (position == 4) {
                no_partner = 5;
            }
            else if (position == 5) {
                no_partner = 6;
            }
           else if (position == 6) {
                no_partner = 7;
            }
           else{
                no_partner=0;
            }
        }


    }

    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub
    }

    private void submit() {
        btnsubmitPartnership.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
            @Override
            public void onClick(View v) {
                if(edt_partnerName.getText().toString().equals("")){
                    edt_partnerName.setError("Please Enter Authorized Partner Name");
                    edt_partnerName.requestFocus();
                }
                else if(no_partner==0){
                    Toast.makeText(PartnershipLLpactivity.this, "Please Select No. Of Partner", Toast.LENGTH_SHORT).show();
                }
                else if(premiseType.equalsIgnoreCase("premises type")){
                    Toast.makeText(PartnershipLLpactivity.this, "Please Select premises type", Toast.LENGTH_SHORT).show();
                }
                else{
                    hitFinalApi();

                }

            }
        });
    }

    private void hitFinalApi() {
         final ProgressDialog progressDialog = ProgressDialog.show(PartnershipLLpactivity.this, "", "Wait...", false);
         progressDialog.show();
         progressDialog.setCanceledOnTouchOutside(false);
         progressDialog.setCancelable(false);
         RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
         StringRequest request = new StringRequest(Request.Method.POST, Api.PartnershipUpdate, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("asddas",response);
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    if(code.equals("200")){
                        Toast.makeText(PartnershipLLpactivity.this, msg, Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(PartnershipLLpactivity.this, NavigationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        editor.clear();
                        editor.commit();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("orderid",orderId);
                hashMap.put("dir_name",edt_partnerName.getText().toString());
                hashMap.put("form_id",formId);
                hashMap.put("premises_type",premiseType);
                hashMap.put("no_of_members", String.valueOf(no_partner));
                 Log.d("asddasd", String.valueOf(hashMap));
                return hashMap;
            }
        };
        requestQueue.add(request);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        panBitmap = null;
        passBookBitmap = null;
        electricityBitmap = null;
        rentBitmap = null;


        if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 1) {


                try {
                    panBitmap = (Bitmap) data.getExtras().get("data");
                    pancard.setImageBitmap(panBitmap);
                    panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);

                    hitUrlForUploadImagePan();
                } catch (Exception e) {
                    e.printStackTrace();

            }

        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 1) {

                try {

                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        panBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                        pancard.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                        hitUrlForUploadImagePan();

                    } else {

                        Log.d("inelse", "inelse");
                        panBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                        panBitmap = Bitmap.createScaledBitmap(panBitmap, 800, 800, false);
                        Picasso.get().load(data.getDataString()).into(pancard);
                        hitUrlForUploadImagePan();
                    }
                } catch (IOException e) {
                    e.printStackTrace();

            }
        } else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 2)
        {


                try {
                    passBookBitmap = (Bitmap) data.getExtras().get("data");
                    passBookBitmap = Bitmap.createScaledBitmap(passBookBitmap, 800, 800, false);
                    passbookpartnership.setImageBitmap(passBookBitmap);

                    hitUrlForUploadImagePassBook();
                } catch (Exception e) {
                    e.printStackTrace();

                }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 2) {

                try {

                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        passBookBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                        passbookpartnership.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                        hitUrlForUploadImagePassBook();

                    } else {

                        Log.d("inelse", "inelse");
                        passBookBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                        passBookBitmap = Bitmap.createScaledBitmap(passBookBitmap, 800, 800, false);
                        Picasso.get().load(data.getDataString()).into(passbookpartnership);
                        hitUrlForUploadImagePassBook();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }


        }
        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 3) {


                try {
                    electricityBitmap = (Bitmap) data.getExtras().get("data");
                    electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                    electricity_bill.setImageBitmap(electricityBitmap);

                    hitUrlForUploadImageElectricity();

                } catch (Exception e) {
                    e.printStackTrace();


            }

        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 3) {

                try {

                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        electricityBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                        electricity_bill.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                        hitUrlForUploadImageElectricity();

                    } else {

                        Log.d("inelse", "inelse");
                        electricityBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                        electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                        Picasso.get().load(data.getDataString()).into(electricity_bill);
                        hitUrlForUploadImageElectricity();
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                }


        }
        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST) && count == 4) {


                try {
                    rentBitmap = (Bitmap) data.getExtras().get("data");
                    rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                    rentAgreement.setImageBitmap(rentBitmap);
                    hitUrlForUploadImageRent();
                } catch (Exception e) {
                    e.printStackTrace();

                }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE) && count == 4) {
                try {


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        rentBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                        rentAgreement.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                        hitUrlForUploadImageRent();

                    } else {

                        Log.d("inelse", "inelse");
                        rentBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                        rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                        Picasso.get().load(data.getDataString()).into(rentAgreement);
                        hitUrlForUploadImageRent();
                    }

                } catch (IOException e) {
                    e.printStackTrace();

            }
        }
        else if ((resultCode == RESULT_OK && requestCode == 10) && count == 5) {
           // if (data != null) {
                try {
                    Log.d("fsdjdksfa","dsffds");
                    rotateImageDeed();
                } catch (Exception e) {
                    e.printStackTrace();

               // }
            }

        }
        else if ((requestCode == 786) && count == 5) {
            Log.d("asdewdfx","adspowdf");
            selectFromGalleryDEED(data);
        }
        else if ((resultCode == RESULT_OK && requestCode == 11) && count == 6) {

                try {
                    rotateImagePan();
                } catch (Exception e) {
                    e.printStackTrace();
                }


        }
        else if ((requestCode == 786) && count == 6) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryPan(data);
        }

        else if ((resultCode == RESULT_OK && requestCode == 12) && count == 7) {

                try {
                    rotateImageaadhar();
                } catch (Exception e) {
                    e.printStackTrace();
                }


        } else if ((requestCode == 786) && count == 7) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryAadhar(data);
        }

        else if ((resultCode == RESULT_OK && requestCode == 13) && count == 8) {

                try {
                    rotateImagePhoto();
                } catch (Exception e) {
                    e.printStackTrace();
                }


        } else if ((requestCode == 786) && count == 8) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryPhoto(data);
        }

    }


    public void startDialog() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });
        myAlertDialog.show();
    }

    private void startDialogMultipleDeed() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                } else {
                    try {
                        takeDEEDCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultiplePan() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                } else {
                    try {
                        takePanCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultipleAadhar() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                } else {
                    try {
                        takeAadharCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialogMultiplePhoto() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                } else {
                    try {
                        takePhotoCameraImg();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }

    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(PartnershipLLpactivity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(PartnershipLLpactivity.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }

    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }
    private void  requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    //This method will be called when the user will tap on allow or deny
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Displaying a toast
                Toast.makeText(this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }



    public static Bitmap handleSamplingAndRotationBitmap(Context context, Uri selectedImage)
            throws IOException {
        int MAX_HEIGHT = 1024;
        int MAX_WIDTH = 1024;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(selectedImage);
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(context, img, selectedImage);
        return img;
    }

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }

    private static Bitmap rotateImageIfRequired(Context context, Bitmap img, Uri selectedImage) throws IOException {

        InputStream input = context.getContentResolver().openInputStream(selectedImage);
        ExifInterface ei = null;
        if (Build.VERSION.SDK_INT > 23) {
            ei = new ExifInterface(input);
        }


        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }


    }

    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }

    ///////////////////////////////////// api for single image ///////////////////////////////////////////

    private void hitUrlForUploadImagePan() {

        final ProgressDialog progressDialog = ProgressDialog.show(PartnershipLLpactivity.this, "", "UpLoading...", false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if (code.equals("200")) {
                        Toast.makeText(PartnershipLLpactivity.this, "PanCard Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse", parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(panBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImagePassBook() {

        final ProgressDialog progressDialog = ProgressDialog.show(PartnershipLLpactivity.this, "", "UpLoading...", false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if (code.equals("200")) {
                        Toast.makeText(PartnershipLLpactivity.this, "Passbook document Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse", parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(passBookBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImageElectricity() {

        final ProgressDialog progressDialog = ProgressDialog.show(PartnershipLLpactivity.this, "", "UpLoading...", false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if (code.equals("200")) {
                        Toast.makeText(PartnershipLLpactivity.this, "document Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse", parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(electricityBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    private void hitUrlForUploadImageRent() {

        final ProgressDialog progressDialog = ProgressDialog.show(PartnershipLLpactivity.this, "", "UpLoading...", false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if (code.equals("200")) {
                        Toast.makeText(PartnershipLLpactivity.this, "document Upload  Successfully", Toast.LENGTH_SHORT).show();
                    }
                    Log.d("chekresponse", parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", "pan");
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                Map<String, DataPart> params = new HashMap<>();
                DataPart dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(rentBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                params.put("document[]", dataPart);
                Log.d("fdkjlskf", String.valueOf(params));

                return params;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }

    ////////////////////////////////// multiple image from camera //////////////////////////////////////////

    private void takeDEEDCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoDeedFile1 = createDEEDFile();
                 Log.d("checkexcesdp", String.valueOf(photoDeedFile1));
            } catch (Exception ex) {
                ex.printStackTrace();
                  Log.d("checkexcep", ex.getMessage());
            }
            photoDeedFile1 = createDEEDFile();

            photoUriDEED1 = FileProvider.getUriForFile(PartnershipLLpactivity.this, getPackageName() + ".provider", photoDeedFile1);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriDEED1);
            startActivityForResult(takePictureIntent, 10);
        }

    }
    private File createDEEDFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
         Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentDEEDPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImageDeed() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoDeedFile1.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListDEED.add(photoPath);
            deedBitMap = MediaStore.Images.Media.getBitmap(PartnershipLLpactivity.this.getContentResolver(), photoUriDEED1);
            deedBitMap = Bitmap.createScaledBitmap(deedBitMap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                deedBitMap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriDEED1);

            } else {
                Log.d("inelse", "inelse");
                deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriDEED1);
                deedBitMap = Bitmap.createScaledBitmap(deedBitMap, 800, 800, false);

            }

            Log.d("asdads", String.valueOf(photoPath));
            imageModel.setImageMobile(deedBitMap);

            if (Deedlist.size() < 10) {
                Deedlist.add(imageModel);
            }


            if (Deedlist.size() > 10) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_deed.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
            deedAdapter = new DeedPartnerAdapter(Deedlist, PartnershipLLpactivity.this);
            rv_deed.setAdapter(deedAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private void takePanCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPanFile = createPanFile();
                 Log.d("checkexcesdp", String.valueOf(photoPanFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                  Log.d("checkexcep", ex.getMessage());
            }
            photoPanFile = createPanFile();
            photoUriPan = FileProvider.getUriForFile(PartnershipLLpactivity.this, getPackageName() + ".provider", photoPanFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPan);
            startActivityForResult(takePictureIntent, 11);
        }

    }
    private File createPanFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
         Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPanPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImagePan() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPanFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPan.add(photoPath);
            panBitMapmultiple = MediaStore.Images.Media.getBitmap(PartnershipLLpactivity.this.getContentResolver(), photoUriPan);
            panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPan);

            } else {
                Log.d("inelse", "inelse");
                panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPan);
                panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

            }

            imageModel.setImageMobile(panBitMapmultiple);

            if (Panlist.size() < no_partner) {
                Panlist.add(imageModel);
            }


            if (Panlist.size() > no_partner) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_Pan.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Panlist, PartnershipLLpactivity.this);
            rv_Pan.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

     private void takeAadharCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoAadharFile = createAadharFile();
                 Log.d("checkexcesdp", String.valueOf(photoAadharFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                  Log.d("checkexcep", ex.getMessage());
            }
            photoAadharFile = createPanFile();
            photoUriAadhar = FileProvider.getUriForFile(PartnershipLLpactivity.this, getPackageName() + ".provider", photoAadharFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriAadhar);
            startActivityForResult(takePictureIntent, 12);
        }

    }
     private File createAadharFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
         Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentAadharPath = image.getAbsolutePath();
        return image;
    }
     public void rotateImageaadhar() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoAadharFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListAadhar.add(photoPath);
            aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(PartnershipLLpactivity.this.getContentResolver(), photoUriAadhar);
            aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriAadhar);

            } else {
                Log.d("inelse", "inelse");
                aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriAadhar);
                aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

            }

            Log.d("asdads", String.valueOf(photoPath));
            imageModel.setImageMobile(aadharBitmapMultiple);

            if (Aadharlist.size() < no_partner) {
                Aadharlist.add(imageModel);
            }


            if (Aadharlist.size() > no_partner) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_adhar.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Aadharlist, PartnershipLLpactivity.this);
            rv_adhar.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private void takePhotoCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPhotographFile = createPhotoFile();
                 Log.d("checkexcesdp", String.valueOf(photoPhotographFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                  Log.d("checkexcep", ex.getMessage());
            }
            photoPhotographFile = createPhotoFile();
            photoUriPhotograph = FileProvider.getUriForFile(PartnershipLLpactivity.this, getPackageName() + ".provider", photoPhotographFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPhotograph);
            startActivityForResult(takePictureIntent, 13);
        }

    }
     private File createPhotoFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
         Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
         mCurrentPhotographPath = image.getAbsolutePath();
        return image;
    }
     public void rotateImagePhoto() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPhotographFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPhoto.add(photoPath);
            photoBitmap = MediaStore.Images.Media.getBitmap(PartnershipLLpactivity.this.getContentResolver(), photoUriPhotograph);
            photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPhotograph);

            } else {
                Log.d("inelse", "inelse");
                photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPhotograph);
                photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

            }
            Log.d("asdads", String.valueOf(photoPath));
            imageModel.setImageMobile(photoBitmap);

            if (Photographlist.size() < no_partner) {
                Photographlist.add(imageModel);
            }


            if (Photographlist.size() > no_partner) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_photograph.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Photographlist, PartnershipLLpactivity.this);
            rv_photograph.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }



    ///////////////////////////   multiple image from gallery //////////////////////////////////////////

    private void selectFromGalleryDEED(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathDEED = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                        imagePathListDEED.add(photoPathDEED);

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedDeed = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            deedBitMap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            deedBitMap = Bitmap.createScaledBitmap(deedBitMap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(deedBitMap);

                        if (Deedlist.size() < 10) {
                            Deedlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathDEED = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                    imagePathListDEED.add(photoPathDEED);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedDeed = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        deedBitMap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        deedBitMap = Bitmap.createScaledBitmap(deedBitMap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(deedBitMap);

                    if (Deedlist.size() < 10) {
                        Deedlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Deedlist));
                    }
                }

                if (Deedlist.size() > 10) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_deed.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
                deedAdapter = new DeedPartnerAdapter(Deedlist, PartnershipLLpactivity.this);
                rv_deed.setAdapter(deedAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }


    private void selectFromGalleryPan(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPan = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                        imagePathListPan.add(photoPathPan);

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPan = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(panBitMapmultiple);

                        if (Panlist.size() < no_partner) {
                            Panlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPan = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                    imagePathListPan.add(photoPathPan);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPan = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(panBitMapmultiple);

                    if (Panlist.size() < no_partner) {
                        Panlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Panlist));
                    }
                }

                if (Panlist.size() > no_partner) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_Pan.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Panlist, PartnershipLLpactivity.this);
                rv_Pan.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void selectFromGalleryAadhar(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathAadhar = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                        imagePathListAadhar.add(photoPathAadhar);
                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedAadhar = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                         aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(aadharBitmapMultiple);

                        if (Aadharlist.size() < (no_partner*2)) {
                            Aadharlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathAadhar = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                    imagePathListAadhar.add(photoPathAadhar);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedAadhar = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(aadharBitmapMultiple);

                    if (Aadharlist.size() < (no_partner*2)) {
                        Aadharlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Aadharlist));
                    }
                }

                if (Aadharlist.size() > (no_partner*2)) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_adhar.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Aadharlist, PartnershipLLpactivity.this);
                rv_adhar.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void selectFromGalleryPhoto(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPhotograph = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                        imagePathListPhoto.add(photoPathPhotograph);
                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPhotograph = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(photoBitmap);

                        if (Photographlist.size() < no_partner) {
                            Photographlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPhotograph = Helper.pathFromUri(PartnershipLLpactivity.this, mImageUri);
                    imagePathListPhoto.add(photoPathPhotograph);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPhotograph = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(photoBitmap);

                    if (Photographlist.size() < no_partner) {
                        Photographlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Photographlist));
                    }
                }

                if (Photographlist.size() > no_partner) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_photograph.setLayoutManager(new LinearLayoutManager(PartnershipLLpactivity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Photographlist, PartnershipLLpactivity.this);
                rv_photograph.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    public byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, buffer);
        return buffer.toByteArray();
    }


    public static class ListAdapter extends RecyclerView.Adapter<ListAdapter.ListViewHolder> {
        ArrayList<ImageModel> list;
        Context context;

        public ListAdapter(ArrayList<ImageModel> list, Context context) {
            this.context = context;
            this.list = list;
        }

        @Override
        public ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.gv_item, null);

            return new ListViewHolder(view);
        }

        @Override
        public void onBindViewHolder(ListAdapter.ListViewHolder holder, final int position) {
            final ImageModel imageModel = list.get(position);
            holder.image.setImageBitmap(imageModel.getImage());


            holder.close.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    removeAt(position);
                }
            });
        }

        public void removeAt(int position) {
            list.remove(position);
            notifyItemRemoved(position);
            notifyItemChanged(position);
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        class ListViewHolder extends RecyclerView.ViewHolder {

            ImageView image;
            TextView close;

            public ListViewHolder(View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.ivGallery);
                close = itemView.findViewById(R.id.badge_view);
            }

        }


    }


}