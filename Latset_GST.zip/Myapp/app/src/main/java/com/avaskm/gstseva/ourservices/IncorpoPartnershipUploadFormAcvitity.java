package com.avaskm.gstseva.ourservices;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.ApiFactory;
import com.avaskm.gstseva.Helper;
import com.avaskm.gstseva.IApiServices;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.VolleyMultipartRequest;
import com.avaskm.gstseva.adapter.PanPartnerAdapter;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.PartnerLLP;
import com.avaskm.gstseva.navigation.NavigationActivity;
import com.google.gson.JsonObject;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import id.zelory.compressor.Compressor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;

import static android.media.MediaRecorder.VideoSource.CAMERA;

public class IncorpoPartnershipUploadFormAcvitity extends AppCompatActivity {


   int count;
   String type="";
    int PICK_IMAGE_MULTIPLE = 1;
   ImageView electricity_bill_partnership_inc,rentAgreement_partnership_inc;
   Button btn_electricity_Partnership_inc,btn_rent_partnership_inc;
   Button btn_pan_inc_partner_select,btn_aadhar_inc_partner_select,btn_passbook_inc_partner_select;
   Button btn_pan_inc_partner_upload,btn_aadhar_inc_partner_upload,btn_passbook_inc_partner_upload;
   Button btn_Partner_submit_form;
    LinearLayout linear_private1, linear_private2;
    View view1_private;

    SharedPreferences sharedPreferences_userId;
    String orderId,userId,premisesType;
    private static final int STORAGE_PERMISSION_CODE = 123;
    private static final int GALLERY_PICTURE = 1;
    private static final int CAMERA_REQUEST = 100;
    private static final String IMAGE_DIRECTORY = "/demonuts_upload_gallery";
    private static final int BUFFER_SIZE = 1024 * 2;
    RecyclerView rv_pan_inc_partner,rv_aadhar_inc_partner,rv_passbook_inc_partner;
    private PanPartnerAdapter panAdapter;
    Bitmap panBitMapmultiple,aadharBitmapMultiple,photoBitmap,electricityBitmap,rentBitmap;

    ArrayList<String> imagePathListPan=new ArrayList<>();
    ArrayList<String> imagePathListAadhar=new ArrayList<>();
    ArrayList<String> imagePathListPassbook=new ArrayList<>();

    ArrayList<PartnerLLP>  Panlist = new ArrayList<>();
    ArrayList<PartnerLLP>  Aadharlist = new ArrayList<>();
    ArrayList<PartnerLLP>  Passbooklist = new ArrayList<>();

    ArrayList<String> imagePathListElectricityPdf=new ArrayList<>();
    ArrayList<String> imagePathListRentPdf=new ArrayList<>();

    File photoPanFile,photoAadharFile,photoPassbookFile = null;
    Uri photoUriPan,photoUriAadhar,photoUriPassbook;
    String mCurrentPanPath,mCurrentAadharPath,mCurrentPassbookPath;
    private String photoPathPan,photoPathAadhar,photoPathPassbook;
    String imageEncodedPan,imageEncodedAadhar,imageEncodedPassbook;
    ProgressBar progressbarPartnership;
    MultipartBody.Part[] imageArray1;
    Map<String, VolleyMultipartRequest.DataPart> params2;
    VolleyMultipartRequest.DataPart dataPart;
    File file;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorpo_partnership_upload_form_acvitity);
        sharedPreferences_userId = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences_userId.getString("userid","");
        orderId = getIntent().getExtras().getString("orderid");
        premisesType = getIntent().getExtras().getString("premisesType");
        Log.d("premisesType",premisesType);
        requestStoragePermission();
        requestMultiplePermissions();
        askForPermissioncamera(Manifest.permission.CAMERA,CAMERA);


        linear_private1 = findViewById(R.id.linear_private1_upload_partnership);
        linear_private2 = findViewById(R.id.linear_private2_upload_partnership);
        view1_private = findViewById(R.id.view1_private_upload_partnership);
        spinnerPremises();

        electricity_bill_partnership_inc = findViewById(R.id.electricity_bill_partnership_inc);
        rentAgreement_partnership_inc = findViewById(R.id.rentAgreement_partnership_inc);
        btn_electricity_Partnership_inc = findViewById(R.id.btn_electricity_Partnership_inc);
        btn_rent_partnership_inc = findViewById(R.id.btn_rent_partnership_inc);
        btn_pan_inc_partner_select = findViewById(R.id.btn_pan_inc_partner_select);
        btn_aadhar_inc_partner_select = findViewById(R.id.btn_aadhar_inc_partner_select);
        btn_passbook_inc_partner_select = findViewById(R.id.btn_passbook_inc_partner_select);
        btn_pan_inc_partner_upload = findViewById(R.id.btn_pan_inc_partner_upload);
        btn_aadhar_inc_partner_upload = findViewById(R.id.btn_aadhar_inc_partner_upload);
        btn_passbook_inc_partner_upload = findViewById(R.id.btn_passbook_inc_partner_upload);
        btn_Partner_submit_form = findViewById(R.id.btn_Partner_inc_submit);
        rv_pan_inc_partner = findViewById(R.id.rv_pan_inc_partner);
        rv_aadhar_inc_partner = findViewById(R.id.rv_aadhar_inc_partner);
        rv_passbook_inc_partner = findViewById(R.id.rv_passbook_inc_partner);
        progressbarPartnership = findViewById(R.id.progressbarPartnership_inc);

        multipleImageClickSelect();
        uploadMultiple();
        singleImageSelect();
        btn_Partner_submit_form.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), NavigationActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

            }
        });

    }

    private void singleImageSelect() {
        btn_electricity_Partnership_inc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=4;
                startDialog();
                type = "electricitybill";
            }
        });
        btn_rent_partnership_inc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=5;
                startDialog();
                type = "rentagreement";
            }
        });
    }

    private void uploadMultiple() {
        btn_pan_inc_partner_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListPan.size()==0){
                    Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Please Select Pan Images", Toast.LENGTH_SHORT).show();
                }else{
                    type="pan";
                    MultipleSubmitApi();
                }

            }
        });
        btn_aadhar_inc_partner_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListAadhar.size()==0){
                    Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Please Select Aadhar Images", Toast.LENGTH_SHORT).show();
                }
                else{
                    type="aadhaar";
                    MultipleSubmitApi();
                }

            }
        });
        btn_passbook_inc_partner_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imagePathListPassbook.size()==0){
                    Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Please Select Passbook Images", Toast.LENGTH_SHORT).show();
                }else{
                    type="passbook";
                    MultipleSubmitApi();
                }

            }
        });

    }


    private void multipleImageClickSelect() {
       btn_pan_inc_partner_select.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
                   count = 1;
                   startDialogMultiple();

           }
       });
       btn_aadhar_inc_partner_select.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
                   count = 2;
                   startDialogMultiple();

           }
       });
       btn_passbook_inc_partner_select.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
                   count = 3;
                   startDialogMultiple();
           }
       });

    }

    private void startDialogMultiple() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 786);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(IncorpoPartnershipUploadFormAcvitity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, PICK_IMAGE_MULTIPLE);

                } else {
                    try {
                        if(count==1){
                            takePanCameraImg();
                        } if(count==2){
                            takeAadharCameraImg();
                        } if(count==3){
                            takePassbookCameraImg();
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

            }
        });
        myAlertDialog.show();
    }
    private void startDialog() {
        AlertDialog.Builder myAlertDialog = new AlertDialog.Builder(this);
        myAlertDialog.setTitle("Upload Pictures Option");
        myAlertDialog.setMessage("How do you want to set your picture?");

        myAlertDialog.setPositiveButton("Gallery", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent pictureActionIntent = null;
                pictureActionIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(pictureActionIntent, GALLERY_PICTURE);

            }
        });

        myAlertDialog.setNegativeButton("Camera", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface arg0, int arg1) {
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(cameraIntent, CAMERA_REQUEST);


            }
        });

        myAlertDialog.setNeutralButton("Pdf", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("application/pdf");
                startActivityForResult(intent,200);
            }
        });

        myAlertDialog.show();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        electricityBitmap=null;
        rentBitmap=null;
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK && requestCode == 1) && count == 1) {

            try {
                rotateImagePan();
            } catch (Exception e) {
                e.printStackTrace();
            }


        }
        else if ((requestCode == 786) && count == 1) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryPan(data);
        }

        else if ((resultCode == RESULT_OK && requestCode == 2) && count == 2) {

            try {
                rotateImageaadhar();
            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if ((requestCode == 786) && count == 2) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryAadhar(data);
        }

        else if ((resultCode == RESULT_OK && requestCode == 3) && count == 3) {

            try {
                rotateImagePassbook();
            } catch (Exception e) {
                e.printStackTrace();
            }


        } else if ((requestCode == 786) && count ==3) {
            Log.d("pogftrf","wqeskz");
            selectFromGalleryPassbook(data);
        }
       else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==4) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    electricityBitmap = (Bitmap) data.getExtras().get("data");
                    electricity_bill_partnership_inc.setImageBitmap(electricityBitmap);
                    electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                    hitUrlForUploadImage();
                }
                else {
                    electricityBitmap = (Bitmap) data.getExtras().get("data");
                    electricity_bill_partnership_inc.setImageBitmap(electricityBitmap);
                    electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                    hitUrlForUploadImage();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==4) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    electricityBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    electricity_bill_partnership_inc.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImage();

                } else {

                    Log.d("inelse", "inelse");

                    electricityBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    electricityBitmap = Bitmap.createScaledBitmap(electricityBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(electricity_bill_partnership_inc);
                    hitUrlForUploadImage();
                }


            } catch (Exception e) {
            }
        }
        else if ((resultCode == RESULT_OK && requestCode == 200) && count==4) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(IncorpoPartnershipUploadFormAcvitity.this,uri);
            Log.d("ioooo",path);
            imagePathListElectricityPdf.add(path);
            uploadPDF(path);
        }

        else if ((resultCode == RESULT_OK && requestCode == CAMERA_REQUEST)&& count==5) {

            try {
                if (Build.VERSION.SDK_INT > 23) {
                    rentBitmap = (Bitmap) data.getExtras().get("data");
                    rentAgreement_partnership_inc.setImageBitmap(rentBitmap);
                    rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                    hitUrlForUploadImage();
                }
                else {
                    rentBitmap = (Bitmap) data.getExtras().get("data");
                    rentAgreement_partnership_inc.setImageBitmap(rentBitmap);
                    rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                    hitUrlForUploadImage();
                }

            } catch (Exception e) {
                e.printStackTrace();

            }


        }
        else if ((resultCode == RESULT_OK && requestCode == GALLERY_PICTURE)&& count==5) {


            try {
                if (Build.VERSION.SDK_INT > 23) {
                    Log.d("inelswe", "inelse");
                    rentBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), data.getData());
                    rentAgreement_partnership_inc.setImageBitmap(handleSamplingAndRotationBitmap(getApplicationContext(), data.getData()));
                    hitUrlForUploadImage();

                } else {

                    Log.d("inelse", "inelse");

                    rentBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), Uri.parse(data.getDataString().toString()));
                    rentBitmap = Bitmap.createScaledBitmap(rentBitmap, 800, 800, false);
                    Picasso.get().load(data.getDataString()).into(rentAgreement_partnership_inc);
                    hitUrlForUploadImage();
                }


            } catch (Exception e) {
            }
        }
        else if ((resultCode == RESULT_OK && requestCode == 200) && count==5) {
            // Get the Uri of the selected file
            Uri uri = data.getData();
            String uriString = uri.toString();
            File myFile = new File(uriString);

            String path = getFilePathFromURI(IncorpoPartnershipUploadFormAcvitity.this,uri);
            Log.d("ioooo",path);
            imagePathListRentPdf.add(path);
            uploadPDF(path);
        }


    }


    /////////////////////////////////////// upload single image //////////////////////////////////////////////
    private void hitUrlForUploadImage() {

        final ProgressDialog progressDialog=ProgressDialog.show(IncorpoPartnershipUploadFormAcvitity.this,"","UpLoading...",false);
        VolleyMultipartRequest request = new VolleyMultipartRequest(Request.Method.POST, Api.properiater, new com.android.volley.Response.Listener<NetworkResponse>() {
            @Override
            public void onResponse(NetworkResponse response) {
                Log.d("networkresponse", String.valueOf(response.data));
                progressDialog.dismiss();

                //   JsonObject jsonObject = new JsonObject(new String(response.data));
                String parsed = "";
                try {
                    parsed = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
                    // parsed.split("","");
                    JSONObject jsonObject = new JSONObject(new String(response.data));
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");

                    if(code.equals("200")){
                        if(type.equalsIgnoreCase("electricitybill")){
                            Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Electricity Document Upload  Successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(type.equalsIgnoreCase("rentagreement")){
                            Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Rent Document Upload  Successfully", Toast.LENGTH_SHORT).show();
                        }

                    }
                    Log.d("chekresponse",parsed);

                } catch (UnsupportedEncodingException e) {

                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("orderid", orderId);
                params.put("userid", userId);
                params.put("type", type);
                Log.d("cheprams", params.toString());
                return params;
            }

            @Override
            protected Map<String, DataPart> getByteData() {

                params2 = new HashMap<>();
                if(type.equalsIgnoreCase("electricitybill")){
                    dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(electricityBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                    params2.put("document[]", dataPart);

                }
                if(type.equalsIgnoreCase("rentagreement")){
                    dataPart = new DataPart(String.valueOf(System.currentTimeMillis() + ".png"), convertBitmapToByteArray(rentBitmap));
//                        Log.d("picture", String.valueOf(dataPart));
                    params2.put("document[]", dataPart);

                }



                Log.d("fdkjlskf", String.valueOf(params2));

                return params2;
            }

        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(request);
    }
    ///////////////////////////////////// upload pdf //////////////////////////////////////////////////////////
    private void uploadPDF(String path){

        String pdfname = String.valueOf(Calendar.getInstance().getTimeInMillis())+".pdf";


        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString("5642vcb546g2334hh555b7r6ewc211vhh34"));
        partMap.put("type", ApiFactory.getRequestBodyFromString(type));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        //File f1= new File(path);
        if(count==4){
            imageArray1 = new MultipartBody.Part[imagePathListElectricityPdf.size()];
        }
        if(count==5){
            imageArray1 = new MultipartBody.Part[imagePathListRentPdf.size()];
        }

        File file = new File(path);
        // Parsing any Media type file
        RequestBody requestBody = RequestBody.create(MediaType.parse("*/*"), file);

        Log.d("filename===",file.getName());
        imageArray1[0] =  MultipartBody.Part.createFormData("document[]", pdfname, requestBody);
        RequestBody filename = RequestBody.create(MediaType.parse("text/plain"), pdfname);

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        Log.d("qwaszaqwsx", String.valueOf(response));
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();


                        if(code.equals("200")){
                            Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "Pdf upload successfully", Toast.LENGTH_SHORT).show();
                        }
                        else if(code.equals("400")){
                            Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, msg, Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {

                        Log.d("data_error", t.getMessage());

                    }
                });

    }

    ////////////////////////////////////// hit Multiple image Api //////////////////////////////////////////////
    public void MultipleSubmitApi() {

        imageArray1=null;
        file=null;
        progressbarPartnership.setVisibility(View.VISIBLE);

        HashMap<String, RequestBody> partMap = new HashMap<>();
        partMap.put("key", ApiFactory.getRequestBodyFromString(Api.key));
        partMap.put("type", ApiFactory.getRequestBodyFromString(type));
        partMap.put("userid", ApiFactory.getRequestBodyFromString(userId));
        partMap.put("orderid", ApiFactory.getRequestBodyFromString(orderId));

        if(count==1){
            imageArray1 = new MultipartBody.Part[imagePathListPan.size()];
        }
        if(count==2){
            imageArray1 = new MultipartBody.Part[imagePathListAadhar.size()];
        }
        if(count==3){
            imageArray1 = new MultipartBody.Part[imagePathListPassbook.size()];
        }



        for (int i = 0; i < imageArray1.length; i++) {
            if(count==1){
                file = new File(imagePathListPan.get(i));
            } if(count==2){
                file = new File(imagePathListAadhar.get(i));
            } if(count==3){
                file = new File(imagePathListPassbook.get(i));
            }

            try {
                File compressedfile = new Compressor(IncorpoPartnershipUploadFormAcvitity.this).compressToFile(file);
                RequestBody requestBodyArray = RequestBody.create(MediaType.parse("image/*"), compressedfile);
                imageArray1[i] = MultipartBody.Part.createFormData("document[]", compressedfile.getName(), requestBodyArray);

                Log.d("astysawe", String.valueOf(imageArray1[i]));
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        IApiServices iApiServices = ApiFactory.createRetrofitInstance(Api.BASE_URL).create(IApiServices.class);
        iApiServices.hitMultiple(imageArray1, partMap)
                .enqueue(new Callback<JsonObject>() {
                    @Override
                    public void onResponse(Call<JsonObject> call, retrofit2.Response<JsonObject> response) {
                        //Toast.makeText(ClaimAssistanceActivity_form.this, "" + response, Toast.LENGTH_SHORT).show();
                        // progressDialog.dismiss();

                        progressbarPartnership.setVisibility(View.GONE);
                        Log.d("resposed_data",response.toString());
                        JsonObject jsonObject = response.body();
                        String code = jsonObject.get("code").getAsString();
                        String msg = jsonObject.get("msg").getAsString();

                        if(code.equals("200")){
                            Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, msg, Toast.LENGTH_SHORT).show();

                        }


                    }

                    @Override
                    public void onFailure(Call<JsonObject> call, Throwable t) {
                        progressbarPartnership.setVisibility(View.GONE);
                        Toast.makeText(IncorpoPartnershipUploadFormAcvitity.this, "fail" + t.getMessage(), Toast.LENGTH_SHORT).show();
                        //   progressDialog.dismiss();
                        Log.d("data_error", t.getMessage());

                    }
                });
    }


    ///////////////////////////   multiple image from Camera  //////////////////////////////////////////
    private void takePanCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPanFile = createPanFile();
                Log.d("checkexcesdp", String.valueOf(photoPanFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoPanFile = createPanFile();
            photoUriPan = FileProvider.getUriForFile(IncorpoPartnershipUploadFormAcvitity.this, getPackageName() + ".provider", photoPanFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPan);
            startActivityForResult(takePictureIntent, 1);
        }

    }
    private File createPanFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPanPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImagePan() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPanFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPan.add(photoPath);
            panBitMapmultiple = MediaStore.Images.Media.getBitmap(IncorpoPartnershipUploadFormAcvitity.this.getContentResolver(), photoUriPan);
            panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();

            Log.d("asdads", String.valueOf(photoPath));


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPan);

            } else {
                Log.d("inelse", "inelse");
                panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPan);
                panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

            }

            imageModel.setImageMobile(panBitMapmultiple);

            if (Panlist.size() < 7) {
                Panlist.add(imageModel);
            }


            if (Panlist.size() > 7) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_pan_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Panlist, IncorpoPartnershipUploadFormAcvitity.this);
            rv_pan_inc_partner.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private void takeAadharCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoAadharFile = createAadharFile();
                Log.d("checkexcesdp", String.valueOf(photoAadharFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoAadharFile = createPanFile();
            photoUriAadhar = FileProvider.getUriForFile(IncorpoPartnershipUploadFormAcvitity.this, getPackageName() + ".provider", photoAadharFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriAadhar);
            startActivityForResult(takePictureIntent, 2);
        }

    }
    private File createAadharFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentAadharPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImageaadhar() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoAadharFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListAadhar.add(photoPath);
            aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(IncorpoPartnershipUploadFormAcvitity.this.getContentResolver(), photoUriAadhar);
            aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriAadhar);

            } else {
                Log.d("inelse", "inelse");
                aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriAadhar);
                aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

            }

            Log.d("asdads", String.valueOf(photoPath));
            imageModel.setImageMobile(aadharBitmapMultiple);

            if (Aadharlist.size() < 7) {
                Aadharlist.add(imageModel);
            }


            if (Aadharlist.size() > 7) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_aadhar_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Aadharlist, IncorpoPartnershipUploadFormAcvitity.this);
            rv_aadhar_inc_partner.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    private void takePassbookCameraImg() throws IOException {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            try {
                photoPassbookFile = createPhotoFile();
                Log.d("checkexcesdp", String.valueOf(photoPassbookFile));
            } catch (Exception ex) {
                ex.printStackTrace();
                Log.d("checkexcep", ex.getMessage());
            }
            photoPassbookFile = createPhotoFile();
            photoUriPassbook = FileProvider.getUriForFile(IncorpoPartnershipUploadFormAcvitity.this, getPackageName() + ".provider", photoPassbookFile);
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUriPassbook);
            startActivityForResult(takePictureIntent, 3);
        }

    }
    private File createPhotoFile() throws IOException {
        String imageFileName = "GOOGLES" + System.currentTimeMillis();
        String storageDir = Environment.getExternalStorageDirectory() + "/skImages";
        Log.d("storagepath===", storageDir);
        File dir = new File(storageDir);
        if (!dir.exists())
            dir.mkdir();

        File image = new File(storageDir + "/" + imageFileName + ".jpg");
        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPassbookPath = image.getAbsolutePath();
        return image;
    }
    public void rotateImagePassbook() throws IOException {
        Log.d("asdads", "check");

        try {
            String photoPath = photoPassbookFile.getAbsolutePath();
            Log.d("asdads", photoPath);
            imagePathListPassbook.add(photoPath);
            photoBitmap = MediaStore.Images.Media.getBitmap(IncorpoPartnershipUploadFormAcvitity.this.getContentResolver(), photoUriPassbook);
            photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);
            PartnerLLP imageModel = new PartnerLLP();


            if (Build.VERSION.SDK_INT > 23) {
                Log.d("inelswe", "inelse");
                photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), photoUriPassbook);

            } else {
                Log.d("inelse", "inelse");
                photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), photoUriPassbook);
                photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

            }
            Log.d("asdads", String.valueOf(photoPath));
            imageModel.setImageMobile(photoBitmap);

            if (Passbooklist.size() < 7) {
                Passbooklist.add(imageModel);
            }


            if (Passbooklist.size() > 7) {
                //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
            }

            rv_passbook_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
            panAdapter = new PanPartnerAdapter(Passbooklist, IncorpoPartnershipUploadFormAcvitity.this);
            rv_passbook_inc_partner.setAdapter(panAdapter);


        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    ///////////////////////////   multiple image from Gallery  //////////////////////////////////////////

    private void selectFromGalleryPan(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPan = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                        imagePathListPan.add(photoPathPan);

                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPan = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(panBitMapmultiple);

                        if (Panlist.size() < 7) {
                            Panlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPan = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                    imagePathListPan.add(photoPathPan);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPan = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        panBitMapmultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        panBitMapmultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        panBitMapmultiple = Bitmap.createScaledBitmap(panBitMapmultiple, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(panBitMapmultiple);

                    if (Panlist.size() < 7) {
                        Panlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Panlist));
                    }
                }

                if (Panlist.size() > 7) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_pan_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Panlist, IncorpoPartnershipUploadFormAcvitity.this);
                rv_pan_inc_partner.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void selectFromGalleryAadhar(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathAadhar = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                        imagePathListAadhar.add(photoPathAadhar);
                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedAadhar = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(aadharBitmapMultiple);

                        if (Aadharlist.size() < (14)) {
                            Aadharlist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathAadhar = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                    imagePathListAadhar.add(photoPathAadhar);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedAadhar = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        aadharBitmapMultiple = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        aadharBitmapMultiple = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        aadharBitmapMultiple = Bitmap.createScaledBitmap(aadharBitmapMultiple, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(aadharBitmapMultiple);

                    if (Aadharlist.size() < (14)) {
                        Aadharlist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Aadharlist));
                    }
                }

                if (Aadharlist.size() > (14)) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_aadhar_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Aadharlist, IncorpoPartnershipUploadFormAcvitity.this);
                rv_aadhar_inc_partner.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }

    private void selectFromGalleryPassbook(Intent data) {
        if (data != null) {
            try {

                String[] filePathColumn = {MediaStore.Images.Media.DATA};
                if (data.getClipData() != null) {
                    int imageCount = data.getClipData().getItemCount();
                    for (int i = 0; i < imageCount; i++) {
                        Uri mImageUri = data.getClipData().getItemAt(i).getUri();
                        photoPathPassbook = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                        imagePathListPassbook.add(photoPathPassbook);
                        // Get the cursor
                        Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                                filePathColumn, null, null, null);
                        // Move to first row
                        cursor1.moveToFirst();

                        int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                        imageEncodedPassbook = cursor1.getString(columnIndex1);

                        if (Build.VERSION.SDK_INT > 23) {
                            Log.d("inelswe", "inelse");
                            photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                        } else {
                            Log.d("inelse", "inelse");
                            photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                            photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

                        }


                        //   deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        cursor1.close();
                        PartnerLLP imageModel = new PartnerLLP();
                        imageModel.setImageMobile(photoBitmap);

                        if (Passbooklist.size() < 7) {
                            Passbooklist.add(imageModel);
                        }
                    }
                } else {
                    Uri mImageUri = data.getData();
                    photoPathPassbook = Helper.pathFromUri(IncorpoPartnershipUploadFormAcvitity.this, mImageUri);
                    imagePathListPassbook.add(photoPathPassbook);

                    // Get the cursor
                    Cursor cursor1 = getApplicationContext().getContentResolver().query(mImageUri,
                            filePathColumn, null, null, null);
                    // Move to first row
                    cursor1.moveToFirst();

                    int columnIndex1 = cursor1.getColumnIndex(filePathColumn[0]);
                    imageEncodedPassbook = cursor1.getString(columnIndex1);


                    if (Build.VERSION.SDK_INT > 23) {
                        Log.d("inelswe", "inelse");
                        photoBitmap = handleSamplingAndRotationBitmap(getApplicationContext(), mImageUri);

                    } else {
                        Log.d("inelse", "inelse");
                        photoBitmap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);
                        photoBitmap = Bitmap.createScaledBitmap(photoBitmap, 800, 800, false);

                    }

                    //  deedBitMap = MediaStore.Images.Media.getBitmap(getApplicationContext().getContentResolver(), mImageUri);

                    cursor1.close();
                    PartnerLLP imageModel = new PartnerLLP();
                    imageModel.setImageMobile(photoBitmap);

                    if (Passbooklist.size() < 7) {
                        Passbooklist.add(imageModel);
                        Log.d("opfldsasd", String.valueOf(Passbooklist));
                    }
                }

                if (Passbooklist.size() > 7) {
                    //Toast.makeText(getApplicationContext(), "Max Limit Only 10", Toast.LENGTH_SHORT).show();
                }
                // Log.d("opfldsasd", String.valueOf(Deedlist));
                rv_passbook_inc_partner.setLayoutManager(new LinearLayoutManager(IncorpoPartnershipUploadFormAcvitity.this, LinearLayoutManager.HORIZONTAL, false));
                panAdapter = new PanPartnerAdapter(Passbooklist, IncorpoPartnershipUploadFormAcvitity.this);
                rv_passbook_inc_partner.setAdapter(panAdapter);

            } catch (Exception e) {

                e.printStackTrace();
            }
        }

    }


    private void spinnerPremises() {
        if (premisesType.equalsIgnoreCase("owned")) {
            linear_private2.setVisibility(View.GONE);
            linear_private1.setVisibility(View.VISIBLE);
            view1_private.setVisibility(View.VISIBLE);
        } else if (premisesType.equalsIgnoreCase("rented/leased")) {
            linear_private1.setVisibility(View.VISIBLE);
            view1_private.setVisibility(View.VISIBLE);
            linear_private2.setVisibility(View.VISIBLE);
        }

    }

    public static String getFilePathFromURI(Context context, Uri contentUri) {
        //copy file and send new file path
        String fileName = getFileName(contentUri);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }
        if (!TextUtils.isEmpty(fileName)) {
            File copyFile = new File(wallpaperDirectory + File.separator + fileName);
            // create folder if not exists

            copy(context, contentUri, copyFile);
            return copyFile.getAbsolutePath();
        }
        return null;
    }

    public static String getFileName(Uri uri) {
        if (uri == null) return null;
        String fileName = null;
        String path = uri.getPath();
        int cut = path.lastIndexOf('/');
        if (cut != -1) {
            fileName = path.substring(cut + 1);
        }
        return fileName;
    }

    public static void copy(Context context, Uri srcUri, File dstFile) {
        try {
            InputStream inputStream = context.getContentResolver().openInputStream(srcUri);
            if (inputStream == null) return;
            OutputStream outputStream = new FileOutputStream(dstFile);
            copystream(inputStream, outputStream);
            inputStream.close();
            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static int copystream(InputStream input, OutputStream output) throws Exception, IOException {
        byte[] buffer = new byte[BUFFER_SIZE];

        BufferedInputStream in = new BufferedInputStream(input, BUFFER_SIZE);
        BufferedOutputStream out = new BufferedOutputStream(output, BUFFER_SIZE);
        int count = 0, n = 0;
        try {
            while ((n = in.read(buffer, 0, BUFFER_SIZE)) != -1) {
                out.write(buffer, 0, n);
                count += n;
            }
            out.flush();
        } finally {
            try {
                out.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
            try {
                in.close();
            } catch (IOException e) {
                Log.e(e.getMessage(), String.valueOf(e));
            }
        }
        return count;
    }

    public static Bitmap handleSamplingAndRotationBitmap(Context context, Uri selectedImage)
            throws IOException {
        int MAX_HEIGHT = 1024;
        int MAX_WIDTH = 1024;

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        InputStream imageStream = context.getContentResolver().openInputStream(selectedImage);
        BitmapFactory.decodeStream(imageStream, null, options);
        imageStream.close();

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, MAX_WIDTH, MAX_HEIGHT);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        imageStream = context.getContentResolver().openInputStream(selectedImage);
        Bitmap img = BitmapFactory.decodeStream(imageStream, null, options);

        img = rotateImageIfRequired(context, img, selectedImage);
        return img;
    }

    private static int calculateInSampleSize(BitmapFactory.Options options,
                                             int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            // Calculate ratios of height and width to requested height and width
            final int heightRatio = Math.round((float) height / (float) reqHeight);
            final int widthRatio = Math.round((float) width / (float) reqWidth);

            // Choose the smallest ratio as inSampleSize value, this will guarantee a final image
            // with both dimensions larger than or equal to the requested height and width.
            inSampleSize = heightRatio < widthRatio ? heightRatio : widthRatio;

            // This offers some additional logic in case the image has a strange
            // aspect ratio. For example, a panorama may have a much larger
            // width than height. In these cases the total pixels might still
            // end up being too large to fit comfortably in memory, so we should
            // be more aggressive with sample down the image (=larger inSampleSize).

            final float totalPixels = width * height;

            // Anything more than 2x the requested pixels we'll sample down further
            final float totalReqPixelsCap = reqWidth * reqHeight * 2;

            while (totalPixels / (inSampleSize * inSampleSize) > totalReqPixelsCap) {
                inSampleSize++;
            }
        }
        return inSampleSize;
    }

    private static Bitmap rotateImageIfRequired(Context context, Bitmap img, Uri selectedImage) throws IOException {

        InputStream input = context.getContentResolver().openInputStream(selectedImage);
        ExifInterface ei = null;
        if (Build.VERSION.SDK_INT > 23) {
            ei = new ExifInterface(input);
        }


        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                return rotateImage(img, 90);
            case ExifInterface.ORIENTATION_ROTATE_180:
                return rotateImage(img, 180);
            case ExifInterface.ORIENTATION_ROTATE_270:
                return rotateImage(img, 270);
            default:
                return img;
        }


    }

    private static Bitmap rotateImage(Bitmap img, int degree) {
        Matrix matrix = new Matrix();
        matrix.postRotate(degree);
        Bitmap rotatedImg = Bitmap.createBitmap(img, 0, 0, img.getWidth(), img.getHeight(), matrix, true);
        img.recycle();
        return rotatedImg;
    }
    public byte[] convertBitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 60, buffer);
        return buffer.toByteArray();
    }

    private void askForPermissioncamera(String permission, Integer requestCode) {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), permission) != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(IncorpoPartnershipUploadFormAcvitity.this, permission)) {

                //This is called if user has denied the permission before
                //In this case I am just asking the permission again
                ActivityCompat.requestPermissions(IncorpoPartnershipUploadFormAcvitity.this, new String[]{permission}, requestCode);

            } else {

                ActivityCompat.requestPermissions(IncorpoPartnershipUploadFormAcvitity.this, new String[]{permission}, requestCode);
            }
        } else {
//            Toast.makeText(this, "" + permission + " is already granted.", Toast.LENGTH_SHORT).show();
        }


    }
    private void requestStoragePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED)
            return;

        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            //If the user has denied the permission previously your code will come to this block
            //Here you can explain why you need this permission
            //Explain here why you need this permission
        }
        //And finally ask for the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        //Checking the request code of our request
        if (requestCode == STORAGE_PERMISSION_CODE) {

            //If permission is granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Displaying a toast
                Toast.makeText(this, "Permission granted now you can read the storage", Toast.LENGTH_LONG).show();
            } else {
                //Displaying another toast if permission is not granted
                Toast.makeText(this, "Oops you just denied the permission", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void  requestMultiplePermissions(){
        Dexter.withActivity(this)
                .withPermissions(

                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                            Toast.makeText(getApplicationContext(), "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings

                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(getApplicationContext(), "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }
}
