package com.avaskm.gstseva.ourservices;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.My_Profile;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SuppressLint("Registered")
public class AuditActivity extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener{

    TextView tv_price_audit;
    String price ="";
    String userId,title;
    SharedPreferences sharedPreferences;
    Spinner spinner_audit;
    String audit="";
    String[] typeAudit = {"Select your Constitution","Proprietor/shopkeeper/individual","Partnership/LLP"
            ,"Private limited Company","Public Limited Company","HUF","NRI","Trust","Society","NGO"};
    EditText edt_name_audit,edt_turnOver_audit,edt_mobile_audit,edt_email_audit;
    Button btn_submit_audit;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audit);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        tv_price_audit = findViewById(R.id.tv_price_audit);
        edt_name_audit = findViewById(R.id.edt_name_audit);
        edt_turnOver_audit = findViewById(R.id.edt_turnOver_audit);
        edt_mobile_audit = findViewById(R.id.edt_mobile_audit);
        edt_email_audit = findViewById(R.id.edt_email_audit);
        btn_submit_audit = findViewById(R.id.btn_submit_audit);



        spinner_audit = findViewById(R.id.spinner_audit);
        spinner_audit.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,typeAudit);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner_audit.setAdapter(aa);
        hitAPiPrice();

        btn_submit_audit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(edt_name_audit.getText().toString().equals("")){
                   edt_name_audit.setError("Please enter the name");
                   edt_name_audit.requestFocus();
               }
               else if(edt_turnOver_audit.getText().toString().equals("")){
                   edt_turnOver_audit.setError("Please enter the audit");
                   edt_turnOver_audit.requestFocus();
               }
               else if(edt_mobile_audit.getText().toString().equals("")){
                   edt_mobile_audit.setError("Please enter the Mobile");
                   edt_mobile_audit.requestFocus();
               }
               else if(edt_mobile_audit.getText().toString().length()!=10){
                   edt_mobile_audit.setError("Mobile No. should be 10 digit");
                   edt_mobile_audit.requestFocus();
               }
               else if(edt_email_audit.getText().toString().equals("")){
                   edt_email_audit.setError("Please enter the Email");
                   edt_email_audit.requestFocus();
               }
               else if (!(edt_email_audit.getText().toString().matches(emailPattern) && edt_email_audit.getText().toString().length() > 0)) {
                   edt_email_audit.setError("Please enter the valid Email");
                   edt_email_audit.requestFocus();
               }
               else if(audit.equalsIgnoreCase("Select your Constitution")) {
                   Toast.makeText(AuditActivity.this, "Please Select Constitution Type", Toast.LENGTH_SHORT).show();
                   //  startActivity(new Intent(getApplicationContext(),PancardActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
               }
               else{
                   hitRegisterApi();
               }
            }
        });
    }


    private void hitRegisterApi() {
        {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
            final ProgressDialog dialog = ProgressDialog.show(AuditActivity.this, "", "Wait....", false);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("responsePaymftn",response);
                    dialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject dataObject=jsonObject.getJSONObject("data");
                        String orderId = dataObject.getString("orderid");

                            Intent intent = new Intent(AuditActivity.this, NavigationActivity.class);
                            intent.putExtra("order", orderId); // getText() SHOULD NOT be static!!!
                            startActivity(intent);
                            Toast.makeText(AuditActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();



                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("userid",userId);
                    params.put("category",title);
                    params.put("price",price);
                    params.put("sel_constitution",audit);
                    params.put("name",edt_name_audit.getText().toString());
                    params.put("mobile",edt_mobile_audit.getText().toString());
                    params.put("email",edt_email_audit.getText().toString());
                    params.put("turnover",edt_turnOver_audit.getText().toString());

                    Log.d("msggsaqw",params.toString());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }
    }

    private  void hitAPiPrice(){
        final ProgressDialog progressDialog=ProgressDialog.show(AuditActivity.this,"","wait...",false);
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                progressDialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONObject dataObject=jsonObject.getJSONObject("data");
                    price =dataObject.getString("price");
                    tv_price_audit.setText(price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                hashMap.put("category",title);
                hashMap.put("userid",userId);
                return hashMap;
            }
        };
        requestQueue.add(request);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getId()==R.id.spinner_audit){

             audit =typeAudit[position];
            ((TextView)parent.getChildAt(0)).setTextColor(Color.WHITE);
            Log.d("asdads",audit);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
