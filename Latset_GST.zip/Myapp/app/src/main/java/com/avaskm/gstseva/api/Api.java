package com.avaskm.gstseva.api;

public class Api {
    public static  final String key = "5642vcb546g2334hh555b7r6ewc211vhh34";
    public static  final String BASE_URL = "http://lawseva.com/gstapi/index.php/";
    public static  final String register_Url =BASE_URL+"registers";
    public static  final String gethomecategory =BASE_URL+"gethomecategory";
    public static  final String SENDOTP = "http://www.smsalert.co.in/api/push.json?/";
//    public static String getgst_price_faq= BASE_URL+"getgst_price_faq";
    public static String gstrequest= BASE_URL+"gstrequest";
    public static String statelist= BASE_URL+"getstate_list";
    public static String properiater= BASE_URL+"upload_doc";
    public static String PartnershipUpdate= BASE_URL+"update_order";
    public static String GetCategoryInfor= BASE_URL+"getcategory_info";
    public static String MakeOrder= BASE_URL+"make_order";
    public static String SendFeedback= BASE_URL+"send_feedback";
    public static String BecomePartner= BASE_URL+"become_partner";
    public static String MakePayment= BASE_URL+"make_payment";
    public static String GetPendingOrder= BASE_URL+"get_pendingorder";
    public static String GetCompleteOrder= BASE_URL+"get_completeorder";
    public static String GetDocument= BASE_URL+"get_document";






    public static final String ForgotPassword = "http://mobileapp.mobileappdevelop.xyz/mobileapp/index.php/forgetpassword";
}
/*
gst.androidappnow.xyz

        "http://gst.androidappnow.xyz/gstapi/index.php/gstrequest";*/
/*
http://gst.androidappnow.xyz/gstapi/index.php/gstrequest*/

/*http://jinnimall.androidappnow.xyz/admin/index.php?component=json&action=home_page*/

