package com.avaskm.gstseva.activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.ourservices.GSTfillingActivity;
import com.avaskm.gstseva.ourservices.ITRfillingActivity;
import com.avaskm.gstseva.ourservices.Incorpo_partnership;
import com.avaskm.gstseva.ourservices.NewFoodlicenseActivity;
import com.avaskm.gstseva.ourservices.SecImportExportActivity;
import com.avaskm.gstseva.ourservices.SecIncorporationofllp;
import com.avaskm.gstseva.ourservices.SecIncorporationpvtActivity;
import com.avaskm.gstseva.ourservices.SecInproprietorshipActivity;
import com.avaskm.gstseva.ourservices.SecInsuranceActivity;
import com.avaskm.gstseva.ourservices.SecLabourlincenseActivity;
import com.avaskm.gstseva.ourservices.SecPancardActivity;
import com.avaskm.gstseva.ourservices.SecRegisterfillActivity;
import com.avaskm.gstseva.ourservices.SecdigitalsingnatureActivity;
import com.avaskm.gstseva.ourservices.SecjwebsiteActivity;
import com.avaskm.gstseva.ourservices.TancardActivity;
import com.avaskm.gstseva.ourservices.UdyogaadhaarActivity;

public class ThankspaymentActivity extends AppCompatActivity {
Button uploadsdocument;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thankspayment);
        uploadsdocument=findViewById(R.id.uploadsdocument);
        uploadsdocument.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sp1 = getSharedPreferences("checkform", ThankspaymentActivity.MODE_PRIVATE);
                String  check = sp1.getString("checkform", "");
                Log.d("check======",check);
                if(check.equals("import"))
                {

                    Intent intent=new Intent(ThankspaymentActivity.this, SecImportExportActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("labour")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecLabourlincenseActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("incorpo")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecIncorporationpvtActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("Itrfill")){

                    Intent intent=new Intent(ThankspaymentActivity.this, ITRfillingActivity.class);
                    startActivity(intent);
                  //  finish();
                }
                if (check.equals("udog")){

                    Intent intent=new Intent(ThankspaymentActivity.this, UdyogaadhaarActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("registra")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecRegisterfillActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("pancard")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecPancardActivity.class);
                    startActivity(intent);
                  //  finish();
                }
                if (check.equals("tancard")){

                    Intent intent=new Intent(ThankspaymentActivity.this, TancardActivity.class);
                    startActivity(intent);
                  //  finish();
                }
                if (check.equals("incorpopro")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecInproprietorshipActivity.class);
                    startActivity(intent);
                    //finish();
                }
                if (check.equals("digital")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecdigitalsingnatureActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("insurance")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecInsuranceActivity.class);
                    startActivity(intent);
                    //finish();
                }
                if (check.equals("incorpart")){

                    Intent intent=new Intent(ThankspaymentActivity.this, Incorpo_partnership.class);
                    startActivity(intent);
                    //finish();
                }
                if (check.equals("incorfllp")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecIncorporationofllp.class);
                    startActivity(intent);
                    //finish();
                }
                if (check.equals("website")){

                    Intent intent=new Intent(ThankspaymentActivity.this, SecjwebsiteActivity.class);
                    startActivity(intent);
                    //finish();
                }
                if (check.equals("newgstfill")){

                    Intent intent=new Intent(ThankspaymentActivity.this, GSTfillingActivity.class);
                    startActivity(intent);
                   // finish();
                }
                if (check.equals("Foodlicense")){
                    Intent intent=new Intent(ThankspaymentActivity.this, NewFoodlicenseActivity.class);
                    startActivity(intent);
                    //finish();
                }
                SharedPreferences sp = getSharedPreferences("checkforuploadform", ThankspaymentActivity.MODE_PRIVATE);
                int position = sp.getInt("position", -1);
                Log.d("position", String.valueOf(position));
               // finish();
                if (position==1){
                    Intent intent=new Intent(ThankspaymentActivity.this,ProprietorActivity.class);
                    startActivity(intent);
                   // finish();
                }else if (position==2){
                    Intent intent=new Intent(ThankspaymentActivity.this, PartnershipLLpactivity.class);
                    startActivity(intent);
                    //finish();
                }else if (position==3){
                    Intent intent=new Intent(ThankspaymentActivity.this, PrivateLimitedActivity.class);
                    startActivity(intent);
                   // finish();
                }else if (position==4){
                    Intent intent=new Intent(ThankspaymentActivity.this, PubliclimitedActivity.class);
                    startActivity(intent);
                  //  finish();
                }else if (position==5){
                    Intent intent=new Intent(ThankspaymentActivity.this, HufActivity.class);
                    startActivity(intent);
                   // finish();
                }else if (position==6){
                    Intent intent=new Intent(ThankspaymentActivity.this, NRIActivity.class);
                    startActivity(intent);
                    //finish();
                }else if (position==7){
                    Intent intent=new Intent(ThankspaymentActivity.this, TrustActivity.class);
                    startActivity(intent);
                   // finish();
                }else if (position==8){
                    Intent intent=new Intent(ThankspaymentActivity.this, SocietyActivity.class);
                    startActivity(intent);
                    //finish();
                }else if (position==9){
                    Intent intent=new Intent(ThankspaymentActivity.this, NGOActivity.class);
                    startActivity(intent);
                   // finish();
                }

            }
        });
    }
}
