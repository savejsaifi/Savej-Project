package com.avaskm.gstseva;

import android.content.Intent;
import android.os.Bundle;

import com.avaskm.gstseva.activity.RegistrationFragment;
import com.daimajia.androidanimations.library.Techniques;
import com.viksaa.sssplash.lib.activity.AwesomeSplash;
import com.viksaa.sssplash.lib.cnst.Flags;
import com.viksaa.sssplash.lib.model.ConfigSplash;

public class SplashScreen extends AwesomeSplash {
    int ll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UtilsClass.fullScreenActivity(SplashScreen.this, ll);
    }

    @Override
    public void initSplash(ConfigSplash configSplash) {

        configSplash.setBackgroundColor(R.color.colorPrimary);
        configSplash.setAnimCircularRevealDuration(2000);
        configSplash.setRevealFlagX(Flags.REVEAL_RIGHT);
        configSplash.setRevealFlagY(Flags.REVEAL_BOTTOM);
        configSplash.setLogoSplash(R.drawable.gstlincence);
        configSplash.setAnimLogoSplashDuration(2000);
        configSplash.setOriginalHeight(400);
        configSplash.setOriginalWidth(400);
        configSplash.setAnimPathStrokeDrawingDuration(3000);
        configSplash.setPathSplashStrokeSize(3);
        configSplash.setPathSplashStrokeColor(R.color.back2);
        configSplash.setAnimPathFillingDuration(3000);
        configSplash.setPathSplashFillColor(R.color.back2);
        configSplash.setTitleSplash("GST " +
                "SEVA");
        configSplash.setTitleTextColor(R.color.back2);
        configSplash.setTitleTextSize(50f);
        configSplash.setAnimTitleDuration(3000);
        configSplash.setAnimTitleTechnique(Techniques.FlipInX);
        configSplash.setTitleFont("fonts/bold.ttf");


    }

    @Override
    public void animationsFinished() {
        startActivity(new Intent(getApplicationContext(), RegistrationFragment.class));

    }//codemain
   /* ImageView image_spalsh;
    RuntimePermissionHelper runtimePermissionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT < 16) {
            // Hide the Action Bar on Android 4.0 and Lower
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        } else {
            // Hide the Action Bar on Android 4.1 and Higher
            View decorView = getWindow().getDecorView();
            int uiOptions = View.SYSTEM_UI_FLAG_FULLSCREEN;
            decorView.setSystemUiVisibility(uiOptions);
            try {
                getSupportActionBar().hide();
            } catch (Exception e) {

            }
        }
        setContentView(R.layout.activity_splash_screen);
        if (Build.VERSION.SDK_INT >= 23) {
            runtimePermissionHelper = RuntimePermissionHelper.getInstance(this);
            if (runtimePermissionHelper.isAllPermissionAvailable()) {
// All permissions available. Go with the flow

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        finish();

                    }
                }, 5000);
            } else {
// Few permissions not granted. Ask for ungranted permissions
                runtimePermissionHelper.setActivity(this);
                runtimePermissionHelper.requestPermissionsIfDenied();
            }
        }else{
// SDK below API 23. Do nothing just go with the flow.
        }

    }

    private void fadeOutAndHideImage(final ImageView img) {
        Animation fadeOut = new AlphaAnimation(0, 1);
        fadeOut.setInterpolator(new AccelerateInterpolator());
        fadeOut.setDuration(1000);

        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            public void onAnimationEnd(Animation animation) {
//                img.setVisibility(View.GONE);
            }

            public void onAnimationRepeat(Animation animation) {
            }

            public void onAnimationStart(Animation animation) {
            }
        });

        img.startAnimation(fadeOut);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        for(int i : grantResults){
            if( i == PackageManager.PERMISSION_GRANTED){

                image_spalsh = findViewById(R.id.image_spalsh);
                final Animation anim_out = AnimationUtils.loadAnimation(this, R.anim.fade_out_animation);
                image_spalsh.setAnimation(anim_out);
                // fadeOutAndHideImage(image_spalsh);


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                        finish();

                    }
                }, 5000);
//                handleButtonClick(view);
            }else{
                runtimePermissionHelper.requestPermissionsIfDenied(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            }
        }
    }*///codemain
}