package com.avaskm.gstseva.payment;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.avaskm.gstseva.R;

public class PaymentModeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_mode);

    }
}
