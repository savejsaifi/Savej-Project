package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.NoOfYearModel;
import com.avaskm.gstseva.model.StateSpinnerModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class LabourlincenseActivity extends AppCompatActivity {


    Spinner SpnConstitution, SpnState, SpnAnyOther, SpnStateSecond, SpnSelectEmployee;
    LinearLayout LinearYesNo;

    EditText EtNameOfFirmShop, EtAddress, EtDistrict, EtPincode, EtLandmark, ErAddressSecond, EtDistrictSecond, EtPincodeSecond;
    EditText EtLandmarkSecond, EtEmail, EtMobile, EtManagerName, EtManagerAddress, EtManagerMobileNo;

    //ArrayList<NewGstFillingModel> arListValue;
    TextView TvPrice;
    //ArrayList<String> arListNewGstFill;
    String[] constitutions = {"Select constitution", "Proprietor/ shopkeeper", "Partnership", "Private limited company", "Huf"};
    String[] AnyOtherBusiness = {"Any other business address in same state", "No", "Yes"};
    String constitut, state, anyOther, stateSecond, EmployeeName, price, orderid, title;

    ArrayList<StateSpinnerModel> listState1_model = new ArrayList<>();
    ArrayList<String> listState1 = new ArrayList<>();

    ArrayList<StateSpinnerModel> listState1_mode2 = new ArrayList<>();
    ArrayList<String> listState2 = new ArrayList<>();

    ArrayList<NoOfYearModel> arListNoOfEmployeeMOdel = new ArrayList<>();
    ArrayList<String> arListEmployee = new ArrayList<>();
    SharedPreferences sharedPreferences;
    String userId;
    Button BtnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_labourlincense);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        Log.d("fsdjk",userId);
        EtNameOfFirmShop = (EditText) findViewById(R.id.et_name_lab);
        EtAddress = (EditText) findViewById(R.id.et_address_lab);
        EtDistrict = (EditText) findViewById(R.id.et_district_lab);
        EtPincode = (EditText) findViewById(R.id.et_pin_code_lab);
        EtLandmark = (EditText) findViewById(R.id.et_landmark_lab);
        EtManagerAddress = (EditText) findViewById(R.id.et_address_food_second_spn_lab);
        EtDistrictSecond = (EditText) findViewById(R.id.et_district_food_second_spn_lab);
        EtPincodeSecond = (EditText) findViewById(R.id.et_pin_code_food_second_spn_lab);
        EtLandmarkSecond = (EditText) findViewById(R.id.et_landmark_food_second_spn_lab);
        EtMobile = (EditText) findViewById(R.id.et_mobile_lab);
        EtEmail = (EditText) findViewById(R.id.et_email_lab);
        EtManagerName = (EditText) findViewById(R.id.et_manager_name_lab);
        EtManagerAddress = (EditText) findViewById(R.id.et_manager_addresss_lab);
        EtManagerMobileNo = (EditText) findViewById(R.id.et_manager_mobile_lab);


        SpnConstitution = (Spinner) findViewById(R.id.spn_constitution_lab);
        SpnState = (Spinner) findViewById(R.id.spn_state_lab);
        SpnAnyOther = (Spinner) findViewById(R.id.spn_any_other_business_lab);
        SpnStateSecond = (Spinner) findViewById(R.id.spn_state_food_second_spn_lab);
        LinearYesNo = (LinearLayout) findViewById(R.id.linear_yes_no_lab);
        SpnSelectEmployee = (Spinner) findViewById(R.id.spn_select_employee_lab);
        TvPrice = (TextView) findViewById(R.id.tv_price_lab);
        /*arListNewGstFill = new ArrayList<>();
        arListValue = new ArrayList<>();*/

        BtnSubmit = (Button) findViewById(R.id.btn_submit_lab);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");


        SpnConstitution.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                constitut = String.valueOf(SpnConstitution.getItemAtPosition(i));
                Log.d("repeatSpin", constitut);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnState.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                state = String.valueOf(SpnState.getItemAtPosition(i));
                Log.d("state", state);
              /* String stateName1 = listState1_model.get(i).getStateName();
                Log.d("stateName1", stateName1);*/
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnAnyOther.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                anyOther = String.valueOf(SpnAnyOther.getItemAtPosition(i));
                Log.d("anyOther", anyOther);


                if (anyOther.equalsIgnoreCase("Yes")) {
                    LinearYesNo.setVisibility(View.VISIBLE);
                } else if (anyOther.equalsIgnoreCase("No")) {
                    LinearYesNo.setVisibility(View.GONE);
                }

                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnStateSecond.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                stateSecond = String.valueOf(SpnStateSecond.getItemAtPosition(i));
                Log.d("stateSecond", stateSecond);
              /* String stateName1 = listState1_model.get(i).getStateName();
                Log.d("stateName1", stateName1);*/
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnSelectEmployee.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                EmployeeName = String.valueOf(SpnSelectEmployee.getItemAtPosition(position));
                price = arListNoOfEmployeeMOdel.get(position).getPrice();
                Log.d("EmployeeName", EmployeeName);
                TvPrice.setText(price);

                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        ArrayAdapter<String> contitutoinAdapter = new ArrayAdapter<String>(LabourlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, constitutions);
        SpnConstitution.setAdapter(contitutoinAdapter);
        ArrayAdapter<String> anyOtherBusiness = new ArrayAdapter<String>(LabourlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, AnyOtherBusiness);
        SpnAnyOther.setAdapter(anyOtherBusiness);


        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setSubmit()) {

                }
                //MakeOrderAPI();
           /*     Intent intent = new Intent(LabourlincenseActivity.this, LabourLicenseFormUploadActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);*/
            }
        });


        hitstateSpinnerApi();
        hitstateSpinnerSecondApi();
        NoOfEmployeeSpinnerApi();

    }


    private boolean setName() {
        if (EtNameOfFirmShop.getText().toString().length() > 0) {
            return true;
        } else {
            EtNameOfFirmShop.setError("Please enter name of firm/shop");
            return false;
        }
    }

    private boolean setConstitution() {
        if (!constitut.equalsIgnoreCase("Select constitution")) {
            return true;
        } else {
            Toast.makeText(LabourlincenseActivity.this, "Please seclect constitution", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setAddress() {
        if (EtAddress.getText().toString().length() > 0) {
            return true;
        } else {
            EtAddress.setError("Please enter address");
            return false;
        }
    }

    private boolean setDistrict() {
        if (EtDistrict.getText().toString().length() > 0) {
            return true;
        } else {
            EtDistrict.setError("Please enter district");
            return false;
        }
    }

    private boolean setState() {
        if (!state.equalsIgnoreCase("Select state")) {
            return true;
        } else {
            Toast.makeText(LabourlincenseActivity.this, "Please select state", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setPincode() {
        if (EtPincode.getText().toString().length() > 0) {
            return true;
        } else {
            EtPincode.setError("Pleae enter pincode");
            return false;
        }
    }

    private boolean setLandmark() {
        if (EtLandmark.getText().toString().length() > 0) {
            return true;
        } else {
            EtLandmark.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setDistrictSecond() {
        if (EtDistrictSecond.getText().toString().length() > 0) {
            return true;

        } else {
            EtDistrictSecond.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setStateSecond() {
        if (!stateSecond.equalsIgnoreCase("Select state")) {
            return true;
        } else {
            Toast.makeText(LabourlincenseActivity.this, "Please Select state", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setPincodeSecond() {
        if (EtPincodeSecond.getText().toString().length() > 0) {
            return true;

        } else {
            EtPincodeSecond.setError("Please enter pincode");
            return false;
        }
    }

    private boolean setLandmarkSecond() {
        if (EtLandmarkSecond.getText().toString().length() > 0) {
            return true;
        } else {
            EtLandmarkSecond.setError("Please enter landmark");
            return false;
        }
    }

    private boolean setAnyOther() {
        if (!anyOther.equalsIgnoreCase("Any other business address in same state")) {
            return true;
        } else {
            Toast.makeText(LabourlincenseActivity.this, "Please select any other business", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setMobile() {
        if (EtMobile.getText().toString().length() > 0) {
            return true;
        } else {
            EtMobile.setError("Please enter 10 digit no");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtEmail.setError("Please enter email");
            return false;
        }
    }

    private boolean setNoOfEmployee() {
        if (!EmployeeName.equalsIgnoreCase("Select no of employees")) {
            return true;
        } else {
            Toast.makeText(LabourlincenseActivity.this, "Please Select no of employee", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setManagerName() {
        if (EtManagerName.getText().toString().length() > 0) {
            return true;

        } else {
            EtManagerName.setError("PLease enter manager name");
            return false;
        }
    }


    private boolean setManagerAddress() {
        if (EtManagerAddress.getText().toString().length() > 0) {
            return true;

        } else {
            EtManagerAddress.setError("Please enter manager address");
            return false;
        }
    }

    private boolean setManagerMobile() {
        if (EtManagerMobileNo.getText().toString().length() > 0) {
            return true;
        } else {
            EtManagerMobileNo.setError("Please enter manager mobile no");
            return false;
        }

    }

    private boolean setSubmit() {
        if (!setName()) {
            return false;
        } else if (!setConstitution()) {
            return false;
        } else if (!setAddress()) {
            return false;
        } else if (!setDistrict()) {
            return false;
        } else if (!setState()) {
            return false;
        } else if (!setPincode()) {
            return false;
        } else if (!setLandmark()) {
            return false;
        } /*else if (!setDistrictSecond()) {
            return false;

        } else if (!setStateSecond()) {
            return false;
        } else if (!setPincodeSecond()) {
            return false;
        } else if (!setLandmarkSecond()) {
            return false;
        }*/ else if (!setAnyOther()) {
            return false;
        } else if (!setMobile()) {
            return false;
        } else if (!setEmail()) {
            return false;
        } else if (!setNoOfEmployee()) {
            return false;
        } else if (!setManagerName()) {
            return false;

        } else if (!setManagerAddress()) {
            return false;

        } else if (!setManagerMobile())
            return false;

        MakeOrderAPI();
        return true;
    }


    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(LabourlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responseState", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    listState1.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState1_model.add(model);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_model.add(model);
                        listState1.add(jsonObject1.getString("state_name"));
                    }


                    ArrayAdapter aa = new ArrayAdapter(LabourlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, listState1);
                    SpnState.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LabourlincenseActivity.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void hitstateSpinnerSecondApi() {
        RequestQueue queue = Volley.newRequestQueue(LabourlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responseState", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    listState2.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState1_mode2.add(model);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_mode2.add(model);
                        listState2.add(jsonObject1.getString("state_name"));
                    }


                    ArrayAdapter aa = new ArrayAdapter(LabourlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, listState2);
                    SpnStateSecond.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LabourlincenseActivity.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                return hashMap;
            }
        };
        queue.add(request);

    }


    private void NoOfEmployeeSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(LabourlincenseActivity.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responYear", response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    JSONArray priceArray = dataObject.getJSONArray("prices");

                    arListEmployee.add("Select no of employees");
                    NoOfYearModel model = new NoOfYearModel();
                    model.setYear("Select no of employees");
                    model.setPrice("");
                    arListNoOfEmployeeMOdel.add(model);

                    for (int i = 0; i < priceArray.length(); i++) {
                        model = new NoOfYearModel();
                        JSONObject priceObject = priceArray.getJSONObject(i);
                        model.setPrice(priceObject.getString("value"));
                        model.setYear(priceObject.getString("key"));
                        String key = priceObject.getString("key");
                        Log.d("keyy", key);
                        arListNoOfEmployeeMOdel.add(model);
                        arListEmployee.add(priceObject.getString("key"));
                    }
                    ArrayAdapter noOfYearAdapter = new ArrayAdapter(LabourlincenseActivity.this, android.R.layout.simple_spinner_dropdown_item, arListEmployee);
                    SpnSelectEmployee.setAdapter(noOfYearAdapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(LabourlincenseActivity.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("category", title);


                return hashMap;
            }
        };
        queue.add(request);


    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(LabourlincenseActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("LabourResponse", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("orderid", orderid);
                    if (code.equalsIgnoreCase("200")) {

                        Toast.makeText(LabourlincenseActivity.this, "Information Saved Successfully", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(LabourlincenseActivity.this, LabourLicenseFormUploadActivity.class);
                        intent.putExtra("orderid", orderid);
                        intent.putExtra("constitut", constitut);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(LabourlincenseActivity.this, msg, Toast.LENGTH_SHORT).show();


                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category", title);
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("firm_name", EtNameOfFirmShop.getText().toString());
                params.put("district", EtDistrict.getText().toString());
                params.put("state", state);
                params.put("pincode", EtPincode.getText().toString());
                params.put("constitution", constitut);
                params.put("landmark", EtLandmark.getText().toString());
                params.put("other_business", anyOther);
                if (anyOther.equalsIgnoreCase("Yes")) {

                    params.put("other_state", stateSecond);
                    params.put("other_disctrict", EtDistrictSecond.getText().toString());
                    params.put("other_pincode", EtPincodeSecond.getText().toString());
                    params.put("other_landmark", EtLandmarkSecond.getText().toString());
                } else if (anyOther.equalsIgnoreCase("No")) {
                    params.put("other_state", "");
                    params.put("other_disctrict", "");
                    params.put("other_pincode", "");
                    params.put("other_landmark", "");
                }
                params.put("address", EtAddress.getText().toString());
                params.put("price", price);
                params.put("num_employee", EmployeeName);
                params.put("manager_name", EtManagerName.getText().toString());
                params.put("manager_mobile", EtManagerMobileNo.getText().toString());
                params.put("manager_address", EtManagerAddress.getText().toString());


                Log.d("allItr", String.valueOf(params));


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(LabourlincenseActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }
}

