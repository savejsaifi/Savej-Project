package com.avaskm.gstseva.ourservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Spinner;

import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class SecPancardActivity extends AppCompatActivity {
    Spinner spinner,spinner1;
    Button newbuttonpan,btn_pansecren,btn_panelectricity,btnpan_rent,secbtn_electricity,sec_btnphotographh,btn_pancardaddhar,btn_pancardphato,btn_sign,btn_Uploadspecimensig;
    ImageView secphotograph,pancardphotograph,Uploadspecimen,singnaturepancard,secpancardrentAgreeme,secaddharcardpan,secrentpanAgreement,secepancardlect,secpancardaddar;
    LinearLayout newpanpancard,secondlinearpancard;
    int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_pancard);
        pancardphotograph=findViewById(R.id.pancardphotograph);
        secpancardaddar=findViewById(R.id.secpancardaddar);
        Uploadspecimen=findViewById(R.id.Uploadspecimen);
        secaddharcardpan=findViewById(R.id.secaddharcardpan);
        btn_Uploadspecimensig=findViewById(R.id.Uploadspecimensig);
        secphotograph=findViewById(R.id.secphotograph);
        sec_btnphotographh=findViewById(R.id.secphotographh);
        secepancardlect=findViewById(R.id.secepancardlect);
        secrentpanAgreement=findViewById(R.id.secrentpanAgreement);
        btn_pancardaddhar=findViewById(R.id.btn_secpancardaddhar);
        btn_sign=findViewById(R.id.btn_sign);
        btn_pancardphato=findViewById(R.id.btn_pancardphato);
        secpancardrentAgreeme=findViewById(R.id.secpancardrentAgreeme);
        singnaturepancard=findViewById(R.id.singnaturepancard);
        secbtn_electricity=findViewById(R.id.secbtn_electricity);
        btnpan_rent=findViewById(R.id.btnpan_rent);
        btn_pansecren=findViewById(R.id.btn_pansecren);
        btn_panelectricity=findViewById(R.id.btnpanelectricity);
        newpanpancard=findViewById(R.id.linearpancardd);
        secondlinearpancard=findViewById(R.id.secondlinearpancard);
        newbuttonpan=findViewById(R.id.secbuttonpancard);
        newbuttonpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SecPancardActivity.this, PaymentActivity.class);
                startActivity(intent);

            }
        });

        addItemsOnSpinner();
        addItemsOnSpinner1();
        btn_pansecren.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=1;
                abc(v);

            }
        });
        btn_panelectricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=2;
                abc(v);
            }
        });
        btnpan_rent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=3;
                abc(v);
            }
        });
        secbtn_electricity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=4;
                abc(v);
            }
        });
        sec_btnphotographh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=5;
                abc(v);
            }
        });
        btn_pancardaddhar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=6;
                abc(v);
            }
        });
        btn_pancardphato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=7;
                abc(v);
            }
        });

        btn_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count=8;
                abc(v);
            }
        });


    }

    private void abc(View v){
        PopupMenu popupMenu = new PopupMenu(SecPancardActivity.this,v);
        popupMenu.getMenuInflater().inflate(R.menu.menu_image, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {

//                    case R.id.Camera:
//                        try {
//                            Intent intent = new Intent();
//                            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
//                            startActivityForResult(intent, 1);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        break;
                    case R.id.Gallery:

                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_PICK);
                        startActivityForResult(intent, 0);
                        break;
                }
                return false;
            }
        });
        popupMenu.show();

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == 0 && count == 1) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secpancardrentAgreeme);
            } else if (requestCode == 1 && count == 1) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secpancardrentAgreeme.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 2) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secaddharcardpan);


            } else if (requestCode == 1 && count == 2) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secaddharcardpan.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 3) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secrentpanAgreement);


            } else if (requestCode == 1 && count == 3) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secrentpanAgreement.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 4) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secepancardlect);


            } else if (requestCode == 1 && count == 4) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secepancardlect.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 5) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secphotograph);


            } else if (requestCode == 1 && count == 5) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secphotograph.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 6) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(secpancardaddar);


            } else if (requestCode == 1 && count == 6) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                secpancardaddar.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 7) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(pancardphotograph);


            } else if (requestCode == 1 && count == 7) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                pancardphotograph.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 8) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(singnaturepancard);


            } else if (requestCode == 1 && count == 8) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                singnaturepancard.setImageBitmap(bitmap);
            }



        } catch (Exception e) {

        }

    }

    public void addItemsOnSpinner1() {

        spinner1 = (Spinner) findViewById(R.id.newspinertwo);
        List<String> list = new ArrayList<String>();
        list.add("select individual firm/company/HUF");
        list.add("Dob / DOI (date of incorporation in case of non-individual)");
        list.add("Father name");
        list.add("Mobile no");
        list.add("Email id");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner1.setOnItemSelectedListener(new SecPancardActivity.CustomOnItemSelectedListener());
        spinner1.setAdapter(dataAdapter);
    }
    public void addItemsOnSpinner() {

        spinner = (Spinner) findViewById(R.id.newpanpancard);
        List<String> list = new ArrayList<String>();
        list.add("new pan card");
        list.add("correction in old pan card");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setOnItemSelectedListener(new SecPancardActivity.CustomOnItemSelectedListener());
        spinner.setAdapter(dataAdapter);
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener{

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (parent.getId() == R.id.newpanpancard) {
                if (position == 0) {
                    newpanpancard.setVisibility(View.VISIBLE);
                } else {
                    newpanpancard.setVisibility(View.GONE);
                }
                if(position==1){
                    secondlinearpancard.setVisibility(View.VISIBLE);
                }
                else{
                    secondlinearpancard.setVisibility(View.GONE);
                }

            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
}
