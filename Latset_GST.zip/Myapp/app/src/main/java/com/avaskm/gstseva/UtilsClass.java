package com.avaskm.gstseva;

import android.os.Build;
import android.view.View;

public class UtilsClass {
   public static final String LOGIN_FRAGMENT = "LOGIN FRAGMENT";
    public static final String REGISTER_FRAGMENT = "REGISTER FRAGMENT";


   /* public static void replaceFragmentFromActivity(FragmentManager fragmentManager, Fragment fragment, String Tag) {
        fragmentManager
                .beginTransaction()
                .setCustomAnimations(R.anim.right_exit, R.anim.left_enter)
                .replace(R.id.frame_container,fragment, Tag).commit();
    }
    public static void repleceFragmentFromFragment(Fragment fragment, FragmentManager fragmentManager,String TAG) {
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frame_container, fragment);
        transaction.addToBackStack(TAG);
        transaction.setCustomAnimations(android.R.animator.fade_in,android.R.animator.fade_out);
        transaction.commit();
    }*/
    public static void fullScreenActivity(SplashScreen context, int currentApiVersion) {

        // int currentVersion; only define kar dena
        // use in oncreate method

        currentApiVersion = Build.VERSION.SDK_INT;
        final int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        if (currentApiVersion >= Build.VERSION_CODES.KITKAT) {
            context.getWindow().getDecorView().setSystemUiVisibility(flags);
            final View decorView = context.getWindow().getDecorView();
            decorView.setOnSystemUiVisibilityChangeListener(new View.OnSystemUiVisibilityChangeListener() {
                @Override
                public void onSystemUiVisibilityChange(int visibility) {
                    if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                        decorView.setSystemUiVisibility(flags);
                    }
                }
            });
        }
    }
}
