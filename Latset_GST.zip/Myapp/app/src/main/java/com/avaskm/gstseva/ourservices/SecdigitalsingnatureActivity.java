package com.avaskm.gstseva.ourservices;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import com.avaskm.gstseva.R;

public class SecdigitalsingnatureActivity extends AppCompatActivity {
    ImageView digitalsignature,digitalpancard,digitalaadhaarcard;
    Button btn_digitalsignature,btn_digitalpancard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secdigitalsingnature);

    }
}
