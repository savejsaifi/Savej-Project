package com.avaskm.gstseva.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.DetailsOrderActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.PendingModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;

public class PendingFragment extends Fragment {

    RecyclerView RvPending;
    PendingAdapter adapter;
    ArrayList<PendingModel> arListPending;
    SharedPreferences sharedPreferences;
    String userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_pending, container, false);
        RvPending = (RecyclerView) view.findViewById(R.id.rv_pending_order);
        arListPending = new ArrayList<>();
        sharedPreferences = getActivity().getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        setRvPending();
        GetPendingOrderAPI();
        return view;
    }


    private void setRvPending() {
        RvPending.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        RvPending.setLayoutManager(layoutManager);
        arListPending.clear();
    }

    public class PendingAdapter extends RecyclerView.Adapter<PendingAdapter.ViewHolder> {
        Context mContext;
        ArrayList<PendingModel> arList;

        public PendingAdapter(Context context, ArrayList<PendingModel> arrayList) {
            this.mContext = context;
            this.arList = arrayList;

        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_pending, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            viewHolder.TvCategoryName.setText(arList.get(i).getCategoryName());
            viewHolder.TvReferenceNo.setText(arList.get(i).getReferenceNo());
            viewHolder.TvPrice.setText(arList.get(i).getPrice());
            viewHolder.TvStatus.setText(arList.get(i).getStatus());
            viewHolder.TvDate.setText(arList.get(i).getDate());
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView TvCategoryName, TvReferenceNo, TvPrice, TvStatus, TvDate, TvViewDetail, TvDoucment;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                TvCategoryName = (TextView) itemView.findViewById(R.id.tv_category_name_pending);
                TvReferenceNo = (TextView) itemView.findViewById(R.id.tv_reference_pending);
                TvPrice = (TextView) itemView.findViewById(R.id.tv_price_pending);
                TvStatus = (TextView) itemView.findViewById(R.id.tv_status_pending);
                TvDate = (TextView) itemView.findViewById(R.id.tv_date_pending);
                TvViewDetail = (TextView) itemView.findViewById(R.id.tv_detail_pending);
                TvDoucment = (TextView) itemView.findViewById(R.id.tv_document_pending);

                TvViewDetail.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        PendingModel model = arListPending.get(getAdapterPosition());
                        String orderId = model.getOrderId();
                        Intent intent = new Intent(getActivity(), DetailsOrderActivity.class);
                        intent.putExtra("orderId", orderId);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                    }
                });
            }
        }
    }


    private void GetPendingOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetPendingOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetPendingOrder", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONArray dataArray = jsonObject.getJSONArray("data");
                    for (int i = 0; i < dataArray.length(); i++) {
                        PendingModel model = new PendingModel();
                        JSONObject dataObject = dataArray.getJSONObject(i);
                        model.setCategoryName(dataObject.getString("category_name"));
                        model.setReferenceNo(dataObject.getString("refid"));
                        model.setPrice(dataObject.getString("price"));
                        model.setStatus(dataObject.getString("status"));
                        model.setDate(dataObject.getString("cdate"));
                        model.setOrderId(dataObject.getString("orderid"));

                        arListPending.add(model);

                    }
                    adapter = new PendingAdapter(getActivity(), arListPending);
                    RvPending.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }

}
