package com.avaskm.gstseva.activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import com.avaskm.gstseva.R;
import java.util.ArrayList;
import java.util.List;

public class PubliclimitedActivity extends AppCompatActivity {
    Spinner spinner,spinnertwo;
    LinearLayout linear_propreiter,linear_propreiter2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publiclimited);
        linear_propreiter =  findViewById(R.id.linearpropreit);
        linear_propreiter2=findViewById(R.id.linearpropublic);

        addItemsOnSpinner2();
        addListenerOnSpinnerItemSelection();
    }
    public void addItemsOnSpinner2() {

        spinner = (Spinner) findViewById(R.id.publicspiner);
        List<String> list = new ArrayList<String>();
        list.add("Director 1");
        list.add("Director 2");
        list.add("Director 3");
        list.add("Director 4");
        list.add("Director 5");
        list.add("Director 6");
        list.add("Director 7");
        list.add("Director 8");
        list.add("Director 9");
        list.add("Director 10");
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);



    }
    public void addListenerOnSpinnerItemSelection() {
        spinnertwo=findViewById(R.id.publicpermision);
        spinnertwo.setOnItemSelectedListener(new PubliclimitedActivity.CustomOnItemSelectedListener());
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            if (parent.getId() == R.id.publicpermision) {
                if (position == 1) {
                    linear_propreiter.setVisibility(View.VISIBLE);
                } else {
                    linear_propreiter.setVisibility(View.GONE);
                }

                if (position == 2) {
                    linear_propreiter2.setVisibility(View.VISIBLE);
                } else {
                    linear_propreiter2.setVisibility(View.GONE);
                }
            }
        }

        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }
}
