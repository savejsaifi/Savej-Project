package com.avaskm.gstseva.ourservices;

import android.content.Intent;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupMenu;

import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PaymentActivity;
import com.squareup.picasso.Picasso;

public class SecLabourlincenseActivity extends AppCompatActivity {
    Button seclaboursubmit,photo_btngraph,sec_btnphotograph;
ImageView uploadphotograph,uploadphotointerior;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_labourlincense);
        uploadphotograph=findViewById(R.id.uploadphotograph);
        sec_btnphotograph=findViewById(R.id.btninterior);
        photo_btngraph=findViewById(R.id.btnlabourphotograp);
        uploadphotointerior=findViewById(R.id.uploadinterior);
        seclaboursubmit=findViewById(R.id.seclaboursubmit);
        seclaboursubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(SecLabourlincenseActivity.this, PaymentActivity.class);
                startActivity(intent);
            }
        });
        photo_btngraph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=1;
                abc(v);

            }
        });
        sec_btnphotograph.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                count=2;
                abc(v);
            }
        });
    }
    private void abc(View v){
        PopupMenu popupMenu = new PopupMenu(SecLabourlincenseActivity.this,v);
        popupMenu.getMenuInflater().inflate(R.menu.menu_image, popupMenu.getMenu());
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

            @Override
            public boolean onMenuItemClick(MenuItem item) {

                switch (item.getItemId()) {

//                    case R.id.Camera:
//                        try {
//                            Intent intent = new Intent();
//                            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
//                            startActivityForResult(intent, 1);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                        break;
                    case R.id.Gallery:

                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_PICK);
                        startActivityForResult(intent, 0);
                        break;
                }
                return false;
            }
        });
        popupMenu.show();

    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        try {
            if (requestCode == 0 && count == 1) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(uploadphotograph);
            } else if (requestCode == 1 && count == 1) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                uploadphotograph.setImageBitmap(bitmap);
            }
            if (requestCode == 0 && count == 2) {

                String url = data.getData().toString();
                Picasso.get().load(url).into(uploadphotointerior);


            } else if (requestCode == 1 && count == 2) {
                Bundle bt = data.getExtras();
                Bitmap bitmap = (Bitmap) bt.get("data");
                uploadphotointerior.setImageBitmap(bitmap);
            }

        } catch (Exception e) {

        }

    }
}
