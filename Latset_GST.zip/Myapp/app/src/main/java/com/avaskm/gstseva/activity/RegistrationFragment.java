package com.avaskm.gstseva.activity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegistrationFragment extends AppCompatActivity {
    Button btnlogin;
    EditText edt_mobile;
    String Mobileno;
    ProgressBar progressbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_registration);
        btnlogin = findViewById(R.id.loginbutton);
        ActionBar actionBar = getSupportActionBar();
        edt_mobile = findViewById(R.id.editmobile);
        // progressbar=findViewById(R.id.progressbar);

        actionBar.setDisplayShowHomeEnabled(true);


        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Mobileno = edt_mobile.getText().toString();
                if (Mobileno.isEmpty()) {
                    // Toast.makeText(RegistrationFragment.this, "Please enter the mobile No.", Toast.LENGTH_SHORT).show();
                    edt_mobile.setError("Please enter the mobile No");
                } else if (Mobileno.length() != 10) {
                    //  Toast.makeText(RegistrationFragment.this, "Please enter the 10 digit mobile No.", Toast.LENGTH_SHORT).show();
                    edt_mobile.setError("Please enter the 10 digit mobile No");
                } else {

                    RegisterAPI();


                }
            }
        });
    }

    private void RegisterAPI() {
        final ProgressDialog dialog = ProgressDialog.show(RegistrationFragment.this, "", "wait....", false);
        RequestQueue requestQueue = Volley.newRequestQueue(RegistrationFragment.this);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.register_Url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        dialog.dismiss();
                        Log.d("mobilenumber ", Mobileno);
                        try {
                            Log.e("onResponse", ": " + response);
                            JSONArray jsonArray = new JSONArray(response);
                            JSONObject jo = jsonArray.getJSONObject(0);
                            String resultcode = jo.getString("code");
                            String msg = jo.getString("msg");
                            // String message = jsonObject.getString("data post sucessfully!");
                            if (resultcode.equalsIgnoreCase("401")) {
                                Intent intent = new Intent(RegistrationFragment.this, OTPFragment.class);
                                intent.putExtra("mobile", Mobileno);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                // Toast.makeText(RegistrationFragment.this, msg, Toast.LENGTH_SHORT).show();

                            }if (resultcode.equalsIgnoreCase("403")) {
                                Intent intent = new Intent(RegistrationFragment.this, OTPFragment.class);
                                intent.putExtra("mobile", Mobileno);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

                Toast.makeText(RegistrationFragment.this,
                        error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("key", Api.key);
          /*      params.put("username",username);

                params.put("password", password);//
                params.put("email", EmailId);
                params.put("address", Address);*/
                params.put("mobile", Mobileno);
           /*     params.put("business_type",Bussinesstype);
                params.put("industry_type",Indusrtrytype);
                params.put("description",Bussinessdescriptioncn);*/
                params.put("status", "0");
                Log.e("ParamResone", ": " + params);
                return params;
            }

            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/x-www-form-urlencoded");
                return params;
            }
        };
        stringRequest.setRetryPolicy(
                new DefaultRetryPolicy(
                        500000,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
                )
        );
        requestQueue.add(stringRequest);
    }

}