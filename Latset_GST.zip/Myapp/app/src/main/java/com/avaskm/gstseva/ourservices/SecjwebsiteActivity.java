package com.avaskm.gstseva.ourservices;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.avaskm.gstseva.R;

import java.util.ArrayList;
import java.util.List;

public class SecjwebsiteActivity extends AppCompatActivity {
    Spinner spinneryesno;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secjwebsite);
        addItems();
    }
    public void addItems() {
        spinneryesno=findViewById(R.id.yesno);
        List<String> list = new ArrayList<String>();
        list.add("yes");
        list.add("no");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinneryesno.setAdapter(dataAdapter);
    }
}
