package com.avaskm.gstseva.ourservices;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ITRfillingActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner spinnerCategory, spinnerone;
    Button itrsubmitt;
    String Salaried, Stockiest, price, orderid,title;
    LinearLayout linear_propreiter, linear_propreiter2;
    TextView TvPrice, TvUpload;

    TextInputEditText EtNamePanCard, EtPanNo, EtAadhaarNo, EtMobile, EtEmail, EtTotalSalary, EtIncomeSource, EtTotalInvestment, EtBusiness, EtTotalPaymentReceivedInCash;
    TextInputEditText EtTotalPaymentInBank, EtGstNo, EtGrossSale, EtPartner, EtSecuredLoan, EtUnsecuredLoan, EtAdvances, EtSundryCreditors, EtOtherLiabilities;
    TextInputEditText EtFixedAsset, EtInventory, EtSundryDebtors, EtBalanceWithBank, EtCashInHand, EtLoanGiven, EtOtherAssetIsAny;


    ArrayList<String> imagePathListMOA = new ArrayList<>();
    private static final String IMAGE_DIRECTORY = "/demonuts_upload_gallery";
    private static final int BUFFER_SIZE = 1024 * 2;


    private Dialog mDialogConfirmPopUp;
    SharedPreferences sharedPreferences;
    String userId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itrfilling);
        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");


        TvPrice = (TextView) findViewById(R.id.tv_price_itr);
        spinnerCategory = findViewById(R.id.salaried);
        spinnerone = findViewById(R.id.dropdown);
        linear_propreiter = findViewById(R.id.totalsalieries);
        linear_propreiter2 = findViewById(R.id.bussiness);
        itrsubmitt = findViewById(R.id.btn_submit_itr);
        EtNamePanCard = (TextInputEditText) findViewById(R.id.et_name_pan_card_itr);
        EtPanNo = (TextInputEditText) findViewById(R.id.et_pan_no_itr);
        EtAadhaarNo = (TextInputEditText) findViewById(R.id.et_aadhaar_no_itr);
        EtMobile = (TextInputEditText) findViewById(R.id.et_mobile_itr);
        EtEmail = (TextInputEditText) findViewById(R.id.et_email_itr);
        EtTotalSalary = (TextInputEditText) findViewById(R.id.et_total_salary_itr);
        EtIncomeSource = (TextInputEditText) findViewById(R.id.et_income_source_itr);
        EtTotalInvestment = (TextInputEditText) findViewById(R.id.et_total_investment);
        // BtnUploadItr = (Button) findViewById(R.id.btn_upload_itr);
        EtBusiness = (TextInputEditText) findViewById(R.id.et_business_firm_itr);
        EtTotalPaymentReceivedInCash = (TextInputEditText) findViewById(R.id.et_total_payment_received_cash_itr);
        EtTotalPaymentInBank = (TextInputEditText) findViewById(R.id.et_total_pay_receive_itr);
        EtGstNo = (TextInputEditText) findViewById(R.id.et_gst_no_itr);
        EtGrossSale = (TextInputEditText) findViewById(R.id.et_gross_sale_itr);
        EtPartner = (TextInputEditText) findViewById(R.id.et_partner_own_itr);
        EtSecuredLoan = (TextInputEditText) findViewById(R.id.et_secured_loan_itr);
        EtUnsecuredLoan = (TextInputEditText) findViewById(R.id.unsecured_loan_itr);
        EtAdvances = (TextInputEditText) findViewById(R.id.et_advances_itr);
        EtSundryCreditors = (TextInputEditText) findViewById(R.id.et_sundry_creditors_itr);
        EtOtherLiabilities = (TextInputEditText) findViewById(R.id.et_other_liabilities_itr);

        EtFixedAsset = (TextInputEditText) findViewById(R.id.et_fixed_asset_itr);
        EtInventory = (TextInputEditText) findViewById(R.id.et_inentory_itr);
        EtSundryDebtors = (TextInputEditText) findViewById(R.id.et_sundry_debtors_itr);
        EtBalanceWithBank = (TextInputEditText) findViewById(R.id.et_balance_with_bank);
        EtCashInHand = (TextInputEditText) findViewById(R.id.et_cash_in_hand_itr);
        EtLoanGiven = (TextInputEditText) findViewById(R.id.et_loan_given);
        EtOtherAssetIsAny = (TextInputEditText) findViewById(R.id.et_other_asset_is_any);


        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        spinnerCategory.setOnItemSelectedListener(this);
        // Spinner Drop down elements
        List<String> categories = new ArrayList<String>();
        categories.add("Are you?");
        categories.add("Salaried");
        categories.add("Business");
        addItemsOnSpinnerup();


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        // Drop down layout style - list view with radio button
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // attaching data adapter to spinner
        spinnerCategory.setAdapter(dataAdapter);
        spinnerCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //selectedCar = position;
                Salaried = (String) parent.getItemAtPosition(position);
                Log.d("first", Salaried);
                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
                if (Salaried.equalsIgnoreCase("Salaried")) {
                    linear_propreiter.setVisibility(View.VISIBLE);
                    linear_propreiter2.setVisibility(View.GONE);
                } else if (Salaried.equalsIgnoreCase("Business")) {
                    linear_propreiter.setVisibility(View.GONE);
                    linear_propreiter2.setVisibility(View.VISIBLE);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        GetCategoryInForAPI();
        itrsubmitt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (setSubmit()) {

                }
                /*Intent intent = new Intent(ITRfillingActivity.this, PaymentActivity.class);
                startActivity(intent);*/
            }
        });

    }


    public void addItemsOnSpinnerup() {
        spinnerone = findViewById(R.id.dropdown);
        List<String> list = new ArrayList<String>();
        list.add("Select buisness type");
        list.add("Retailer");
        list.add("Wholesaler");
        list.add("Distributor");
        list.add("Service provider");
        list.add("Stockiest");
        list.add("Manufacturer");
        list.add("Broker");
        list.add("Farmer");
        list.add("Contactor");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerone.setOnItemSelectedListener(new ITRfillingActivity.CustomOnItemSelectedListener());
        spinnerone.setAdapter(dataAdapter);
        spinnerone.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        spinnerone.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //selectedCar = position;
                Stockiest = (String) parent.getItemAtPosition(position);

                Log.d("secondddddd", Stockiest);
                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            /*if (parent.getId() == R.id.anotherspinner) {
                if (position == 2) {
                    linear_Layout.setVisibility(View.VISIBLE);
                } else {
                    linear_Layout.setVisibility(View.GONE);
                }
            }*/
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }


    private boolean setAreYouSpn() {
        if (!Salaried.equalsIgnoreCase("Are you?")) {
            return true;
        } else {
            Toast.makeText(ITRfillingActivity.this, "Please select profession", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    private boolean setSubmit() {
        if (!setAreYouSpn()) {
            return false;
        }
        MakeOrderAPI();
        return true;
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(ITRfillingActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCategoryInForAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    price = dataObject.getString("price");
                    TvPrice.setText(price);
                    //Log.d("price",price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("category", title);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ITRfillingActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(ITRfillingActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("MakeOrderww", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("sssorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {

                        if (Salaried.equalsIgnoreCase("Salaried")) {
                            Intent intent = new Intent(ITRfillingActivity.this, ITRFillingUploadFormActivity.class);
                            intent.putExtra("orderid", orderid);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            Toast.makeText(ITRfillingActivity.this, msg, Toast.LENGTH_SHORT).show();

                        } else {
                            Intent intent = new Intent(ITRfillingActivity.this, NavigationActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                            startActivity(intent);
                            Toast.makeText(ITRfillingActivity.this, msg, Toast.LENGTH_SHORT).show();
                        }

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category", title);
                params.put("price", price);
                params.put("name", EtNamePanCard.getText().toString());
                params.put("pancard", EtPanNo.getText().toString());
                params.put("aadhaar", EtAadhaarNo.getText().toString());
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("employement_type", Salaried);

                if (Salaried.equalsIgnoreCase("Salaried")) {
                    params.put("salary", EtTotalSalary.getText().toString());
                    params.put("other_income", EtIncomeSource.getText().toString());
                    params.put("investment", EtTotalInvestment.getText().toString());
                } else if (Salaried.equalsIgnoreCase("Business")) {
                    params.put("firm_name", EtBusiness.getText().toString());
                    params.put("business_type", Stockiest);
                    params.put("payment_cash", EtTotalPaymentReceivedInCash.getText().toString());
                    params.put("payment_bank", EtTotalPaymentInBank.getText().toString());
                    params.put("gst_no", EtGstNo.getText().toString());
                    params.put("sale_amount", EtGrossSale.getText().toString());
                    params.put("capital", EtPartner.getText().toString());
                    params.put("secured_loan", EtSecuredLoan.getText().toString());
                    params.put("unsecured_loan", EtUnsecuredLoan.getText().toString());
                    params.put("advances", EtAdvances.getText().toString());
                    params.put("sundry_creditors", EtSundryCreditors.getText().toString());
                    params.put("other_libilities", EtOtherLiabilities.getText().toString());
                    params.put("fixed_asset", EtFixedAsset.getText().toString());
                    params.put("stock_value", EtInventory.getText().toString());
                    params.put("sundry_debitors", EtSundryDebtors.getText().toString());
                    params.put("balance_bank", EtBalanceWithBank.getText().toString());
                    params.put("cash_in_hand", EtCashInHand.getText().toString());
                    params.put("loan_given", EtLoanGiven.getText().toString());
                    params.put("other_asset", EtOtherAssetIsAny.getText().toString());
                    Log.d("allItr", String.valueOf(params));
                }
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(ITRfillingActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
