package com.avaskm.gstseva.session;
import android.content.Context;
import android.content.SharedPreferences;

public class SessonManager {

    private static SessonManager pref;
    private SharedPreferences sharedPreference;
    private SharedPreferences.Editor editor;
    public static final String NAME = "MY_PREFERENCES";
    public static final String USERID = "userId";
    public static final String CITYNAME = "cityName";
    public static final String PRIZE = "prizeName";
    public static final String VALIDITY = "validityName";
    public static final String CATEGORYNAME = "categoryName";
    public static final String SERVICENAME = "serviceName";

    public SessonManager(Context ctx) {
        sharedPreference = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        editor = sharedPreference.edit();
    }
    public static SessonManager getInstance(Context ctx) {
        if (pref == null) {
            pref = new SessonManager(ctx);
        }
        return pref;
    }

    public void setUserId(String userId){
        editor.putString(USERID,userId);
        editor.commit();

    }
    public void setCityName(String cityName){

       // Log.
        editor.putString(CITYNAME,cityName);
        editor.commit();

    }


    public void setServiceName(String servicename){

        // Log.
        editor.putString(SERVICENAME,servicename);
        editor.commit();

    }
    public  void deleteAllSharePrefs(){
        sharedPreference.edit().clear().commit();
    }

    public String getServiceName(){
        return sharedPreference.getString(SERVICENAME,"");
    }

    public String getUserid(){
        return sharedPreference.getString(USERID,"");
}


public String getCityname(){
        return sharedPreference.getString(CITYNAME,"");
}
    public String getPrice(){
        return sharedPreference.getString(PRIZE,"");
    }

    public String getValidity(){
        return sharedPreference.getString(VALIDITY,"");
    }
    public String getCategoryname(){
        return sharedPreference.getString(CATEGORYNAME,"");
    }
}
