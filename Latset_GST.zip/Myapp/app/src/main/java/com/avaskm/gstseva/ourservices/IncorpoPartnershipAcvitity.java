package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class IncorpoPartnershipAcvitity extends AppCompatActivity {


    TextView TvPrice;
    Button BtnSubmit;
    EditText EtNameOfPartnerShip, EtAddressOfPartnerShip, EtMobile, EtEmail, EtBusinessDes, EtFirmEmail;
    String orderid, title;
    SharedPreferences sharedPreferences_userId;
    String userId, partnerType, premisesType;
    Spinner SpnPartner, SpnPremises;
    String[] NoOfPartner = {"Selecr no of partner", "1", "2", "3", "4"};
    String[] Premises = {"Select premises type", "owned", "rented/leased"};
    LinearLayout LinearFirst, LinearSecond, LinearThree, LinearFour;

    EditText EtNameFirstFitst, EtFatherNameFirst, EtRatioFirst, EtMobileFirst, EtEmailFirst,
            EtNameFirstSecond, EtFatherFirstSecond, EtRatioFirstSecond, EtMobileFirstSecond, EtEmailFirstSecond, EtNameSeconsSecond, EtFatherSecondSecond,
            EtRatioSecondSecond, EtMobileSecondSecond, EtEmailSecondSecond,
            EtNameFirstThree, EtFatherFirstThree, EtRatioFirstThree, EtMobileFirstThree, EtEmailFirstThree, EtNameSecondThree, EtFatherSecondThree,
            EtRatioSecondThree, EtMobileSecondThree, EtEmailSecondThree, EtNameThreeThree, EtFatherThreeThree, EtRatioThreeThree, EtMobileThreeThree, EtEmailThreeThree,
            EtNameFirstFour, EtFatherFirstFour, EtRatioFirstFour, EtMobileFirstFour, EtEmailFirstFour, EtNameSecondFour, EtFatherSecondFour, EtRatioSecondFour, EtMobileSecondFour, EtEmailSecondFour,
            EtNameThreeFour, EtFatherThreeFour, EtRatioThreeFour, EtMobileThreeFour, EtEmailThreeFour, EtNameFourFour, EtFatherFourFour, EtRatioFourFour, EtMobileFourFour, EtEmailFourFour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec_incorpo_partnership);
        sharedPreferences_userId = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences_userId.getString("userid", "");

        TvPrice = (TextView) findViewById(R.id.tv_price_incorporation_Proprietorship);
        BtnSubmit = (Button) findViewById(R.id.btn_submit_in_partnership);
        EtNameOfPartnerShip = (EditText) findViewById(R.id.et_name_of_partner_partner);
        EtAddressOfPartnerShip = (EditText) findViewById(R.id.et_address_of_partner_partner);
        EtMobile = (EditText) findViewById(R.id.et_mobile_partner);
        EtEmail = (EditText) findViewById(R.id.et_email_partner);
        EtBusinessDes = (EditText) findViewById(R.id.et_business_dis_partner);
        EtFirmEmail = (EditText) findViewById(R.id.et_firm_email_partner);
        SpnPartner = (Spinner) findViewById(R.id.spn_no_of_partner_Incorp);
        LinearFirst = (LinearLayout) findViewById(R.id.linear_first_partner_upload);
        LinearSecond = (LinearLayout) findViewById(R.id.linear_second_partner_upload);
        LinearThree = (LinearLayout) findViewById(R.id.linear_three_partner_upload);
        LinearFour = (LinearLayout) findViewById(R.id.linear_four_partner_upload);

        EtNameFirstFitst = (EditText) findViewById(R.id.et_first_partner_name_first);
        EtFatherNameFirst = (EditText) findViewById(R.id.et_father_name_of_first_partner_first);
        EtRatioFirst = (EditText) findViewById(R.id.et_ratio_of_first_partner_first);
        EtMobileFirst = (EditText) findViewById(R.id.et_mobile_no_of_first_partner);
        EtEmailFirst = (EditText) findViewById(R.id.et_email_id_of_first_partner_first);

        EtNameFirstSecond = (EditText) findViewById(R.id.et_name_first_second);
        EtFatherFirstSecond = (EditText) findViewById(R.id.et_father_name_first_second);
        EtRatioFirstSecond = (EditText) findViewById(R.id.et_ratio_first_second);
        EtMobileFirstSecond = (EditText) findViewById(R.id.et_mobile_first_second_part);
        EtEmailFirstSecond = (EditText) findViewById(R.id.et_email_first_second_part);
        EtNameSeconsSecond = (EditText) findViewById(R.id.et_name_second_second);
        EtFatherSecondSecond = (EditText) findViewById(R.id.et_father_second_second);
        EtRatioSecondSecond = (EditText) findViewById(R.id.et_ratio_second_second);
        EtMobileSecondSecond = (EditText) findViewById(R.id.et_mobile_second_second_partner);
        EtEmailSecondSecond = (EditText) findViewById(R.id.et_eamil_second_second);

        EtNameFirstThree = (EditText) findViewById(R.id.et_name_first_three_part);
        EtFatherFirstThree = (EditText) findViewById(R.id.et_father_first_three_part);
        EtRatioFirstThree = (EditText) findViewById(R.id.et_ratio_first_three_part);
        EtMobileFirstThree = (EditText) findViewById(R.id.et_mobile_first_three_part);
        EtEmailFirstThree = (EditText) findViewById(R.id.et_email_first_three_part);
        EtNameSecondThree = (EditText) findViewById(R.id.et_name_second_three_part);
        EtFatherSecondThree = (EditText) findViewById(R.id.et_father_second_three_part);
        EtRatioSecondThree = (EditText) findViewById(R.id.et_ratio_second_three_part);
        EtMobileSecondThree = (EditText) findViewById(R.id.et_mobile_second_three_part);
        EtEmailSecondThree = (EditText) findViewById(R.id.et_email_second_three_part);
        EtNameThreeThree = (EditText) findViewById(R.id.et_name_three_three_part);
        EtFatherThreeThree = (EditText) findViewById(R.id.et_father_three_three_part);
        EtRatioThreeThree = (EditText) findViewById(R.id.et_ratio_three_three_part);
        EtMobileThreeThree = (EditText) findViewById(R.id.et_mobile_three_three_part);
        EtEmailThreeThree = (EditText) findViewById(R.id.et_email_three_three_part);

        EtNameFirstFour = (EditText) findViewById(R.id.et_name_first_four_part);
        EtFatherFirstFour = (EditText) findViewById(R.id.et_father_first_four_part);
        EtRatioFirstFour = (EditText) findViewById(R.id.et_ratio_first_four_part);
        EtMobileFirstFour = (EditText) findViewById(R.id.et_mobile_first_four_part);
        EtEmailFirstFour = (EditText) findViewById(R.id.et_email_first_four_part);
        EtNameSecondFour = (EditText) findViewById(R.id.et_name_second_four_part);
        EtFatherSecondFour = (EditText) findViewById(R.id.et_father_second_four_part);
        EtRatioSecondFour = (EditText) findViewById(R.id.et_ratio_second_four_part);
        EtMobileSecondFour = (EditText) findViewById(R.id.et_mobile_second_four_part);
        EtEmailSecondFour = (EditText) findViewById(R.id.et_email_second_four_part);
        EtNameThreeFour = (EditText) findViewById(R.id.et_name_three_four_part);
        EtFatherThreeFour = (EditText) findViewById(R.id.et_father_three_four_part);
        EtRatioThreeFour = (EditText) findViewById(R.id.et_ratio_three_four_part);
        EtMobileThreeFour = (EditText) findViewById(R.id.et_mobile_three_four_part);
        EtEmailThreeFour = (EditText) findViewById(R.id.et_email_three_four_part);
        EtNameFourFour = (EditText) findViewById(R.id.et_name_four_four_part);
        EtFatherFourFour = (EditText) findViewById(R.id.et_father_four_four_part);
        EtRatioFourFour = (EditText) findViewById(R.id.et_ratio_four_four_part);
        EtMobileFourFour = (EditText) findViewById(R.id.et_mobile_four_four_part);
        EtEmailFourFour = (EditText) findViewById(R.id.et_email_four_four_part);

        SpnPremises = (Spinner) findViewById(R.id.spn_permissiontype_form);

        //et_email_second_three_part

        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setSubmit()) {

                }

            }
        });

        SpnPartner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                partnerType = String.valueOf(SpnPartner.getItemAtPosition(i));
                Log.d("partnerType", partnerType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));

                if (partnerType.equalsIgnoreCase("1")) {
                    LinearFirst.setVisibility(View.VISIBLE);
                    LinearSecond.setVisibility(View.GONE);
                    LinearThree.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                } else if (partnerType.equalsIgnoreCase("2")) {
                    LinearSecond.setVisibility(View.VISIBLE);
                    LinearFirst.setVisibility(View.GONE);
                    LinearThree.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                } else if (partnerType.equalsIgnoreCase("Selecr no of partner")) {
                    LinearSecond.setVisibility(View.GONE);
                    LinearFirst.setVisibility(View.GONE);
                    LinearThree.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                } else if (partnerType.equalsIgnoreCase("3")) {
                    LinearThree.setVisibility(View.VISIBLE);
                    LinearSecond.setVisibility(View.GONE);
                    LinearFirst.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                } else if (partnerType.equalsIgnoreCase("4")) {
                    LinearFour.setVisibility(View.VISIBLE);
                    LinearSecond.setVisibility(View.GONE);
                    LinearFirst.setVisibility(View.GONE);
                    LinearThree.setVisibility(View.GONE);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnPremises.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                premisesType = String.valueOf(SpnPremises.getItemAtPosition(i));
                Log.d("premisesType", premisesType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> ExtraAdapter = new ArrayAdapter<String>(IncorpoPartnershipAcvitity.this, android.R.layout.simple_spinner_dropdown_item, NoOfPartner);
        SpnPartner.setAdapter(ExtraAdapter);

        ArrayAdapter<String> PremisesAdapter = new ArrayAdapter<String>(IncorpoPartnershipAcvitity.this, android.R.layout.simple_spinner_dropdown_item, Premises);
        SpnPremises.setAdapter(PremisesAdapter);

        GetCategoryInForAPI();
    }


    private boolean setName() {
        if (EtNameOfPartnerShip.getText().toString().length() > 0) {
            return true;
        } else {
            EtNameOfPartnerShip.setError("Please enter name of partnership");
            return false;
        }
    }

    private boolean setAddress() {
        if (EtAddressOfPartnerShip.getText().toString().length() > 0) {
            return true;
        } else {
            EtAddressOfPartnerShip.setError("Please enter address of partnership");
            return false;
        }
    }

    private boolean setMobile() {
        if (EtMobile.getText().toString().length() > 1) {
            return true;
        } else {
            EtMobile.setError("Please enter 10 digit mobile no ");
            return false;
        }
    }

    private boolean setEmail() {
        if (EtEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtEmail.setError("Please enter enail");
            return false;
        }
    }


    private boolean setBusinessDes() {
        if (EtBusinessDes.getText().toString().length() > 0) {
            return true;

        } else {
            EtBusinessDes.setError("Please enter business description");
            return false;
        }
    }

    private boolean setFirmEmail() {
        if (EtFirmEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtFirmEmail.setError("Please firm email");
            return false;
        }
    }


    private boolean setPartnetType() {
        if (!partnerType.equalsIgnoreCase("Selecr no of partner")) {
            return true;
        } else {
            Toast.makeText(IncorpoPartnershipAcvitity.this, "Please selecr no of partner", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setPermisesType(){
       if(!premisesType.equalsIgnoreCase("Select premises type")){
           return true;
       }else {
           Toast.makeText(IncorpoPartnershipAcvitity.this, "Please select premises type", Toast.LENGTH_SHORT).show();
           return false;
       }
    }
    private boolean setSubmit() {
        if (!setName()) {
            return false;
        } else if (!setAddress()) {
            return false;
        } else if (!setMobile()) {
            return false;
        } else if (!setEmail()) {
            return false;
        } else if (!setBusinessDes()) {
            return false;
        } else if (!setFirmEmail()) {
            return false;
        } else if (!setPartnetType()) {
            return false;
        }else if(!setPermisesType()){
            return false;
        }
        MakeOrderAPI();
        return true;
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(IncorpoPartnershipAcvitity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("PartnershipRes", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    String price = dataObject.getString("price");
                    TvPrice.setText(price);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("category", title);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(IncorpoPartnershipAcvitity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(IncorpoPartnershipAcvitity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("IncorpoPartnershRe", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("Inco", orderid);
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(IncorpoPartnershipAcvitity.this, IncorpoPartnershipUploadFormAcvitity.class);
                        intent.putExtra("orderid", orderid);
                        intent.putExtra("premisesType", premisesType);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category", title);
                params.put("price", TvPrice.getText().toString());
                params.put("ptr_firm_name", EtNameOfPartnerShip.getText().toString());
                params.put("ptr_firm_address", EtAddressOfPartnerShip.getText().toString());
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("business_des", EtBusinessDes.getText().toString());
                params.put("firm_emailid", EtFirmEmail.getText().toString());
                params.put("no_of_ptr", partnerType);
                params.put("premises_type",premisesType);
                if (partnerType.equalsIgnoreCase("1")) {
                    params.put("all_ptr_name", EtNameFirstFitst.getText().toString());
                    params.put("all_ptr_father_name", EtFatherNameFirst.getText().toString());
                    params.put("all_ptr_ratio", EtRatioFirst.getText().toString());
                    params.put("all_ptr_mobile", EtMobileFirst.getText().toString());
                    params.put("all_ptr_email", EtEmailFirst.getText().toString());
                } else if (partnerType.equalsIgnoreCase("2")) {
                    String nameSecond = EtNameFirstSecond.getText().toString() + "," + EtNameSeconsSecond.getText().toString();
                    params.put("all_ptr_name", nameSecond);
                    String fatherSecond = EtFatherFirstSecond.getText().toString() + "," + EtFatherSecondSecond.getText().toString();
                    params.put("all_ptr_father_name", fatherSecond);
                    String ratioSecond = EtRatioFirstSecond.getText().toString() + "," + EtRatioSecondSecond.getText().toString();
                    params.put("all_ptr_ratio", ratioSecond);
                    String mobileSecond = EtMobileFirstSecond.getText().toString() + "," + EtMobileSecondSecond.getText().toString();
                    params.put("all_ptr_mobile", mobileSecond);
                    String emailSecond = EtEmailFirstSecond.getText().toString() + "," + EtEmailSecondSecond.getText().toString();
                    params.put("all_ptr_email", emailSecond);
                } else if (partnerType.equalsIgnoreCase("3")) {
                    String nameThree = EtNameFirstThree.getText().toString() + "," + EtNameSecondThree.getText().toString() + "," + EtNameThreeThree.getText().toString();
                    params.put("all_ptr_name", nameThree);
                    String fatherThree = EtFatherFirstThree.getText().toString() + "," + EtFatherSecondThree.getText().toString() + "," + EtFatherThreeThree.getText().toString();
                    params.put("all_ptr_father_name", fatherThree);
                    String ratioThree = EtRatioFirstThree.getText().toString() + "," + EtRatioSecondThree.getText().toString() + "," + EtRatioThreeThree.getText().toString();
                    params.put("all_ptr_ratio", ratioThree);
                    String mobileThree = EtMobileFirstThree.getText().toString() + "," + EtMobileSecondThree.getText().toString() + "," + EtMobileThreeThree.getText().toString();
                    params.put("all_ptr_mobile", mobileThree);
                    String emailThree = EtEmailFirstThree.getText().toString() + "," + EtEmailSecondThree + "," + EtEmailThreeThree.getText().toString();
                    params.put("all_ptr_email", emailThree);
                } else if (partnerType.equalsIgnoreCase("4")) {
                    String nametFour = EtNameFirstFour.getText().toString() + "," + EtNameSecondFour.getText().toString() + "," + EtNameThreeFour.getText().toString() + "," + EtNameFourFour.getText().toString();
                    params.put("all_ptr_name", nametFour);
                    String fatherFour = EtFatherFirstFour.getText().toString() + "," + EtFatherSecondFour.getText().toString() + "," + EtFatherThreeFour.getText().toString() + "," + EtFatherFourFour.getText().toString();
                    params.put("all_ptr_father_name", fatherFour);
                    String ratioFour = EtRatioFirstFour.getText().toString() + "," + EtRatioSecondFour.getText().toString() + "," + EtRatioThreeFour.getText().toString() + "," + EtRatioFourFour.getText().toString();
                    params.put("all_ptr_ratio", ratioFour);
                    String mobileFour = EtMobileFirstFour.getText().toString() + "," + EtMobileSecondFour.getText().toString() + "," + EtMobileThreeFour.getText().toString() + "," + EtMobileThreeFour.getText().toString() + "," + EtMobileFourFour.getText().toString();
                    params.put("all_ptr_mobile", mobileFour);
                    String emailFour = EtEmailFirstFour.getText().toString() + "," + EtEmailSecondFour.getText().toString() + "," + EtEmailThreeFour.getText().toString() + "," + EtEmailFourFour.getText().toString();
                    params.put("all_ptr_email", emailFour);

                }


                Log.d("allItr", String.valueOf(params));


                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(IncorpoPartnershipAcvitity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}