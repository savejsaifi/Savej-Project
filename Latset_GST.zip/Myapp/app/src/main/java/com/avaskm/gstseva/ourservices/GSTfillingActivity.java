package com.avaskm.gstseva.ourservices;

import android.graphics.Matrix;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ScaleGestureDetector;
import android.widget.ImageView;

import com.avaskm.gstseva.R;
import com.jsibbold.zoomage.ZoomageView;

public class GSTfillingActivity extends AppCompatActivity {
    private ImageView imageView;
    private ScaleGestureDetector scaleGestureDetector;
    private Matrix matrix = new Matrix();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gstfilling);
       // imageView = (ImageView)findViewById(R.id.imageView);
        //scaleGestureDetector = new ScaleGestureDetector(this,new ScaleListener());

        ZoomageView imageZoom = (ZoomageView)findViewById(R.id.myZoomageView);
    }


}
