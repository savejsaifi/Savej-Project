package com.avaskm.gstseva.activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.HashMap;
import java.util.Map;

public class PaymentActivity extends AppCompatActivity {
    Button payment;
    String cvv,edtmobile,edtuseremail,edtaddress,edtlandmark,edtpincode,edtaddress2,edtlandmark2,servicenam,textviewlifetyp,price,Giostate,pincode;
    String constitut,selectedstate,secaddress,selectedcity,statespinnertwo,itemcity;
    EditText edt_username,edt_mobile,edt_useremail,edt_address,edt_landmark,edt_pincode;
    EditText edt_address2,edt_landmark2;
    TextView TvPrice, TvLifeTime, TvState, TvSecState;
    String servicename,textviewlifetype,textView,textViewstate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        Intent intent = getIntent();
        String textviewlifetype = intent.getStringExtra("textviewlifetype");
        String textView = intent.getStringExtra("textView");
        String textViewstate = intent.getStringExtra("textViewstate");

         cvv = intent.getStringExtra("edt_username");
        edtmobile = intent.getStringExtra("edt_mobile");
        edtuseremail = intent.getStringExtra("edt_useremail");
        edtaddress = intent.getStringExtra("edt_address");
        edtlandmark = intent.getStringExtra("edt_landmark");
        edtpincode = intent.getStringExtra("edt_pincode");
        edtaddress2 = intent.getStringExtra("edt_address2");
        edtlandmark2 = intent.getStringExtra("edt_landmark2");
        servicenam = intent.getStringExtra("servicename");
        textviewlifetyp = intent.getStringExtra("textviewlifetype");
        price = intent.getStringExtra("textView");
        Giostate = intent.getStringExtra("textViewstate");
        pincode = intent.getStringExtra("edt_pincode");//constitution_spinner
        constitut = intent.getStringExtra("constitut");//SpinnerCountry
        selectedstate = intent.getStringExtra("selectedstate");//secaddress
        secaddress = intent.getStringExtra("secaddress");//selectedcity
        selectedcity = intent.getStringExtra("selectedcity");//state_spinner2
        statespinnertwo = intent.getStringExtra("statespinnertwo");//citySpinner2
        itemcity = intent.getStringExtra("itemcity");


      //  String

        intent.putExtra("textviewlifetype",textviewlifetype);
        intent.putExtra("textView",textView);
        intent.putExtra("textViewstate",textViewstate);
        payment = findViewById(R.id.payment);
        TvPrice = (TextView) findViewById(R.id.tv_price);
        TvLifeTime = (TextView) findViewById(R.id.tv_lifetime);
        TvState = (TextView) findViewById(R.id.tv_state);
        TvSecState = (TextView) findViewById(R.id.tvstate);
        TvPrice.setText(textView);
        TvLifeTime.setText(textviewlifetype);
        TvSecState.setText(textViewstate);

        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegisterApi();
                Intent intent1=new Intent(PaymentActivity.this,ThankspaymentActivity.class);
                startActivity(intent1);
            }
        });
    }
    public void RegisterApi(){
        //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
        final ProgressDialog dialog = ProgressDialog.show(PaymentActivity.this, "", "Loading....", false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.gstrequest, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responseP",response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray=new JSONArray(response);
                    JSONObject jsonObject=jsonArray.getJSONObject(0);
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");
                    if (code.equalsIgnoreCase("200")) {
                        //Toast.makeText(LoginAcitivity.this, ""+msg, Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(PaymentActivity.this, ThankspaymentActivity.class);
                        intent.putExtra("edt_username",edt_username.getText().toString());
                        intent.putExtra("edt_mobile",edt_mobile.getText().toString());
                        intent.putExtra("edt_useremail",edt_useremail.getText().toString());
                        intent.putExtra("edt_address",edt_address.getText().toString());
                        intent.putExtra("edt_landmark",edt_landmark.getText().toString());
                        intent.putExtra("edt_pincode",edt_pincode.getText().toString());
                        intent.putExtra("edt_address2",edt_address2.getText().toString());
                        intent.putExtra("edt_landmark2",edt_landmark2.getText().toString());
                        intent.putExtra("edt_username",edt_username.getText().toString());
                        intent.putExtra("edt_username",edt_username.getText().toString());
                        intent.putExtra("edt_username",edt_username.getText().toString());
                        intent.putExtra("edt_username",edt_username.getText().toString());
                        intent.putExtra("edt_username",edt_username.getText().toString());



                        intent.putExtra("textviewlifetype",textviewlifetype);
                        intent.putExtra("textView",textView);
                        intent.putExtra("textViewstate",textViewstate);
                        startActivity(intent);
                        Intent intent1=new Intent(PaymentActivity.this,ThankspaymentActivity.class);
                        startActivity(intent1);
                    } else {
                        Toast.makeText(PaymentActivity.this, "" + msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
            //key,userid,category_name,validity,price,geo_state,name,mobile_no,email,business_address,business_landmark,business_state,business_city,business_pincode,constitution,additional_address,additional_landmark,additional_state,additional_city
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                //params.put("userid",sessonManager.getUserid());
                params.put("userid","1");
                // Log.d("category_name",et_username_login.getText().toString());
                //params.put("category_name",sessonManager.getCategoryname());
                params.put("category_name",servicenam);
                //Log.d("price",et_password_login.getText().toString());
                //params.put("validity",sessonManager.getValidity());
                params.put("validity",textviewlifetyp);

                //params.put("price",sessonManager.getPrice());
                params.put("price",price);
                // params.put("geo_state",sessonManager.getCityname());
                params.put("geo_state",Giostate);
                params.put("name",cvv);
                params.put("mobile_no",edtmobile);
                params.put("email",edtuseremail);
                params.put("business_address",edtaddress);
                params.put("business_landmark",edtlandmark);
                params.put("business_state",selectedstate);//
                Log.d("businessstate","business_state");
                params.put("business_city",selectedcity);
                params.put("business_pincode",edtpincode);
                Log.d("pincode","pincode");
                params.put("constitution",constitut);
                Log.d("constitution","constitution");
                params.put("additional_address",secaddress);//
                params.put("additional_landmark",edtlandmark2);
                params.put("additional_state",statespinnertwo);
                params.put("additional_city",itemcity);
                Log.d("msgg",params.toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
    }
}
