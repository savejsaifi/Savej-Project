package com.avaskm.gstseva.model;
public class Customermodel {
    private String rupess;
    private String secondrupess;
    public Customermodel() {
    }
    public Customermodel(String rupess, String secondrupess) {
        this.rupess = rupess;
        this.secondrupess = secondrupess;
    }
    public String getRupess() {
        return rupess;
    }

    public void setRupess(String rupess) {
        this.rupess = rupess;
    }

    public String getSecondrupess() {
        return secondrupess;
    }
    public void setSecondrupess(String secondrupess) {
        this.secondrupess = secondrupess;
    }
}
