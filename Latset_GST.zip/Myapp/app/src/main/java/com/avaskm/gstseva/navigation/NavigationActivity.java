package com.avaskm.gstseva.navigation;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.RegistrationFragment;
import com.avaskm.gstseva.fragment.CompleteorderFragment;
import com.avaskm.gstseva.fragment.DocumentFragment;
import com.avaskm.gstseva.fragment.FeedbackFragment;
import com.avaskm.gstseva.fragment.Homefragment;
import com.avaskm.gstseva.fragment.MakepaymentFragment;
import com.avaskm.gstseva.fragment.MyDocumentFragment;
import com.avaskm.gstseva.fragment.OpenFragment;
import com.avaskm.gstseva.fragment.PartnerFragment;
import com.avaskm.gstseva.fragment.PendingFragment;
import com.avaskm.gstseva.fragment.ProfileFragment;

public class NavigationActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    int BackCounter;

    Snackbar snackbar;
    TextView TvMobileGuest;
    MenuItem OpenOrder, PendingOrder, CompleteOrder;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_navigation);
        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("GST SEVA");
        setSupportActionBar(toolbar);
        //toolbar.setTitleTextColor(Color.parseColor("#C09006"));
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        snackbar = Snackbar.make(drawer, "Press once again to exit!", Snackbar.LENGTH_LONG);
        NavigationView navigationView = findViewById(R.id.nav_view);
        displaySelectedScreen(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        OpenOrder = navigationView.getMenu().findItem(R.id.nav_open_order_nav);
        PendingOrder = navigationView.getMenu().findItem(R.id.nav_pending_order_event_nav);
        CompleteOrder = navigationView.getMenu().findItem(R.id.nav_complete_order_hotel_nav);
        OpenOrder.setVisible(false);
        PendingOrder.setVisible(false);
        CompleteOrder.setVisible(false);
        navigationView.setNavigationItemSelectedListener(this);

        displaySelectedScreen(R.id.nav_home);
        BackCounter = 0;

    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else if (BackCounter == 0) {
            if (snackbar.isShown()) {
                Intent a = new Intent(Intent.ACTION_MAIN);
                a.addCategory(Intent.CATEGORY_HOME);
                a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(a);
                super.onBackPressed();
            } else {
                snackbar.show();
            }
        } else {
            displaySelectedScreen(R.id.nav_home);
        }


    }


    /*  @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
*/


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    private boolean displaySelectedScreen(int itemId) {
        Fragment fragment = null;

        String title = getString(R.string.app_name);
        switch (itemId) {
            case R.id.nav_home:
                fragment = new Homefragment();
                BackCounter = 0;
                break;

            case R.id.nav_profile_nav:
                fragment = new ProfileFragment();
                BackCounter++;
                break;
            case R.id.nav_myorder_nav:
                if (!OpenOrder.isVisible() & !PendingOrder.isVisible() & !CompleteOrder.isVisible()) {
                    OpenOrder.setVisible(true);
                    PendingOrder.setVisible(true);
                    CompleteOrder.setVisible(true);
                } else {
                    OpenOrder.setVisible(false);
                    PendingOrder.setVisible(false);
                    CompleteOrder.setVisible(false);
                }

                return true;
            case R.id.nav_open_order_nav:
                fragment = new OpenFragment();
                BackCounter++;
                break;

            case R.id.nav_pending_order_event_nav:
                fragment = new PendingFragment();
                BackCounter++;
                break;

            case R.id.nav_complete_order_hotel_nav:
                fragment = new CompleteorderFragment();
                BackCounter++;
                break;
            case R.id.nav_document_nav:
                fragment = new DocumentFragment();
                BackCounter++;
                break;

            case R.id.nav_my_document_nav:
                fragment = new MyDocumentFragment();
                BackCounter++;
                break;
            case R.id.nav_make_payment_nav:
                fragment = new MakepaymentFragment();
                BackCounter++;
                break;
            case R.id.nav_feedback_nav:
                fragment = new FeedbackFragment();
                BackCounter++;
                break;

            case R.id.nav_share_nav:
                /*Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                intent.setType("text/plain");
                String shareBodyText = "Hey check out my app at: https://play.google.com/store/apps/details?id=com.avaskm.celeb.Celebration";
                intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject/Title");
                intent.putExtra(android.content.Intent.EXTRA_TEXT, shareBodyText);
                startActivity(Intent.createChooser(intent, "Choose sharing method"));*/
                BackCounter++;
                break;

            case R.id.nav_partner_nav:
                fragment = new PartnerFragment();
                BackCounter++;
                break;


            case R.id.nav_logout:
                AlertDialog.Builder builder1 = new AlertDialog.Builder(NavigationActivity.this);
                builder1.setMessage("Are you sure you want to logout?");
                builder1.setCancelable(false);
                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                SharedPreferences sharedPreferences2 = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                                sharedPreferences2.edit().clear().commit();
                                //sessonManager.setUserId("", "");
                                Intent intent = new Intent(NavigationActivity.this, RegistrationFragment.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                                startActivity(intent);
                                finish();
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                                return;

                            }
                        });

                AlertDialog alert11 = builder1.create();
                alert11.show();

                BackCounter++;
                break;


        }
        //replacing the fragment
        if (fragment != null) {
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.content_frame, fragment);
            ft.commit();
            // getSupportActionBar().setTitle(title);
        }
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return false;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        displaySelectedScreen(item.getItemId());
        return true;
    }


   /* @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_tools) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }*/
}
