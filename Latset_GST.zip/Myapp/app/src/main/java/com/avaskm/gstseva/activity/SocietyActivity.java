package com.avaskm.gstseva.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.avaskm.gstseva.R;

import java.util.ArrayList;
import java.util.List;

public class SocietyActivity extends AppCompatActivity {
    Spinner trustlimited;
    LinearLayout linearbillfirst,societylinearsecond;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_society);
        linearbillfirst=findViewById(R.id.linearsocietybillelectri);
        societylinearsecond=findViewById(R.id.societybillinear);
        addItemsOnSpinner2();
    }
    public void addItemsOnSpinner2() {

        trustlimited=findViewById(R.id.societypermissiontype);
        List<String> list = new ArrayList<String>();
        list.add("premises type");
        list.add("owned");
        list.add("rented/leased");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        trustlimited.setOnItemSelectedListener(new SocietyActivity.CustomOnItemSelectedListener());
        trustlimited.setAdapter(dataAdapter);
    }
    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener{

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            if (parent.getId() == R.id.societypermissiontype) {
                if (position == 1) {
                    linearbillfirst.setVisibility(View.VISIBLE);
                } else {
                    linearbillfirst.setVisibility(View.GONE);
                }
                if(position==2){
                    societylinearsecond.setVisibility(View.VISIBLE);
                }
                else{
                    societylinearsecond.setVisibility(View.GONE);
                }

            }

        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }
}
