package com.avaskm.gstseva.model;

import android.graphics.Bitmap;

public class PartnerLLP {

    public Bitmap imageMobile;
    public Bitmap getImageMobile() {
        return imageMobile;
    }

    public void setImageMobile(Bitmap imageMobile) {
        this.imageMobile = imageMobile;
    }

}
