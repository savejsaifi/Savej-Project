package com.avaskm.gstseva.fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.model.Customermodel;
import java.util.ArrayList;
public class CustomerorderFragment extends Fragment {
    RecyclerView RvWallet;
    ArrayList<Customermodel>arListWallet;
    CustomerAdapter adapter;
    String[]date={"27-06-2019","28-06-2019"};
    String[]TotalAmount={"₹ 110","₹ 250"};
    public CustomerorderFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_customerorder, container, false);
        RvWallet=(RecyclerView)view.findViewById(R.id.rv_wallet);
        arListWallet=new ArrayList<>();
        setRvWallet();
        return view;
    }

    private void setRvWallet(){
        RvWallet.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager=new GridLayoutManager(getContext(),1);
        RvWallet.setLayoutManager(layoutManager);
        arListWallet.clear();
        for(int i=0;i<date.length;i++){
            Customermodel model=new Customermodel();
            model.setRupess(date[i]);
            model.setSecondrupess(TotalAmount[i]);
            arListWallet.add(model);

        }
        adapter=new CustomerAdapter(arListWallet, getContext());
        RvWallet.setAdapter(adapter);

    }

    public class CustomerAdapter extends RecyclerView.Adapter<CustomerAdapter.ViewHolder>{
        ArrayList<Customermodel>arList;
        Context mContext;


        public CustomerAdapter(ArrayList<Customermodel> arList, Context mContext) {
            this.arList = arList;
            this.mContext = mContext;
        }
        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view=LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_row,viewGroup,false);
            ViewHolder viewHolder=new ViewHolder(view);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(@NonNull CustomerAdapter.ViewHolder viewHolder, int i) {
            viewHolder.Paydone.setText(arList.get(i).getRupess());

            viewHolder.paynow.setText(arList.get(i).getSecondrupess());
        }

        @Override
        public int getItemCount() {
            return 0;
        }
        public class ViewHolder extends RecyclerView.ViewHolder{
            TextView Paydone,paynow;


            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                Paydone=(TextView)itemView.findViewById(R.id.paymentdone);
                paynow=(TextView)itemView.findViewById(R.id.paynow);

            }
        }
    }

    }

