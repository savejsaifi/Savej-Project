package com.avaskm.gstseva.fragment;

import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.WevViewPDFFileActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.DocumentModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static android.content.Context.MODE_PRIVATE;


public class DocumentFragment extends Fragment {

    RecyclerView RvDocument;
    ArrayList<DocumentModel> arListDocument;
    DocumentAdapter adapter;

    SharedPreferences sharedPreferences;
    String userId;
    DownloadManager manager;
    private Dialog mDialogConfirmPopUp;
    Button btn_ok_pop_down_out_line;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_document, container, false);
        RvDocument = (RecyclerView) view.findViewById(R.id.rv_document);
        arListDocument = new ArrayList<>();
        sharedPreferences = getActivity().getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");
        setRvDocument();
        GetDocumentAPI();
        return view;

    }


    private void setRvDocument() {
        RvDocument.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 1);
        RvDocument.setLayoutManager(layoutManager);
        arListDocument.clear();


    }

    public class DocumentAdapter extends RecyclerView.Adapter<DocumentAdapter.ViewHolder> {

        ArrayList<DocumentModel> arList;
        Context mContext;

        public DocumentAdapter(Context context, ArrayList<DocumentModel> arrayList) {
            this.mContext = context;
            this.arList = arrayList;

        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_document, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            viewHolder.TvTitleName.setText(arList.get(i).getTitleName());
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {

            TextView TvTitleName, TvOpen, TvDonwload;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                TvTitleName = (TextView) itemView.findViewById(R.id.tv_title_name_document);
                TvOpen = (TextView) itemView.findViewById(R.id.tv_open_document);
                TvDonwload = (TextView) itemView.findViewById(R.id.tv_download_document);

                TvOpen.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DocumentModel model = arListDocument.get(getAdapterPosition());
                        String documentUrl = model.getDocumentURL();
                        Log.d("documentUrl", documentUrl);
                        Intent intent = new Intent(getActivity(), WevViewPDFFileActivity.class);
                        intent.putExtra("documentUrl", documentUrl);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                        startActivity(intent);

                    }
                });

                TvDonwload.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        DocumentModel model = arListDocument.get(getAdapterPosition());
                        String documentUrl = model.getDocumentURL();

                        manager = (DownloadManager) getActivity().getSystemService(Context.DOWNLOAD_SERVICE);
                        Uri uri = Uri.parse(documentUrl);
                        DownloadManager.Request request = new DownloadManager.Request(uri);
                        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                        Long refresh = manager.enqueue(request);
                        PopDownloadPDF();
                        //Toast.makeText(getActivity(), "Download successfully", Toast.LENGTH_SHORT).show();


                    }
                });
            }
        }


    }


    private void GetDocumentAPI() {
        final ProgressDialog dialog = ProgressDialog.show(getActivity(), "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetDocument, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetDocument", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    if (code.equalsIgnoreCase("200")) {
                        JSONArray dataArray = jsonObject.getJSONArray("data");
                        for (int i = 0; i < dataArray.length(); i++) {
                            DocumentModel model = new DocumentModel();
                            JSONObject dataObject = dataArray.getJSONObject(i);
                            model.setTitleName(dataObject.getString("category_name"));
                            model.setDocumentURL(dataObject.getString("document"));
                            arListDocument.add(model);

                        }
                        adapter = new DocumentAdapter(getActivity(), arListDocument);
                        RvDocument.setAdapter(adapter);
                    } else if (code.equalsIgnoreCase("401")) {
                        Toast.makeText(getActivity(), msg, Toast.LENGTH_SHORT).show();

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity());
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


    private void PopDownloadPDF() {
        {
            LayoutInflater inflater = LayoutInflater.from(getActivity());
            mDialogConfirmPopUp = new Dialog(getActivity(),
                    android.R.style.Theme_Translucent_NoTitleBar);
            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
            lp.dimAmount = 0.75f;
            mDialogConfirmPopUp.getWindow()
                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialogConfirmPopUp.getWindow();

            View dialoglayout = inflater.inflate(R.layout.pop_donwload, null);
            mDialogConfirmPopUp.setContentView(dialoglayout);

            btn_ok_pop_down_out_line = (Button) mDialogConfirmPopUp.findViewById(R.id.btn_ok_pop_down_out_line);
            btn_ok_pop_down_out_line.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mDialogConfirmPopUp.dismiss();
                }
            });
            mDialogConfirmPopUp.show();
        }
    }



}
