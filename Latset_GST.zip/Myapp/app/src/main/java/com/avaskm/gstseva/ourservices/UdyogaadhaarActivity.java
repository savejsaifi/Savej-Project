package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.navigation.MainsecActivity;
import com.avaskm.gstseva.navigation.NavigationActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UdyogaadhaarActivity extends AppCompatActivity {

    TextView TvPrice;
    EditText EtAadhar, EtName, EtNameOfEnterPrise, EtPanNo, EtOfficeLocation, EtEmail, EtMobile, EtBankAccountNo, EtIFSC, EtNoOfEmployee, EtDetailAboutBusiness, EtStarting, EtDate;
    Spinner SpnGender, SpnPhsicallyYesNo, SpnTypeOriganisation, SpnSocialCategory;
    String genderType[] = {"Select gender", "Male", "Female"};
    String[] phsicallyYesNoType = {"Select phsically handicapped", "No", "Yes"};
    String[] typeOfOrganisation = {"Type of organisation", "Proprietor", "Shopkeeper", "Pvt Ltd", "Huf/co-operative", "Trust", "Society"};
    String[] socialCategoryType = {"Select social category", "GENERAL", "OBC", "SC", "ST"};
    String gender, phsically, typeOfOrganis, socialCategory, price, orderid,title;
    Button BtnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_udyogaadhaar);

        EtAadhar = (EditText) findViewById(R.id.et_aadhar_no_udyog);
        EtName = (EditText) findViewById(R.id.et_name_udyog);
        EtNameOfEnterPrise = (EditText) findViewById(R.id.et_name_enterprise_udyog);
        EtPanNo = (EditText) findViewById(R.id.et_pan_no_udyog);
        EtOfficeLocation = (EditText) findViewById(R.id.et_office_location_udyog);
        EtEmail = (EditText) findViewById(R.id.et_email_udyog);
        EtMobile = (EditText) findViewById(R.id.et_mobile_udyog);
        EtBankAccountNo = (EditText) findViewById(R.id.et_bank_udyog);
        EtIFSC = (EditText) findViewById(R.id.et_ifsc_code_udyog);
        EtNoOfEmployee = (EditText) findViewById(R.id.et_employee_code_udyog);
        EtDetailAboutBusiness = (EditText) findViewById(R.id.et_detail_about_business_udyog);
        EtStarting = (EditText) findViewById(R.id.et_starting_investment_udyog);
        EtDate = (EditText) findViewById(R.id.et_date_udyog);

        TvPrice = (TextView) findViewById(R.id.tv_price_udyog);
        BtnSubmit = (Button) findViewById(R.id.btn_submit_udyog);


        SpnGender = (Spinner) findViewById(R.id.spn_gender_udyog);
        SpnPhsicallyYesNo = (Spinner) findViewById(R.id.spn_phsically_handicapped_udyog);
        SpnTypeOriganisation = (Spinner) findViewById(R.id.spn_origanisation_udyog);
        SpnSocialCategory = (Spinner) findViewById(R.id.spn_social_category_udyog);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");
        SpnGender.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                gender = String.valueOf(SpnGender.getItemAtPosition(i));
                Log.d("gender", gender);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        SpnPhsicallyYesNo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                phsically = String.valueOf(SpnPhsicallyYesNo.getItemAtPosition(i));
                Log.d("phsically", phsically);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        SpnTypeOriganisation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                typeOfOrganis = String.valueOf(SpnTypeOriganisation.getItemAtPosition(i));
                Log.d("typeOfOrganis", typeOfOrganis);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        SpnSocialCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {


                socialCategory = String.valueOf(SpnSocialCategory.getItemAtPosition(i));
                Log.d("socialCategory", socialCategory);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> countTablet = new ArrayAdapter<String>(UdyogaadhaarActivity.this, android.R.layout.simple_spinner_dropdown_item, genderType);
        SpnGender.setAdapter(countTablet);

        ArrayAdapter<String> phsicallyAdapter = new ArrayAdapter<String>(UdyogaadhaarActivity.this, android.R.layout.simple_spinner_dropdown_item, phsicallyYesNoType);
        SpnPhsicallyYesNo.setAdapter(phsicallyAdapter);


        ArrayAdapter<String> typeOrganisationAdapter = new ArrayAdapter<String>(UdyogaadhaarActivity.this, android.R.layout.simple_spinner_dropdown_item, typeOfOrganisation);
        SpnTypeOriganisation.setAdapter(typeOrganisationAdapter);

        ArrayAdapter<String> SocialCategoryAdapter = new ArrayAdapter<String>(UdyogaadhaarActivity.this, android.R.layout.simple_spinner_dropdown_item, socialCategoryType);
        SpnSocialCategory.setAdapter(SocialCategoryAdapter);
        GetCategoryInForAPI();
    }


    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(UdyogaadhaarActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("UdyogaadhaarActivity", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    price = dataObject.getString("price");
                    TvPrice.setText(price);
                    //Log.d("price",price);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("category", title);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(UdyogaadhaarActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }

    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(UdyogaadhaarActivity.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("MakeOrderww", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                    Log.d("sssorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(UdyogaadhaarActivity.this, ITRFillingUploadFormActivity.class);
                        intent.putExtra("orderid", orderid);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(UdyogaadhaarActivity.this, msg, Toast.LENGTH_SHORT).show();

                    } else {
                        Intent intent = new Intent(UdyogaadhaarActivity.this, NavigationActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(UdyogaadhaarActivity.this, msg, Toast.LENGTH_SHORT).show();


                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", "2");
                params.put("category", title);
                params.put("price", price);
                params.put("firm_name", EtNameOfEnterPrise.getText().toString());
                params.put("aadhaar", EtAadhar.getText().toString());
                params.put("pan", EtPanNo.getText().toString());
                params.put("mobile", EtMobile.getText().toString());
                params.put("email", EtEmail.getText().toString());
                params.put("name", EtName.getText().toString());
                params.put("category_other", socialCategory);
                params.put("gender", gender);
                params.put("handicapped", phsically);
                params.put("organization_type", typeOfOrganis);
                params.put("incorporation_date", EtDate.getText().toString());
                params.put("office_location", EtOfficeLocation.getText().toString());
                params.put("bank_account", EtBankAccountNo.getText().toString());
                params.put("ifsc", EtIFSC.getText().toString());
                params.put("num_employee", EtNoOfEmployee.getText().toString());
                params.put("business_details", EtDetailAboutBusiness.getText().toString());
                params.put("starting_investment", EtStarting.getText().toString());
                params.put("price", TvPrice.getText().toString());

                Log.d("allItr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(UdyogaadhaarActivity.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
