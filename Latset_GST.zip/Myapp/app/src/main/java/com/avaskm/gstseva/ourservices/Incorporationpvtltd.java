package com.avaskm.gstseva.ourservices;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.activity.PrivateLimitedActivity;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.ExtraLicenseModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Incorporationpvtltd extends AppCompatActivity {

    Spinner SpnNoOfDirector,spinnertwo;
    String[] NoOfDirector = {"Select no of director", "2", "3", "4", "5", "6", "7"};
    String[] PrimisesOwned = {"Select primises type", "Rented", "Owned"};

    LinearLayout LinearTow, LinearThree, LinearFour, LinearFive, LinearSix, LinearSiven;
    String noOfDirectorType, primisesType, orderid, price, ExtraPirce, name, perdirectorprice, title,formId;


    String SecondMobille, SecondEmail, ThreeMobile, ThreeEMail, FourMobile, FourEmail, FiveMobile, FiveEmail, SixMobile, SixEmail, SevenMobile, SevenEmail;
    TextView TvPrice, TvExtra, TvOk;

    EditText EtTypeOne, EtTypeTwo, EtTypeThree, EtTypeFour, EtTypeFive, EtBusinessDiscription, EtBusinessAddress, EtCoEmail;

    EditText EtMobileFirstSecond, EtMobileSecondSecond, EtEmailFirstSecond, EtEmailSecondSecond,
            EtMobileFirstThree, EtMobileSecondThree, EtMobileThreeThree, EtEmailFirstThree, EtEmailSecondThree, EtEmailThreeThree,
            EtMobileFirstFour, EtMobileSecondFour, EtMobileThreeFour, EtMobileFourFour, EtEmailFirstFour, EtEmailSecondFour, EtEmailThreeFour, EtEmailFourFour,
            EtMobileFirstFive, EtMobileSecondFive, EtMobileThreeFive, EtMobileFourFive, EtMObileFiveFive, EtEmailFirstFive, EtEmailSecondFive, EtEmailThreeFive, EtEmailFourFive, EtEmailFiveFive,
            EtMobileFirstSix, EtMobileSecondSix, EtMobileThreeSix, EtMobileFourSix, EtMobileFiveSix, EtMobileSixSix,
            EtEmailFirstSix, EtEmailSecondSix, EtEmailThreeSix, EtEmailFourSix, EtEmailFiveSix, EtEmailSixSix,
            EtMobileFirstSeven, EtMobileSecondSeven, EtMobileThreeSeven, EtMobileFourSeven, EtMobileFiveSeven, EtMobileSixSeven, EtMobileSevenSeven,
            EtEmailFirstSeven, EtEmailSecondSeven, EtEmailThreeSeven, EtEmailFourSeven, EtEmailFiveSeven, EtEmailSixSeven, EtEmailSevenSeven;

    String premiseType = "";

    Button BtnSubmit;
    private Dialog mDialogConfirmPopUp;

    RecyclerView RvExtra;
    ExtraLinecseRequiredAdapter adapter;
    ArrayList<ExtraLicenseModel> arListExtra = new ArrayList<>();

    List<String> extraitems = new ArrayList<>();
    int extraprice = 0;
    int directorsprice = 0;
    int setprice = 0, TotalResult;

    SharedPreferences sharedPreferences;
    String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incorporationpvtltd);

        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        SpnNoOfDirector = (Spinner) findViewById(R.id.spn_no_of_director);

        addListenerOnSpinnerItemSelection();

        LinearTow = (LinearLayout) findViewById(R.id.linear_two);
        LinearThree = (LinearLayout) findViewById(R.id.linear_three);
        LinearFour = (LinearLayout) findViewById(R.id.linear_four);
        LinearFive = (LinearLayout) findViewById(R.id.linear_five);
        LinearSix = (LinearLayout) findViewById(R.id.linear_six);
        LinearSiven = (LinearLayout) findViewById(R.id.linear_siven);

        EtTypeOne = (EditText) findViewById(R.id.et_type_one);
        EtTypeTwo = (EditText) findViewById(R.id.et_type_two);
        EtTypeThree = (EditText) findViewById(R.id.et_type_three);
        EtTypeFour = (EditText) findViewById(R.id.et_type_four);
        EtTypeFive = (EditText) findViewById(R.id.et_type_five);
        EtBusinessDiscription = (EditText) findViewById(R.id.et_business_discription);
        EtBusinessAddress = (EditText) findViewById(R.id.et_business_address);
        EtCoEmail = (EditText) findViewById(R.id.et_co_email);
        TvPrice = (TextView) findViewById(R.id.tv_price_incorporation);
        TvExtra = (TextView) findViewById(R.id.tv_extra_license);
        BtnSubmit = (Button) findViewById(R.id.btn_submit_incorporation_pvt_ltd);

        EtMobileFirstSecond = (EditText) findViewById(R.id.et_mobile_first_second);
        EtMobileSecondSecond = (EditText) findViewById(R.id.et_mobile_second_second);
        EtEmailFirstSecond = (EditText) findViewById(R.id.et_email_first_second);
        EtEmailSecondSecond = (EditText) findViewById(R.id.et_email_second_second);

        EtMobileFirstThree = (EditText) findViewById(R.id.et_mobile_first_three);
        EtMobileSecondThree = (EditText) findViewById(R.id.et_mobile_second_three);
        EtMobileThreeThree = (EditText) findViewById(R.id.et_mobile_three_three);
        EtEmailFirstThree = (EditText) findViewById(R.id.et_email_first_three);
        EtEmailSecondThree = (EditText) findViewById(R.id.et_email_second_three);
        EtEmailThreeThree = (EditText) findViewById(R.id.et_email_three_three);

        EtMobileFirstFour = (EditText) findViewById(R.id.et_mobile_first_four);
        EtMobileSecondFour = (EditText) findViewById(R.id.et_mobile_second_four);
        EtMobileThreeFour = (EditText) findViewById(R.id.et_mobile_three_four);
        EtMobileFourFour = (EditText) findViewById(R.id.et_mobile_four_four);
        EtEmailFirstFour = (EditText) findViewById(R.id.et_email_first_four);
        EtEmailSecondFour = (EditText) findViewById(R.id.et_email_second_four);
        EtEmailThreeFour = (EditText) findViewById(R.id.et_email_three_four);
        EtEmailFourFour = (EditText) findViewById(R.id.et_email_four_four);

        EtMobileFirstFive = (EditText) findViewById(R.id.et_mobile_first_five);
        EtMobileSecondFive = (EditText) findViewById(R.id.et_mobile_second_five);
        EtMobileThreeFive = (EditText) findViewById(R.id.et_mobile_three_five);
        EtMobileFourFive = (EditText) findViewById(R.id.et_mobile_four_five);
        EtMObileFiveFive = (EditText) findViewById(R.id.et_mobile_five_five);
        EtEmailFirstFive = (EditText) findViewById(R.id.et_email_first_five);
        EtEmailSecondFive = (EditText) findViewById(R.id.et_email_second_five);
        EtEmailThreeFive = (EditText) findViewById(R.id.et_email_three_five);
        EtEmailFourFive = (EditText) findViewById(R.id.et_email_four_five);
        EtEmailFiveFive = (EditText) findViewById(R.id.et_email_five_five);

        EtMobileFirstSix = (EditText) findViewById(R.id.et_mobile_first_six);
        EtMobileSecondSix = (EditText) findViewById(R.id.et_mobile_second_six);
        EtMobileThreeSix = (EditText) findViewById(R.id.et_mobile_three_six);
        EtMobileFourSix = (EditText) findViewById(R.id.et_mobile_four_six);
        EtMobileFiveSix = (EditText) findViewById(R.id.et_mobile_five_six);
        EtMobileSixSix = (EditText) findViewById(R.id.et_mobile_six_six);
        EtEmailFirstSix = (EditText) findViewById(R.id.et_email_first_six);
        EtEmailSecondSix = (EditText) findViewById(R.id.et_email_second_six);
        EtEmailThreeSix = (EditText) findViewById(R.id.et_email_three_six);
        EtEmailFourSix = (EditText) findViewById(R.id.et_email_four_six);
        EtEmailFiveSix = (EditText) findViewById(R.id.et_email_five_six);
        EtEmailSixSix = (EditText) findViewById(R.id.et_email_six_six);
        EtMobileFirstSeven = (EditText) findViewById(R.id.et_mobile_first_seven);
        EtMobileSecondSeven = (EditText) findViewById(R.id.et_mobile_second_seven);
        EtMobileThreeSeven = (EditText) findViewById(R.id.et_mobile_three_seven);
        EtMobileFourSeven = (EditText) findViewById(R.id.et_mobile_four_seven);
        EtMobileFiveSeven = (EditText) findViewById(R.id.et_mobile_five_seven);
        EtMobileSixSeven = (EditText) findViewById(R.id.et_mobile_six_seven);
        EtMobileSevenSeven = (EditText) findViewById(R.id.et_mobile_seven_seven);
        EtEmailFirstSeven = (EditText) findViewById(R.id.et_email_first_seven);
        EtEmailSecondSeven = (EditText) findViewById(R.id.et_email_second_seven);
        EtEmailThreeSeven = (EditText) findViewById(R.id.et_email_three_seven);
        EtEmailFourSeven = (EditText) findViewById(R.id.et_email_four_seven);
        EtEmailFiveSeven = (EditText) findViewById(R.id.et_email_five_seven);
        EtEmailSixSeven = (EditText) findViewById(R.id.et_email_six_seven);
        EtEmailSevenSeven = (EditText) findViewById(R.id.et_email_seven_seven);

        Intent intent = getIntent();
        title = intent.getStringExtra("title");


        SpnNoOfDirector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                noOfDirectorType = String.valueOf(SpnNoOfDirector.getItemAtPosition(i));
                Log.d("noOfDirectorType", noOfDirectorType);
                ((TextView) adapterView.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));

                if (noOfDirectorType.equalsIgnoreCase("2")) {
                    LinearTow.setVisibility(View.VISIBLE);
                    LinearThree.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice);
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);

                } else if (noOfDirectorType.equalsIgnoreCase("3")) {
                    LinearThree.setVisibility(View.VISIBLE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice) * 1;
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);
                } else if (noOfDirectorType.equalsIgnoreCase("4")) {
                    LinearFour.setVisibility(View.VISIBLE);
                    LinearThree.setVisibility(View.GONE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice) * 2;
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);
                } else if (noOfDirectorType.equalsIgnoreCase("Select no of director")) {
                    LinearThree.setVisibility(View.GONE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                } else if (noOfDirectorType.equalsIgnoreCase("5")) {
                    LinearFive.setVisibility(View.VISIBLE);
                    LinearThree.setVisibility(View.GONE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice) * 3;
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);
                } else if (noOfDirectorType.equalsIgnoreCase("6")) {
                    LinearSix.setVisibility(View.VISIBLE);
                    LinearThree.setVisibility(View.GONE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSiven.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice) * 4;
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);
                } else if (noOfDirectorType.equalsIgnoreCase("7")) {
                    LinearSiven.setVisibility(View.VISIBLE);
                    LinearThree.setVisibility(View.GONE);
                    LinearTow.setVisibility(View.GONE);
                    LinearFour.setVisibility(View.GONE);
                    LinearFive.setVisibility(View.GONE);
                    LinearSix.setVisibility(View.GONE);
                    directorsprice = Integer.parseInt(perdirectorprice) * 5;
                    setprice = Integer.parseInt(price) + extraprice + directorsprice;
                    TvPrice.setText("" + setprice);
                }
//                System.out.println(price);


                Log.d("directorsprice", String.valueOf(directorsprice));


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        ArrayAdapter<String> noOfDirectorAdapter = new ArrayAdapter<String>(Incorporationpvtltd.this, android.R.layout.simple_spinner_dropdown_item, NoOfDirector);
        SpnNoOfDirector.setAdapter(noOfDirectorAdapter);


        TvExtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDialogConfirmPopUp.show();
                //  IncorporationGetCategoryApi();
            }
        });


        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (setSubmit()) {

                }
            }
        });

        IncorporationGetCategoryApi();
        ExtraPop();
    }

    public void addListenerOnSpinnerItemSelection() {
        spinnertwo = findViewById(R.id.permissiontype_inc_pvt);
        spinnertwo.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }

    public class CustomOnItemSelectedListener implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            if (parent.getId() == R.id.permissiontype_inc_pvt) {


                if (position == 1) {
                    premiseType = "owned";


                } else if (position == 2) {
                    premiseType = "rented / leased";


                } else {
                    premiseType = "premises type";
                }


            }


        }

        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
    }


    private boolean setOneType() {
        if (EtTypeOne.getText().toString().length() > 0) {
            return true;

        } else {
            EtTypeOne.setError("Please enter type 1 proposed complany name");
            return false;
        }
    }

    private boolean setTwoType() {
        if (EtTypeTwo.getText().toString().length() > 0) {
            return true;

        } else {
            EtTypeTwo.setError("Please enter type 2 proposed complany name");
            return false;
        }
    }

    private boolean setThreeType() {
        if (EtTypeThree.getText().toString().length() > 0) {
            return true;

        } else {
            EtTypeThree.setError("Please enter type 3 proposed complany name");
            return false;
        }
    }

    private boolean setFourType() {
        if (EtTypeFour.getText().toString().length() > 0) {
            return true;

        } else {
            EtTypeFour.setError("Please enter type 4 proposed complany name");
            return false;
        }
    }

    private boolean setFiveType() {
        if (EtTypeFive.getText().toString().length() > 0) {
            return true;

        } else {
            EtTypeFive.setError("Please enter type 5 proposed complany name");
            return false;
        }
    }


    private boolean setSelectNoOfDirector() {
        if (!noOfDirectorType.equalsIgnoreCase("Select no of director")) {
            return true;
        } else {
            Toast.makeText(Incorporationpvtltd.this, "Please select no of director", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setBusinessDes() {
        if (EtBusinessDiscription.getText().toString().length() > 0) {
            return true;

        } else {
            EtBusinessDiscription.setError("Please enter business description");
            return false;
        }
    }


    private boolean setBusinessAddress() {
        if (EtBusinessAddress.getText().toString().length() > 0) {
            return true;
        } else {
            EtBusinessAddress.setError("Please enter business address");
            return false;
        }
    }

    private boolean setCoEmail() {
        if (EtCoEmail.getText().toString().length() > 0) {
            return true;
        } else {
            EtCoEmail.setError("Please enter co email id");
            return false;
        }
    }


    private boolean setExtra() {
        if (!TvExtra.getText().toString().equalsIgnoreCase("Extra license required?")) {
            return true;
        } else {
            Toast.makeText(Incorporationpvtltd.this, "Please select extra license required?", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    private boolean setPremises(){
        if(!premiseType.equalsIgnoreCase("premises type")){
            return true;
        }else {
            Toast.makeText(this, "Please select Premises type", Toast.LENGTH_SHORT).show();
            return false;
        }
    }

    private boolean setSubmit() {
        if (!setOneType()) {
            return false;
        } else if (!setTwoType()) {
            return false;

        } else if (!setThreeType()) {
            return false;
        } else if (!setFourType()) {
            return false;
        } else if (!setFiveType()) {
            return false;
        } else if (!setSelectNoOfDirector()) {
            return false;
        } else if (!setBusinessDes()) {
            return false;
        } else if (!setBusinessAddress()) {
            return false;
        } else if (!setCoEmail()) {
            return false;
        } else if (!setExtra()) {
            return false;
        }else if(!setPremises()){
            return false;

        }

        MakeOrderAPI();
        return true;

    }

    private void ExtraPop() {
        {
            LayoutInflater inflater = LayoutInflater.from(Incorporationpvtltd.this);
            mDialogConfirmPopUp = new Dialog(Incorporationpvtltd.this,
                    android.R.style.Theme_Translucent_NoTitleBar);
            mDialogConfirmPopUp.setCanceledOnTouchOutside(false);
            mDialogConfirmPopUp.getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.MATCH_PARENT);
            mDialogConfirmPopUp.getWindow().setGravity(Gravity.CENTER);
            final WindowManager.LayoutParams lp = mDialogConfirmPopUp.getWindow().getAttributes();
            lp.dimAmount = 0.75f;
            mDialogConfirmPopUp.getWindow()
                    .addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            mDialogConfirmPopUp.requestWindowFeature(Window.FEATURE_NO_TITLE);
            mDialogConfirmPopUp.getWindow();

            View dialoglayout = inflater.inflate(R.layout.pop_extra_license_incorporation, null);
            mDialogConfirmPopUp.setContentView(dialoglayout);
            RvExtra = (RecyclerView) mDialogConfirmPopUp.findViewById(R.id.rv_extra_license);
            TvOk = (TextView) mDialogConfirmPopUp.findViewById(R.id.tv_ok_pop_extra);

            TvOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (extraitems.size() > 0) {
                        StringBuilder csvBuilder = new StringBuilder();
                        for (String item : extraitems) {
                            csvBuilder.append(item);
                            csvBuilder.append(",");
                        }
                        String extra_items = csvBuilder.toString();

                        extra_items = extra_items.substring(0, extra_items.length() - ",".length());
                        TvExtra.setText(extra_items);


                    } else {
                        TvExtra.setText("Extra license required?");
                    }
                    //extraitems.clear();
//                    System.out.println(Integer.parseInt(price));
                   /*setprice = extraprice + directorsprice;
                    TvPrice.setText(setprice);*/
                    mDialogConfirmPopUp.dismiss();
                }
            });


            RvExtra.setHasFixedSize(true);
            RecyclerView.LayoutManager layoutManager = new GridLayoutManager(Incorporationpvtltd.this, 1);
            RvExtra.setLayoutManager(layoutManager);
            arListExtra.clear();


        }
    }


    public class ExtraLinecseRequiredAdapter extends RecyclerView.Adapter<ExtraLinecseRequiredAdapter.ViewHolder> {

        Context mContext;
        ArrayList<ExtraLicenseModel> arList;

        public ExtraLinecseRequiredAdapter(Context mContext, ArrayList<ExtraLicenseModel> arList) {
            this.mContext = mContext;
            this.arList = arList;
        }


        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_extra_license, viewGroup, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
            viewHolder.TvName.setText(arList.get(i).getName());
        }

        @Override
        public int getItemCount() {
            return arList.size();
        }

        public class ViewHolder extends RecyclerView.ViewHolder {
            TextView TvName;
            CheckBox CbExtra;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                CbExtra = (CheckBox) itemView.findViewById(R.id.cb_extra);
                TvName = (TextView) itemView.findViewById(R.id.tv_name_extra);
                CbExtra.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ExtraLicenseModel model = arListExtra.get(getAdapterPosition());
                        ExtraPirce = model.getPrice();
                        name = model.getName();
                        if (CbExtra.isChecked()) {
                            extraitems.add(name);
                            extraprice = extraprice + Integer.parseInt(ExtraPirce);
                            Log.d("extraprice", String.valueOf(extraprice));
                        } else {
                            extraitems.remove(extraitems.indexOf(name));
                            extraprice = extraprice - Integer.parseInt(ExtraPirce);
                            Log.d("extraprice", String.valueOf(extraprice));
                        }

                        setprice = Integer.parseInt(price) + extraprice + directorsprice;
                        TvPrice.setText("" + setprice);
//                        int result = extraprice;
//                        Log.d("result", String.valueOf(result));
//                        TotalResult = Integer.parseInt(price) + result;
//                        Log.d("TotalResult", String.valueOf(TotalResult));
//                        TvPrice.setText("" + TotalResult);
                    }
                });


            }
        }

    }


    private void IncorporationGetCategoryApi() {
        final ProgressDialog dialog1 = ProgressDialog.show(Incorporationpvtltd.this, "", "Loading....", false);
        RequestQueue queue = Volley.newRequestQueue(Incorporationpvtltd.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                Log.d("responIncorporation", response);
                dialog1.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    price = dataObject.getString("price");
                    perdirectorprice = dataObject.getString("addtionalprice");

                    TvPrice.setText(price);
                    JSONArray categoryArray = dataObject.getJSONArray("categories");
                    for (int i = 0; i < categoryArray.length(); i++) {
                        ExtraLicenseModel model = new ExtraLicenseModel();
                        JSONObject categoryObject = categoryArray.getJSONObject(i);
                        String name = categoryObject.getString("name");
                        model.setName(categoryObject.getString("name"));
                        model.setPrice(categoryObject.getString("price"));
                        arListExtra.add(model);
                    }
                    adapter = new ExtraLinecseRequiredAdapter(Incorporationpvtltd.this, arListExtra);
                    RvExtra.setAdapter(adapter);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Incorporationpvtltd.this, "state list are not availbale", Toast.LENGTH_SHORT).show();
                dialog1.dismiss();
            }
        }) {
            protected Map<String, String> getParams() {
                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("key", Api.key);
                hashMap.put("category", title);


                return hashMap;
            }
        };
        queue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(Incorporationpvtltd.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("Incorporationpvtltdnse", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    orderid = dataObject.getString("orderid");
                  //  formId = dataObject.getString("form_id");
                    Log.d("Insurancorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(Incorporationpvtltd.this, IncorporationpvtltdUploadFormActivity.class);
                        intent.putExtra("orderid", orderid);
                        intent.putExtra("premises", premiseType);
                        //intent.putExtra("formId", formId);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                params.put("userid", userId);
                params.put("category", title);
                params.put("proposed1", EtTypeOne.getText().toString());
                params.put("proposed2", EtTypeTwo.getText().toString());
                params.put("proposed3", EtTypeThree.getText().toString());
                params.put("proposed4", EtTypeFour.getText().toString());
                params.put("proposed5", EtTypeFive.getText().toString());
                params.put("no_of_dir", noOfDirectorType);

                if (noOfDirectorType.equalsIgnoreCase("2")) {
                    SecondMobille = EtMobileFirstSecond.getText().toString() + "," + EtMobileSecondSecond.getText().toString();
                    params.put("dir_mobiles", SecondMobille);
                    SecondEmail = EtEmailFirstSecond.getText().toString() + "," + EtEmailSecondSecond.getText().toString();
                    params.put("dir_emails", SecondEmail);
                } else if (noOfDirectorType.equalsIgnoreCase("3")) {
                    ThreeMobile = EtMobileFirstThree.getText().toString() + "," + EtMobileSecondThree.getText().toString() + "," + EtMobileThreeThree.getText().toString();
                    params.put("dir_mobiles", ThreeMobile);
                    ThreeEMail = EtEmailFirstThree.getText().toString() + "," + EtEmailSecondThree.getText().toString() + "," + EtEmailThreeThree.getText().toString();
                    params.put("dir_emails", ThreeEMail);
                } else if (noOfDirectorType.equalsIgnoreCase("4")) {
                    FourMobile = EtMobileFirstFour.getText().toString() + "," + EtMobileSecondFour.getText().toString() + "," + EtMobileThreeFour.getText().toString() + "," + EtMobileFourFour.getText().toString();
                    params.put("dir_mobiles", FourMobile);
                    FourEmail = EtEmailFirstFour.getText().toString() + "," + EtEmailSecondFour.getText().toString() + "," + EtEmailThreeFour.getText().toString() + "," + EtEmailFourFour.getText().toString();
                    params.put("dir_emails", FourEmail);
                } else if (noOfDirectorType.equalsIgnoreCase("5")) {
                    FiveMobile = EtMobileFirstFive.getText().toString() + "," + EtMobileSecondFive.getText().toString() + "," + EtMobileThreeFive.getText().toString() + "," + EtMobileFourFive.getText().toString() + "," + EtMObileFiveFive.getText().toString();
                    params.put("dir_mobiles", FiveMobile);
                    FiveEmail = EtEmailFirstFive.getText().toString() + "," + EtEmailSecondFive.getText().toString() + "," + EtEmailThreeFive.getText().toString() + "," + EtEmailFourFive.getText().toString() + "," + EtEmailFiveFive.getText().toString();
                    params.put("dir_emails", FiveEmail);
                } else if (noOfDirectorType.equalsIgnoreCase("6")) {
                    SixMobile = EtMobileFirstSix.getText().toString() + "," + EtMobileSecondSix.getText().toString() + "," + EtMobileThreeSix.getText().toString() + "," + EtMobileFiveSix.getText().toString() + "," + EtMobileSixSix.getText().toString();
                    params.put("dir_mobiles", SixMobile);
                    SixEmail = EtEmailFirstSix.getText().toString() + "," + EtEmailSecondSix.getText().toString() + "," + EtEmailThreeSix.getText().toString() + "," + EtEmailFourSix.getText().toString() + "," + EtEmailFiveSix.getText().toString() + "," + EtEmailSixSix.getText().toString() +
                            params.put("dir_emails", SixEmail);
                } else if (noOfDirectorType.equalsIgnoreCase("7")) {
                    SevenMobile = EtMobileFirstSeven.getText().toString() + "," + EtMobileSecondSeven.getText().toString() + "," + EtMobileThreeSeven.getText().toString() + "," + EtMobileFourSeven.getText().toString() + "," + EtMobileFiveSeven.getText().toString() + "," + EtMobileSixSeven.getText().toString() + "," + EtMobileSevenSeven.getText().toString();
                    params.put("dir_mobiles", SevenMobile);
                    SevenEmail = EtEmailFirstSeven.getText().toString() + "," + EtEmailSecondSeven.getText().toString() + "," + EtEmailThreeSeven.getText().toString() + "," + EtEmailFourSeven.getText().toString() + "," + EtEmailFiveSeven.getText().toString() + "," + EtEmailSixSeven.getText().toString() + "," + EtEmailSevenSeven.getText().toString();
                    params.put("dir_emails", SevenEmail);
                }


                params.put("business_description", EtBusinessDiscription.getText().toString());
                params.put("business_address", EtBusinessAddress.getText().toString());
                params.put("company_email", EtCoEmail.getText().toString());
                //params.put("premise_type", primisesType);
                params.put("extra_requirements", TvExtra.getText().toString());
                params.put("price", TvPrice.getText().toString());
                params.put("premises_type", premiseType);
                Log.d("allIqwtr", String.valueOf(params));

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(Incorporationpvtltd.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
