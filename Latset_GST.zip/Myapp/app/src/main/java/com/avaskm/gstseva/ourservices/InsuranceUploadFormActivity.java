package com.avaskm.gstseva.ourservices;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.avaskm.gstseva.R;

public class InsuranceUploadFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insurance_upload_form);

        Intent intent=getIntent();
        String orderid=intent.getStringExtra("orderid");
        Log.d("orderidIns",orderid);
    }
}
