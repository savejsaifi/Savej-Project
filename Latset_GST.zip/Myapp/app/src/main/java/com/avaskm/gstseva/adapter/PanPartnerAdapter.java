package com.avaskm.gstseva.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.model.PartnerLLP;
import java.util.ArrayList;

public class PanPartnerAdapter extends RecyclerView.Adapter<PanPartnerAdapter.ListViewHolder> {
    ArrayList<PartnerLLP> list;
    Context context;

    public PanPartnerAdapter(ArrayList<PartnerLLP> list, Context context) {
        this.context = context;
        this.list = list;
    }

    @Override
    public PanPartnerAdapter.ListViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.row_deed_partner, null);

        return new PanPartnerAdapter.ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PanPartnerAdapter.ListViewHolder holder, final int position) {
        final PartnerLLP imageModel = list.get(position);
        holder.image.setImageBitmap(imageModel.getImageMobile());
        holder.close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeAt(position);
            }
        });
    }

    public void removeAt(int position) {
        list.remove(position);
        notifyItemRemoved(position);
        notifyItemChanged(position);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    class ListViewHolder extends RecyclerView.ViewHolder {

        ImageView image;
        TextView close;

        public ListViewHolder(View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.ivGallery);
            close = itemView.findViewById(R.id.badge_view);
        }

    }
}