package com.avaskm.gstseva.activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.model.Partnerllb;
import java.util.ArrayList;

import android.content.Intent;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.PopupMenu;


public class PartnerLLBActivity extends AppCompatActivity {
    private ArrayList<Partnerllb> arLIstPartner;
    private RecyclerView recyclerView;
    private Partneradapter mAdapter;
     String[] name={"Jyoti","Kavita","HHhhhh","dhfhd","fgg","jjk","ghjhj","gjhjj","fghh","ghh"};
    String[] pancardno={"pancardno","pancardno","pancardno","pancardno","pancardno","pancardno","pancardno","pancardno","pancardno","pancardno"};
    String[] addharcardno={"addharcardno","addharcardno","addharcardno","addharcardno","addharcardno","addharcardno","addharcardno","addharcardno","addharcardno","addharcardno"};
    String[] button={"upload","upload","upload","upload","upload","upload","upload","upload","upload","upload"};
    String[] buttonone={"upload","upload","upload","upload","upload","upload","upload","upload","upload","upload"};
    String[] buttonthree={"upload","upload","upload","upload","upload","upload","upload","upload","upload","upload"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partner_llb);

        recyclerView = (RecyclerView) findViewById(R.id.recyclerview);
        arLIstPartner=new ArrayList<>();

        prepareMovieData();

    }
    public class Partneradapter extends RecyclerView.Adapter<Partneradapter.MyViewHolder> {
         ArrayList<Partnerllb> partnerllbs;

        Context mContext;

    public Partneradapter(Context context,ArrayList<Partnerllb>arrayList){
            this.mContext=context;
            this.partnerllbs=arrayList;

        }

        @NonNull
        @Override
        public Partneradapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewtype) {
            View itemView = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.partnerlistview, parent, false);


            return new Partneradapter.MyViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
            Partnerllb partner=partnerllbs.get(position);
            holder.Nmae.setText(partner.getName());
            holder.Pancardno.setText(partner.getPancardno());
//        Log.d("card",partner.getPancardno());
            holder.Addharcardno.setText(partner.getAddharcardno());
            holder.Imageviewone.setImageResource(partner.getImage_drawableone());
            holder.imageViewtwo.setImageResource(partner.getGetImage_drawabletwo());
            holder.Person.setImageResource(partner.getImage_drawable());//
            holder.buttonone.setText(partner.getButtonone());
            holder.buttontwo.setText(partner.getButtontwo());
            holder.buttonthree.setText(partner.getButtonthree());
        }

        @Override
        public int getItemCount() {
            return partnerllbs.size();
        }

        public class MyViewHolder extends RecyclerView.ViewHolder{

            public TextView Nmae,Pancardno,Addharcardno;
            public Button buttonone,buttontwo,buttonthree;
            public ImageView Person,Imageviewone,imageViewtwo;
            public MyViewHolder(View view){
                super(view);
                Nmae=(TextView)view.findViewById(R.id.personname);
                Pancardno=(TextView)view.findViewById(R.id.pancardno);
                Addharcardno=(TextView)view.findViewById(R.id.addharcardno);
                Person=(ImageView)view.findViewById(R.id.imgView);
                Imageviewone=(ImageView)view.findViewById(R.id.imgViewone);
                imageViewtwo=(ImageView)view.findViewById(R.id.imgViewtwo);//
                buttonone=(Button)view.findViewById(R.id.uploadone);
                buttontwo=(Button)view.findViewById(R.id.uploadsecond);
                buttonthree=(Button)view.findViewById(R.id.uploadthird);

               buttonone.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        PopupMenu popupMenu = new PopupMenu(PartnerLLBActivity.this, v);
                        popupMenu.getMenuInflater().inflate(R.menu.menu_image, popupMenu.getMenu());
                        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                            @Override
                            public boolean onMenuItemClick(MenuItem item) {
                                switch (item.getItemId()) {
//                                    case R.id.Camera:
//                                        try {
//                                            Intent intent = new Intent();
//                                            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
//                                            startActivityForResult(intent, 1);
//                                        } catch (Exception e) {
//                                            e.printStackTrace();
//                                        }
//                                        break;
                                    case R.id.Gallery:

                                        Intent intent = new Intent();
                                        intent.setType("image/*");
                                        intent.setAction(Intent.ACTION_PICK);
                                        startActivityForResult(intent, 0);
                                        break;
                                }
                                return false;
                            }
                        });
                        popupMenu.show();


                    }


               });

            }

        }}

    private void prepareMovieData() {
            recyclerView.setHasFixedSize(true);
            RecyclerView.LayoutManager layoutManager=new GridLayoutManager(PartnerLLBActivity.this,1);
            recyclerView.setLayoutManager(layoutManager);
            arLIstPartner.clear();
            for(int i=0;i<name.length;i++){
                Partnerllb partnerllb=new Partnerllb();
                partnerllb.setName(name[i]);
                partnerllb.setPancardno(pancardno[i]);
                partnerllb.setAddharcardno(addharcardno[i]);
                partnerllb.setButtonone(button[i]);
                partnerllb.setButtontwo(buttonone[i]);
                partnerllb.setButtonthree(buttonthree[i]);
                arLIstPartner.add(partnerllb);//
            }

        mAdapter=new Partneradapter(PartnerLLBActivity.this,arLIstPartner);
            recyclerView.setAdapter(mAdapter);


    }
}
