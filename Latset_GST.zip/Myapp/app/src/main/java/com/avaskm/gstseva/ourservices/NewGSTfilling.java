package com.avaskm.gstseva.ourservices;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.NewGstFillingModel;
import com.avaskm.gstseva.pdfFile.PdfActivity;
import com.github.chrisbanes.photoview.PhotoView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class NewGSTfilling extends AppCompatActivity {
    Button BtnSubmit;

    Spinner SpnBill;

    PhotoView PvImage;
    TextView TvPrice;

    TextInputEditText EtName, EtGstNo, EtUserId, EtPassword;

    ArrayList<NewGstFillingModel> arListValue;

    ArrayList<String> arListNewGstFill;
    String price, billName;
    SharedPreferences sharedPreferences;
    String userId,title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_gstfilling);
        sharedPreferences = getSharedPreferences("GstUser", MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        TvPrice = (TextView) findViewById(R.id.tv_price);
        PvImage = (PhotoView) findViewById(R.id.photoView_image);
        SpnBill = (Spinner) findViewById(R.id.spin_bill);
        EtName = (TextInputEditText) findViewById(R.id.et_name_gstfill);
        EtGstNo = (TextInputEditText) findViewById(R.id.et_gst_no_gstfill);
        EtUserId = (TextInputEditText) findViewById(R.id.et_user_id_gstfill);
        EtPassword = (TextInputEditText) findViewById(R.id.et_password_gstfill);


        BtnSubmit = (Button) findViewById(R.id.btn_submit_gstfill);
        arListNewGstFill = new ArrayList<>();
        arListValue = new ArrayList<>();
        Intent intent = getIntent();
        title = intent.getStringExtra("title");

        SpnBill.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                billName = String.valueOf(SpnBill.getItemAtPosition(position));
                price = arListValue.get(position).getPrice();
                Log.d("billName", billName);
                TvPrice.setText("\u20B9" + " " + price);
                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        BtnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Submit()) {

                }
            }
        });

        GetCategoryInForAPI();
    }


    private boolean setSelectNoOFBill() {
        if (!billName.equalsIgnoreCase("Select no of bill")) {
            return true;

        } else {
            Toast.makeText(NewGSTfilling.this, "Please select no of bill", Toast.LENGTH_SHORT).show();
            return false;
        }
    }


    private boolean setName() {
        if (EtName.getText().toString().length() > 0) {
            return true;

        } else {
            EtName.setError("Please enter name");
            return false;
        }
    }


    private boolean setGstNo() {
        if (EtGstNo.getText().toString().length() > 0) {
            return true;

        } else {
            EtGstNo.setError("Please enter gst no");
            return false;
        }
    }


    private boolean setUserId() {
        if (EtUserId.getText().toString().length() > 0) {
            return true;

        } else {
            EtUserId.setError("Please enter user id");
            return false;
        }
    }

    private boolean setPassword() {
        if (EtPassword.getText().toString().length() > 0) {
            return true;

        } else {
            EtPassword.setError("Please enter password");
            return false;
        }
    }

    private boolean setNoOfBill() {
        if (EtGstNo.getText().toString().length() > 0) {
            return true;
        } else {
            EtGstNo.setError("Please enter no of bill");
            return false;
        }


    }


    private boolean Submit() {

        if (!setSelectNoOFBill()) {
            return false;
        } else if (!setName()) {
            return false;

        } else if (!setGstNo()) {
            return false;

        } else if (!setUserId()) {
            return false;

        } else if (!setPassword()) {
            return false;

        } else if (!setNoOfBill()) {
            return false;

        }
        MakeOrderAPI();

        return true;
    }

    private void GetCategoryInForAPI() {
        final ProgressDialog dialog = ProgressDialog.show(NewGSTfilling.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("GetCategoryInForAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");

                    arListValue.clear();
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    String image = dataObject.getString("image");
                    Log.d("image", image);

                    Picasso.get().load(image).into(PvImage);
                    JSONArray priceArray = dataObject.getJSONArray("prices");

                    arListNewGstFill.add("Select no of bill");
                    NewGstFillingModel model = new NewGstFillingModel();
                    model.setBillName("Select no of bill");
                    model.setPrice("");
                    arListValue.add(model);


                    for (int i = 0; i < priceArray.length(); i++) {
                        model = new NewGstFillingModel();
                        JSONObject priceObject = priceArray.getJSONObject(i);
                        String key = priceObject.getString("key");
                        model.setBillName(priceObject.getString("key"));
                        Log.d("key", key);
                        String value = priceObject.getString("value");
                        model.setPrice(value);
                        Log.d("value", value);

                        arListValue.add(model);
                        arListNewGstFill.add(key);
                    }
                    ArrayAdapter aa = new ArrayAdapter(NewGSTfilling.this, android.R.layout.simple_spinner_dropdown_item, arListNewGstFill);
                    SpnBill.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("category", title);

                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(NewGSTfilling.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


    private void MakeOrderAPI() {
        final ProgressDialog dialog = ProgressDialog.show(NewGSTfilling.this, "", "Loading....", false);
        StringRequest request = new StringRequest(Request.Method.POST, Api.MakeOrder, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("MakeOrderAPI", response);
                dialog.dismiss();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String msg = jsonObject.getString("msg");
                    String code = jsonObject.getString("code");
                    JSONObject dataObject = jsonObject.getJSONObject("data");
                    String orderid = dataObject.getString("orderid");
                    Log.d("sssorderid", orderid);
                    if (code.equalsIgnoreCase("200")) {
                        Intent intent = new Intent(NewGSTfilling.this, PdfActivity.class);
                        intent.putExtra("orderid", orderid);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);
                        Toast.makeText(NewGSTfilling.this, msg, Toast.LENGTH_SHORT).show();
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", Api.key);
                params.put("userid", userId);
                params.put("category", title);
                params.put("price", price);
                params.put("no_bills", billName);
                params.put("name", EtName.getText().toString());
                params.put("gst_no", EtGstNo.getText().toString());
                params.put("user_id", EtUserId.getText().toString());
                params.put("password", EtPassword.getText().toString());
                Log.d("all", String.valueOf(params));
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(NewGSTfilling.this);
        requestQueue.getCache().clear();
        requestQueue.add(request);

    }


}
