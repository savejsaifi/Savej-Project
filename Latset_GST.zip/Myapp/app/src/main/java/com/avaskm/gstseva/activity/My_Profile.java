package com.avaskm.gstseva.activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.avaskm.gstseva.DescriptionActivity;
import com.avaskm.gstseva.PartnershipLLpactivity;
import com.avaskm.gstseva.R;
import com.avaskm.gstseva.api.Api;
import com.avaskm.gstseva.model.StateSpinnerModel;
import com.avaskm.gstseva.ourservices.RegistrationfillActivity;
import com.avaskm.gstseva.session.SessonManager;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class My_Profile extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {
    EditText edt_username, edt_mobile, edt_useremail, edt_userFirmName, edt_address, edt_landmark,edt_city1, edt_pincode1;
    EditText edt_address2, edt_landmark2,edt_city2,edt_pincode2;
    String name, mobile, email, firmName, address, landmark, pincode1,city1, secaddress="", seclandmark="",pincode2="",city2="", stateName1, stateName2;
    String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
    Button btn_Register;
    //SessonManager sessonManager;
    String[] another_details = {"any other buisness address in same state?","Yes","No"};

    TextView textview_state, tv_chkbox;
    Spinner stateSpinner1, constitution_spinner;
    Spinner state_spinner2,anotherspinner;
    final Context context = this;
    LinearLayout linear_Layout, linear_Layoutone;
    Button btnRegister;
    String servicename, validity, price, geo_state,title;
    String constitut;
    int constitutePosition=0;
    String anotherString=" ";
    ArrayList<String> listState1 = new ArrayList<>();
    ArrayList<StateSpinnerModel> listState1_model = new ArrayList<>();
    ArrayList<String> listState2 = new ArrayList<>();
    ArrayList<StateSpinnerModel> listState2_model = new ArrayList<>();
    SharedPreferences sharedPreferences;
    String userId;
    List<String> list = new ArrayList<String>();
    List<Descrip> listModel = new ArrayList<Descrip>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my__profile);

        sharedPreferences = getSharedPreferences("GstUser",MODE_PRIVATE);
        userId = sharedPreferences.getString("userid", "");

        edt_username = findViewById(R.id.edt_username);
        edt_mobile = findViewById(R.id.edt_mobile);
        edt_useremail = findViewById(R.id.edt_useremail);
        edt_userFirmName = findViewById(R.id.edt_userFirmName);
        edt_address = findViewById(R.id.edt_address);
        edt_landmark = findViewById(R.id.edt_landmark);
        edt_city1 = findViewById(R.id.edt_city1);
        edt_pincode1 = findViewById(R.id.edt_pincode);
        btn_Register = findViewById(R.id.btn_Register);
        //textview_state = findViewById(R.id.textview_state);

        stateSpinner1 = findViewById(R.id.state_spinner1);
        constitution_spinner = (Spinner) findViewById(R.id.constitution_spinner);
        anotherspinner = (Spinner) findViewById(R.id.anotherspinner);
        // tv_chkbox=findViewById(R.id.tv_chkbox);
        linear_Layout = findViewById(R.id.linear_Layout);
        edt_address2 = findViewById(R.id.edt_address2);
        edt_landmark2 = findViewById(R.id.edt_landmark2);
        state_spinner2 = findViewById(R.id.state_spinner2);
        edt_city2 = findViewById(R.id.edt_city2);
        edt_pincode2 = findViewById(R.id.edt_pincode2);

        Intent intent = getIntent();
        servicename = intent.getStringExtra("servicename");
        validity = intent.getStringExtra("validity");
       // price = intent.getStringExtra("price");
        geo_state = intent.getStringExtra("geo_state");
        title = intent.getStringExtra("title");
        Log.d("tittt",title);


     Log.d("weiojd",servicename+" "+validity+" "+price+" "+geo_state+" ");

        OnItemSelectedListener countrySelectedListener = new OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> spinner, View container,
                                       int position, long id) {
                SharedPreferences sp = getSharedPreferences("checkforuploadform", My_Profile.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putInt("position", position);
                editor.commit();
                //mTvCountry.setText(countries[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
                // TODO Auto-generated method stub
            }
        };

        hitConstitueSpinnerApi();
        // Setting ItemClick Handler for Spinner Widget
        constitution_spinner.setOnItemSelectedListener(countrySelectedListener);


        hitstateSpinnerApi();
        hitstateSpinnerApi2();
        allSpinnerclick();

        buttoonClick();
    }

    private void hitConstitueSpinnerApi() {

            final ProgressDialog dialog = ProgressDialog.show(My_Profile.this, "", "Loading....", false);
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Api.GetCategoryInfor, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Log.d("fgfgdfgdfgg", response);


                    dialog.dismiss();
                    // arListCity.size()

                    if (list.size() > 0) {
                        list.clear();

                    }
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONObject jsonObject1 = jsonObject.getJSONObject("data");

                        list.add("Select Constitution");
                        Descrip model = new Descrip();
                        model.setConstName("Select Constitution");
                        model.setPrice("");
                        listModel.add(model);
                        JSONArray catogryArray = jsonObject1.getJSONArray("categories");
                        for(int i =0;i<catogryArray.length();i++){
                            model = new Descrip();
                            JSONObject jsonObject2 = catogryArray.getJSONObject(i);
                            model.setConstName(jsonObject2.getString("name"));
                            model.setPrice(jsonObject2.getString("price"));
                            listModel.add(model);
                            list.add(jsonObject2.getString("name"));

                        }
                        ArrayAdapter aa = new ArrayAdapter(My_Profile.this,android.R.layout.simple_spinner_dropdown_item,list);
                        constitution_spinner.setAdapter(aa);

                         Log.d("sdasdds", String.valueOf(list));

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    dialog.dismiss();

                }
            }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String, String> params = new HashMap<>();
                    params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                    params.put("category", title);
                    params.put("userid", userId);

                     return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.getCache().clear();
            requestQueue.add(stringRequest);
        }


    private void hitstateSpinnerApi() {
        RequestQueue queue = Volley.newRequestQueue(My_Profile.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                listState1.add("Select state");
                StateSpinnerModel model = new StateSpinnerModel();
                model.setStateName("Select state");
                model.setId("");
                listState1_model.add(model);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i =0;i<jsonArray.length();i++){
                         model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState1_model.add(model);
                        listState1.add(jsonObject1.getString("state_name"));
                    }
                    ArrayAdapter aa = new ArrayAdapter(My_Profile.this,android.R.layout.simple_spinner_dropdown_item,listState1);
                    stateSpinner1.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }){
               protected Map<String,String> getParams(){
                   HashMap<String,String> hashMap = new HashMap<>();
                   hashMap.put("key",Api.key);
                   return hashMap;
               }
        };
        queue.add(request);

    }


    private void hitstateSpinnerApi2() {
        RequestQueue queue = Volley.newRequestQueue(My_Profile.this);
        StringRequest request = new StringRequest(Request.Method.POST, Api.statelist, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    listState2.add("Select state");
                    StateSpinnerModel model = new StateSpinnerModel();
                    model.setStateName("Select state");
                    model.setId("");
                    listState2_model.add(model);
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    for(int i =0;i<jsonArray.length();i++){
                        model = new StateSpinnerModel();
                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                        model.setId(jsonObject1.getString("id"));
                        model.setStateName(jsonObject1.getString("state_name"));
                        listState2_model.add(model);
                        listState2.add(jsonObject1.getString("state_name"));
                    }
                    ArrayAdapter aa = new ArrayAdapter(My_Profile.this,android.R.layout.simple_spinner_dropdown_item,listState2);
                    state_spinner2.setAdapter(aa);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "state list are not availbale", Toast.LENGTH_SHORT).show();
            }
        }){
            protected Map<String,String> getParams(){
                HashMap<String,String> hashMap = new HashMap<>();
                hashMap.put("key",Api.key);
                return hashMap;
            }
        };
        queue.add(request);
    }

    private void allSpinnerclick() {

        constitution_spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                //  selectedCar = position;
                //   item = (String) parent.getItemAtPosition(position);
                constitut = listModel.get(position).getConstName();
                price = listModel.get(position).getPrice();
                ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                Log.d("asdadasdw",constitut+" "+price);
            //    constitutePosition =  constitution_spinner.getSelectedItemPosition();
             //   Log.d("kkjkjh",constitut+" "+constitutePosition);

//                ((TextView) parent.getChildAt(0)).setTextColor(Color.parseColor("#ffff"));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        anotherspinner.setOnItemSelectedListener(this);
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,another_details);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        anotherspinner.setAdapter(aa);


          stateSpinner1.setOnItemSelectedListener(new OnItemSelectedListener() {
              @Override
              public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                  ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                  stateName1 = listState1_model.get(position).getStateName();
                  Log.d("asdds",stateName1);
              }
              @Override
              public void onNothingSelected(AdapterView<?> parent) {

              }
          });


             state_spinner2.setOnItemSelectedListener(new OnItemSelectedListener() {
              @Override
              public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                  ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
                  stateName2 = listState2_model.get(position).getStateName();
                  Log.d("asdiods",stateName2);
              }

              @Override
              public void onNothingSelected(AdapterView<?> parent) {

              }
          });



    }



    private void buttoonClick () {
        btn_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // RegisterApi();


                name = edt_username.getText().toString();
                mobile = edt_mobile.getText().toString();
                email = edt_useremail.getText().toString();
                firmName = edt_userFirmName.getText().toString();
                address = edt_address.getText().toString();
                landmark = edt_landmark.getText().toString();
                pincode1 = edt_pincode1.getText().toString();
                city1 = edt_city1.getText().toString();
                secaddress = edt_address2.getText().toString();
                seclandmark = edt_landmark2.getText().toString();
                pincode2 = edt_pincode2.getText().toString();
                city2 = edt_city2.getText().toString();

//                selectedstate = stateSpinner1.getSelectedItem().toString();
                //constitut = constitution_spinner.getSelectedItem().toString();
                //statespinner2 = state_spinner2.getSelectedItem().toString();


                if (name.isEmpty()) {
                    edt_username.setError("Please enter the name");
                    edt_username.requestFocus();
                  //  Toast.makeText(My_Profile.this, "Please enter the name", Toast.LENGTH_SHORT).show();

                } else if (mobile.isEmpty()) {
                    edt_mobile.setError("Please enter the mobile No.");
                    edt_mobile.requestFocus();
                } else if (mobile.length() != 10) {
                    edt_mobile.setError("Please enter the 10 digit mobile No.");
                    edt_mobile.requestFocus();
                } else if (email.isEmpty()) {
                    edt_useremail.setError("Please enter the Email");
                    edt_useremail.requestFocus();
                    //Toast.makeText(My_Profile.this, "Please enter the Email", Toast.LENGTH_SHORT).show();
                } else if (!(email.matches(emailPattern) && email.length() > 0)) {
                    edt_useremail.setError("Please enter the valid Email");
                    edt_useremail.requestFocus();
                } else if (firmName.isEmpty()) {
                    edt_userFirmName.setError("Please enter the Firm Name");
                    edt_userFirmName.requestFocus();
                  //  Toast.makeText(My_Profile.this, "Please enter the Firm Name", Toast.LENGTH_SHORT).show();
                } else if (address.isEmpty()) {
                    edt_address.setError("Please enter the Address");
                    edt_address.requestFocus();
                  //  Toast.makeText(My_Profile.this, "Please enter the Address", Toast.LENGTH_SHORT).show();
                } else if (landmark.isEmpty()) {
                    edt_landmark.setError("Please enter the landmark");
                    edt_landmark.requestFocus();
                 //   Toast.makeText(My_Profile.this, "Please enter the landmark", Toast.LENGTH_SHORT).show();
                }
                else if(stateName1.equals("Select state")){
                    Toast.makeText(My_Profile.this, "Please Select State", Toast.LENGTH_SHORT).show();
                }
                else if (city1.isEmpty()) {
                    edt_city1.setError("Please enter the City");
                 //   Toast.makeText(My_Profile.this, "Please enter the landmark", Toast.LENGTH_SHORT).show();
                }

                else if (pincode1.isEmpty()) {
                    edt_pincode1.setError("Please enter the pincode");
                    edt_pincode1.requestFocus();
                } else if (pincode1.length() != 6) {
                    edt_pincode1.setError("Please enter the 6 digit pincode");
                    edt_pincode1.requestFocus();
                }
                else if (constitut.equals("Select Constitution")) {
                    Toast.makeText(context, "Please select the Constitution", Toast.LENGTH_SHORT).show();
                }
                 else {
                 //   Toast.makeText(context, "erwkha;fas;", Toast.LENGTH_SHORT).show();
                    RegisterApi();
                    //   startActivity(new Intent(My_Profile.this, PaymentActivity.class));

                    }
                }
        });
    }

        public void RegisterApi () {
            //Toast.makeText(context, "text", Toast.LENGTH_SHORT).show();
        final ProgressDialog dialog = ProgressDialog.show(My_Profile.this, "", "Loading....", false);
        StringRequest stringRequest=new StringRequest(Request.Method.POST, Api.gstrequest, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("responsePaymedftn",response);
                dialog.dismiss();
                try {
                    JSONArray jsonArray=new JSONArray(response);
                    JSONObject jsonObject=jsonArray.getJSONObject(0);
                    String code = jsonObject.getString("code");
                    String msg = jsonObject.getString("msg");
                    SharedPreferences sharedPreferences = getSharedPreferences("orderId",MODE_PRIVATE);
                    sharedPreferences.edit().putString("orderId",jsonObject.getString("orderid")).apply();
                    sharedPreferences.edit().putString("formId",jsonObject.getString("form_id")).apply();

                    Log.d("sdqasd",jsonObject.getString("form_id"));
                    if (code.equalsIgnoreCase("200")) {
                        //Toast.makeText(LoginAcitivity.this, ""+msg, Toast.LENGTH_SHORT).show();
                        if(constitut.equalsIgnoreCase("Proprietor/Shopkeeper/individual")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, ProprietorActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("Partnership / LLP")){

                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, PartnershipLLpactivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("Private Limited Company")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, PrivateLimitedActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("Public Limited Company")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, PrivateLimitedActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("NRI")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, NRIActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("HUF")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, HufActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("Trust")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, TrustActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("Society")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, TrustActivity.class);
                            startActivity(intent);
                        }
                        else if(constitut.equalsIgnoreCase("NGO")){
                            Toast.makeText(context, "Information saved Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(My_Profile.this, TrustActivity.class);
                            startActivity(intent);
                        }
                    //    Intent intent = new Intent(My_Profile.this, PaymentActivity.class);


//                        intent.putExtra("edt_username",edt_username.getText().toString());
//                        intent.putExtra("edt_mobile",edt_mobile.getText().toString());
//                        intent.putExtra("edt_useremail",edt_useremail.getText().toString());
//                        intent.putExtra("edt_address",edt_address.getText().toString());
//                        intent.putExtra("edt_landmark",edt_landmark.getText().toString());
//                        intent.putExtra("edt_pincode",edt_pincode1.getText().toString());
//                        intent.putExtra("edt_address2",edt_address2.getText().toString());
//                        intent.putExtra("edt_landmark2",edt_landmark2.getText().toString());
//                        intent.putExtra("edt_username",edt_username.getText().toString());
//                        intent.putExtra("edt_username",edt_username.getText().toString());
//                        intent.putExtra("edt_username",edt_username.getText().toString());
//                        intent.putExtra("edt_username",edt_username.getText().toString());
//                        intent.putExtra("edt_username",edt_username.getText().toString());
//
//                        intent.putExtra("validity",validity);
//                        intent.putExtra("price",price);
//                        intent.putExtra("geo_state",geo_state);
                      //  startActivity(intent);
                    } else {
                        Toast.makeText(My_Profile.this, "" + msg, Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                dialog.dismiss();

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> params = new HashMap<>();
                params.put("key", "5642vcb546g2334hh555b7r6ewc211vhh34");
                //params.put("userid",sessonManager.getUserid());
                params.put("userid",userId);
                params.put("category_name",title);
                params.put("validity",validity);
                params.put("price",price);
                params.put("geo_state",geo_state);
                params.put("name",name);
                params.put("mobile_no",mobile);
                params.put("email",email);
                params.put("business_address",address);
                params.put("business_landmark",landmark);
                params.put("business_state",stateName1);
                params.put("business_city",city1);
                params.put("business_pincode",pincode1);
                params.put("constitution",constitut);
                params.put("company_name",firmName);
             //   params.put("gst_type",String.valueOf(constitutePosition));
                if(anotherString.equals("Yes")){
                    params.put("additional_state",stateName2);
                    params.put("additional_address",secaddress);
                    params.put("additional_landmark",seclandmark);
                    params.put("additional_city",city2);
                    params.put("additional_pincode",pincode2);

                }
               else if(!anotherString.equals("Yes")){
                    params.put("additional_state"," ");
                    params.put("additional_address"," ");
                    params.put("additional_landmark"," ");
                    params.put("additional_city"," ");
                    params.put("additional_pincode"," ");
                }

                Log.d("msggsaqw",params.toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.getCache().clear();
        requestQueue.add(stringRequest);
        }

        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.main, menu);
            return true;
        }


        public void constitution_layout (View view){
        }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        anotherString = another_details[position];
        ((TextView) parent.getChildAt(0)).setTextColor(Color.WHITE);
        Log.d("asdklweo",anotherString);

        if(anotherString.equals("Yes")){
            linear_Layout.setVisibility(View.VISIBLE);
        }
        else {
            linear_Layout.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    /**
     * Called when pointer capture is enabled or disabled for the current window.
     *
     * @param hasCapture True if the window has pointer capture.
     */
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
