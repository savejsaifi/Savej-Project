package com.avaskm.gstseva.model;

public class BannerModel {
    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    private String image;
}
