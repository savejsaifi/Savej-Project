package com.example.administrator.design_of_sketch.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.example.administrator.design_of_sketch.R;
import com.example.administrator.design_of_sketch.activity.activity.MainActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;


public class Email_Fragment extends Fragment {


    Button btnRegister;

    String name1, email, password1;
    TextView tv_Register;

    private EditText inputName ,inputEmail,inputPassword;
    private ProgressBar progressBar;
    private FirebaseAuth auth;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_email_, null);

        btnRegister = (Button) view.findViewById(R.id.btnRegister);
        inputName = (EditText) view.findViewById(R.id.ed1);
        inputEmail = (EditText) view.findViewById(R.id.ed2);
        inputPassword = (EditText) view.findViewById(R.id.ed3);
        tv_Register = (TextView) view.findViewById(R.id.tv_Register);
        auth = FirebaseAuth.getInstance();
        progressBar = (ProgressBar)view.findViewById(R.id.progressBar);


        tv_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity().getApplication(), MainActivity.class);
                startActivity(intent);
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = inputName.getText().toString().trim();
                String email = inputEmail.getText().toString().trim();
                String password = inputPassword.getText().toString().trim();

                if (TextUtils.isEmpty(name)) {
                    Toast.makeText(getActivity(), "Enter name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getActivity(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getActivity(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(getActivity(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);



                //create user
                auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(getActivity(), new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(getActivity(), "Registraion Successfull:" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(getActivity(), "Authentication failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

            }
        });
        return view;
       /* btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name1 = ed1.getText().toString().trim();
                email = ed2.getText().toString().trim();
                password1 = ed3.getText().toString().trim();

                if (name1.trim().equals("")) {
                    Toast.makeText(getActivity(), "Name Field cant't be blank", Toast.LENGTH_SHORT).show();
                } else if (email.trim().equals("")) {
                    Toast.makeText(getActivity(), "Email Field cant't be blank", Toast.LENGTH_SHORT).show();
                    //  ed2.setError("Field can't be blank");
                } else if (password1.trim().equals("")) {
                    Toast.makeText(getActivity(), "Field cant't be blank", Toast.LENGTH_SHORT).show();
                    // ed3.setError("Field can't be blank");
                } else {

                    boolean isInserted = myDb.insertData(ed1.getText().toString(),
                            ed2.getText().toString(),
                            ed3.getText().toString() );
                    if(isInserted == true)
                        Toast.makeText(getActivity(),"Data Inserted",Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getActivity(),"Data not Inserted",Toast.LENGTH_LONG).show();
                }

            }
        });*/


    }

    @Override
    public void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }

}
