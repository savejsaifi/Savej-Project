package com.example.administrator.design_of_sketch.activity.activity;

import android.content.Intent;
import android.os.Build;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toolbar;


import com.example.administrator.design_of_sketch.R;
import com.example.administrator.design_of_sketch.adapter.MyAdapter;
import com.example.administrator.design_of_sketch.fragment.Email_Fragment;
import com.example.administrator.design_of_sketch.fragment.Mobile_Fragment;

import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;
   // TextView tv_Register;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        tabLayout=(TabLayout)findViewById(R.id.tabLayout);
        viewPager=(ViewPager)findViewById(R.id.viewPager);
      //  tv_Register = findViewById(R.id.tv_Register);
        tabLayout.addTab(tabLayout.newTab().setText("EMAIL"));
        tabLayout.addTab(tabLayout.newTab().setText("MOBILE Number"));

        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);



        /*if(tabLayout.equals("Mobile")){
            tabLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    FragmentManager fManager=getSupportFragmentManager();
                    FragmentTransaction fTx=fManager.beginTransaction();
                    fTx.add(R.id.frame, new Mobile_Fragment());
                    fTx.commit();
                }
            });

        }*/


        final MyAdapter adapter = new MyAdapter(this,getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(final TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
                
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }

    }


