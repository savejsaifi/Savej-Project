package com.example.administrator.design_of_sketch.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import com.example.administrator.design_of_sketch.R;
import com.example.administrator.design_of_sketch.activity.activity.MainActivity;
import com.example.administrator.design_of_sketch.activity.activity.VerifyPhoneActivity;


public class Mobile_Fragment extends Fragment {

Context context;

   TextView tv_Register;
    Button btnRegister11;
    EditText inputname,inputmobile,inputpassword;
   // String name,mobile,password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        View view=inflater.inflate(R.layout.fragment_mobile_,null);

        btnRegister11=(Button)view.findViewById(R.id.btnRegister11);

        inputname=(EditText) view.findViewById(R.id.ed11);
        inputmobile=(EditText) view.findViewById(R.id.ed22);
        inputpassword=(EditText) view.findViewById(R.id.ed33);
        tv_Register = (TextView)view.findViewById(R.id.tv_Register);
      //  mydb = new DataBaseHelper_Two(getActivity().getApplication());

        tv_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity().getApplication(), MainActivity.class);
                startActivity(intent);
            }
        });

        btnRegister11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = inputname.getText().toString();
                String mobile = inputmobile.getText().toString();
                String password = inputpassword.getText().toString();

                if(name.isEmpty()){
                    inputname.setError("Enter the name");
                    inputname.requestFocus();
                    return;
                }
                if(mobile.isEmpty() || mobile.length() < 10){
                    inputmobile.setError("Enter a valid mobile");
                    inputmobile.requestFocus();
                    return;
                }
                if(password.isEmpty() || password.length() < 6){
                    inputpassword.setError("Enter the password");
                    inputpassword.requestFocus();
                    return;
                }

                Intent intent = new Intent(getActivity(), VerifyPhoneActivity.class);
                intent.putExtra("mobile", mobile);
                startActivity(intent);

            }
        });


        return view;
       /* btnRegister11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                name = ed11.getText().toString().trim();
                mobile = ed22.getText().toString().trim();
                password = ed33.getText().toString().trim();

                if(name.trim().equals("")){
                    ed11.setError("Field can't be blank");
                }
               else if(mobile.trim().equals("")){
                    ed22.setError("Field can't be blank");
                }
              else  if(password.trim().equals("")){
                    ed33.setError("Field can't be blank");
                }

               else if(name.isEmpty() && mobile.isEmpty() && password.isEmpty()){
                    Toast.makeText(getActivity(),"Fill all the field", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    boolean isInserted1;
                    isInserted1=true;
                    if (isInserted1 == true)
                        Toast.makeText(getActivity().getApplication(), "Registerd Successfully", Toast.LENGTH_LONG).show();
                    else
                        Toast.makeText(getActivity().getApplication(), "Data not Inserted", Toast.LENGTH_LONG).show();
                }

            }
        });*/


    }

    }






