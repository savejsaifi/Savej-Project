package com.example.administrator.design_of_sketch.adapter;


import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.administrator.design_of_sketch.fragment.Email_Fragment;
import com.example.administrator.design_of_sketch.fragment.Mobile_Fragment;

public class MyAdapter extends FragmentPagerAdapter {
    private Context myContext;
    int totalTabs;

    public MyAdapter(Context context, FragmentManager fm, int totalTabs ) {
        super(fm);
        myContext = context;
        this.totalTabs = totalTabs;
    }


    // this is for fragment tabs
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                Email_Fragment emailFragment = new Email_Fragment();
                return emailFragment;
            case 1:
                Mobile_Fragment mobile_fragment = new Mobile_Fragment();
                return mobile_fragment;

            default:
                return null;
        }
    }

    // this counts total number of tabs
    @Override
    public int getCount() {
        return totalTabs;
    }
}
