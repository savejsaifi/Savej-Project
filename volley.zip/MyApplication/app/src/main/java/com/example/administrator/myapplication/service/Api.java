package com.example.administrator.myapplication.service;


import com.example.administrator.myapplication.model.UpdateModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Administrator on 23-01-2018.
 */

public interface Api {

    String BASE_UPDATE_DETAIL = "http://idawebsite.azurewebsites.net/api/frmUpdateContactDetails/";

    @GET("getUpdateContactDetails?")
    Call<UpdateModel> getupdateMethod(@Query("Refno") String s_Refno, @Query("PropertyNo") String s_SchCode, @Query("MobileNo") String s_plotno, @Query("LandLineNo") String LandLineNo, @Query("Email") String Email, @Query("UpdateInMaster") String UpdateInMaster);


}

//////////////////////////Final Webservices//////////////////////////////////



/*          ///////// for IDA Menu/////////////

//	----------------	for about Us
	http://idawebsite.azurewebsites.net/api/FrmAdmAboutUs/GetDatasetAboutUs?Ind=1


//	-----------------  	For Board Memeber Detail
	http://idawebsite.azurewebsites.net/api/MstBoardMem/getBoardMemDtlNew?Ind=1

//	---------------		for Chaiarman Message
	http://idawebsite.azurewebsites.net/api/FrmAdmMstChairmanMsg/GetDsMstChairmanMsg?Ind=1

//	--------------		for Telephone Directory
	http://idawebsite.azurewebsites.net/api/FrmAdmMstTeleDirectory/MstTeleDirectory

//	----------------	Vyyan Niyam 2013
	http://idawebsite.azurewebsites.net/api/MstVyyanNiyam/GetDsVyynNiyam

//         ----------------for Notification  of section 50(7)
                  http://idaindore.org/pdf/Dhara_50-7/Ida_Dhara_50-7.pdf

//                           for Contact Us
                  --------------- FOR Mail-Send

//	--------------- FOR Mail-Send

	http://idawebsite.azurewebsites.net/api/MstMailDtl/PostSendMail
         String from = "contactidaIndore@gmail.com";
        String password  = "Subhida_123";
         String to = "idaindore7@yahoo.in";

post perameter--------
            params.put("Method", "PostSendMail");
            params.put("Ind", 1);
            params.put("Name", Name);
            params.put("Org", Org);
            params.put("Subject", Subject);
            params.put("SenderId",contactidaIndore@gmail.com);
            params.put("RecevierId", idaindore7@yahoo.in);
            params.put("Mobile", Mobile);
            params.put("Msg", Msg);
            params.put("OrgCode", 0);
            params.put("CityCode", 0);


                      -----------------------for Indore Menu-------------

         //	--------------- FOR About-INDORE

	http://103.21.54.53/IdaWebApi/api/FrmAdmAbout_Indore/GetDsAbout_Indore

         //	--------------- FOR Heritage
         http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/GetDsHeritageAllPhoto
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/GetDsHeritagePhotoByHeritageId?HeritId=1

                //--------------------For MasterPlan 2021
                       http://idawebsite.azurewebsites.net/api/MstMsterPlan/GetDsMsterPlanById?MstPlanId=1


                                 -------- For Project Menu------

//	-------------- ALL PROJECT (TITLE, SHORT DESCRIPTION, IMAGE PATH)
	http://idawebsite.azurewebsites.net/api/MstProject/GetDsAllProject

/	-------------- ALL PROJECT (TITLE, SHORT DESCRIPTION, IMAGE PATH) FOR 1= Live                 PROJECTS                                                                           And 0=completed Project
	http://idawebsite.azurewebsites.net/api/MstProject/GetDsProjectIsNewOld?IsNewOld=1

    --------------For News Menu-------------

      //	---------------		for News
	http://idawebsite.azurewebsites.net/api/FrmAdmMstNews/GetNews

	http://idawebsite.azurewebsites.net/api/FrmAdmMstNews/GetDsNewsYearMonth_DDL	--- FOR DROP DOWN FILL

	http://idawebsite.azurewebsites.net/api/FrmAdmMstNews/GetDsNewsYearMonth_Wise?YyMmValue=2018-1	--                   FOR YEAR AND MONTH WISE NEWS DATA

          ------------------- for Notice And Circular-------------


	//http://idawebsite.azurewebsites.net/api/MstNoticeAndCircular/NoticeAndCircular


     -----------for Citizen  Services---------------

//           When Serch Button Click

//When GET DETEAIL click then next page Reference Number and Scheme Code send to next page for search Detail

                                for property Search
   /*http://idawebsite.azurewebsites.net/api/Payment/FillddlScheme

http://idawebsite.azurewebsites.net/api/Payment/SearchDtl?Refno=15900036&SchCode=%27%27&PlotNo=%27%27&Name=%27%27

http://idawebsite.azurewebsites.net/api/Payment/PropertyHolderDtl?Refno=15900036&SchCode=%27%27&PlotNo=%27%27&Name=%27%27

                                 for Application  Status

http://idawebsite.azurewebsites.net/api/Payment/AppStstus?InwardNo=6383



           ----------------------For Tender ----------------------------

//	--------------- FOR Procurement----------------
         http://idawebsite.azurewebsites.net/api/TenderIda/fillDDL


             ------  for Schemes-----------
            http://idawebsite.azurewebsites.net/api/FrmAdmMstSchemes/Schemes

//	----------------     for RTI-------------------------
	http://idawebsite.azurewebsites.net/api/FrmAdmRTI/GetDsRtiDtl



///////////////////pay online for webview//////////////
       http://idaindore.org/frmPayment.aspx

 //////////////////Property Information//////////////////
                 Vacant Property Details
http://idawebsite.azurewebsites.net/api/MstVacantPlotDtl/fillDDL

http://idawebsite.azurewebsites.net/api/MstVacantPlotDtl/VacantPlotDtl?IDASchNo=102

http://idawebsite.azurewebsites.net/api/TenderIda/fillDDL



FOR DEFAULTER LIST
http://idawebsite.azurewebsites.net/api/CtrlDefaultersList/GetDefaulterList


FOR SCHEME WISE ALLOTTEES

http://idawebsite.azurewebsites.net/api/SchemeWiseAlloteesList/fillDDL

http://idawebsite.azurewebsites.net/api/SchemeWiseAlloteesList/AlloteesList?IDASchNo=78


FOR UPDATE CONTACT DETAIL

http://idawebsite.azurewebsites.net/api/frmUpdateContactDetails/getUpdateContactDetails?RefNo,

string RefNo, string PropertyNo, string MobileNo, string LandLineNo, string Email, string UpdateInMaster


FOR EXPRESS YOUR INTEREST
http://idawebsite.azurewebsites.net/api/FrmExpressIntrest/getFillDDDL

http://idawebsite.azurewebsites.net/api/FrmExpressIntrest/getExpressIntrest?Name&...

string Name, string MobileNo, string Email, string Budget, string TypeCode, string TypeDesc

Budget, TypeCode ARE INTETER TYPE DEFAULT VALUE IS 0


http://idawebsite.azurewebsites.net/api/FrmExpressIntrest/getExpressIntrest?Name=NameTest333&MobileNo=1234567890&Email=test@gmail.com&Budget=2018&TypeCode=12&TypeDesc=test


*/



/*
//	-----------------  	For Board Memeber Detail
	http://103.21.54.53/IdaWebApi/api/MstBoardMem/getBoardMemDtlNew?Ind=1


//	----------------	for about Us
	http://103.21.54.53/IdaWebApi/api/FrmAdmAboutUs/GetDatasetAboutUs?Ind=1


//	---------------		for Chaiarman Message
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstChairmanMsg/GetDsMstChairmanMsg?Ind=1
//	---------------		for News
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/GetNews

	http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/GetDsNewsYearMonth_DDL	--- FOR DROP DOWN FILL

	http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/GetDsNewsYearMonth_Wise?YyMmValue=2018-1	-- FOR YEAR AND MONTH WISE NEWS DATA

//	--------------   	Chairman Short Message (Name, Post, Image path and Message)
	http://103.21.54.53/IdaWebApi/api/MstChairman/GetDsChairmanShortMsg


//	--------------		for Telephone Directory
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstTeleDirectory/MstTeleDirectory


//	--------------		for Budget pdf (HERE YearId=17 FOR 2017-18)
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstBudget/MstBudgetByYearId?YearId=17


//	-------------- ALL PROJECT (TITLE, SHORT DESCRIPTION, IMAGE PATH)
	http://103.21.54.53/IdaWebApi/api/MstProject/GetDsAllProject



//	-------------- ALL PROJECT (TITLE, SHORT DESCRIPTION, IMAGE PATH) FOR 1=NEW PROJECTS AND 0=OLD PROJECTS
	http://103.21.54.53/IdaWebApi/api/MstProject/GetDsProjectIsNewOld?IsNewOld=1



//	--------------- PRJECT DETAIL WITH ALL ITS PHOTO'S WITH DESCRIPTION
	http://103.21.54.53/IdaWebApi/api/MstProject/GetDsProjectPhoto?PrjId=1



//	--------------- FOR MASTER PLAN ( MstPlanId=1 GIVE MSTER PLAN 1, MstPlanId=2 GIVE MSTER PLAN 2,  MstPlanId=3 GIVE MSTER PLAN 3, )
	http://103.21.54.53/IdaWebApi/api/MstMsterPlan/GetDsMsterPlanById?MstPlanId=1



//	--------------- FOR Tender

	http://103.21.54.53/IdaWebApi/api/MstTender/GetDsLiveTender
	http://103.21.54.53/IdaWebApi/api/MstTender/GetDsExpiredTender



	--	FOR TENDER DETAIL

	http://103.21.54.53/IdaWebApi/api/MstTender/PostDsTenderDtl

	public class PL_Tender
    	{
        	public int Ind { get; set; }	--	8 FIX
        	public int SerNo { get; set; }
       	 	public string NitNo { get; set; }
        	public string TndNo { get; set; }
	}



	http://103.21.54.53/IdaWebApi/api/MstTender/GetDsTenderDtl?SerNo=10&NitNo=Nit%20No-1010&TndNo=Tender%20No-10010


//	--------------- FOR Heritage

	http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/GetDsHeritageAllPhoto
	http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/GetDsHeritagePhotoByHeritageId?HeritId=1




//	--------------- FOR About-INDORE

	http://103.21.54.53/IdaWebApi/api/FrmAdmAbout_Indore/GetDsAbout_Indore




//	--------------- FOR Mail-Send

	http://103.21.54.53/IdaWebApi/api/MstMailDtl/PostSendMail
	--	"payresponsekota@gmail.com", "paymentkota123"
    	public class PL_MailDtl
    	{
        	public string Ind { get; set; }//---------1
        	public string Name { get; set; }
        	public string Org { get; set; }
        	public string Subject { get; set; }
        	public string SenderId { get; set; }
        	public string RecevierId { get; set; }//---------prg@oswaldata.com
        	public string Mobile { get; set; }
        	public string Msg { get; set; }
        	public string OrgCode { get; set; }//---------0
        	public string CityCode { get; set; }//---------0
    	}
private void SendHtmlEmail(string body, string emailid)
    {

        try
        {
            using (MailMessage mailMessage = new MailMessage())
            {
                MailMessage loginInfo = new MailMessage();
                loginInfo.To.Add(emailid);
                loginInfo.From = new MailAddress("payresponsekota@gmail.com");
                loginInfo.Subject = "Enquiry : " + txt_Subject.Text.ToString().Trim();
                loginInfo.Body = body;
                loginInfo.IsBodyHtml = true;
                SmtpClient smtp = new SmtpClient();
                smtp.UseDefaultCredentials = false;
                smtp.Credentials = new System.Net.NetworkCredential("payresponsekota@gmail.com", "paymentkota123");
                smtp.Host = "smtp.gmail.com";
                smtp.Port = 587;
                loginInfo.Priority = MailPriority.High;
                loginInfo.DeliveryNotificationOptions = DeliveryNotificationOptions.OnFailure;
                smtp.EnableSsl = true;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Send(loginInfo);
            }
        }
        catch (System.Net.Mail.SmtpException ex)
        {
            Response.Write(ex.Message);
        }
        finally
        {

        }
    }
http://103.21.54.53/IdaWebApi/api/MstMailDtl/GetSendMail?Name=YourName-1&Org=YourOrganization-1&Subject=YourSubject-1&SenderId=Your-1@MailId.com&Mobile=0123456111&Msg=YourMessageHere-1
//	-----------------  Notices and Circulars

	http://103.21.54.53/IdaWebApi/api/MstNoticeAndCircular/NoticeAndCircular
//	-----------------	CEO Proposal
	http://103.21.54.53/IdaWebApi/api/FrmMstCeoProposal/CeoProposal

//	----------------	RTI
	http://103.21.54.53/IdaWebApi/api/FrmAdmRTI/GetDsRtiDtl

//	----------------	Vyyan Niyam 2013
	http://103.21.54.53/IdaWebApi/api/MstVyyanNiyam/GetDsVyynNiyam*/

////////////////////For Payment online ////////////

//                         Fill Scheme DDL
//


//           When Serch Button Click
//

//When GET DETEAIL click then next page Reference Number and Scheme Code send to next page for search Detail

//                               Property Holder Detail
// http://occweb05/idaFrontOfficeapi/api/RegisterComplain/GetSearch?Ind=5&RefNo=15900036&SchCode=''&PlotNo=''

    /*                              Show Demand Detail
        http://occweb05/IDADemandApi/api/LeaseDemand/GetCalculate?Ind=5&RefNo=15900036&ServiceNo=159
*/
                              /*Bank Master Check Box Fill
        http://103.21.54.53/IdaWebApi/api/Payment/GetDsBankMasterDDL

                       --	For Save Data and geting DEMAND NUMBER
        http://occweb05/IDADemandApi/api/LeaseDemand/SaveLeaseDemand */

                              /*http://103.21.54.53/IdaWebApi/api/Payment/FillddlScheme

http://103.21.54.53/IdaWebApi/api/Payment/SearchDtl?Refno=15900036&SchCode=%27%27&PlotNo=%27%27&Name=%27%27

http://103.21.54.53/IdaWebApi/api/Payment/PropertyHolderDtl?Refno=15900036&SchCode=%27%27&PlotNo=%27%27&Name=%27%27

http://103.21.54.53/IdaWebApi/api/Payment/DemandDtl?Refno=15900036&ServiceNo=1039000036

--	Bank Master Check Box Fill
	http://103.21.54.53/IdaWebApi/api/Payment/GetDsBankMasterDDL
*/



/*String BASE_URL = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstChairmanMsg/";
    String BASE_URL_CHAIRMAN_IMAGE = "http://103.21.54.53/IdaWebApi/api/MstChairman/";
    String BASE_NEWS_url = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/";
    String BASE_GET_ALLProjects = "http://103.21.54.53/IdaWebApi/api/MstProject/";
    String BASE_Project_type = "http://103.21.54.53/IdaWebApi/api/MstProject/";
    String BASE_Project_discripation = "http://103.21.54.53/IdaWebApi/api/MstProject/";
    String BASE_PROCUREMENT_TENDER = "http://103.21.54.53/IdaWebApi/api/MstTender/";
    String BASE_ABOUT_US = "http://103.21.54.53/IdaWebApi/api/FrmAdmAboutUs/";
    String BASE_ABOUT_INDORE = "http://103.21.54.53/IdaWebApi/api/FrmAdmAbout_Indore/";
    String BASE_MASTERPLAN_1 = "http://103.21.54.53/IdaWebApi/api/MstMsterPlan/";
    String BASE_PostSendMail = "http://103.21.54.53/IdaWebApi/api/MstMailDtl/";
    String BASE_HeritageAllPhoto = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/";
    String BASE_HeritageId = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstHeritage/";
    String BASE_Notice_Circlular = "http://103.21.54.53/IdaWebApi/api/MstNoticeAndCircular/";
    String BASE_TENDER_DISCRIPATION = "http://103.21.54.53/IdaWebApi/api/MstTender/";
    String BASE_CEO_PROPOSAL = "http://103.21.54.53/IdaWebApi/api/FrmMstCeoProposal/";
    String BASE_NEWS_DROPDOWN = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/";
    String BASE_NEWS_YearMonth_Wise = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstNews/";
    String BASE_RTI_URL = "http://103.21.54.53/IdaWebApi/api/FrmAdmRTI/";
    String BASE_VVYAMNIYAM_URL = "http://103.21.54.53/IdaWebApi/api/MstVyyanNiyam/";
    String BASE_TELEPHONE_DIRECTORY = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstTeleDirectory/";
    String BASE_BUDGET_FILE = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstBudget/";
    String BASE_SCHEMES_TENDER = "http://103.21.54.53/IdaWebApi/api/FrmAdmMstSchemes/";
    String BASE_PAY_FilddlScheme = "http://103.21.54.53/IdaWebApi/api/Payment/";
    String BASE_PAYFOR_SearchDtl = "http://103.21.54.53/IdaWebApi/api/Payment/";              //SearchDtl?Refno=15900036&SchCode=%27%27&PlotNo=%27%27&Name=%27%27
    String BASE_PROPRTYHOLDER_DETAIL = "http://103.21.54.53/IdaWebApi/api/Payment/";
    String BASE_FAQ= "http://103.21.54.53/IdaWebApi/api/FrmAdmMstFAQ/";      */

/*
http://idawebsite.azurewebsites.net/api/MstVacantPlotDtl/fillDDL

        http://idawebsite.azurewebsites.net/api/MstVacantPlotDtl/VacantPlotDtl?IDASchNo=102

        http://idawebsite.azurewebsites.net/api/TenderIda/fillDDL
*/
/*

    FOR DEFAULTER LIST
        http://idawebsite.azurewebsites.net/api/CtrlDefaultersList/GetDefaulterList
*/
/*

    FOR SCHEME WISE ALLOTTEES

http://idawebsite.azurewebsites.net/api/SchemeWiseAlloteesList/fillDDL

        http://idawebsite.azurewebsites.net/api/SchemeWiseAlloteesList/AlloteesList?IDASchNo=78



        --	DOCUMENT ADVISOR

        --DDL
        http://idawebsite.azurewebsites.net/api/FrmAdmMstDoc/getServiceType

        --DOC LIST
        http://idawebsite.azurewebsites.net/api/FrmAdmMstDoc/getDocList?ServiceCode=7





        */


