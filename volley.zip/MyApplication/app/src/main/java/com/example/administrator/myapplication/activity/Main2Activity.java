package com.example.administrator.myapplication.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.administrator.myapplication.R;
import com.example.administrator.myapplication.model.Table1;
import com.example.administrator.myapplication.adapter.GithubAdapter2;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {

    ArrayList<Table1> table1ArrayList;
    GithubAdapter2 githubAdapter2;
    RecyclerView recyclerView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        recyclerView2 = findViewById(R.id.rView);
        recyclerView2.setHasFixedSize(true);
        recyclerView2.setLayoutManager(new LinearLayoutManager(Main2Activity.this));
        requestMethod();
    }
    private void requestMethod(){
        table1ArrayList = new ArrayList<>();

        StringRequest stringRequest2 = new StringRequest(Request.Method.GET, "http://idawebsite.azurewebsites.net/api/FrmAdmMstHeritage/GetDsHeritageAllPhoto",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                       try{
                           JSONObject object = new JSONObject(response);
                           JSONArray jsonArray=object.getJSONArray("Table2");


                           Log.e("RESPONSE",response);
                           for(int i=0;i<jsonArray.length();i++){
                               JSONObject jsonObject = jsonArray.getJSONObject(i);
                               String HeritId = jsonObject.getString("HeritId");
                               String HeritTitleE = jsonObject.getString("HeritTitleE");
                               String CoverPhotoPathMobile = jsonObject.getString("CoverPhotoPathMobile");

                               Log.e("ID",jsonObject.getString("HeritId"));
                               table1ArrayList.add(new Table1(HeritId, HeritTitleE, CoverPhotoPathMobile));
                               githubAdapter2 = new GithubAdapter2(Main2Activity.this, table1ArrayList);
                               // recyclerView1.setDivider(null);
                               recyclerView2.setAdapter(githubAdapter2);
                           }

                       } catch (JSONException e) {
                           e.printStackTrace();
                       }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Main2Activity.this, "No Internet Connection", Toast.LENGTH_LONG).show();
            }
        });

        stringRequest2.setRetryPolicy(new DefaultRetryPolicy(
                60000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest2);
    }
}
