
package com.example.administrator.myapplication.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class User {

    @SerializedName("OrgCode")
    @Expose
    private Integer orgCode;
    @SerializedName("CityCode")
    @Expose
    private Integer cityCode;
    @SerializedName("BoardMemCode")
    @Expose
    private Integer boardMemCode;
    @SerializedName("BoardMemNmE")
    @Expose
    private String boardMemNmE;
    @SerializedName("BoardMemNmH")
    @Expose
    private String boardMemNmH;
    @SerializedName("BoardMemDesgE")
    @Expose
    private String boardMemDesgE;
    @SerializedName("BoardMemDesgH")
    @Expose
    private String boardMemDesgH;
    @SerializedName("BoardMemMobile")
    @Expose
    private String boardMemMobile;
    @SerializedName("BoardMemPhone")
    @Expose
    private String boardMemPhone;
    @SerializedName("BoardMemEmail")
    @Expose
    private String boardMemEmail;
    @SerializedName("EntryDate")
    @Expose
    private String entryDate;
    @SerializedName("EntryUserCode")
    @Expose
    private Integer entryUserCode;
    @SerializedName("OrderBy")
    @Expose
    private Integer orderBy;
    @SerializedName("IsActive")
    @Expose
    private Integer isActive;
    @SerializedName("ImagePath")
    @Expose
    private String imagePath;

    public User(String boardMemNmE, String boardMemDesgE, String boardMemMobile, String boardMemPhone) {
        this.boardMemNmE=boardMemNmE  ;
        this.boardMemDesgE=boardMemDesgE  ;
        this.boardMemMobile=boardMemMobile  ;
        this.boardMemPhone=boardMemPhone  ;

    }

    public Integer getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(Integer orgCode) {
        this.orgCode = orgCode;
    }

    public Integer getCityCode() {
        return cityCode;
    }

    public void setCityCode(Integer cityCode) {
        this.cityCode = cityCode;
    }

    public Integer getBoardMemCode() {
        return boardMemCode;
    }

    public void setBoardMemCode(Integer boardMemCode) {
        this.boardMemCode = boardMemCode;
    }

    public String getBoardMemNmE() {
        return boardMemNmE;
    }

    public void setBoardMemNmE(String boardMemNmE) {
        this.boardMemNmE = boardMemNmE;
    }

    public String getBoardMemNmH() {
        return boardMemNmH;
    }

    public void setBoardMemNmH(String boardMemNmH) {
        this.boardMemNmH = boardMemNmH;
    }

    public String getBoardMemDesgE() {
        return boardMemDesgE;
    }

    public void setBoardMemDesgE(String boardMemDesgE) {
        this.boardMemDesgE = boardMemDesgE;
    }

    public String getBoardMemDesgH() {
        return boardMemDesgH;
    }

    public void setBoardMemDesgH(String boardMemDesgH) {
        this.boardMemDesgH = boardMemDesgH;
    }

    public String getBoardMemMobile() {
        return boardMemMobile;
    }

    public void setBoardMemMobile(String boardMemMobile) {
        this.boardMemMobile = boardMemMobile;
    }

    public String getBoardMemPhone() {
        return boardMemPhone;
    }

    public void setBoardMemPhone(String boardMemPhone) {
        this.boardMemPhone = boardMemPhone;
    }

    public String getBoardMemEmail() {
        return boardMemEmail;
    }

    public void setBoardMemEmail(String boardMemEmail) {
        this.boardMemEmail = boardMemEmail;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public Integer getEntryUserCode() {
        return entryUserCode;
    }

    public void setEntryUserCode(Integer entryUserCode) {
        this.entryUserCode = entryUserCode;
    }

    public Integer getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(Integer orderBy) {
        this.orderBy = orderBy;
    }

    public Integer getIsActive() {
        return isActive;
    }

    public void setIsActive(Integer isActive) {
        this.isActive = isActive;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

}


