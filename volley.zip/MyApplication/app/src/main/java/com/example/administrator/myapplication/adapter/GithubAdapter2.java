package com.example.administrator.myapplication.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.administrator.myapplication.R;
import com.example.administrator.myapplication.model.Table1;

import java.util.ArrayList;

public class GithubAdapter2 extends RecyclerView.Adapter<GithubAdapter2.TableViewHolder> {

    ArrayList<Table1> tabl;
    Context context;
    public GithubAdapter2(Context context,ArrayList<Table1> tabl){
        this.context=context;
        this.tabl=tabl;
    }
    @NonNull
    @Override
    public TableViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new GithubAdapter2.TableViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TableViewHolder holder, int position) {
        final Table1 singleUser = tabl.get(position);
       // holder.txtUser2.setText(String.valueOf(singleUser.getHeritId()));
        holder.txtUser2.setText(singleUser.getHeritTitleE());
        Glide.with(holder.imgTable.getContext()).load(singleUser.getCoverPhotoPathMobile()).into(holder.imgTable);

    }

    @Override
    public int getItemCount() {
        return tabl.size();
    }

    public class TableViewHolder extends RecyclerView.ViewHolder{
         ImageView imgTable;
        TextView txtUser2;
        public TableViewHolder(@NonNull View itemView) {
            super(itemView);
            txtUser2 = itemView.findViewById(R.id.txtTable);
            imgTable = itemView.findViewById(R.id.imgTable);
        }
    }
}
