
package com.example.administrator.myapplication.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Table1 {

    @SerializedName("HeritId")
    @Expose
    private String heritId;
    @SerializedName("HeritTitleE")
    @Expose
    private String heritTitleE;
    @SerializedName("HeritTitleH")
    @Expose
    private String heritTitleH;
    @SerializedName("HeritDescE")
    @Expose
    private String heritDescE;
    @SerializedName("HeritDescH")
    @Expose
    private String heritDescH;
    @SerializedName("CoverPhotoPath")
    @Expose
    private String coverPhotoPath;
    @SerializedName("CoverPhotoPathMobile")
    @Expose
    private String coverPhotoPathMobile;

    public Table1(String heritId, String heritTitleE, String coverPhotoPathMobile) {
        this.heritId=heritId;
        this.heritTitleE=heritTitleE;
        this.coverPhotoPathMobile=coverPhotoPathMobile;
    }

    public String getHeritId() {
        return heritId;
    }

    public void setHeritId(String heritId) {
        this.heritId = heritId;
    }

    public String getHeritTitleE() {
        return heritTitleE;
    }

    public void setHeritTitleE(String heritTitleE) {
        this.heritTitleE = heritTitleE;
    }

    public String getHeritTitleH() {
        return heritTitleH;
    }

    public void setHeritTitleH(String heritTitleH) {
        this.heritTitleH = heritTitleH;
    }

    public String getHeritDescE() {
        return heritDescE;
    }

    public void setHeritDescE(String heritDescE) {
        this.heritDescE = heritDescE;
    }

    public String getHeritDescH() {
        return heritDescH;
    }

    public void setHeritDescH(String heritDescH) {
        this.heritDescH = heritDescH;
    }

    public String getCoverPhotoPath() {
        return coverPhotoPath;
    }

    public void setCoverPhotoPath(String coverPhotoPath) {
        this.coverPhotoPath = coverPhotoPath;
    }

    public String getCoverPhotoPathMobile() {
        return coverPhotoPathMobile;
    }

    public void setCoverPhotoPathMobile(String coverPhotoPathMobile) {
        this.coverPhotoPathMobile = coverPhotoPathMobile;
    }
}
