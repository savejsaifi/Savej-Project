package com.example.administrator.myapplication.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.administrator.myapplication.R;
import com.example.administrator.myapplication.model.User;
import com.example.administrator.myapplication.adapter.GithubAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<User> userlist;
   // private static final String Url = "https://api.github.com/users";
    GithubAdapter mAdapter;
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView  = findViewById(R.id.userList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        loadspinner();
    }


    private void loadspinner() {
        userlist=new ArrayList<>();
        StringRequest stringRequest = new StringRequest(Request.Method.GET, "http://103.21.54.53/IdaWebApi/api/MstBoardMem/getBoardMemDtlNew?Ind=1",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject object = new JSONObject(response);
                            JSONArray marray=object.getJSONArray("Table");

                           Log.e("RESPONSE",response);

                            for (int i = 0; i < marray.length(); i++) {
                                JSONObject jsonObject = marray.getJSONObject(i);

                                String BoardMemNmE = jsonObject.getString("BoardMemNmE");

                                String BoardMemDesgE = jsonObject.getString("BoardMemDesgE");
                                String BoardMemMobile = jsonObject.getString("BoardMemMobile");
                                String BoardMemPhone = jsonObject.getString("BoardMemPhone");

                                userlist.add(new User(BoardMemNmE, BoardMemDesgE, BoardMemMobile, BoardMemPhone));
                              mAdapter = new GithubAdapter(MainActivity.this, userlist);
                                // recyclerView1.setDivider(null);
                                recyclerView.setAdapter(mAdapter);

                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(MainActivity.this, "No Internet Connection", Toast.LENGTH_LONG).show();

                    }
                }) {


        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                60000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
